/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import { connect } from "react-redux";
import { createPortal } from "react-dom";
import { ToastNotification, Modal, Loading } from "carbon-components-react";
import classnames from "classnames";
import PropTypes from "prop-types";
import { AppMsg, MessageTypes } from "../utils";
import { LayoutSelectors } from "../store";

const cssBase = "showAppMessages";

class ShowAppMessages extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    message: PropTypes.object,
    clearMessage: PropTypes.func,
    isLargeLayout: PropTypes.bool,
    retryExchangeAuthentication: PropTypes.func,
    cancelExchangeAuthentication: PropTypes.func,
    dir: PropTypes.string,
  };

  render() {
    const {
      message,
      clearMessage,
      isLargeLayout,
      retryExchangeAuthentication,
      cancelExchangeAuthentication,
      dir,
    } = this.props;
    return (
      <>
        {message != null &&
          message.kind === "modal" &&
          message.type === MessageTypes.SESSION_EXPIRED &&
          createPortal(
            <Modal
              className={`${cssBase}__modalSessionExpired`}
              modalHeading={
                this.props.appMessages[
                  AppMsg.ERRORS.SESSION_EXPIRED_ERROR_TITLE
                ]
              }
              modalAriaLabel={
                this.props.appMessages[
                  AppMsg.ERRORS.SESSION_EXPIRED_ERROR_TITLE
                ]
              }
              primaryButtonText={this.props.appMessages[AppMsg.BUTTON.REFRESH]}
              onRequestSubmit={this.handleRefreshClick}
              open
              size="xs"
              iconDescription={this.props.appMessages[AppMsg.BUTTON.CLOSE]}
            >
              <p>
                {
                  this.props.appMessages[
                    AppMsg.ERRORS.SESSION_EXPIRED_ERROR_DESCRIPTION
                  ]
                }
              </p>
            </Modal>,
            document.body
          )}

        {message != null &&
          message.kind === "modal" &&
          message.type === MessageTypes.EXCHANGE_AUTHENTICATION &&
          createPortal(
            <Modal
              className={`${cssBase}__modalExchangeAuthentication`}
              modalHeading={
                this.props.appMessages[AppMsg.EXCHANGE_AUTHENTICATION_HEADER]
              }
              modalAriaLabel={
                this.props.appMessages[AppMsg.EXCHANGE_AUTHENTICATION_HEADER]
              }
              passiveModal
              open
              size="xs"
              iconDescription={this.props.appMessages[AppMsg.BUTTON.CLOSE]}
            >
              <p>
                {
                  this.props.appMessages[
                    AppMsg.EXCHANGE_AUTHENTICATION_SUB_HEADER
                  ]
                }
              </p>
              <p>
                {this.props.appMessages[AppMsg.EXCHANGE_AUTHENTICATION_TEXT]}
              </p>
              <Loading
                className={`${cssBase}__modalLoading`}
                active
                withOverlay={false}
              />
            </Modal>,
            document.body
          )}

        {message != null &&
          message.kind === "modal" &&
          message.type === MessageTypes.POPUP_BLOCKED &&
          createPortal(
            <Modal
              className={`${cssBase}__modalPopupBlocked`}
              modalHeading={this.props.appMessages[AppMsg.POPUP_BLOCKED_HEADER]}
              modalAriaLabel={
                this.props.appMessages[AppMsg.POPUP_BLOCKED_HEADER]
              }
              open
              size="xs"
              primaryButtonText={
                this.props.appMessages[AppMsg.BUTTON.BUTTON_TRY_AGAIN]
              }
              secondaryButtonText={
                this.props.appMessages[AppMsg.BUTTON.BUTTON_BACK]
              }
              onRequestSubmit={retryExchangeAuthentication}
              onRequestClose={cancelExchangeAuthentication}
              onSecondarySubmit={cancelExchangeAuthentication}
              iconDescription={this.props.appMessages[AppMsg.BUTTON.CLOSE]}
            >
              <p>{this.props.appMessages[AppMsg.POPUP_BLOCKED_SUB_HEADER]}</p>
              <p>{this.props.appMessages[AppMsg.POPUP_BLOCKED_TEXT]}</p>
            </Modal>,
            document.body
          )}

        {message != null &&
          message.kind === "modal" &&
          message.type === MessageTypes.EXCHANGE_AUTHENTICATION_FAILED &&
          createPortal(
            <Modal
              className={`${cssBase}__modalAuthenticationFailed`}
              modalHeading={
                this.props.appMessages[AppMsg.EXCHANGE_AUTH_FAILED_HEADER]
              }
              modalAriaLabel={
                this.props.appMessages[AppMsg.EXCHANGE_AUTH_FAILED_HEADER]
              }
              open
              size="xs"
              primaryButtonText={
                this.props.appMessages[AppMsg.BUTTON.BUTTON_TRY_AGAIN]
              }
              secondaryButtonText={
                this.props.appMessages[AppMsg.BUTTON.BUTTON_BACK]
              }
              onRequestSubmit={retryExchangeAuthentication}
              onRequestClose={cancelExchangeAuthentication}
              onSecondarySubmit={cancelExchangeAuthentication}
              iconDescription={this.props.appMessages[AppMsg.BUTTON.CLOSE]}
            >
              <p>
                {this.props.appMessages[AppMsg.EXCHANGE_AUTH_FAILED_SUB_HEADER]}
              </p>
            </Modal>,
            document.body
          )}

        {message != null &&
          message.kind !== "modal" &&
          createPortal(
            <div dir={dir} className={`${cssBase}__notification`}>
              <ToastNotification
                className={classnames({
                  [`${cssBase}__toast`]: true,
                  [`${cssBase}__toast--large`]: isLargeLayout,
                })}
                kind={message.kind}
                dir={dir}
                title={message.title}
                statusIconDescription={message.title}
                subtitle={
                  <div>
                    <div>{message.subtitle1}</div>
                    <div>{message.subtitle2}</div>
                  </div>
                }
                key={"notification" + Math.floor(Math.random() * 1000)}
                caption={message.caption}
                hideCloseButton={message.hideCloseButton}
                lowContrast
                timeout={message.kind === "error" ? 0 : 5000}
                onCloseButtonClick={clearMessage}
                iconDescription={this.props.appMessages[AppMsg.BUTTON.CLOSE]}
              />
            </div>,
            document.body
          )}
      </>
    );
  }

  handleRefreshClick = () => {
    window.location.reload();
  };
}

const mapStateToProps = (state) => {
  return {
    dir: LayoutSelectors.dirSelector(state),
  };
};

export default withTriDictionary(connect(mapStateToProps, {})(ShowAppMessages));
