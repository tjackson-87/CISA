/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { createPortal } from "react-dom";
import { connect } from "react-redux";
import classnames from "classnames";
import { Route, Switch } from "react-router-dom";
import {
  getTriAppConfig,
  TriLoginApi,
  withTriDictionary,
} from "@tririga/tririga-react-components";
import {
  Loading,
  Header,
  HeaderName,
  HeaderMenuButton,
  HeaderContainer,
} from "carbon-components-react";

import { SideNav } from "carbon-addons-iot-react";
import {
  Calendar16,
  Devices16,
  EventSchedule16,
  Home20,
  Logout20,
} from "@carbon/icons-react";
import PropTypes from "prop-types";
import {
  ReservationListPage,
  MeetingReservationPage,
  WorkspaceReservationPage,
  OfficeReservationPage, // CISA
  EventDetailsPageSmall,
  RoomDetailsPageSmall,
  CateringListPageSmall,
  EquipmentListPageSmall,
  EquipmentDetailsPageSmall,
  ReservationCostSummaryPage,
  ColleagueReservationPageSmall,
} from "../pages";
import { ReservationSkeleton } from "../components";
import {
  AppMsg,
  Routes,
  ReservationTypes,
  MAIN_APP_CONTAINER_CLASSNAME,
  LayoutTypesConstants,
  isWorkplaceServicesAppHome,
  EventEmitter,
} from "../utils";
import {
  MessageSelectors,
  MessageActions,
  LoadingSelectors,
  ReservationActions,
  RouteActions,
  ExchangeActions,
  LocationSelectors,
  CurrentUserSelectors,
} from "../store";
import ShowAppMessages from "./ShowAppMessages";
import "./TririgaRoomReservationApp.scss";

const cssBase = MAIN_APP_CONTAINER_CLASSNAME;
export const TRIDATA_SESSION_STORAGE_KEY = "tridata-session";
const LOCATION_CONTEXT_TYPE = "selected";
const ROOM_RESERVATION_APP_PATH = "/app/tririgaRoomReservation";
const WORKPLACE_SERVICES_APP_PATH = "/p/web/workplaceServices";

class TririgaRoomReservationApp extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    loading: PropTypes.bool,
    message: PropTypes.object,
    clearMessage: PropTypes.func,
    initializeNewReservation: PropTypes.func.isRequired,
    navigateToHomePage: PropTypes.func.isRequired,
    retryExchangeAuthentication: PropTypes.func,
    cancelExchangeAuthentication: PropTypes.func,
    pathname: PropTypes.string,
    selectedBuilding: PropTypes.object,
    userLocale: PropTypes.string,
  };

  static defaultProps = {
    loading: false,
  };

  constructor(props) {
    super(props);
    // Remove this line to implement the desktop layout
    this.isLargeLayout =
      window.innerWidth > LayoutTypesConstants.MIN_LARGE_SCREEN_WIDTH &&
      window.innerHeight > LayoutTypesConstants.MIN_LARGE_SCREEN_WIDTH;
    this.isWorkplaceServicesAppHome = isWorkplaceServicesAppHome();
    this.isAutoEnter = false;
    EventEmitter.subscribe("appMenuFocus", (event) => {
      const element = document.getElementsByClassName("bx--header__action")[0];
      if (element) {
        element.focus();
      }
    });
  }

  state = { isSideNavExpanded: false };

  componentWillMount() {
    document.documentElement.lang = this.props.userLocale;
  }

  componentWillUnmount() {
    EventEmitter.unsubscribe("appMenuFocus");
  }

  render() {
    const { isSideNavExpanded } = this.state;
    const classes = classnames({
      [cssBase]: true,
      [`${cssBase}--large`]: this.isLargeLayout,
      [`${cssBase}--sideNavExpanded`]: isSideNavExpanded,
    });
    const {
      loading,
      message,
      clearMessage,
      retryExchangeAuthentication,
      cancelExchangeAuthentication,
      pathname,
    } = this.props;
    const links = [
      {
        icon: Home20,
        isEnabled: true,
        metaData: {
          label: AppMsg.getMessage(AppMsg.APP_HOME),
          onClick: () => {
            this.handleHomeClick();
          },
          onKeyDown: (e) => {
            if (e.key === "Enter") this.onMenuKeyDown("home");
          },
          element: "button",
        },
        linkContent: AppMsg.getMessage(AppMsg.APP_HOME),
        isActive: !this.isWorkplaceServicesAppHome && pathname === Routes.HOME,
      },
      {
        icon: Calendar16,
        isEnabled: this.isWorkplaceServicesAppHome,
        metaData: {
          label: this.props.appMessages[AppMsg.RESERVATION_LIST_PAGE_TITLE],
          onClick: () => {
            this.handleAgendaClick();
          },
          element: "button",
        },
        linkContent: this.props.appMessages[AppMsg.RESERVATION_LIST_PAGE_TITLE],
        isActive: pathname === Routes.HOME,
      },
      {
        icon: EventSchedule16,
        isEnabled: true,
        metaData: {
          label: AppMsg.getMessage(AppMsg.CREATE_NEW_MEETING),
          onClick: () => {
            this.handleCreateNewMeeting();
          },
          onKeyDown: (e) => {
            if (e.key === "Enter") this.onMenuKeyDown("meeting");
            if(this.isSideNavExpanded){
              this.setState({ isSideNavExpanded: false});
            }
          },
          /*
          onFocus: () => {
            if(!this.isSideNavExpanded){
              this.setState({ isSideNavExpanded: true });
              
            }
           
          },*/
          element: "button",
        },
        linkContent: AppMsg.getMessage(AppMsg.CREATE_NEW_MEETING),
        isActive: pathname === Routes.MEETING,
      },
      {
        icon: Calendar16,
        isEnabled: true,
        metaData: {
          label: AppMsg.getMessage(AppMsg.CREATE_NEW_WORKSPACE),
          onClick: () => {
            this.handleCreateNewWorkspace();
          },
          onKeyDown: (e) => {
            if (e.key === "Enter") this.onMenuKeyDown("workspace");
          },
          element: "button",
        },
        linkContent: AppMsg.getMessage(AppMsg.CREATE_NEW_WORKSPACE),
        isActive: pathname === Routes.WORKSPACE,
      },
      // CISA
      {
        icon: Devices16,
        isEnabled: true,
        metaData: {
          label: AppMsg.getMessage(AppMsg.CREATE_NEW_OFFICE),
          onClick: () => {
            this.handleCreateNewOffice();
          },
          onKeyDown: (e) => {
            if (e.key === "Enter") this.onMenuKeyDown("office");
          },
          /*
          onFocus: () => {
            if(!this.isSideNavExpanded){
              this.setState({ isSideNavExpanded: true });
              
            }},*/
          element: "button"
        },
        linkContent: AppMsg.getMessage(AppMsg.CREATE_NEW_OFFICE),
        isActive: pathname === Routes.OFFICE,
      },
      {
        icon: Logout20,
        isEnabled: true,
        metaData: {
          label: AppMsg.getMessage(AppMsg.APP_LOGOUT),
          onClick: () => {
            this.handleLogout();
          },
          onKeyDown: (e) => {
            if (e.key === "Enter") this.handleLogout(e);
          },
          element: "button",
        },
        linkContent: AppMsg.getMessage(AppMsg.APP_LOGOUT),
      },
    ];
    return (
      <div className={classes}>
        <HeaderContainer
          iconDescription={this.props.appMessages[AppMsg.BUTTON.CLOSE]}
          isSideNavExpanded={isSideNavExpanded}
          render={() => (
            <>
              <Header aria-label={this.props.appMessages[AppMsg.APP_TITLE]}>
                <HeaderMenuButton
                  aria-label={
                    isSideNavExpanded
                      ? this.props.appMessages[AppMsg.CLOSE_MENU]
                      : this.props.appMessages[AppMsg.OPEN_MENU]
                  }
                  isCollapsible
                  onClick={() => {
                    this.toggleSideNav();
                  }}
                  
                  onFocus={() => {
                    this.setState({ isSideNavExpanded: true });
                  }} 
                
                  isActive={isSideNavExpanded}
                />
                <HeaderName prefix="CISA"> 
                  {this.props.appMessages[AppMsg.APP_TITLE]} 
                </HeaderName>
              </Header>
              <SideNav links={links} isSideNavExpanded={isSideNavExpanded} />
            </>
          )}
        />
        <Switch>
          <Route path={Routes.MEETING}>
            {({ match }) => (
              <MeetingReservationPage match={match} smallLayout={true} />
            )}
          </Route>
          <Route path={Routes.WORKSPACE}>
            {({ match }) => (
              <WorkspaceReservationPage match={match} smallLayout={true} />
            )}
          </Route>
          { /*CISA*/ }
          <Route path={Routes.OFFICE}>
            {({ match }) => (
              <OfficeReservationPage match={match} smallLayout={true} />
            )}
          </Route>
          <Route
            exact
            path={`${Routes.EVENT_DETAILS}/:eventId${Routes.SPACE_DETAILS}/:roomId${Routes.EQUIPMENT}/:equipmentId`}
          >
            <EquipmentDetailsPageSmall />
          </Route>
          <Route
            exact
            path={`${Routes.EVENT_DETAILS}/:eventId${Routes.SPACE_DETAILS}/:roomId${Routes.EQUIPMENT}`}
          >
            <EquipmentListPageSmall />
          </Route>
          <Route
            path={`${Routes.EVENT_DETAILS}/:eventId${Routes.SPACE_DETAILS}/:roomId${Routes.CATERING}`}
          >
            <CateringListPageSmall />
          </Route>
          <Route path={`${Routes.EVENT_DETAILS}/:eventId/:start/:end`}>
            <EventDetailsPageSmall />
          </Route>
          <Route
            exact
            path={`${Routes.EVENT_DETAILS}${Routes.SPACE_DETAILS}/:roomId`}
          >
            <RoomDetailsPageSmall />
          </Route>
          <Route path={`${Routes.EDIT_RESERVATION}/:reservationId`}>
            <ReservationSkeleton />
          </Route>
          <Route path={`${Routes.EDIT_EVENT}/:eventId`}>
            <ReservationSkeleton />
          </Route>
          <Route
            path={`${Routes.COST_SUMMARY}/:reservationId/:editMode/:start/:end`}
          >
            <ReservationCostSummaryPage />
          </Route>
          <Route path={`${Routes.COLLEAGUE_RESERVATION}/:colleagueId`}>
             <ColleagueReservationPageSmall />
           </Route>
          <Route path={Routes.HOME}>
            <ReservationListPage smallLayout={true} />
          </Route>
        </Switch>
        <ShowAppMessages
          message={message}
          clearMessage={clearMessage}
          isLargeLayout={this.isLargeLayout}
          retryExchangeAuthentication={retryExchangeAuthentication}
          cancelExchangeAuthentication={cancelExchangeAuthentication}
        />
        {createPortal(<Loading active={loading} withOverlay />, document.body)}
      </div>
    );
  }

  toggleSideNav = (keyPress = false) => {
    if (keyPress) {
      this.setState({ isSideNavExpanded: false });  
    } else {
      if (!this.isAutoEnter)
        this.setState({ isSideNavExpanded: !this.state.isSideNavExpanded });
    }
  };

  handleHomeClick = () => {
    const { navigateToHomePage } = this.props;
    this.toggleSideNav();
    if (this.isWorkplaceServicesAppHome) {
      this.navigateToWorkplaceServicesApp();
    } else {
      navigateToHomePage();
    }
  };

  navigateToWorkplaceServicesApp = () => {
    const URL_LOCATION = window.location;
    const CONTEXT_PATH = URL_LOCATION.pathname.substring(
      0,
      URL_LOCATION.pathname.lastIndexOf(ROOM_RESERVATION_APP_PATH)
    );
    const URL_PROTOCOL = URL_LOCATION.protocol;
    const URL_HOST = URL_LOCATION.host;
    this.saveUserSelectedBuildingIdToStorage();
    URL_LOCATION.assign(
      `${URL_PROTOCOL}//${URL_HOST}${CONTEXT_PATH}${WORKPLACE_SERVICES_APP_PATH}`
    );
  };

  saveUserSelectedBuildingIdToStorage = () => {
    const { selectedBuilding } = this.props;
    if (selectedBuilding) {
      try {
        localStorage.setItem(
          TRIDATA_SESSION_STORAGE_KEY,
          JSON.stringify({
            locationContextSelectedBuildingId: selectedBuilding._id,
            locationContextType: LOCATION_CONTEXT_TYPE,
          })
        );
      } catch (error) {}
    }
  };

  removeUserSelectedBuildingIdFromStorage = () => {
    try {
      localStorage.removeItem(TRIDATA_SESSION_STORAGE_KEY);
    } catch (error) {}
  };

  handleCreateNewMeeting = () => {
    this.toggleSideNav();
    this.props.initializeNewReservation(ReservationTypes.MEETING, true);
  };

  handleCreateNewWorkspace = () => {
    this.toggleSideNav();
    this.props.initializeNewReservation(ReservationTypes.WORKSPACE, true);
  };
  // CISA
  handleCreateNewOffice= () => {
    this.toggleSideNav();
    this.props.initializeNewReservation(ReservationTypes.OFFICE, true);
  };

  handleAgendaClick = () => {
    this.toggleSideNav();
    this.props.navigateToHomePage();
  };

  handleLogout = async () => {
    this.toggleSideNav();
    this.removeUserSelectedBuildingIdFromStorage();
    await TriLoginApi.logout();
    const { sso } = getTriAppConfig();
    if (!sso) {
      window.location.reload();
    }
  };

  onMenuKeyDown = (type) => {
    this.isAutoEnter = true;
    switch (type) {
      case "home":
        this.toggleSideNav(true);
        EventEmitter.dispatch("agendaCreateMeetingFocus", true);
        if (this.isWorkplaceServicesAppHome) {
          this.navigateToWorkplaceServicesApp();
        } else {
          navigateToHomePage();
        }
        break;
      case "meeting":
        this.toggleSideNav(true);
        this.props.initializeNewReservation(ReservationTypes.MEETING, true);
        break;
      case "workspace":
        this.toggleSideNav(true);
        this.props.initializeNewReservation(ReservationTypes.WORKSPACE, true);
        break;
      default:
    }
    setTimeout(() => {
      this.isAutoEnter = false;
    }, 500);
  };
}

const mapStateToProps = (state) => {
  return {
    pathname: state.router.location.pathname,
    loading: LoadingSelectors.mainLoadingSelector(state),
    smallLayout: state.layout.small,
    message: MessageSelectors.messageSelector(state),
    selectedBuilding: LocationSelectors.selectedBuildingSelector(state),
    userLocale: CurrentUserSelectors.localeSelector(state),
  };
};

const { clearMessage } = MessageActions;
const { initializeNewReservation } = ReservationActions;
const { navigateToHomePage } = RouteActions;

const {
  retryExchangeAuthentication,
  cancelExchangeAuthentication,
} = ExchangeActions;

export default withTriDictionary(
  connect(mapStateToProps, {
    clearMessage,
    initializeNewReservation,
    navigateToHomePage,
    retryExchangeAuthentication,
    cancelExchangeAuthentication,
  })(TririgaRoomReservationApp)
);
