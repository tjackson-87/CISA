/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import {
  DataTable,
  DataTableSkeleton,
  Table,
  TableHead,
  TableRow,
  TableHeader,
  TableBody,
  TableCell,
  Loading
} from 'carbon-components-react';
import debounce from "lodash/debounce";
import isEmpty from "lodash/isEmpty";
import { Bee16 } from "@carbon/icons-react";
import { PropTypes} from "prop-types";
import { AppMsg} from "../../utils";
import {LOCATION_TABLE_HEADERS, LOCATION_TABLE_HEADERS_LOADING} from "../../utils/constants/DataTableHeaders";

const cssBase = "locationSearchTable";

class LocationSearchTable extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    id: PropTypes.string,
    open: PropTypes.bool,
    searchText: PropTypes.string,
    buildings: PropTypes.array,
    loading: PropTypes.bool,
    loadingMore: PropTypes.bool,
    onSelect: PropTypes.func,
    onSearchMore: PropTypes.func,
    headers: PropTypes.array
  };

  static defaultProps = {
    open: true,
    headers: LOCATION_TABLE_HEADERS,
    loadingHeaders: LOCATION_TABLE_HEADERS_LOADING,
    useZebraStyles: true,
    stickyHeader: true,
    showHeader: false,
    showToolbar: false,
    loadingColumnCount: 5,
    rowSize: 'lg'
  };

  render() {
    return (
      <div>
        {this.renderTable()}
        {this.renderEmptyMessage()}
        {this.renderLoading()}
        {this.renderLoadingMore()}
      </div>
    );
  }

  constructor(props) {
    super(props);
    this.debonuceOnSearchMore = debounce(this.props.onSearchMore, 100, { 'maxWait': 500 });
  }

  renderTable(){
    const {open, loading, buildings, headers, useZebraStyles, rowSize, stickyHeader} = this.props;
    if(open && !loading){
      return (
        <div>
          <DataTable size={rowSize} className={`${cssBase}__Table`}  rows={buildings} useZebraStyles={useZebraStyles} headers={headers} stickyHeader={stickyHeader}>
            {({ rows, headers, getTableProps, getHeaderProps, getRowProps }) => (
              <Table onScroll={this.handleOnScroll} {...getTableProps()}>
                <TableHead>
                  <TableRow>
                    {headers.map((header) => (
                      <TableHeader {...getHeaderProps({ header, isSortable: true })}>
                        {header.header}
                      </TableHeader>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {rows.map((row) => (
                      <TableRow className={`${cssBase}__TableRow`} building-id={row.id} onClick={this.handleOptionClick} {...getRowProps({ row})}>
                        {row.cells.map((cell) => (
                          <TableCell key={cell.id}>{cell.value}</TableCell>
                        ))}
                      </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </DataTable>
        </div>
      );
    } else {
      return null;
    }
  }

  renderLoading() {
    const { loading, open, loadingHeaders, showHeader, showToolbar, loadingColumnCount} = this.props;
    if (open && loading) {
      return (
        <div className={`${cssBase}__loading`}>
           <DataTableSkeleton headers={loadingHeaders} showHeader={showHeader} showToolbar={showToolbar} columnCount={loadingColumnCount} aria-label="Buildings Table" />
        </div>
      );
    }
    return null;
  }

  renderLoadingMore() {
    const { loadingMore, open} = this.props;
    if (open && loadingMore) {
      return <Loading className={'some-class'} withOverlay={true} />;
    }
    return null;
  }

  renderEmptyMessage() {
    const { loading, buildings, searchText, open } = this.props;
    if (open && !loading && isEmpty(buildings)) {
      return (
        <div className={`${cssBase}__empty`}>
          <Bee16 className={`${cssBase}__emptyIcon`} />
          <div>{`${
            this.props.appMessages[AppMsg.RESERVATION_MESSAGE.NO_MACTHES_FOUND]
          } ${searchText}`}</div>
        </div>
      );
    }
    return null;
  }

  handleOptionClick = (event) => {
    const { onSelect, buildings} = this.props;
    if (onSelect != null) {
      const id = Number(
        event.currentTarget.getAttribute("building-id")
      );
      let buildingIndex = buildings.findIndex(element => element.id === id.toString())
      onSelect(buildings[buildingIndex]);
    }
  };

  handleOnScroll = (event) => {
    if (event.target.offsetHeight + event.target.scrollTop >= (event.target.scrollHeight * 0.75)) {
      this.debonuceOnSearchMore();
    }
  }

  componentDidUpdate() {
  }

}

export default withTriDictionary(LocationSearchTable);
