/* IBM Confidential· - OCO Source Materials· - (C) COPYRIGHT IBM CORP. 2023 - The source code for this program is not published or otherwise· divested of its trade secrets, irrespective of what has been· deposited with the U.S. Copyright Office. */

import React from "react";
import { screen } from "@testing-library/react";
import UserCard from "../UserCard";
import { AppMsg } from "../../../utils";
import { renderWithTriDictionaryProvider } from "../../../testUtils";

afterEach(() => jest.clearAllMocks());
describe("UserCard", () => {
  let props, appMessages, calendar, onChangeUserClicked;
  beforeEach(() => {
    calendar = {
      id: "some-exchange-id",
      changeKey: "0PIjfK7rqEa/9aZutOkb0wAAS6HNHg==",
      name: "Yong",
      email: "yong@Tririga01.onmicrosoft.com",
      isDefaultCalendar: true,
      image: null,
      isValidInTririga: true,
      userProfileId: "139941196",
    };
    onChangeUserClicked = jest.fn();
    const showChangeUser = true;
    const changeDelegateRef = React.createRef();
    appMessages = AppMsg.getAppMessages();
    props = {
      calendar,
      onChangeUserClicked,
      showChangeUser,
      changeDelegateRef,
    };
  });

  it("renders correctly", () => {
    renderWithTriDictionaryProvider(<UserCard {...props} />, { appMessages });
    const calendarName = screen.getByTestId("name");
    const calendarEmail = screen.getByTestId("email");
    const changeButton = screen.getByRole("button");
    const initialName = screen.getByTestId("initial");
    expect(calendarName).toBeInTheDocument();
    expect(calendarEmail).toBeInTheDocument();
    expect(changeButton).toBeInTheDocument();
    expect(initialName).toBeInTheDocument();
    expect(initialName.textContent).toEqual(calendar.name[0].toUpperCase());
  });

  it("displays initial capital letter of first and last  when calendar has a full name", () => {
    const expectedInitial = "JS";
    calendar.name = "john snow";
    renderWithTriDictionaryProvider(<UserCard {...props} />, { appMessages });
    const calendarName = screen.getByTestId("initial");
    expect(calendarName.textContent).toEqual(expectedInitial);
    expect(calendarName).toBeInTheDocument();
  });

  it("hides change user button when showChangeUser is false", () => {
    props.showChangeUser = false;
    renderWithTriDictionaryProvider(<UserCard {...props} />, { appMessages });
    const changeUserButton = screen.queryByRole("button");
    expect(changeUserButton).not.toBeInTheDocument();
  });

  it("handles when button is focused and flatpickr-calendar is not null", () => {
    const getElementsByClassName = document.getElementsByClassName;
    document.getElementsByClassName = jest.fn();
    document.getElementsByClassName.mockReturnValue([
      { classList: { contains: () => {}, remove: () => {} } },
      { classList: { contains: () => {}, remove: () => {} } },
    ]);
    renderWithTriDictionaryProvider(<UserCard {...props} />, { appMessages });
    const button = screen.getByRole("button");
    button.focus();
    expect(document.getElementsByClassName).toBeCalled();
    document.getElementsByClassName = getElementsByClassName;
  });
});
