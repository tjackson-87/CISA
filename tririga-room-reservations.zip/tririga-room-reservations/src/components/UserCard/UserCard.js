/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import PropTypes from "prop-types";
import { withTriDictionary } from "@tririga/tririga-react-components";
import isEmpty from "lodash/isEmpty";
import classNames from "classnames";

import { AppMsg } from "../../utils";
import { Button } from "carbon-components-react";
import { calendarDetails } from "../../utils/reservation/ReservationUtils";

const cssBase = "userCard";

class UserCard extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    calendar: PropTypes.object,
    onChangeUserClicked: PropTypes.func,
    showChangeUser: PropTypes.bool,
    changeDelegateRef: PropTypes.any,
    isColleague: PropTypes.bool,
  };

  render() {
    const {
      calendar,
      onChangeUserClicked,
      showChangeUser,
      changeDelegateRef,
      isColleague,
    } = this.props;
    return calendar ? (
      <div
        className={classNames(
          cssBase,
          isColleague ? `${cssBase}__colleagueCard` : ""
        )}
      >
        <div
          className={classNames(
            `${cssBase}__imageContainer`,
            isColleague ? `${cssBase}__imageContainerColleague` : ""
          )}
        >
          {calendar.image && (
            <img
              className={`${cssBase}__image`}
              src={calendar.image}
              alt={this.props.appMessages[AppMsg.CALENDAR_OWNER]}
            />
          )}
          {!calendar.image && (
            <div data-testid="initial" className={`${cssBase}__nameInitials`}>
              {this.computeInitials(calendar.name)}
            </div>
          )}
        </div>
        <div className={`${cssBase}__details`}>
          <div
            className={`${cssBase}__nameAndEmailContainer`}
            tabIndex={0}
            aria-label={!isColleague ? calendarDetails(calendar) : ""}
          >
            <div data-testid="name" className={`${cssBase}__nameContainer`}>
              {calendar.name}
            </div>
            {isColleague && (
              <>
                <div className={`${cssBase}__emailContainer`}>
                  {calendar.title}
                </div>
                <div className={`${cssBase}__emailContainer`}>
                  {calendar.orgName}
                </div>
              </>
            )}
            <div data-testid="email" className={`${cssBase}__emailContainer`}>
              {calendar.email}
            </div>
          </div>
          {showChangeUser && (
            <div className={`${cssBase}__change`}>
              <Button
                kind="ghost"
                size="field"
                ref={changeDelegateRef}
                onClick={onChangeUserClicked}
                aria-label={AppMsg.getMessage(AppMsg.CHANGE_USER_CALENDAR)}
                onFocus={this.handleFocus}
              >
                {this.props.appMessages[AppMsg.CHANGE_USER]}
              </Button>
            </div>
          )}
        </div>
      </div>
    ) : null;
  }

  computeInitials(displayName) {
    displayName = displayName.split(/(\s).+\s/).join("");
    const [firstName, lastName] = displayName.split(" ");
    if (!isEmpty(firstName) && !isEmpty(lastName)) {
      return `${firstName
        .toUpperCase()
        .charAt(0)}${lastName.toUpperCase().charAt(0)}`;
    } else {
      return displayName.toUpperCase().charAt(0);
    }
  }

  handleFocus() {
    if (document.getElementsByClassName("flatpickr-calendar") !== null) {
      const ele = document.getElementsByClassName("flatpickr-calendar");
      ele.forEach((el) => {
        el.classList.remove("open");
        el.classList.remove("close");
      });
    }
  }
}

export default withTriDictionary(UserCard);
