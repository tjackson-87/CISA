/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import { connect } from "react-redux";
import { withTriDictionary } from "@tririga/tririga-react-components";
import Button from "@mui/material/Button";
import ButtonGroup from "@mui/material/ButtonGroup";
import ArrowDropDownIcon from "@mui/icons-material/ArrowDropDown";
import ClickAwayListener from "@mui/material/ClickAwayListener";
import Grow from "@mui/material/Grow";
import Paper from "@mui/material/Paper";
import Popper from "@mui/material/Popper";
import MenuItem from "@mui/material/MenuItem";
import MenuList from "@mui/material/MenuList";
import PropTypes from "prop-types";
import { AppMsg } from "../../utils";
import classNames from "classnames";
import {
  RoomSearchActions,
  RoomDetailsActions,
  RoomSearchSelectors,
} from "../../store";
import RoomDetailsPageSmall from "../../pages/RoomDetails/RoomDetailsPageSmall";

const cssBase = "roomSearchFooterButttons";

class RoomSearchFooterButttons extends React.PureComponent {
  constructor(props) {
    super(props);
    this.anchorRef = React.createRef();
    this.dropDownButtonRef = React.createRef();
    this.state = {
      isOpen: false,
      selectedRoomId: null,
      groupedSelectedRooms: {},
      roomData: {},
      selectedIndex: -1,
      roomDetailsPageModel: false,
    };
    this.handleMenuKeyDown = this.handleMenuKeyDown.bind(this);
  }

  static propTypes = {
    appMessages: PropTypes.object,
    selectedRooms: PropTypes.array,
    clickHandler: PropTypes.func,
    primaryDisabled: PropTypes.bool,
    setRoomDetailsModal: PropTypes.func,
    setRoomId: PropTypes.func,
    isRoomSearchButtons: PropTypes.bool,
    onDelete: PropTypes.func,
    toggleModal: PropTypes.func,
  };

  handleMenuItemClick = (roomId, room) => {
    const { setRoomDetailsModal, setRoomId } = this.props;

    this.setState({
      isOpen: false,
      selectedRoomId: roomId,
      roomData: room,
      roomDetailsPageModel: true,
    });
    this.props.toggleModal();
    setRoomId(room._id);
    setRoomDetailsModal(true);
  };

  onClosePopUp = () => {
    const { setRoomDetailsModal } = this.props;
    this.props.toggleModal();
    this.setState({ roomDetailsPageModel: false });
    setRoomDetailsModal(false);
    setTimeout(() => {
      if (this.dropDownButtonRef && this.dropDownButtonRef.current) {
        this.dropDownButtonRef.current.focus();
      }
    }, 1);
  };

  handleToggle = () => {
    const groupedMenuItems = this.props.selectedRooms.reduce(
      (grouped, item) => {
        if (!grouped[item.building]) {
          grouped[item.building] = [];
        }
        grouped[item.building].push(item);
        return grouped;
      },
      {}
    );
    const groupedArrayItems = Object.keys(groupedMenuItems).map((group) => {
      return {
        groupName: group,
        items: groupedMenuItems[group],
      };
    });

    const menuItems = groupedArrayItems.reduce((acc, group, index) => {
      acc.push(
        <MenuItem key={group.groupName} disabled>
          {group.groupName}
        </MenuItem>
      );

      group.items.forEach((item, itemIndex) => {
        acc.push(
          <MenuItem
            key={item.roomId}
            selected={index === this.state.selectedIndex && itemIndex === 0}
            onClick={(event) => this.handleMenuItemClick(item.roomId, item)}
            onKeyDown={(e) =>
              e.key === "Enter"
                ? this.handleMenuItemClick(item.roomId, item)
                : false
            }
          >
            {item.roomId + "," + item.name}
          </MenuItem>
        );
      });

      return acc;
    }, []);

    this.setState({
      isOpen: !this.state.isOpen,
      groupedSelectedRooms: menuItems,
    });
  };

  handleDelete = () => {
    this.props.onDelete(this.state.roomData, false);
    this.onClosePopUp();
  };

  handleClose = (event) => {
    this.setState({ isOpen: false });
  };

  handleMenuKeyDown(event) {
    const { groupedSelectedRooms, selectedIndex } = this.state;
    if (event.keyCode === 38) {
      // up arrow
      event.preventDefault();
      const newSelectedIndex =
        selectedIndex > 0 ? selectedIndex - 1 : groupedSelectedRooms.length - 1;
      this.setState({ selectedIndex: newSelectedIndex });
    } else if (event.keyCode === 40) {
      // down arrow
      event.preventDefault();
      const newSelectedIndex =
        selectedIndex < groupedSelectedRooms.length - 1 ? selectedIndex + 1 : 0;
      this.setState({ selectedIndex: newSelectedIndex });
    } else if (event.key === "Tab") {
      event.preventDefault();
      this.setState({ isOpen: false });
    }
  }

  render() {
    const { selectedRooms, clickHandler, primaryDisabled } = this.props;
    const { roomDetailsPageModel } = this.state;
    return (
      <div className={cssBase}>
        {roomDetailsPageModel && (
          <RoomDetailsPageSmall
            onClosePopUp={() => this.onClosePopUp()}
            onDelete={() => this.handleDelete()}
            isRoomSearchButton={true}
          />
        )}
        <div>
          <ButtonGroup
            className={`${cssBase}__groupButton`}
            variant="contained"
            ref={this.anchorRef}
            aria-label="select button"
            data-testid="group"
          >
            <Button
              className={classNames(
                `${cssBase}__button`,
                `${cssBase}__button_left`
              )}
              onClick={clickHandler}
              disabled={primaryDisabled}
              data-testid="select"
              disableFocusRipple
              disableTouchRipple
            >
              <span>
                {`${this.props.appMessages[AppMsg.BUTTON.CONTINUE]} (${
                  selectedRooms.length
                })`}
              </span>
            </Button>
            <Button
              className={`${cssBase}__button`}
              size="small"
              aria-controls={
                this.state.isOpen ? "split-button-menu" : undefined
              }
              aria-expanded={this.state.isOpen ? "true" : undefined}
              aria-label="menu button"
              aria-haspopup="menu"
              onClick={this.handleToggle}
              data-testid="dropdown"
              disableFocusRipple
              disableTouchRipple
              ref={this.dropDownButtonRef}
              disabled={primaryDisabled}
            >
              <ArrowDropDownIcon />
            </Button>
          </ButtonGroup>
          <Popper
            sx={{
              zIndex: 1,
            }}
            open={this.state.isOpen}
            anchorEl={this.anchorRef.current}
            role={undefined}
            transition
            disablePortal
          >
            {({ TransitionProps, placement }) => (
              <Grow
                {...TransitionProps}
                style={{
                  transformOrigin:
                    placement === "bottom" ? "center top" : "center bottom",
                }}
              >
                <Paper>
                  <ClickAwayListener onClickAway={this.handleClose}>
                    <MenuList
                      id="grouped-menu-button"
                      data-testid="menulist"
                      onKeyDown={this.handleMenuKeyDown}
                      autoFocus={true}
                      aria-labelledby="grouped-menu-button"
                    >
                      {this.state.groupedSelectedRooms}
                    </MenuList>
                  </ClickAwayListener>
                </Paper>
              </Grow>
            )}
          </Popper>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    isRoomModalOpen: RoomSearchSelectors.roomModalSelector(state),
  };
};

export default withTriDictionary(
  connect(mapStateToProps, {
    setRoomDetailsModal: RoomSearchActions.setRoomDetailsModal,
    setRoomId: RoomDetailsActions.setRoomId,
  })(RoomSearchFooterButttons)
);
