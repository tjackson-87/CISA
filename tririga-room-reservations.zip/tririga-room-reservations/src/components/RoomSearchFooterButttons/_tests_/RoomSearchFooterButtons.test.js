/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import "mutationobserver-shim";
import { screen, fireEvent, waitFor } from "@testing-library/react";
import { AppMsg, ReservationTypes } from "../../../utils";
import {
  createReservableRoom,
  createReservationParam,
  createResource,
  renderWithReduxAndDictionaryProvider,
} from "../../../testUtils";
import RoomSearchFooterButttons from "../RoomSearchFooterButttons";
import {
  RoomDetailsActions,
  RoomSearchActions,
  getAppStore,
} from "../../../store";

import { reservationReducer } from "../../../store/reducers/ReservationReducer";

afterEach(() => jest.clearAllMocks());

function MockedRoomDetailsPage({
  // eslint-disable-next-line react/prop-types
  onClosePopUp,
  // eslint-disable-next-line react/prop-types
  onDelete,
}) {
  return (
    <div data-testid="roomDetailsPage">
      <button onClick={onClosePopUp}>room Details close</button>
      <button onClick={onDelete}>room Detail Delete</button>
    </div>
  );
}

jest.mock("../../../pages/RoomDetails/RoomDetailsPageSmall", () => {
  return MockedRoomDetailsPage;
});

RoomSearchActions.setRoomDetailsModal.mockImplementation(() => jest.fn());
RoomDetailsActions.setRoomId.mockImplementation(() => jest.fn());

jest.mock("../../../store/actions/CurrentUserActions");
jest.mock("../../../store/actions/ReservationActions");
jest.mock("../../../store/actions/RoomSearchActions");
jest.mock("../../../store/actions/RoomDetailsActions");
jest.mock("../../../store/actions/LocationActions");

describe("RoomSearchFooterButton", () => {
  let props,
    appMessages,
    selectedRooms,
    clickHandler,
    primaryDisabled,
    fakeRoom,
    reservationParam,
    resource,
    initialReservationState,
    initialRoomDetailsState,
    toggleModal,
    onDelete;

  describe("Readonly RoomSearchFooterButton", () => {
    beforeEach(() => {
      fakeRoom = createReservableRoom("Spider-man", "Marvel", 1);
      reservationParam = createReservationParam();
      resource = createResource(fakeRoom);
      appMessages = AppMsg.getAppMessages();
      props = {};
      initialReservationState = {
        ...getAppStore().getState.reservation,
        data: {
          ...reservationParam,
        },
        type: ReservationTypes.WORKSPACE,
        selectedResource: resource,
      };

      initialRoomDetailsState = {
        ...getAppStore().getState.roomDetails,
        data: fakeRoom,
        roomId: 1,
        contactRoles: [],
      };

      const initialState = {
        ...getAppStore().getState(),
        reservation: initialReservationState,
        roomDetails: initialRoomDetailsState,
        roomSearch: {
          ...getAppStore().getState.roomSearch,
          isRoomModalOpen: true,
        },
      };

      appMessages = AppMsg.getAppMessages();
      clickHandler = jest.fn();
      toggleModal = jest.fn();
      onDelete = jest.fn();
      primaryDisabled = true;
      selectedRooms = [];
      props = {
        appMessages,
        selectedRooms,
        clickHandler,
        primaryDisabled,
        toggleModal,
        onDelete,
      };

      renderWithReduxAndDictionaryProvider(
        <RoomSearchFooterButttons {...props} />,
        {
          initialState,
          reducer: reservationReducer,
        },
        appMessages
      );
    });

    it("should render ButtonGroup with two buttons", () => {
      const buttonGroup = screen.getByTestId("group");

      const selectButton = screen.getByTestId("select");
      const dropDownButton = screen.getByTestId("dropdown");

      expect(buttonGroup).toBeInTheDocument();
      expect(selectButton).toBeInTheDocument();
      expect(dropDownButton).toBeInTheDocument();
    });

    it("should render buttons as disabled when selected rooms length is zero", () => {
      const selectButton = screen.getByTestId("select");
      expect(selectButton.textContent).toEqual("Continue (0)");
      expect(selectButton.disabled).toBe(true);
    });

    it("should set the dropdown value as no workspace added yet when selected rooms length is zero", () => {
      const dropDownButton = screen.getByTestId("dropdown");
      fireEvent.click(dropDownButton);
      const noWorkpsacesSelected = screen.getByText(
        appMessages[AppMsg.NO_WORKSPACES_ADDED_YET]
      );

      expect(noWorkpsacesSelected).toBeInTheDocument();
    });
  });

  describe("RoomSearchFooterButton renders correctly", () => {
    beforeEach(() => {
      fakeRoom = createReservableRoom("Spider-man", "Marvel", 1);
      reservationParam = createReservationParam();
      resource = createResource(fakeRoom);
      appMessages = AppMsg.getAppMessages();
      props = {};
      initialReservationState = {
        ...getAppStore().getState.reservation,
        data: {
          ...reservationParam,
        },
        type: ReservationTypes.WORKSPACE,
        selectedResource: resource,
      };

      initialRoomDetailsState = {
        ...getAppStore().getState.roomDetails,
        data: fakeRoom,
        roomId: 1,
        contactRoles: [],
      };

      const initialState = {
        ...getAppStore().getState(),
        reservation: initialReservationState,
        roomDetails: initialRoomDetailsState,
        roomSearch: {
          ...getAppStore().getState.roomSearch,
          isRoomModalOpen: true,
        },
      };

      appMessages = AppMsg.getAppMessages();
      clickHandler = jest.fn();
      toggleModal = jest.fn();
      onDelete = jest.fn();
      primaryDisabled = false;
      selectedRooms = [
        {
          roomId: 1002121,
          name: "10.1047B",
          _id: "127379372",
        },
        {
          roomId: 2,
          name: "room2",
          _id: "127379370",
        },
      ];

      props = {
        appMessages,
        selectedRooms,
        clickHandler,
        primaryDisabled,
        toggleModal,
        onDelete,
      };

      renderWithReduxAndDictionaryProvider(
        <RoomSearchFooterButttons {...props} />,
        {
          initialState,
          reducer: reservationReducer,
        },
        appMessages
      );
    });

    it("should display the selected rooms in the dropdown", () => {
      const dropDownButton = screen.getByTestId("dropdown");
      fireEvent.click(dropDownButton);
      const option1 = screen.getByText(
        selectedRooms[0].roomId + "," + selectedRooms[0].name
      );
      const option2 = screen.getByText(
        selectedRooms[1].roomId + "," + selectedRooms[1].name
      );

      expect(option1).toBeInTheDocument();
      expect(option2).toBeInTheDocument();
    });

    it("Should call onClick function when select button is clicked", () => {
      const selectButton = screen.getByTestId("select");
      fireEvent.click(selectButton);
      expect(props.clickHandler).toHaveBeenCalled();
    });

    it("should render buttons as enabled when selected rooms length is greater then zero", () => {
      const selectButton = screen.getByTestId("select");
      expect(selectButton.textContent).toEqual(
        "Continue (" + selectedRooms.length + ")"
      );
      expect(selectButton.disabled).toBe(false);
    });

    it("should open menu when dropdown button is clicked", () => {
      const dropDownButton = screen.getByTestId("dropdown");
      fireEvent.click(dropDownButton);
      const menuList = screen.getByTestId("menulist");
      expect(menuList).toBeVisible();
    });

    it("should close  the  menu when dropdown button is clicked again", () => {
      const dropDownButton = screen.getByTestId("dropdown");
      fireEvent.click(dropDownButton);
      const menuList = screen.getByTestId("menulist");
      fireEvent.click(dropDownButton);
      expect(menuList).not.toBeVisible();
    });

    it("should close the dropdown when the outside is clicked", () => {
      const dropDownButton = screen.getByTestId("dropdown");
      fireEvent.click(dropDownButton);
      const dropdownMenu = screen.getByTestId("menulist");
      expect(dropdownMenu).toBeInTheDocument();
      fireEvent.click(document);

      setTimeout(() => {
        expect(dropdownMenu).not.toBeInTheDocument();
      }, 1000);
    });

    it("should call onclick functioality on menu item click and open room details modal", async () => {
      const dropDownButton = screen.getByTestId("dropdown");
      fireEvent.click(dropDownButton);

      const menuItem = screen.getByText(
        selectedRooms[0].roomId + "," + selectedRooms[0].name
      );
      fireEvent.click(menuItem);
      expect(props.toggleModal).toHaveBeenCalled();
      const roomDetailsPage = screen.getByTestId("roomDetailsPage");
      expect(RoomDetailsActions.setRoomId).toHaveBeenCalledWith("127379372");
      expect(RoomSearchActions.setRoomDetailsModal).toHaveBeenCalledWith(true);
      expect(roomDetailsPage).toBeInTheDocument();
      await waitFor(() => {
        expect(menuItem).not.toBeInTheDocument();
      });
    });

    it("should close room details popup on close button click", async () => {
      const dropDownButton = screen.getByTestId("dropdown");
      fireEvent.click(dropDownButton);

      const menuItem = screen.getByText(
        selectedRooms[0].roomId + "," + selectedRooms[0].name
      );
      fireEvent.click(menuItem);
      expect(props.toggleModal).toHaveBeenCalled();
      const roomDetailsPage = screen.getByTestId("roomDetailsPage");
      expect(RoomDetailsActions.setRoomId).toHaveBeenCalledWith("127379372");
      expect(RoomSearchActions.setRoomDetailsModal).toHaveBeenCalledWith(true);
      expect(roomDetailsPage).toBeInTheDocument();
      const closeroomDetails = screen.getByRole("button", {
        name: /room Details close/,
      });
      fireEvent.click(closeroomDetails);
      await waitFor(() => {
        expect(RoomSearchActions.setRoomDetailsModal).toHaveBeenCalledWith(
          false
        );
      });
    });

    it("should delete room details  on remove button click in room details popup", async () => {
      const dropDownButton = screen.getByTestId("dropdown");
      fireEvent.click(dropDownButton);

      const menuItem = screen.getByText(
        selectedRooms[0].roomId + "," + selectedRooms[0].name
      );
      fireEvent.click(menuItem);
      expect(props.toggleModal).toHaveBeenCalled();
      const roomDetailsPage = screen.getByTestId("roomDetailsPage");
      expect(RoomDetailsActions.setRoomId).toHaveBeenCalledWith("127379372");
      expect(RoomSearchActions.setRoomDetailsModal).toHaveBeenCalledWith(true);
      expect(roomDetailsPage).toBeInTheDocument();
      const removeroomDetails = screen.getByRole("button", {
        name: /room Detail Delete/,
      });
      fireEvent.click(removeroomDetails);
      await waitFor(() => {
        expect(props.onDelete).toHaveBeenCalled();
        expect(RoomSearchActions.setRoomDetailsModal).toHaveBeenCalledWith(
          false
        );
      });
    });

    it("should close the menu on tab button", async () => {
      const dropDownButton = screen.getByTestId("dropdown");
      fireEvent.click(dropDownButton);

      const menuItem = screen.getByText(
        selectedRooms[0].roomId + "," + selectedRooms[0].name
      );
      fireEvent.keyDown(menuItem, { key: "Tab" });
      await waitFor(() => {
        expect(menuItem).not.toBeInTheDocument();
      });
    });

    it("should move up and down in menu list", async () => {
      const dropDownButton = screen.getByTestId("dropdown");
      fireEvent.click(dropDownButton);

      const menuItem = screen.getByText(
        selectedRooms[0].roomId + "," + selectedRooms[0].name
      );
      fireEvent.keyDown(menuItem, { keyCode: "40" });
      fireEvent.keyDown(menuItem, { keyCode: "38" });
      await waitFor(() => {
        expect(menuItem).toBeInTheDocument();
      });
    });
  });
});
