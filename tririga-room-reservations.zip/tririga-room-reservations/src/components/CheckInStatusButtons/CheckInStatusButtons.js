/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import classnames from "classnames";
import moment from "moment-timezone";
import { CheckmarkFilled16, WarningFilled16 } from "@carbon/icons-react";
import {
  AppMsg,
  CheckInStates,
  isNow,
  isPast,
  ReservationEditMode,
} from "../../utils";
import {
  BUTTON,
  RESERVATION_MESSAGE,
} from "../../utils/messages/ApplicationMessages";
import ActionButton from "./ActionButton";
import { isEmpty, isEqual, isNil } from "lodash";
import { Button } from "carbon-components-react";
import { connect } from "react-redux";
import {
  CurrentUserSelectors,
  CheckInActions,
  ExchangeSelectors,
} from "../../store";

const cssBase = "checkInStatusButtons";

const computeCheckInValues = (event) => {
  let checkInStatus = CheckInStates.NONE;
  let timerDuration = null;
  if (isEmpty(event)) return {};
  const { rooms, instance, start, end } = event;
  if (isEmpty(instance)) return {};
  const {
    checkInRequired,
    checkInReminderDateTime,
    autoCancellationDateTime,
    actualStart,
    actualEnd,
  } = instance;
  if (
    !isEmpty(rooms) &&
    (isNow(start, end) ||
      (checkInReminderDateTime && isNow(checkInReminderDateTime, end)))
  ) {
    if (actualEnd && isPast(actualEnd)) {
      checkInStatus = CheckInStates.EARLY_END;
    } else if (
      actualStart ||
      (!checkInRequired && !autoCancellationDateTime && isPast(start))
    ) {
      checkInStatus = CheckInStates.CLOSED;
    } else if (checkInRequired) {
      if (
        autoCancellationDateTime &&
        isNow(checkInReminderDateTime, autoCancellationDateTime)
      ) {
        timerDuration =
          new Date(autoCancellationDateTime).getTime() - new Date().getTime();
        checkInStatus = CheckInStates.OPEN;
      } else if (autoCancellationDateTime && isPast(autoCancellationDateTime)) {
        checkInStatus = CheckInStates.EXPIRED;
      } else if (
        !autoCancellationDateTime &&
        isNow(checkInReminderDateTime, start)
      ) {
        checkInStatus = CheckInStates.OPEN;
      } else if (!autoCancellationDateTime && isPast(start)) {
        checkInStatus = CheckInStates.CLOSED;
      }
    }
  }
  return { checkInStatus, timerDuration };
};

class CheckInStatusButtons extends React.PureComponent {
  static propTypes = {
    reservation: PropTypes.object,
    timezone: PropTypes.string,
    className: PropTypes.string,
    releaseRoom: PropTypes.func,
    checkIn: PropTypes.func,
    releaseRoomEarly: PropTypes.func,
    recheckRoom: PropTypes.func,
    editReservation: PropTypes.func,
    appMessages: PropTypes.object,
    timerEndDuration: PropTypes.number,
    updateRoomsCanceled: PropTypes.func,
    personId: PropTypes.string,
    userEmail: PropTypes.string,
    currentCalendar: PropTypes.object,
  };

  static getDerivedStateFromProps(
    { reservation, timezone, timerEndDuration, updateRoomsCanceled },
    state
  ) {
    const {
      prevReservation,
      prevTimerDuration,
      prevTimerEndDuration,
      roomReservationInvalid,
    } = state;
    if (
      timerEndDuration !== prevTimerEndDuration ||
      (reservation &&
        reservation.instance &&
        !isEqual(reservation, prevReservation))
    ) {
      const { checkInStatus, timerDuration } = computeCheckInValues(
        reservation,
        timezone,
        timerEndDuration,
        roomReservationInvalid
      );
      if (
        !timerDuration &&
        prevTimerDuration &&
        checkInStatus === CheckInStates.EXPIRED
      ) {
        updateRoomsCanceled(
          reservation.reservationId,
          reservation.start,
          reservation.rooms
        );
      }
      return {
        ...state,
        checkInStatus,
        timerDuration,
        prevReservation: reservation,
        prevTimerDuration: timerDuration,
        prevTimerEndDuration: timerEndDuration,
      };
    }
    return { ...state };
  }

  state = {
    prevReservation: null,
    roomReservationInvalid: false,
    checkInStatus: null,
    timerDuration: null,
    prevTimerDuration: null,
    prevTimerEndDuration: null,
    loadingReleaseRoom: false,
    loadingCheckIn: false,
    loadingReleaseRoomEarly: false,
    loadingRecheckRoom: false,
  };

  componentDidMount() {
    this._isMounted = true;
  }

  componentWillUnmount() {
    this._isMounted = false;
  }

  render() {
    const { className } = this.props;
    const { checkInStatus, timerDuration, roomReservationInvalid } = this.state;
    const checkInMessage = this.computeCheckInMessage(
      checkInStatus,
      roomReservationInvalid
    );
    return (
      <div className={classnames(cssBase, className)}>
        {checkInStatus !== CheckInStates.NONE && (
          <div className={`${cssBase}__checkInButtonsContainer`}>
            {checkInStatus === CheckInStates.OPEN &&
              this.renderReleaseRoomButton()}
            {checkInStatus === CheckInStates.OPEN && this.renderCheckInButton()}
            {checkInStatus === CheckInStates.CLOSED &&
              this.renderReleaseRoomEarlyButton()}
            {checkInStatus === CheckInStates.EXPIRED &&
              !roomReservationInvalid &&
              this.renderReCheckRoomButton()}
            {roomReservationInvalid && this.renderEditReservationButton()}
          </div>
        )}
        {!isEmpty(checkInMessage) && (
          <div className={`${cssBase}__checkInMessagesContainer`}>
            {this.renderMessageIcon(checkInStatus, roomReservationInvalid)}
            <span className={`${cssBase}__checkInMessage`}>
              {checkInMessage}
              &nbsp;
            </span>
            {timerDuration && this.renderCountdown(timerDuration)}
          </div>
        )}
      </div>
    );
  }

  renderReleaseRoomButton = () => {
    const { loadingReleaseRoom, loadingCheckIn } = this.state;
    return (
      <ActionButton
        kind="tertiary"
        size="small"
        onClick={this.handleReleaseRoom}
        label={this.props.appMessages[BUTTON.RELEASE_ROOM]}
        isLoading={loadingReleaseRoom}
        loadingMessage={this.props.appMessages[BUTTON.RELEASE_ROOM_LOADING]}
        disabled={loadingCheckIn}
        className={`${cssBase}__checkInButton`}
      />
    );
  };

  renderCheckInButton = () => {
    const { loadingCheckIn, loadingReleaseRoom } = this.state;
    return (
      <ActionButton
        size="small"
        onClick={this.handleCheckIn}
        label={this.props.appMessages[BUTTON.CHECK_IN]}
        isLoading={loadingCheckIn}
        loadingMessage={this.props.appMessages[BUTTON.CHECK_IN_LOADING]}
        disabled={loadingReleaseRoom}
        className={`${cssBase}__checkInButton`}
      />
    );
  };

  renderReleaseRoomEarlyButton = () => {
    const { loadingReleaseRoomEarly } = this.state;
    return (
      <ActionButton
        kind="tertiary"
        size="small"
        onClick={this.handleReleaseRoomEarly}
        label={this.props.appMessages[BUTTON.RELEASE_ROOM_EARLY]}
        isLoading={loadingReleaseRoomEarly}
        loadingMessage={
          this.props.appMessages[BUTTON.RELEASE_ROOM_EARLY_LOADING]
        }
      />
    );
  };

  renderReCheckRoomButton = () => {
    const { loadingRecheckRoom } = this.state;
    return (
      <ActionButton
        kind="tertiary"
        size="small"
        onClick={this.handleReCheckRoom}
        isLoading={loadingRecheckRoom}
        label={this.props.appMessages[BUTTON.RECHECK_ROOM]}
        loadingMessage={this.props.appMessages[BUTTON.RECHECK_ROOM_LOADING]}
      />
    );
  };

  renderEditReservationButton = () => {
    return (
      <Button kind="tertiary" size="small" onClick={this.handleReserveRoom}>
        {this.props.appMessages[BUTTON.EDIT_RESERVATION]}
      </Button>
    );
  };

  renderMessageIcon = (checkInStatus, roomReservationInvalid) => {
    if (checkInStatus === CheckInStates.OPEN) {
      return <WarningFilled16 className={`${cssBase}__checkInReminderIcon`} />;
    } else if (
      checkInStatus === CheckInStates.EXPIRED ||
      roomReservationInvalid
    )
      return <WarningFilled16 className={`${cssBase}__checkInExpiredIcon`} />;
    else if (
      checkInStatus === CheckInStates.CLOSED ||
      checkInStatus === CheckInStates.EARLY_END
    )
      return <CheckmarkFilled16 className={`${cssBase}__checkedInIcon`} />;
  };

  computeCheckInMessage = (checkInStatus, roomReservationInvalid) => {
    if (this.state.timerDuration) {
      return AppMsg.getMessage(RESERVATION_MESSAGE.CHECK_IN_EXPIRING_COUNTDOWN);
    } else if (checkInStatus === CheckInStates.CLOSED) {
      return AppMsg.getMessage(RESERVATION_MESSAGE.CHECKED_IN);
    } else if (checkInStatus === CheckInStates.EARLY_END) {
      return AppMsg.getMessage(RESERVATION_MESSAGE.ROOM_RELEASED_EARLY);
    } else if (
      checkInStatus === CheckInStates.EXPIRED ||
      roomReservationInvalid
    ) {
      return AppMsg.getMessage(RESERVATION_MESSAGE.CHECK_IN_EXPIRED);
    }
  };

  renderCountdown = (timerDuration) => {
    return (
      <span className={`${cssBase}__countdown`}>
        {moment.duration(timerDuration).format("mm:ss")}
      </span>
    );
  };

  handleReleaseRoom = async (e) => {
    e.stopPropagation();
    this.setState({ loadingReleaseRoom: true });
    const {
      reservation: {
        reservationId,
        start,
        end,
        isRecurringReservation,
        eventId,
      },
      releaseRoom,
    } = this.props;
    await releaseRoom(
      reservationId,
      start,
      end,
      isRecurringReservation,
      eventId
    );
    if (this._isMounted) {
      this.setState({ loadingReleaseRoom: false });
    }
  };

  handleCheckIn = async (e) => {
    e.stopPropagation();
    this.setState({ loadingCheckIn: true });
    const {
      reservation: { reservationId, start, instance },
      checkIn,
    } = this.props;
    await checkIn(reservationId, start, instance._id);
    this.setState({ loadingCheckIn: false });
  };

  handleReleaseRoomEarly = async (e) => {
    e.stopPropagation();
    this.setState({ loadingReleaseRoomEarly: true });
    const {
      reservation: { reservationId, start, instance, eventId },
      releaseRoomEarly,
      timezone,
      currentCalendar,
    } = this.props;

    const calendarId = currentCalendar ? currentCalendar.id : null;

    await releaseRoomEarly(
      reservationId,
      start,
      instance._id,
      instance.checkInRequired,
      eventId,
      timezone,
      calendarId
    );
    this.setState({ loadingReleaseRoomEarly: false });
  };

  handleReCheckRoom = async (e) => {
    e.stopPropagation();
    this.setState({ loadingRecheckRoom: true });
    const {
      reservation: { reservationId, seriesReservationId, start, rooms },
      recheckRoom,
    } = this.props;
    const delegateUserEmail =
      this.props.currentCalendar.email === this.props.userEmail
        ? null
        : this.props.currentCalendar.email;
    if (!isNil(seriesReservationId)) {
      const reservationException = await CheckInActions.waitUntilExceptionIsCreated(
        this.props.reservation.start,
        this.props.reservation.end,
        this.props.personId,
        this.props.reservation.seriesReservationId,
        delegateUserEmail
      );
      if (!isNil(reservationException)) {
        const recheckRoomResults = await recheckRoom(
          reservationException.reservationId,
          start,
          rooms,
          reservationId
        );
        this.setState({
          roomReservationInvalid:
            recheckRoomResults && !recheckRoomResults.success,
        });
      }
    } else {
      const recheckRoomResults = await recheckRoom(reservationId, start, rooms);
      this.setState({
        roomReservationInvalid:
          recheckRoomResults && !recheckRoomResults.success,
      });
    }

    this.setState({ loadingRecheckRoom: false });
  };

  handleReserveRoom = (e) => {
    e.stopPropagation();
    const { reservation, editReservation } = this.props;
    const editMode = reservation.isRecurringReservation
      ? ReservationEditMode.SERIES_OCCURRENCE
      : ReservationEditMode.OCCURRENCE;
    editReservation(reservation, editMode);
  };
}

const mapStateToProps = (state) => {
  return {
    personId: CurrentUserSelectors.personIdSelector(state),
    userEmail: CurrentUserSelectors.currentUserEmailSelector(state),
    currentCalendar: ExchangeSelectors.currentCalendarSelector(state),
  };
};

export default withTriDictionary(
  connect(mapStateToProps, {})(CheckInStatusButtons)
);
