/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import PropTypes from "prop-types";
import classnames from "classnames";
import { Button, InlineLoading } from "carbon-components-react";

const cssBase = "checkInStatusButtons";

export default class ActionButton extends React.PureComponent {
  static propTypes = {
    kind: PropTypes.string,
    size: PropTypes.string,
    isLoading: PropTypes.bool,
    label: PropTypes.string,
    loadingMessage: PropTypes.string,
    className: PropTypes.string,
    onClick: PropTypes.func,
    disabled: PropTypes.bool,
  };

  render() {
    const {
      size,
      kind,
      onClick,
      label,
      disabled,
      isLoading,
      loadingMessage,
      className,
    } = this.props;
    return (
      <div className={classnames(cssBase, className)}>
        {!isLoading && (
          <Button kind={kind} size={size} onClick={onClick} disabled={disabled}>
            {label}
          </Button>
        )}
        {isLoading && (
          <div className={`${cssBase}__inlineLoadingContainer`}>
            <InlineLoading />
            <span className={`${cssBase}__loadingMessage`}>
              {loadingMessage}
            </span>
          </div>
        )}
      </div>
    );
  }
}
