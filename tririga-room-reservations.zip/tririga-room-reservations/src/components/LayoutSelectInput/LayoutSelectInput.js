/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import { Select, SelectItem } from "carbon-components-react";
import { AppMsg, DefaultValues } from "../../utils";

class LayoutSelectInput extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    value: PropTypes.string,
    labelText: PropTypes.string,
    onChange: PropTypes.func,
    layoutTypes: PropTypes.array,
    className: PropTypes.string,
  };

  render() {
    const { value, labelText, onChange, layoutTypes, className } = this.props;

    return (
      <Select
        id="layoutSelectInput"
        value={value}
        labelText={labelText}
        onChange={onChange}
        light={true}
        className={className}
      >
        <SelectItem
          text={
            this.props.appMessages[
              AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_LAYOUT_ANY
            ]
          }
          value={DefaultValues.LAYOUT_TYPE.internalValue}
        />
        {layoutTypes.map((item) => {
          return (
            <SelectItem
              key={item._id}
              text={item.value}
              value={item.internalValue}
            />
          );
        })}
      </Select>
    );
  }
}

export default withTriDictionary(LayoutSelectInput);
