/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import defaultTo from "lodash/defaultTo";
import PropTypes from "prop-types";
import moment from "moment";
import printf from "printf";
import isEmpty from "lodash/isEmpty";
import { isNil, uniq } from "lodash";
import "moment/min/locales";
import { Select, SelectItem } from "carbon-components-react";
import { DefaultValues, closeAllDatepickerPopups } from "../../utils";

const cssBase = "timeInput";

const timeList = [];

for (let i = 0; i < 12; i++) {
  //for (let j = 0; j < 12; j++) { // OOB
  for (let j = 0; j < 4; j++) { // CISA
    timeList.push(
      //`${printf("%02d", ((i + 11) % 12) + 1)}:${printf("%02d", 5 * j)}` // OOB
      `${printf("%02d", ((i + 11) % 12) + 1)}:${printf("%02d", 15 * j)}` // CISA
    );
  }
}

export default class TimeInput extends React.PureComponent {
  static propTypes = {
    onTimeChange: PropTypes.func.isRequired,
    onTimePeriodChange: PropTypes.func.isRequired,
    locale: PropTypes.string,
    time: PropTypes.string,
    timePeriod: PropTypes.string,
    endTime: PropTypes.string,
    endTimePeriod: PropTypes.string,
    label: PropTypes.string,
    id: PropTypes.string,
    startTime: PropTypes.string,
    startTimePeriod: PropTypes.string,
    isAllDayEvent: PropTypes.bool,
    additionalInformation: PropTypes.object,
    labelText: PropTypes.string,
  };

  static defaultProps = {
    timePeriod: DefaultValues.TIME_PERIOD,
    locale: DefaultValues.LOCALE,
  };

  constructor(props) {
    super(props);
    this.getLocalTimePeriodsLabel();
  }

  getLocalTimePeriodsLabel = () => {
    const userLocaleData = moment.localeData(
      defaultTo(this.props.locale, DefaultValues.LOCALE)
    );
    this.amLabel = userLocaleData.meridiem(1, 0);
    this.pmLabel = userLocaleData.meridiem(13, 0);
  };

  filterTimeList(start, end, startPeriod, endPeriod, skipEndTimeCheckBefore12) {
    try {
      const startTimeHour = parseInt(start.split(":")[0]);
      const startTimeMin = parseInt(start.split(":")[1]);
      const endTimeHour = parseInt(end.split(":")[0]);
      const endTimeMin = parseInt(end.split(":")[1]);
      const filteredList = [];

      if (startPeriod === endPeriod) {
        if (endTimeHour < startTimeHour) {
          for (let i = startTimeHour; i <= 12; i++) {
            //for (let j = 0; j < 12; j++) { // OOB
            for (let j = 0; j < 4; j++) { // CISA
              //if (parseInt(printf("%02d", 5 * j)) >= startTimeMin) { // OOB
              if (parseInt(printf("%02d", 15 * j)) >= startTimeMin) { // CISA
                filteredList.push(
                  `${printf("%02d", ((i + 11) % 12) + 1)}:${printf(
                    "%02d",
                   // 5 * j // OOB
                   15 * j // CISA
                  )}`
                );
              } else {
                filteredList.push(
                  `${printf("%02d", ((i + 11) % 12) + 1)}:${printf(
                    "%02d",
                    //5 * j // OOB
                    15 * j // CISA
                  )}`
                );
              }
            }
          }

          for (let i = 0; i <= endTimeHour; i++) {
            for (let j = 0; j < 12; j++) {
              if (i === endTimeHour) {
                if (parseInt(printf("%02d", 5 * j)) <= endTimeMin) {
                  filteredList.push(
                    `${printf("%02d", ((i + 11) % 12) + 1)}:${printf(
                      "%02d",
                      // 5 * j // OOB
                      15 * j // CISA
                    )}`
                  );
                }
              } else {
                filteredList.push(
                  `${printf("%02d", ((i + 11) % 12) + 1)}:${printf(
                    "%02d",
                   // 5 * j // OOB
                   15 * j // CISA
                  )}`
                );
              }
            }
          }
        } else {
          for (let i = startTimeHour; i <= endTimeHour; i++) {
            //for (let j = 0; j < 12; j++) { // OOB
            for (let j = 0; j < 4; j++) { // CISA
              if (i === startTimeHour && startTimeHour === endTimeHour) {
                if (
                  /*
                  parseInt(printf("%02d", 5 * j)) >= startTimeMin &&
                  parseInt(printf("%02d", 5 * j)) <= endTimeMin
                  */ // OOB
                  parseInt(printf("%02d", 15 * j)) >= startTimeMin &&
                  parseInt(printf("%02d", 15 * j)) <= endTimeMin //CISA
                ) {
                  filteredList.push(
                    `${printf("%02d", ((i + 11) % 12) + 1)}:${printf(
                      "%02d",
                      // 5 * j // OOB
                      15 * j // CISA
                    )}`
                  );
                }
              } else if (i === startTimeHour) {
                // if (parseInt(printf("%02d", 5 * j)) >= startTimeMin) { // OOB
                if (parseInt(printf("%02d", 15 * j)) >= startTimeMin) { // CISA 
                  filteredList.push(
                    `${printf("%02d", ((i + 11) % 12) + 1)}:${printf(
                      "%02d",
                      //5 * j //OOB
                      15 * j // CISA
                    )}`
                  );
                }
              } else if (i === endTimeHour) {
                //if (parseInt(printf("%02d", 5 * j)) <= endTimeMin) { // OOB
                if (parseInt(printf("%02d", 15 * j)) <= endTimeMin) {  // CISA
                  filteredList.push(
                    `${printf("%02d", ((i + 11) % 12) + 1)}:${printf(
                      "%02d",
                      //5 * j // OOB
                      15 * j // CISA
                    )}`
                  );
                }
              } else {
                filteredList.push(
                  `${printf("%02d", ((i + 11) % 12) + 1)}:${printf(
                    "%02d",
                    //5 * j // OOB
                    15 * j // CISA
                  )}`
                );
              }
            }
          }
        }
      } else {
        for (let i = startTimeHour; i <= 12; i++) {
          //for (let j = 0; j < 12; j++) { // OOB
          for (let j = 0; j < 4; j++) { // CISA  
            if (i === startTimeHour) {
              //if (parseInt(printf("%02d", 5 * j)) >= startTimeMin) { // OOB
              if (parseInt(printf("%02d", 15 * j)) >= startTimeMin) { // CISA 
                filteredList.push(
                  `${printf("%02d", ((i + 11) % 12) + 1)}:${printf(
                    "%02d",
                    //5 * j // OOB
                    15 * j // CISA
                  )}`
                );
              }
            } else if (i === endTimeHour && !skipEndTimeCheckBefore12) {
              //if (parseInt(printf("%02d", 5 * j)) <= endTimeMin) { // OOB
              if (parseInt(printf("%02d", 15 * j)) <= endTimeMin) { // CISA  
                filteredList.push(
                  `${printf("%02d", ((i + 11) % 12) + 1)}:${printf(
                    "%02d",
                    // 5 * j // OOB
                    15 * j // CISA
                  )}`
                );
              }
            } else {
              filteredList.push(
                `${printf("%02d", ((i + 11) % 12) + 1)}:${printf(
                  "%02d",
                 // 5 * j // OOB
                 15 * j // CISA
                )}`
              );
            }
          }
        }

        if (endTimeHour !== 12) {
          for (let i = 0; i <= endTimeHour; i++) {
            //for (let j = 0; j < 12; j++) { // OOB
            for (let j = 0; j < 4; j++) { // CISA
              if (i === endTimeHour) {
               // if (parseInt(printf("%02d", 5 * j)) <= endTimeMin) { // OOB
               if (parseInt(printf("%02d", 5 * j)) <= endTimeMin) { // CISA
                  filteredList.push(
                    `${printf("%02d", ((i + 11) % 12) + 1)}:${printf(
                      "%02d",
                     // 5 * j // OOB
                     15 * j // CISA
                    )}`
                  );
                }
              } else {
                filteredList.push(
                  `${printf("%02d", ((i + 11) % 12) + 1)}:${printf(
                    "%02d",
                  //  5 * j // OOB
                  15 * j //CISA
                  )}`
                );
              }
            }
          }
        }
      }
      return uniq(filteredList);
    } catch (error) {
      return timeList;
    }
  }

  checkForAllDayEvent(isAllDayEvent) {
    if (isNil(isAllDayEvent)) {
      return false;
    }
    return isAllDayEvent;
  }

  get24HourFormat(time, period) {
    const timeFormat = moment(time + " " + period, ["h:mm A"]).format("HH:mm");
    return parseInt(timeFormat.replace(/:/g, ""));
  }

  subtractTimeInHours(time, period, hour) {
    const { locale } = this.props;
    const timeFormat = moment(
      moment().format("YYYY-MM-DD") + " " + time + " " + period,
      "YYYY-MM-DD hh:mm:ss a"
    );
    return timeFormat.subtract(hour, "h").locale(locale).format("hh:mm A");
  }

  render() {
    const {
      time,
      timePeriod,
      endTime,
      endTimePeriod,
      onTimeChange,
      onTimePeriodChange,
      label,
      id,
      startTime,
      startTimePeriod,
      isAllDayEvent,
      additionalInformation,
    } = this.props;
    this.getLocalTimePeriodsLabel();
    const { amLabel, pmLabel } = this;
    let timeOptions = timeList;
    let deliveryTime = time;
    let deliveryTimePeriod = timePeriod;
    let updatedStartTime = startTime;
    let updatedStartTimePeriod = startTimePeriod;
    let timePeriods = [];
    let updatedStartTimeFormat = null;
    let startTime24Format = null;
    let deliveryTime24Format = null;
    let endTime24Format = null;
    let skipEndTimeCheckBefore12 = false;
    let deliveryTime24FormatWithAM = null;
    if (
      !!startTime &&
      !!endTime &&
      !isEmpty(endTime) &&
      !!endTimePeriod &&
      !this.checkForAllDayEvent(isAllDayEvent)
    ) {
      try {
        updatedStartTimeFormat = this.subtractTimeInHours(
          startTime,
          startTimePeriod,
          1
        );
        updatedStartTime = updatedStartTimeFormat.split(" ")[0];
        updatedStartTimePeriod = updatedStartTimeFormat.split(" ")[1];

        startTime24Format = this.get24HourFormat(
          updatedStartTime,
          updatedStartTimePeriod
        );
        deliveryTime24FormatWithAM = this.get24HourFormat(time, amLabel);
        deliveryTime24Format = this.get24HourFormat(time, pmLabel);
        endTime24Format = this.get24HourFormat(endTime, endTimePeriod);

        if (
          (startTimePeriod === pmLabel || updatedStartTimePeriod === pmLabel) &&
          endTimePeriod === amLabel
        ) {
          if (
            deliveryTime24FormatWithAM <= endTime24Format && 
            deliveryTime24FormatWithAM <= 2400 &&
            deliveryTime24Format >= startTime24Format &&
            deliveryTime24Format <= 2400
          ) {
            timePeriods = [];
            timePeriods.push(amLabel);
            timePeriods.push(pmLabel);
            deliveryTimePeriod = startTimePeriod;
            skipEndTimeCheckBefore12 = true;
          } else if (
            deliveryTime24Format >= startTime24Format &&
            deliveryTime24Format < 2400
          ) {
            timePeriods.push(pmLabel);
            deliveryTimePeriod = pmLabel;
          } else {
            timePeriods.push(amLabel);
            deliveryTimePeriod = amLabel;
          }
        } else {
          if (
            deliveryTime24FormatWithAM >= startTime24Format && 
            deliveryTime24FormatWithAM <= endTime24Format &&
            deliveryTime24Format >= startTime24Format &&
            deliveryTime24Format <= endTime24Format
          ) {
            timePeriods = [];
            timePeriods.push(amLabel);
            timePeriods.push(pmLabel);
            deliveryTimePeriod = startTimePeriod;
            skipEndTimeCheckBefore12 = true;
          } else if (
            deliveryTime24Format >= startTime24Format &&
            deliveryTime24Format <= endTime24Format
          ) {
            timePeriods.push(pmLabel);
            deliveryTimePeriod = pmLabel;
          } else {
            timePeriods.push(amLabel);
            deliveryTimePeriod = amLabel;
          }
        }
      } catch (error) {
        console.log(error);
      }
      if (additionalInformation.deliveryTime !== startTime) {
        timePeriods = [];
        deliveryTime = additionalInformation.deliveryTime;
        deliveryTimePeriod = additionalInformation.deliveryTimePeriod;
        const deliveryTime24FormatWithAM = this.get24HourFormat(
          deliveryTime,
          amLabel
        );
        const deliveryTime24Format = this.get24HourFormat(
          deliveryTime,
          pmLabel
        );
        if (
          (startTimePeriod === pmLabel || updatedStartTimePeriod === pmLabel) &&
          endTimePeriod === amLabel
        ) {
          if (
            deliveryTime24FormatWithAM <= endTime24Format &&  
            deliveryTime24FormatWithAM <= 2400 && 
            deliveryTime24Format >= startTime24Format && 
            deliveryTime24Format <= 2400 
          ) {
            timePeriods = [];
            timePeriods.push(amLabel);
            timePeriods.push(pmLabel);
            skipEndTimeCheckBefore12 = true;
          } else if (
            deliveryTime24Format >= startTime24Format &&
            deliveryTime24Format < 2400
          ) {
            timePeriods.push(pmLabel);
            deliveryTimePeriod = pmLabel;
          } else {
            timePeriods.push(amLabel);
            deliveryTimePeriod = amLabel;
          }
        } else {
          if (
            deliveryTime24FormatWithAM >= startTime24Format && 
            deliveryTime24FormatWithAM <= endTime24Format && 
            deliveryTime24Format >= startTime24Format && 
            deliveryTime24Format <= endTime24Format 
          ) {
            timePeriods = [];
            timePeriods.push(amLabel);
            timePeriods.push(pmLabel);
            skipEndTimeCheckBefore12 = true;
          } else if (
            deliveryTime24Format >= startTime24Format &&
            deliveryTime24Format <= endTime24Format
          ) {
            timePeriods.push(pmLabel);
            deliveryTimePeriod = pmLabel;
          } else {
            timePeriods.push(amLabel);
            deliveryTimePeriod = amLabel;
          }
        }
      }
      timeOptions = this.filterTimeList(
        updatedStartTime,
        endTime,
        updatedStartTimePeriod,
        endTimePeriod,
        skipEndTimeCheckBefore12
      );
      if (!timeOptions.includes(time)) {
        timePeriods = [];
        deliveryTime = startTime;
        deliveryTimePeriod = startTimePeriod;
        timePeriods.push(startTimePeriod);
      }
    } else {
      timePeriods.push(amLabel);
      timePeriods.push(pmLabel);
    }
    return (
      <div className={cssBase}>
        <Select
          className={`${cssBase}__timePicker`}
          id={id}
          labelText={label}
          value={defaultTo(deliveryTime, DefaultValues.TIME)}
          onChange={onTimeChange}
          onFocus={() => closeAllDatepickerPopups()}
        >
          {timeOptions.map((item, index) => (
            <SelectItem key={index} value={item} text={item} />
          ))}
        </Select>
        <Select
          className={`${cssBase}__timePeriodPicker`}
          id={`${id}-period`}
          labelText={this.props.labelText}
          value={defaultTo(deliveryTimePeriod, DefaultValues.TIME_PERIOD)}
          onChange={onTimePeriodChange}
          onFocus={() => closeAllDatepickerPopups()}
        >
          {timePeriods.includes(amLabel) && (
            <SelectItem value={DefaultValues.TIME_PERIOD} text={amLabel} />
          )}
          {timePeriods.includes(pmLabel) && (
            <SelectItem value={DefaultValues.TIME_PERIOD_PM} text={pmLabel} />
          )}
        </Select>
      </div>
    );
  }
}
