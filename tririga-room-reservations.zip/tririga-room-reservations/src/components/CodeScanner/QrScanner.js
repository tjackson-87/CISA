/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import jsQR from "jsqr";
import debounce from "debounce";

const cssBase = "qrCodeScanner";
export default class QrScanner extends React.PureComponent {
  static propTypes = {
    captureTime: PropTypes.number,
    isTimeout: PropTypes.bool,
    found: PropTypes.bool,
    onScan: PropTypes.func,
    onError: PropTypes.func,
    onResume: PropTypes.func,
  };

  static defaultProps = {
    captureTime: 3000,
    isTimeout: false,
    found: false,
    onError: () => {},
    onScan: () => {},
    onResume: () => {},
  };

  state = {
    viewPort: null,
    video: null,
    stream: null,
    canvasElement: null,
  };

  constructor(props) {
    super(props);
    this.handleScan = debounce(this.handleScan.bind(this), 300);
  }

  render() {
    return (
      <div className={classNames(cssBase)}>
        <div
          id="interactive"
          className={classNames(`${cssBase}__viewport`, "viewport")}
          ref={(element) => {
            this.setState({ viewPort: element });
          }}
        >
          <video
            id="video"
            ref={(element) => {
              this.setState({ video: element });
            }}
          />
          <div
            className={`${cssBase}__frame`}
            found={this.props.found ? "true" : "false"}
          />
          <canvas
            id="canvas"
            ref={(element) => {
              this.setState({ canvasElement: element });
            }}
          />
        </div>
      </div>
    );
  }

  async handleScan() {
    const video = this.state.video;
    const canvasElement = this.state.canvasElement;
    const canvas = this.state.canvasElement.getContext("2d");
    const { videoHeight, videoWidth } = video;

    if (
      video.readyState === video.HAVE_ENOUGH_DATA &&
      videoHeight &&
      videoWidth
    ) {
      canvasElement.height = videoHeight;
      canvasElement.width = videoWidth;

      canvas.drawImage(video, 0, 0, canvasElement.width, canvasElement.height);
      const imageData = canvas.getImageData(
        0,
        0,
        canvasElement.width,
        canvasElement.height
      );
      const code = jsQR(imageData.data, imageData.width, imageData.height, {
        inversionAttempts: "dontInvert",
      });
      if (code) {
        video.pause();
        this.props.onScan(code.data);
        await this.resume(this.props.onResume);
        await video.play();
        setTimeout(() => {
          requestAnimationFrame(this.handleScan);
        }, this.props.captureTime);
      } else {
        requestAnimationFrame(this.handleScan);
      }
    }
  }

  start() {
    navigator.mediaDevices
      .getUserMedia({ video: { facingMode: "environment" } })
      .then(async (stream) => {
        this.setState({ stream });
        this.state.video.srcObject = stream;
        this.state.video.setAttribute("playsinline", true);
        await this.state.video.play();
        requestAnimationFrame(this.handleScan);
      })
      .catch((error) => {
        this.props.onError(error);
      });
  }

  resume(cb) {
    return new Promise((resolve) => cb(resolve));
  }

  stop() {
    const canvas = this.state.canvasElement.getContext("2d");
    canvas.clearRect(
      0,
      0,
      this.state.canvasElement.width,
      this.state.canvasElement.height
    );
    this.state.video.pause();
    this.state.stream && this.state.stream.getVideoTracks()[0].stop();
    this.handleScan = () => {};
  }

  componentDidMount() {
    this.start();
  }

  componentWillUnmount() {
    this.stop();
  }

  async componentDidUpdate({ isTimeout }) {
    if (this.props.isTimeout && isTimeout !== this.props.isTimeout) {
      this.state.video.pause();
      await this.resume(this.props.onResume);
      await this.state.video.play();
    }
  }
}
