/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import classNames from "classnames";
import {
  Button,
  ButtonSet,
  Loading,
  TooltipIcon,
} from "carbon-components-react";
import { Close20, ErrorFilled32, CheckmarkFilled32 } from "@carbon/icons-react";

import BarScanner from "./BarScanner";
import QrScanner from "./QrScanner";
import { AppMsg, CodeScannerConstants } from "../../utils";

const { QR } = CodeScannerConstants;
const cssBase = "codeScanner";
class CodeScanner extends React.PureComponent {
  constructor(props) {
    super(props);
    this.pagetitle = React.createRef();
  }

  static propTypes = {
    appMessages: PropTypes.object,
    found: PropTypes.bool,
    scanning: PropTypes.bool,
    detected: PropTypes.bool,
    isNotAvailable: PropTypes.bool,
    isTimeout: PropTypes.bool,
    addedRoom: PropTypes.bool,
    scannerType: PropTypes.string,
    captureTime: PropTypes.number,
    onScan: PropTypes.func,
    onSelectAnyway: PropTypes.func,
    onScanAnother: PropTypes.func,
    onClose: PropTypes.func,
    onResume: PropTypes.func,
    onTryAgain: PropTypes.func,
    dir: PropTypes.string,
  };

  static defaultProps = {
    found: false,
    scanning: false,
    detected: false,
    isTimeout: false,
    isNotAvailable: false,
    addedRoom: false,
    captureTime: 3000,
    onScan: () => {},
    onClose: () => {},
    onSelectAnyway: () => {},
    onScanAnother: () => {},
    onTryAgain: () => {},
  };

  componentDidMount() {
    if (this.pagetitle.current)
      setTimeout(() => this.pagetitle.current.focus(), 1);
  }

  render() {
    return (
      <main>
        <div className={classNames(cssBase)}>
          <div className={`${cssBase}__header`}>
            <div className={`${cssBase}__header-title`}>
              <span
                aria-label={
                  this.props.appMessages[
                    AppMsg.SEARCH_LOCATION[
                      this.props.scannerType === QR
                        ? "QR_CODE_TITLE"
                        : "BAR_CODE_TITLE"
                    ]
                  ]
                }
                tabIndex={0}
                ref={this.pagetitle}
              >
                {
                  this.props.appMessages[
                    AppMsg.SEARCH_LOCATION[
                      this.props.scannerType === QR
                        ? "QR_CODE_TITLE"
                        : "BAR_CODE_TITLE"
                    ]
                  ]
                }
              </span>
              <div
                onClick={this.props.onClose}
                onKeyDown={(e) =>
                  e.key === "Enter" ? this.props.onClose() : false
                }
                className={`${cssBase}__closeButton`}
              >
                <TooltipIcon
                  direction="left"
                  align={this.props.dir === "ltr" ? "start" : "end"}
                  tooltipText={this.props.appMessages[AppMsg.BUTTON.CLOSE]}
                  aria-label={this.props.appMessages[AppMsg.BUTTON.CLOSE]}
                >
                  <Close20 />
                </TooltipIcon>
              </div>
            </div>
          </div>
          {this.renderScanner()}
          <div className={`${cssBase}__footer`}>{this.renderMessage()}</div>
          {this.renderActionFoundButError()}
          {this.renderActionWhenRoomNotFoundOrTimeout()}
        </div>
      </main>
    );
  }

  renderScanner() {
    const {
      captureTime,
      found,
      onScan,
      onResume,
      isTimeout,
      scannerType,
    } = this.props;
    return scannerType === QR ? (
      <QrScanner
        captureTime={captureTime}
        isTimeout={isTimeout}
        onScan={(code) => onScan(code)}
        found={found}
        onResume={onResume}
      />
    ) : (
      <BarScanner
        isTimeout={isTimeout}
        onScan={(code) => onScan(code)}
        onResume={onResume}
        found={found}
      />
    );
  }

  renderMessage() {
    return this.props.isTimeout
      ? this.renderTimeout()
      : this.renderScanResult();
  }

  renderScanResult() {
    return this.props.scanning ? (
      <span className={`${cssBase}__footer-textContainer`}>
        <Loading small withOverlay={false} />
        <span className={`${cssBase}__footer-text`}>
          {this.props.appMessages[AppMsg.SEARCH_LOCATION.SCANNING]}
        </span>
      </span>
    ) : (
      this.renderDetected()
    );
  }

  renderTimeout() {
    return (
      <span className={`${cssBase}__footer-textContainer`}>
        <ErrorFilled32 className={`${cssBase}__notFoundIcon`} />
        <span
          className={`${cssBase}__footer-text`}
          tabIndex={0}
          aria-label={
            this.props.appMessages[
              AppMsg.SEARCH_LOCATION[
                this.props.scannerType === QR ? "QR_TIME_OUT" : "BAR_TIME_OUT"
              ]
            ]
          }
          role="alert"
        >
          {
            this.props.appMessages[
              AppMsg.SEARCH_LOCATION[
                this.props.scannerType === QR ? "QR_TIME_OUT" : "BAR_TIME_OUT"
              ]
            ]
          }
        </span>
      </span>
    );
  }

  renderDetected() {
    return this.props.detected ? (
      this.props.found ? (
        this.renderFound()
      ) : (
        this.renderNotFound()
      )
    ) : (
      <span className={`${cssBase}__footer-textContainer`}>
        <span className={`${cssBase}__footer-description`}>
          {
            this.props.appMessages[
              AppMsg.SEARCH_LOCATION[
                this.props.scannerType === QR
                  ? "QR_CODE_DESCRIPTION"
                  : "BAR_CODE_DESCRIPTION"
              ]
            ]
          }
        </span>
      </span>
    );
  }

  renderFound() {
    return this.props.isNotAvailable || this.props.addedRoom ? (
      <span className={`${cssBase}__footer-textContainer`}>
        <ErrorFilled32 className={`${cssBase}__notFoundIcon`} />
        <span>
          {
            this.props.appMessages[
              this.props.addedRoom
                ? AppMsg.SEARCH_LOCATION.ROOM_HAS_ALREADY_ADDED
                : AppMsg.SEARCH_LOCATION.NOT_AVAILABLE
            ]
          }
        </span>
      </span>
    ) : (
      <span className={`${cssBase}__footer-textContainer`}>
        <CheckmarkFilled32 className={`${cssBase}__foundIcon`} />
        <span className={`${cssBase}__footer-text`}>
          {this.props.appMessages[AppMsg.SEARCH_LOCATION.ROOM_FOUND]}
        </span>
      </span>
    );
  }

  renderNotFound() {
    return (
      <span className={`${cssBase}__footer-textContainer`}>
        <ErrorFilled32 className={`${cssBase}__notFoundIcon`} />
        <span className={`${cssBase}__footer-text`}>
          {
            this.props.appMessages[
              AppMsg.SEARCH_LOCATION[
                this.props.scannerType === QR
                  ? "QR_ROOM_NOT_FOUND"
                  : "BAR_ROOM_NOT_FOUND"
              ]
            ]
          }
        </span>
      </span>
    );
  }

  renderActionFoundButError() {
    return (
      (this.props.isNotAvailable || this.props.addedRoom) &&
      this.props.found && (
        <div className={`${cssBase}__selectOptions`}>
          <ButtonSet>
            <Button
              className={`${cssBase}__selectOptions-option`}
              kind="secondary"
              onClick={
                this.props.addedRoom
                  ? () => this.props.onClose()
                  : () => this.props.onSelectAnyway()
              }
            >
              {
                this.props.appMessages[
                  this.props.addedRoom
                    ? AppMsg.BUTTON.CANCEL
                    : AppMsg.SEARCH_LOCATION.SELECT
                ]
              }
            </Button>
            <Button
              className={`${cssBase}__selectOptions-option`}
              kind="primary"
              onClick={() => this.props.onScanAnother()}
            >
              {this.props.appMessages[AppMsg.SEARCH_LOCATION.SCAN_ANOTHER]}
            </Button>
          </ButtonSet>
        </div>
      )
    );
  }

  renderActionWhenRoomNotFoundOrTimeout() {
    return (
      ((this.props.detected && !this.props.found) || this.props.isTimeout) && (
        <div className={`${cssBase}__selectOptions`}>
          <ButtonSet>
            <Button
              className={`${cssBase}__selectOptions-option`}
              kind="secondary"
              onClick={() => this.props.onClose()}
            >
              {this.props.appMessages[AppMsg.BUTTON.CANCEL]}
            </Button>
            <Button
              className={`${cssBase}__selectOptions-option`}
              kind="primary"
              onClick={() => {
                this.props.onTryAgain();
                const element = document.getElementsByClassName(
                  `${cssBase}__closeButton`
                );
                if (element[0]) setTimeout(() => element[0].focus(), 1);
              }}
            >
              {this.props.appMessages[AppMsg.SEARCH_LOCATION.TRY_AGAIN]}
            </Button>
          </ButtonSet>
        </div>
      )
    );
  }
}

export default withTriDictionary(CodeScanner);
