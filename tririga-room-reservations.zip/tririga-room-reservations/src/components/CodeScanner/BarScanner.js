/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import Quagga from "quagga";
import debounce from "debounce";

const cssBase = "barScanner";
const DEFAULT_TYPE = "code_128_reader";
export default class BarScanner extends React.PureComponent {
  static propTypes = {
    found: PropTypes.bool,
    isTimeout: PropTypes.bool,
    types: PropTypes.array,
    onScan: PropTypes.func,
    onError: PropTypes.func,
    onResume: PropTypes.func,
  };

  static defaultProps = {
    isTimeout: false,
    found: false,
    captureTime: 2000,
    types: [DEFAULT_TYPE],
    onError: () => {},
    onScan: () => {},
  };

  state = {
    viewPort: null,
  };

  constructor(props) {
    super(props);
    this.detected = debounce(this.detected.bind(this), 300);
  }

  render() {
    return (
      <div className={classNames(cssBase)}>
        <div
          id="interactive"
          className={classNames(`${cssBase}__viewport`, "viewport")}
          ref={(element) => {
            this.setState({ viewPort: element });
          }}
        />
      </div>
    );
  }

  start() {
    Quagga.init(
      {
        inputStream: {
          name: "Live",
          type: "LiveStream",
          constraints: {
            width: { min: 640 },
            height: { min: 480 },
            facingMode: "environment",
            aspectRatio: { min: 1, max: 2 },
          },
          target: this.state.viewPort,
        },
        decoder: {
          readers: this.props.types,
        },
      },
      (error) => {
        if (error) {
          this.props.onError(error);
          return;
        }
        Quagga.start();
      }
    );
  }

  resume(cb) {
    return new Promise((resolve) => cb(resolve));
  }

  async detected({ codeResult: { code } }) {
    const video = this.state.viewPort.querySelector("video");
    if (code === this.scannedCode) return;
    this.props.onScan(code);
    video.pause();
    Quagga.offDetected(this.detected);
    await this.resume(this.props.onResume);
    await video.play();
    Quagga.onDetected(this.detected);
    this.scannedCode = null;
  }

  componentDidMount() {
    this.start();
    Quagga.onDetected(this.detected);
  }

  componentWillUnmount() {
    Quagga.stop();
    Quagga.offDetected(this.detected);
  }

  async componentDidUpdate({ isTimeout }) {
    const canvas = this.state.viewPort.querySelector("canvas");
    const video = this.state.viewPort.querySelector("video");
    if (canvas) {
      if (this.props.found) {
        canvas.setAttribute("found", "true");
      } else {
        canvas.setAttribute("found", "false");
      }
    }

    if (this.props.isTimeout !== isTimeout && this.props.isTimeout) {
      video.pause();
      await this.resume(this.props.onResume);
      await video.play();
    }
  }
}
