/* IBM Confidential· - OCO Source Materials· - (C) COPYRIGHT IBM CORP. 2023 - The source code for this program is not published or otherwise· divested of its trade secrets, irrespective of what has been· deposited with the U.S. Copyright Office. */

import React from "react";
import { fireEvent, screen } from "@testing-library/react";
import { AppMsg } from "../../../utils";
import { renderWithTriDictionaryProvider } from "../../../testUtils";
import ColleagueSearchDropdown from "../ColleagueSearchDropdown";
import { VirtuosoMockContext } from 'react-virtuoso'
import { TriDictionaryProvider } from "@tririga/tririga-react-components";
import * as utils from "../../../utils/utils";
afterEach(() => jest.clearAllMocks());

(global).document.createRange = () => ({
  setStart: () => {},
  setEnd: () => {},
  commonAncestorContainer: {
    nodeName: 'BODY',
    ownerDocument: document,
  },
});

jest.spyOn(utils, "getScrollParent").mockReturnValue({scrollHeight: 400, clientHeight: 300})
describe("ColleagueSearchDropdown", () => {
  
  let props;
  const id = "";
  let anchorEl;
  const open = true;
  let searchText;
  const colleagues = [{name: "shiva"},{name:"kumar"}];
  const highlightedIndex = 0;
  let loading;
  let loadingMore;
  let dir;
  const onHighlightedIndexChange = jest.fn();
  const onSearchMore = jest.fn();
  const onSelect = jest.fn();
  const appMessages = AppMsg.getAppMessages();

  beforeEach(() => {
    props = {
      id,
      anchorEl,
      open,
      searchText,
      highlightedIndex,
      onSearchMore,
      onSelect,
      colleagues,
      loading,
      dir,
      onHighlightedIndexChange,
      loadingMore,
    };
  });

  it("Should render correctly", () => {
    const para = document.createElement("p");
    const node = document.createTextNode("This is new.");
    para.appendChild(node);
    
    const args = { ...props, loading: false, anchorEl: para}
    renderWithTriDictionaryProvider(<ColleagueSearchDropdown {...args} />, {
      appMessages,
      
        wrapper: ({ 
          // eslint-disable-next-line react/prop-types
          children}) => (
          <VirtuosoMockContext.Provider value={{ viewportHeight: 300, itemHeight: 100 }}>
            {children}
          </VirtuosoMockContext.Provider>
        ),
      
    });
    
    const listbox = screen.getByRole("listbox");
    expect(listbox).toBeInTheDocument();
  })

  it("Should call onSelect method when item is clicked", () => {
    const para = document.createElement("p");
    const node = document.createTextNode("This is new.");
    para.appendChild(node);
    
    const args = { ...props, loading: false, anchorEl: para}
    renderWithTriDictionaryProvider(<ColleagueSearchDropdown {...args} />, {
      appMessages,
      
        wrapper: ({ 
          // eslint-disable-next-line react/prop-types
          children}) => (
          <VirtuosoMockContext.Provider value={{ viewportHeight: 300, itemHeight: 100 }}>
            {children}
          </VirtuosoMockContext.Provider>
        ),
      
    });

    const nodeItem = screen.getByText("kumar");
    fireEvent.click(nodeItem);
    expect(props.onSelect).toHaveBeenCalled();
  })

  it("Should call onHighlightedIndexChange method when item is hover using mouse", () => {
    const para = document.createElement("p");
    const node = document.createTextNode("This is new.");
    para.appendChild(node);
    
    const args = { ...props, loading: false, anchorEl: para}
    renderWithTriDictionaryProvider(<ColleagueSearchDropdown {...args} />, {
      appMessages,
      
        wrapper: ({ 
          // eslint-disable-next-line react/prop-types
          children}) => (
          <VirtuosoMockContext.Provider value={{ viewportHeight: 300, itemHeight: 100 }}>
            {children}
          </VirtuosoMockContext.Provider>
        ),
      
    });

    const nodeItem = screen.getByText("kumar");
    fireEvent.mouseOver(nodeItem, { currentTarget: { nodeItem }});
    expect(props.onHighlightedIndexChange).toHaveBeenCalled();
  })

  it("Component should render empty message if there are no matching items", () => {
    const para = document.createElement("p");
    const node = document.createTextNode("This is new.");
    para.appendChild(node);
    
    const args = { ...props, searchText:"mk", colleagues:[], loading: false, anchorEl: para}
    renderWithTriDictionaryProvider(<ColleagueSearchDropdown {...args} />, {
      appMessages,
      
        wrapper: ({ 
          // eslint-disable-next-line react/prop-types
          children}) => (
          <VirtuosoMockContext.Provider value={{ viewportHeight: 300, itemHeight: 100 }}>
            {children}
          </VirtuosoMockContext.Provider>
        ),
      
    });
    const nodeItem = screen.getByText(appMessages.NO_MACTHES_FOUND + " mk")
    expect(nodeItem).toBeInTheDocument();
  })

  it("Component should render loading when items are still loading", () => {
    const para = document.createElement("p");
    const node = document.createTextNode("This is new.");
    para.appendChild(node);
    
    const args = { ...props, open:true, searchText:"mk", loading: true, anchorEl: para}
    renderWithTriDictionaryProvider(<ColleagueSearchDropdown {...args} />, {
      appMessages,
      
        wrapper: ({ 
          // eslint-disable-next-line react/prop-types
          children}) => (
          <VirtuosoMockContext.Provider value={{ viewportHeight: 300, itemHeight: 100 }}>
            {children}
          </VirtuosoMockContext.Provider>
        ),
      
    });
    const nodeItem = screen.getByTestId("renderLoading");
    expect(nodeItem).toBeInTheDocument();
  })

  it("Component should render loading footer when scroll reaches end", () => {
    const para = document.createElement("p");
    const node = document.createTextNode("This is new.");
    para.appendChild(node);
    
    const args = { ...props, searchText:"mk", loadingMore: true, anchorEl: para}
    renderWithTriDictionaryProvider(<ColleagueSearchDropdown {...args} />, {
      appMessages,
      
        wrapper: ({ 
          // eslint-disable-next-line react/prop-types
          children}) => (
          <VirtuosoMockContext.Provider value={{ viewportHeight: 300, itemHeight: 100 }}>
            {children}
          </VirtuosoMockContext.Provider>
        ),
      
    });
    const nodeItem = screen.getByTestId("renderFooter");
    expect(nodeItem).toBeInTheDocument();
  })

  it("Component should update when props are changed", () => {
  
    const para = document.createElement("p");
    const node = document.createTextNode("This is new.");
    para.appendChild(node);
    
    const args = { ...props, loading: false, anchorEl: para}
    const { rerender } = renderWithTriDictionaryProvider(<ColleagueSearchDropdown {...args} />, {
      appMessages,
      
        wrapper: ({ 
          // eslint-disable-next-line react/prop-types
          children}) => (
          <VirtuosoMockContext.Provider value={{ viewportHeight: 300, itemHeight: 100 }}>
            {children}
          </VirtuosoMockContext.Provider>
        ),
      
    });
    
    const listbox = screen.getByRole("listbox");
    expect(listbox).toBeInTheDocument();
    const args1 = { ...props, 
      highlightedIndex: 1, 
      open: true, 
      colleagues: [
        {name: "shiva"},
        {name:"kumar"},
        {name:"thyagaraj"},
      ], 
      loading: false, 
      anchorEl: para}
    rerender(
    <TriDictionaryProvider appMessages={appMessages}>
      <ColleagueSearchDropdown {...args1} />
    </TriDictionaryProvider>,
      {wrapper: ({ 
        // eslint-disable-next-line react/prop-types
        children}) => (
        <VirtuosoMockContext.Provider value={{ viewportHeight: 300, itemHeight: 100 }}>
          {children}
        </VirtuosoMockContext.Provider>
      )}
    )
    const updatedNode = screen.getByText("thyagaraj");
    expect(updatedNode).toBeInTheDocument();
  })


})