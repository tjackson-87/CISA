/* IBM Confidential· - OCO Source Materials· - (C) COPYRIGHT IBM CORP. 2023 - The source code for this program is not published or otherwise· divested of its trade secrets, irrespective of what has been· deposited with the U.S. Copyright Office. */

import React from "react";
import { screen, act, fireEvent } from "@testing-library/react";
import { AppMsg } from "../../../utils";
import { renderWithTriDictionaryProvider } from "../../../testUtils";
import ColleagueSearch from "../ColleagueSearch";
import { Button } from "carbon-addons-iot-react";
afterEach(() => jest.clearAllMocks());

let index = null;

function mockedDropdown({
  // eslint-disable-next-line react/prop-types
  highlightedIndex,
  // eslint-disable-next-line react/prop-types
  onSelect,
}) {
  index = highlightedIndex;
  return (
    <div>
      <div data-testid="colleagueDropdown">
        Colleague DropDown
      </div>
      <Button onClick={onSelect} aria-label="select" />
    </div>
  );
}

jest.mock("../../../components/ColleagueSearch/ColleagueSearchDropdown", () => {
  return mockedDropdown;
});

const mockOrientationChange = (status) => {
    const events = {};
    jest.spyOn(window, 'addEventListener').mockImplementation((event, handle, options = {}) => {
        events[event] = handle;
    });
    const orientationchange = new window.Event(status);
    act(() => {
        window.dispatchEvent(orientationchange);
    });
};
describe("ColleagueSearch", () => {
  let props;
  let searchText;
  const onSearchTextChange = jest.fn();
  const onSearchMore = jest.fn();
  const onSelect = jest.fn();
  const appMessages = AppMsg.getAppMessages();
  let colleagues;
  let loading;
  let dir;
  let isModalOpen;
  let loadingMore;

  beforeEach(() => {
    props = {
      searchText,
      onSearchTextChange,
      onSearchMore,
      onSelect,
      colleagues,
      loading,
      dir,
      isModalOpen,
      loadingMore,
    };
  });

  it("Should render correctly", () => {
    renderWithTriDictionaryProvider(<ColleagueSearch {...props} />, {
      appMessages,
    });
    mockOrientationChange('orientationchange');
    const placeholderText = screen.getByPlaceholderText(
      appMessages[AppMsg.RESERVATION_MESSAGE.SEARCH_COLLEAGUES_MODAL_TITLE]
    );
    expect(placeholderText).toBeInTheDocument();
  });

  it("Should call onSearchTextChange method when text is entered in textbox", () => {
    renderWithTriDictionaryProvider(<ColleagueSearch {...props} />, {
      appMessages,
    });
    const tb = screen.getByPlaceholderText(
      appMessages[AppMsg.RESERVATION_MESSAGE.SEARCH_COLLEAGUES_MODAL_TITLE]
    );
    fireEvent.change(tb, { target: { value: "sh" } });
    expect(props.onSearchTextChange).toHaveBeenCalled();
  })

  it("Home button should work",() => {
    const args = { ...props, 
      colleagues:["shiva", "kumar"], 
      loading: false,
      isModalOpen: true,
      searchText: "sh"}
    renderWithTriDictionaryProvider(<ColleagueSearch {...args} />, {
      appMessages,
    });
    const tb = screen.getByPlaceholderText(
      appMessages[AppMsg.RESERVATION_MESSAGE.SEARCH_COLLEAGUES_MODAL_TITLE]
    );
    fireEvent.keyDown(tb, { key: "Home" });
    expect(index).toBe(0);
  })

  it("End button should work",() => {
    const args = { ...props, 
      colleagues:["shiva", "kumar", "thyagaraj"], 
      loading: false,
      isModalOpen: true,
      searchText: "sh"}
    renderWithTriDictionaryProvider(<ColleagueSearch {...args} />, {
      appMessages,
    });
    const tb = screen.getByPlaceholderText(
      appMessages[AppMsg.RESERVATION_MESSAGE.SEARCH_COLLEAGUES_MODAL_TITLE]
    );
    fireEvent.keyDown(tb, { key: "End" });
    expect(index).toBe(2);
  })

  it("PageUp button should work",() => {
    const args = { ...props, 
      colleagues:["shiva", "kumar", "thyagaraj"], 
      loading: false,
      isModalOpen: true,
      searchText: "sh"}
    renderWithTriDictionaryProvider(<ColleagueSearch {...args} />, {
      appMessages,
    });
    const tb = screen.getByPlaceholderText(
      appMessages[AppMsg.RESERVATION_MESSAGE.SEARCH_COLLEAGUES_MODAL_TITLE]
    );
    fireEvent.keyDown(tb, { key: "PageUp" });
    expect(index).toBe(0);
  })

  it("PageDown button should work",() => {
    const args = { ...props, 
      colleagues:["shiva", "kumar", "thyagaraj"], 
      loading: false,
      isModalOpen: true,
      searchText: "sh"}
    renderWithTriDictionaryProvider(<ColleagueSearch {...args} />, {
      appMessages,
    });
    const tb = screen.getByPlaceholderText(
      appMessages[AppMsg.RESERVATION_MESSAGE.SEARCH_COLLEAGUES_MODAL_TITLE]
    );
    fireEvent.keyDown(tb, { key: "PageDown" });
    expect(index).toBe(2);
  })

  it("ArrowDown button should work",() => {
    const args = { ...props, 
      colleagues:["shiva", "kumar", "thyagaraj"], 
      loading: false,
      isModalOpen: true,
      searchText: "sh"}
    renderWithTriDictionaryProvider(<ColleagueSearch {...args} />, {
      appMessages,
    });
    const tb = screen.getByPlaceholderText(
      appMessages[AppMsg.RESERVATION_MESSAGE.SEARCH_COLLEAGUES_MODAL_TITLE]
    );
    fireEvent.keyDown(tb, { key: "ArrowDown" });
    expect(index).toBe(1);
  })

  it("ArrowUp button should work",() => {
    const args = { ...props, 
      colleagues:["shiva", "kumar", "thyagaraj"], 
      loading: false,
      isModalOpen: true,
      searchText: "sh"}
    renderWithTriDictionaryProvider(<ColleagueSearch {...args} />, {
      appMessages,
    });
    const tb = screen.getByPlaceholderText(
      appMessages[AppMsg.RESERVATION_MESSAGE.SEARCH_COLLEAGUES_MODAL_TITLE]
    );
    fireEvent.keyDown(tb, { key: "ArrowUp" });
    expect(index).toBe(0);
  })

  it("Escape button should work",() => {
    const args = { ...props, 
      colleagues:["shiva", "kumar", "thyagaraj"], 
      loading: false,
      isModalOpen: true,
      searchText: "sh"}
    renderWithTriDictionaryProvider(<ColleagueSearch {...args} />, {
      appMessages,
    });
    const tb = screen.getByPlaceholderText(
      appMessages[AppMsg.RESERVATION_MESSAGE.SEARCH_COLLEAGUES_MODAL_TITLE]
    );
    fireEvent.keyDown(tb, { key: "Escape" });
    expect(index).toBe(0);
  })

  it("Enter button should work",() => {
    const args = { ...props, 
      colleagues:["shiva", "kumar", "thyagaraj"], 
      loading: false,
      isModalOpen: true,
      searchText: "sh"}
    renderWithTriDictionaryProvider(<ColleagueSearch {...args} />, {
      appMessages,
    });
    const tb = screen.getByPlaceholderText(
      appMessages[AppMsg.RESERVATION_MESSAGE.SEARCH_COLLEAGUES_MODAL_TITLE]
    );
    fireEvent.keyDown(tb, { key: "Enter" });
    expect(props.onSelect).toHaveBeenCalled();
  })
});
