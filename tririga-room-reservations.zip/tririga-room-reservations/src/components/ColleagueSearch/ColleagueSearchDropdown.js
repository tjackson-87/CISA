/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import { SkeletonText } from "carbon-components-react";
import Popper from "@material-ui/core/Popper";
import Paper from "@material-ui/core/Paper";
import Collapse from "@material-ui/core/Collapse";
import classnames from "classnames";
import isEmpty from "lodash/isEmpty";
import { Bee16 } from "@carbon/icons-react";
import { PropTypes } from "prop-types";
import { Virtuoso } from "react-virtuoso";
import Highlighter from "react-highlight-words";
import { AppMsg, getScrollParent } from "../../utils";

const cssBase = "colleagueSearchDropdown";

class ColleagueSearchDropdown extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    id: PropTypes.string,
    open: PropTypes.bool,
    anchorEl: PropTypes.object,
    searchText: PropTypes.string,
    colleagues: PropTypes.array,
    highlightedIndex: PropTypes.number,
    loading: PropTypes.bool,
    loadingMore: PropTypes.bool,
    dir: PropTypes.string,
    onSelect: PropTypes.func,
    onSearchMore: PropTypes.func,
    onHighlightedIndexChange: PropTypes.func,
  };

  static defaultProps = {
    open: false,
  };

  popperModifiers = {
    preventOverflow: {
      enabled: false,
    },
    hide: {
      enabled: false,
    },
    sameWidth: {
      enabled: true,
      order: 840,
      fn: (data) => {
        data.offsets.popper.width = data.styles.width = Math.round(
          data.offsets.reference.width
        );
        return data;
      },
    },
    flip: {
      enabled: false,
    },
  };

  render() {
    const { id, open, anchorEl, dir } = this.props;
    return (
      <Popper
        className={cssBase}
        open={open}
        anchorEl={anchorEl}
        disablePortal={true}
        keepMounted
        transition
        placement="bottom-start"
        dir={dir}
        modifiers={this.popperModifiers}
      >
        {({ TransitionProps }) => (
          <Collapse {...TransitionProps} timeout={50}>
            <Paper
              id={id}
              square
              elevation={3}
              className={`${cssBase}__content`}
              ref={(paper) => {
                this.paper = paper;
              }}
              onMouseDown={(e) => e.preventDefault()}
            >
              {this.renderEmptyMessage()}
              {this.renderLoading()}
              {this.renderColleagues()}
            </Paper>
          </Collapse>
        )}
      </Popper>
    );
  }

  renderLoading() {
    const { loading, open } = this.props;
    if (open && loading) {
      return (
        <div className={`${cssBase}__loading`} data-testid="renderLoading">
          <SkeletonText heading lineCount={1} paragraph={false} />
          <SkeletonText heading={false} lineCount={3} paragraph />
        </div>
      );
    }
    return null;
  }

  renderEmptyMessage() {
    const { loading, colleagues, searchText, open } = this.props;
    if (open && !loading && isEmpty(colleagues)) {
      return (
        <div className={`${cssBase}__empty`}>
          <Bee16 className={`${cssBase}__emptyIcon`} />
          <div>{`${
            this.props.appMessages[AppMsg.RESERVATION_MESSAGE.NO_MACTHES_FOUND]
          } ${searchText}`}</div>
        </div>
      );
    }
    return null;
  }

  renderColleagues() {
    const {
      loading,
      colleagues,
      searchText,
      onSearchMore,
      highlightedIndex,
      id,
      open,
    } = this.props;
    if (!open || loading || isEmpty(colleagues)) {
      return null;
    }
    const virtualHeight = this.computeVirtualListHeight(colleagues.length);
    return (
      <Virtuoso
        totalCount={colleagues.length}
        endReached={onSearchMore}
        components={{
          Footer: () => this.renderFooter(),
        }}
        style={{
          height: `${virtualHeight}px`,
        }}
        ref={(virtuoso) => {
          this.virtuoso = virtuoso;
        }}
        role="listbox"
        aria-label={
          this.props.appMessages[
            AppMsg.RESERVATION_MESSAGE.SEARCH_COLLEAGUES_MODAL_TITLE
          ]
        }
        itemContent={(index) =>
          this.renderRow(
            colleagues[index],
            searchText,
            highlightedIndex === index,
            index,
            id
          )
        }
      />
    );
  }

  renderRow(colleague, searchText, highlighted, index, dropdownId) {
    const classes = classnames({
      [`${cssBase}__building`]: true,
      [`${cssBase}__building--highlighted`]: highlighted,
    });
    return (
      <div
        className={classes}
        data-option-index={index}
        onMouseDown={this.handleMouseDown}
        onMouseOver={this.handleOptionMouseOver}
        onClick={this.handleOptionClick}
        onKeyDown={(e) =>
          e.key === "Enter" ? this.handleOptionClick(e) : null
        }
        tabIndex={0}
        role="option"
        aria-selected="true"
        aria-label={`${colleague.name} ${colleague.email}`}
        id={`${dropdownId}-option-${index}`}
      >
        <div className={`${cssBase}__buildingDetails`} tabIndex={-1}>
          <div className={`${cssBase}__buildingName`}>
            <Highlighter
              highlightClassName={`${cssBase}__highlightedText`}
              searchWords={[searchText]}
              textToHighlight={colleague.name}
            />
            <span className={`${cssBase}__email`}>({colleague.email})</span>
          </div>
        </div>
      </div>
    );
  }

  renderFooter() {
    const { loadingMore } = this.props;
    if (loadingMore) {
      return (
        <div className={`${cssBase}__loadingMore`} data-testid="renderFooter">
          <SkeletonText heading={false} lineCount={1} />
        </div>
      );
    }
    return null;
  }

  computeVirtualListHeight = (count) => {
    const ROW_HEIGHT = 59;
    const ROW_DISPLAYABLE_COUNT = 5;
    const height = Math.min(
      Math.trunc(window.innerHeight - 150),
      ROW_HEIGHT * Math.min(ROW_DISPLAYABLE_COUNT, count) - 1
    );
    return height < ROW_HEIGHT ? ROW_HEIGHT - 1 : height;
  };

  handleMouseDown = (event) => {
    event.preventDefault();
  };

  handleOptionMouseOver = (event) => {
    const { onHighlightedIndexChange } = this.props;
    if (onHighlightedIndexChange != null) {
      onHighlightedIndexChange(
        Number(event.currentTarget.getAttribute("data-option-index"))
      );
    }
  };

  handleOptionClick = (event) => {
    const { onSelect, colleagues } = this.props;
    if (onSelect != null) {
      const index = Number(
        event.currentTarget.getAttribute("data-option-index")
      );
      onSelect(colleagues[index]);
    }
  };

  componentDidUpdate(prevProps) {
    const { highlightedIndex, loading, colleagues, open } = this.props;
    if (
      highlightedIndex !== prevProps.highlightedIndex &&
      open &&
      !loading &&
      !isEmpty(colleagues)
    ) {
      this.scrollToIndex(
        highlightedIndex,
        highlightedIndex > prevProps.highlightedIndex ? "end" : "start"
      );
    }
  }

  scrollToIndex(highlightedIndex, align) {
    const option = this.paper.querySelector(
      `[data-option-index="${highlightedIndex}"]`
    );
    if (!option) {
      this.virtuoso.scrollToIndex({ index: highlightedIndex, align });
    } else {
      const parent = getScrollParent(option, this.paper);
      if (parent != null && parent.scrollHeight > parent.clientHeight) {
        const scrollBottom = parent.clientHeight + parent.scrollTop;
        const elementBottom = option.offsetTop + option.offsetHeight;
        if (elementBottom > scrollBottom) {
          parent.scrollTop = elementBottom - parent.clientHeight;
        } else if (option.offsetTop < parent.scrollTop) {
          parent.scrollTop = option.offsetTop;
        }
      }
    }
  }
}

export default withTriDictionary(ColleagueSearchDropdown);
