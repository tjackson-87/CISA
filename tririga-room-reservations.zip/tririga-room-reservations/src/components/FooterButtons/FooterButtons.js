/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import PropTypes from "prop-types";
import classnames from "classnames";
import { Button } from "carbon-components-react";

const cssBase = "footerButtons";

export default class FooterButtons extends React.PureComponent {
  static propTypes = {
    className: PropTypes.string,
    secondaryLabel: PropTypes.string,
    secondaryClickedHandler: PropTypes.func,
    primaryLabel: PropTypes.string,
    primaryClickedHandler: PropTypes.func,
    primaryDisabled: PropTypes.bool,
    isRoomSearchButton: PropTypes.bool,
    tertiaryLabel: PropTypes.string,
    tertiaryClickedHandler: PropTypes.func,
  };

  render() {
    const {
      className,
      secondaryLabel,
      secondaryClickedHandler,
      primaryLabel,
      primaryClickedHandler,
      primaryDisabled,
      isRoomSearchButton,
      tertiaryLabel,
      tertiaryClickedHandler,
    } = this.props;

    return (
      <div
        className={classnames(
          isRoomSearchButton ? `${cssBase}__tertiaryFooterButton` : cssBase,
          className
        )}
        aria-label="FooterButtons"
      >
        <div
          className={classnames(
            isRoomSearchButton
              ? `${cssBase}__tertiaryButtonContainer`
              : `${cssBase}__container`
          )}
        >
          {secondaryLabel && (
            <Button
              className={classnames(
                isRoomSearchButton
                  ? `${cssBase}__tertiaryButton`
                  : `${cssBase}__button`,
                !secondaryLabel || !primaryLabel
                  ? `${cssBase}__singleButton`
                  : ""
              )}
              kind="secondary"
              size="small"
              onClick={secondaryClickedHandler}
              aria-label={secondaryLabel}
              id="secondary-button"
            >
              {secondaryLabel}
            </Button>
          )}

          {primaryLabel && (
            <Button
              className={classnames(
                `${cssBase}__button`,
                !secondaryLabel || !primaryLabel
                  ? `${cssBase}__singleButton`
                  : ""
              )}
              kind="primary"
              size="small"
              disabled={primaryDisabled}
              onClick={primaryClickedHandler}
              aria-label={primaryLabel}
            >
              {primaryLabel}
            </Button>
          )}

          {tertiaryLabel && (
            <Button
              className={`${cssBase}__tertiaryButton`}
              id="dangerButton"
              kind="danger"
              size="small"
              onClick={tertiaryClickedHandler}
              aria-labelledby="removeRoomButton"
            >
              <span hidden id="removeRoomButton">
                {tertiaryLabel}
              </span>
              {tertiaryLabel}
            </Button>
          )}
        </div>
      </div>
    );
  }
}
