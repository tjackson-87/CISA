/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import { ContentSwitcher } from "carbon-components-react";
import { IconSwitch } from "carbon-addons-iot-react";
import { List24, Map24 as Floorplan24 } from "@carbon/icons-react";
import { AppMsg } from "../../utils";

export const RoomViewMode = {
  LIST: "LIST",
  FLOORPLAN: "FLOORPLAN",
};

const switches = [
  {
    name: RoomViewMode.FLOORPLAN,
    messageKey: AppMsg.BUTTON.SWITCH_FLOORPLAN,
    icon: Floorplan24,
  },
  {
    name: RoomViewMode.LIST,
    messageKey: AppMsg.BUTTON.SWITCH_LIST,
    icon: List24,
  },
];

function getRoomViewModeIndex(mode) {
  const index = switches.findIndex((switchInfo) => switchInfo.name === mode);
  return index >= 0 ? index : 0;
}

class RoomViewSwitcher extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    mode: PropTypes.string.isRequired,
    onChange: PropTypes.func,
    className: PropTypes.string,
    dir: PropTypes.string,
  };

  static defaultProps = {
    mode: RoomViewMode.FLOORPLAN,
  };

  render() {
    const { className, mode, dir } = this.props;

    return (
      <ContentSwitcher
        onChange={this.handleOnChange}
        selectionMode="manual"
        className={className}
        selectedIndex={getRoomViewModeIndex(mode)}
      >
        {switches.map((switchInfo, index) => (
          <IconSwitch
            name={switchInfo.name}
            text={this.props.appMessages[switchInfo.messageKey]}
            renderIcon={switchInfo.icon}
            key={switchInfo.name}
            tooltipAlignment="center"
            tooltipPosition={dir === "ltr" ? "right" : "left"}
            index={index}
            onClick={() => {}}
            onKeyDown={() => {}}
          />
        ))}
      </ContentSwitcher>
    );
  }

  handleOnChange = (selected) => {
    const { onChange } = this.props;
    if (onChange) {
      onChange(selected.name);
    }
  };
}

export default withTriDictionary(RoomViewSwitcher);
