/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import defaultTo from "lodash/defaultTo";
import { TextInput } from "carbon-components-react";
import { AppMsg } from "../../utils";

class SubjectInput extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    onValueChanged: PropTypes.func.isRequired,
    value: PropTypes.string,
    readOnly: PropTypes.bool,
    onBlur: PropTypes.func.isRequired,
    onFocus: PropTypes.func.isRequired,
    textInputReference: PropTypes.func,
    hideLabel: PropTypes.bool,
    placeholder: PropTypes.string,
    className: PropTypes.string,
    readOnlyClassName: PropTypes.string,
  };

  static defaultProps = {
    hideLabel: false,
  };

  constructor(props) {
    super(props);
    this.textInputRef = React.createRef();
  }

  componentDidMount() {
    this.props.textInputReference(this.textInputRef);
  }

  render() {
    const {
      onValueChanged,
      value,
      onBlur,
      onFocus,
      hideLabel,
      placeholder,
      className,
      readOnly,
      readOnlyClassName,
    } = this.props;
    return (
      <TextInput
        id="subject"
        tabIndex={0}
        readOnly={readOnly}
        className={readOnly ? readOnlyClassName : className}
        onBlur={onBlur}
        onFocus={onFocus}
        ref={this.textInputRef}
        hideLabel={hideLabel}
        labelText={
          this.props.appMessages[
            AppMsg.RESERVATION_MESSAGE.STEP_MEETING_SUBJECT
          ]
        }
        onChange={onValueChanged}
        placeholder={placeholder}
        type="text"
        value={defaultTo(value, "")}
        maxLength="150"
      />
    );
  }
}

export default withTriDictionary(SubjectInput);
