/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import classNames from "classnames";
import { ChevronRight16, ChevronLeft16 } from "@carbon/icons-react";
import { ToastNotification } from "carbon-components-react";
import { AppMsg } from "../../utils";
import { isNil } from "lodash";

const cssBase = "reservationStepLink";

class ReservationStepLink extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    stepIcon: PropTypes.elementType,
    onClick: PropTypes.func,
    onKeyDown: PropTypes.func,
    stepLinkReference: PropTypes.func,
    name: PropTypes.string,
    className: PropTypes.string,
    children: PropTypes.node,
    dir: PropTypes.string,
    addIcon: PropTypes.elementType,
    ariaLabel: PropTypes.string,
    invalidStartDate: PropTypes.bool,
  };

  constructor(props) {
    super(props);
    this.stepLinkRef = React.createRef();
  }

  componentDidMount() {
    if (this.props.stepLinkReference) {
      this.props.stepLinkReference(this.stepLinkRef);
    }
  }

  renderArrowIcon(dir, AddIcon) {
    if (AddIcon) return <AddIcon className={`${cssBase}__icon`} />;
    if (dir === "rtl") {
      return <ChevronLeft16 className={`${cssBase}__icon`} />;
    } else {
      return <ChevronRight16 className={`${cssBase}__icon`} />;
    }
  }

  renderArrowIconDisabled(dir, AddIcon) {
    if (AddIcon) return <AddIcon className={`${cssBase}__iconDisabled`} />;
    if (dir === "rtl") {
      return <ChevronLeft16 className={`${cssBase}__iconDisabled`} />;
    } else {
      return <ChevronRight16 className={`${cssBase}__iconDisabled`} />;
    }
  }

  renderCateringContent(disableHeader) {
    const { stepIcon: StepIcon, name, addIcon: AddIcon, dir } = this.props;
    return (
      <>
        <div
          className={
            disableHeader
              ? `${cssBase}__contentDisabled`
              : `${cssBase}__content`
          }
        >
          <div
            className={
              disableHeader
                ? `${cssBase}__headerDisabled`
                : `${cssBase}__header`
            }
          >
            {StepIcon ? (
              <StepIcon
                className={
                  disableHeader
                    ? `${cssBase}__headerIconDisabled`
                    : `${cssBase}__headerIcon`
                }
              />
            ) : (
              <div className={`${cssBase}__noStepIcon`} />
            )}
            <div className={`${cssBase}__headerName`}>{name}</div>
          </div>
          <div className={`${cssBase}__notificationHeader`}>
            <ToastNotification
              className={`${cssBase}__notification`}
              tabIndex={0}
              kind="info"
              lowContrast
              hideCloseButton={true}
              notificationType="toast"
              title={
                this.props.appMessages[
                  AppMsg.RESERVATION_MESSAGE
                    .CATERING_WARNING_MESSAGE_FOR_PAST_START_DATE_TITLE
                ]
              }
              subtitle={
                <span>
                  {
                    this.props.appMessages[
                      AppMsg.RESERVATION_MESSAGE
                        .CATERING_WARNING_MESSAGE_FOR_PAST_START_DATE
                    ]
                  }
                </span>
              }
            />
          </div>
        </div>
        {disableHeader
          ? this.renderArrowIconDisabled(dir, AddIcon)
          : this.renderArrowIcon(dir, AddIcon)}
      </>
    );
  }

  render() {
    const {
      stepIcon: StepIcon,
      onClick,
      onKeyDown,
      name,
      className,
      children,
      dir,
      addIcon: AddIcon,
      ariaLabel,
      invalidStartDate,
    } = this.props;
    const label = !isNil(ariaLabel) ? ariaLabel : name;

    if (!isNil(invalidStartDate) && invalidStartDate) {
      if (children) {
        return (
          <div
            className={classNames(cssBase, className)}
            ref={this.stepLinkRef}
            onClick={onClick}
            onKeyDown={onKeyDown}
            role="link"
            aria-label={label}
            tabIndex={0}
          >
            {this.renderCateringContent(false)}
          </div>
        );
      } else {
        return (
          <div
            className={classNames(cssBase, className)}
            ref={this.stepLinkRef}
          >
            {this.renderCateringContent(true)}
          </div>
        );
      }
    }

    return (
      <div
        className={classNames(cssBase, className)}
        ref={this.stepLinkRef}
        onClick={onClick}
        onKeyDown={onKeyDown}
        role="link"
        tabIndex={0}
        aria-label={ariaLabel ? label : null}
      >
        <div className={`${cssBase}__content ${cssBase}__pointer`}>
          <div className={`${cssBase}__header`}>
            {StepIcon ? (
              <StepIcon className={`${cssBase}__headerIcon`} />
            ) : (
              <div className={`${cssBase}__noStepIcon`} />
            )}
            <div
              className={`${cssBase}__headerName`}
              aria-label={!ariaLabel ? label : null}
            >
              {name}
            </div>
          </div>
          {children != null && (
            <div className={`${cssBase}__children`}>{children}</div>
          )}
        </div>
        {this.renderArrowIcon(dir, AddIcon)}
      </div>
    );
  }
}
export default withTriDictionary(ReservationStepLink);
