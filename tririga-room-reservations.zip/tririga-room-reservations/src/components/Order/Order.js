/* IBM Confidential· - OCO Source Materials· - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise· divested of its trade secrets, irrespective of what has been· deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import classNames from "classnames";
import PropTypes from "prop-types";
import { Button } from "carbon-components-react";
import { AppMsg } from "../../utils";
import OrderSummary from "./OrderSummary";
import AdditionalInformation from "./AdditionalInformation";

const cssBase = "order";

class Order extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    orders: PropTypes.array.isRequired,
    className: PropTypes.string,
    onAddItems: PropTypes.func,
    viewAdditionalInformation: PropTypes.bool,
    onDisplayAdditionalInformation: PropTypes.func,
    handleQtyChanged: PropTypes.func,
    onAdditionalInformation: PropTypes.func,
    dateAndTime: PropTypes.object,
    additionalInformation: PropTypes.object,
    currencies: PropTypes.array,
    currentUserLocale: PropTypes.string,
    onOrderFoodDetail: PropTypes.func,
    dir: PropTypes.string,
    isReadOnly: PropTypes.bool,
    cateringStartTime: PropTypes.string,
    cateringStartTimePeriod: PropTypes.string,
    cateringEndTime: PropTypes.string,
    cateringEndTimePeriod: PropTypes.string,
    eventStart: PropTypes.string,
    setOrderRef: PropTypes.func,
    removeOrderRef: PropTypes.any,
  };

  render() {
    const {
      className,
      orders,
      onAddItems,
      viewAdditionalInformation,
      onDisplayAdditionalInformation,
      handleQtyChanged,
      onAdditionalInformation,
      additionalInformation,
      dateAndTime,
      currencies,
      currentUserLocale,
      onOrderFoodDetail,
      dir,
      isReadOnly,
      cateringStartTime,
      cateringStartTimePeriod,
      cateringEndTime,
      cateringEndTimePeriod,
      eventStart,
      setOrderRef,
      removeOrderRef,
    } = this.props;

    return (
      <div className={classNames(cssBase, className)}>
        <div className={`${cssBase}__orderHeader`}>
          <div className={`${cssBase}__orderLabel`}>
            {
              this.props.appMessages[
                AppMsg.RESERVATION_MESSAGE.STEP_ROOM_ORDER_SUMMARY
              ]
            }
          </div>
          {!isReadOnly && (
            <Button kind="ghost" size="field" onClick={onAddItems}>
              {
                this.props.appMessages[
                  AppMsg.RESERVATION_MESSAGE.ADD_OR_EDIT_ITEMS
                ]
              }
            </Button>
          )}
        </div>
        <div className={`${cssBase}__orderList`}>
          <OrderSummary
            orders={orders}
            handleQtyChanged={handleQtyChanged}
            currencies={currencies}
            currentUserLocale={currentUserLocale}
            onOrderFoodDetail={onOrderFoodDetail}
            dir={dir}
            isReadOnly={isReadOnly}
            setOrderRef={setOrderRef}
            removeOrderRef={removeOrderRef}
          />
          <AdditionalInformation
            currentUserLocale={currentUserLocale}
            viewAdditionalInformation={viewAdditionalInformation}
            onDisplayAdditionalInformation={onDisplayAdditionalInformation}
            cateringStartTime={cateringStartTime}
            cateringStartTimePeriod={cateringStartTimePeriod}
            cateringEndTime={cateringEndTime}
            cateringEndTimePeriod={cateringEndTimePeriod}
            onAdditionalInformation={onAdditionalInformation}
            dateAndTime={dateAndTime}
            additionalInformation={additionalInformation}
            isReadOnly={isReadOnly}
            eventStart={eventStart}
          />
        </div>
      </div>
    );
  }
}

export default withTriDictionary(Order);
