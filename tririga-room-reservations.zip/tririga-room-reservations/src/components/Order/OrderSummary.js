/* IBM Confidential· - OCO Source Materials· - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise· divested of its trade secrets, irrespective of what has been· deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import classNames from "classnames";
import PropTypes from "prop-types";
import { Close20, ChevronRight16, ChevronLeft16 } from "@carbon/icons-react";
import { TooltipIcon } from "carbon-components-react";
import { AppMsg, CateringUtils } from "../../utils";

const cssBase = "orderSummary";

class OrderSummary extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    orders: PropTypes.array.isRequired,
    className: PropTypes.string,
    handleQtyChanged: PropTypes.func,
    currencies: PropTypes.array,
    currentUserLocale: PropTypes.string,
    onOrderFoodDetail: PropTypes.func,
    dir: PropTypes.string,
    isReadOnly: PropTypes.bool,
    setOrderRef: PropTypes.func,
    removeOrderRef: PropTypes.any,
  };

  render() {
    const {
      className,
      orders,
      currencies,
      currentUserLocale,
      onOrderFoodDetail,
      dir,
      isReadOnly,
      setOrderRef,
    } = this.props;
    return (
      <div className={classNames(cssBase, className)}>
        {orders.map((order, key) => (
          <div key={key} className={`${cssBase}__orderContent`}>
            <div
              className={`${cssBase}__orderDetails`}
              onClick={() => onOrderFoodDetail(order)}
              tabIndex={0}
              role="link"
              onKeyDown={(e) =>
                e.key === "Enter"
                  ? setTimeout(() => onOrderFoodDetail(order), 1)
                  : null
              }
              ref={(ref) => {
                setOrderRef(ref, order._id);
              }}
            >
              {currentUserLocale === "ar-EG" ? (
                <div className={`${cssBase}__orderQty`}>&nbsp;x{order.qty}</div>
              ) : (
                <div className={`${cssBase}__orderQty`}>{order.qty}x&nbsp;</div>
              )}
              <div className={`${cssBase}__orderTitle`}>{order.menuItem}</div>
            </div>
            <div className={`${cssBase}__orderCost`}>
              {CateringUtils.getFoodCost(
                currentUserLocale,
                CateringUtils.getCurrency(currencies, order),
                (order.qty * order.costPerItem.value).toFixed(2)
              )}
            </div>
            <div
              className={`${cssBase}__orderRemove`}
              onClick={() => isReadOnly && onOrderFoodDetail(order)}
            >
              {!isReadOnly ? (
                <div
                  className={`${cssBase}__closeButton`}
                  onClick={() => this.handleDeleteOrder(order)}
                >
                  <TooltipIcon
                    direction="left"
                    align={dir === "ltr" ? "start" : "end"}
                    tooltipText={this.props.appMessages[AppMsg.BUTTON.CLOSE]}
                    aria-label={this.props.appMessages[AppMsg.BUTTON.CLOSE]}
                  >
                    <Close20 />
                  </TooltipIcon>
                </div>
              ) : (
                this.renderArrowIcon(dir)
              )}
            </div>
          </div>
        ))}
      </div>
    );
  }

  handleDeleteOrder = (order) => {
    const { handleQtyChanged, removeOrderRef } = this.props;
    handleQtyChanged({ ...order, qty: 0 });
    if (removeOrderRef) setTimeout(() => removeOrderRef.focus(), 1);
  };

  renderArrowIcon = (dir) => {
    if (dir === "rtl") {
      return <ChevronLeft16 className={`${cssBase}__icon`} />;
    } else {
      return <ChevronRight16 className={`${cssBase}__icon`} />;
    }
  };
}

export default withTriDictionary(OrderSummary);
