/* IBM Confidential· - OCO Source Materials· - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise· divested of its trade secrets, irrespective of what has been· deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import classNames from "classnames";
import PropTypes from "prop-types";
import { TriImage, withTriDictionary } from "@tririga/tririga-react-components";
import {
  ComposedModal,
  ModalFooter,
  ModalBody,
  ModalHeader,
  Button,
  Select,
  SelectItem,
  Accordion,
  AccordionItem,
  FormLabel,
} from "carbon-components-react";
import { isEmpty } from "lodash";
import { Add16, Edit16, TrashCan16 } from "@carbon/icons-react";
import { AppMsg } from "../../utils";
import { InstructionsModel } from "..";

const cssBase = "orderFoodDetail";
class OrderFoodDetail extends React.PureComponent {
  constructor(props) {
    super(props);
    this.addInstructionsButtonref = React.createRef();
  }

  static propTypes = {
    className: PropTypes.string,
    currentOrderFoodDetail: PropTypes.object.isRequired,
    appMessages: PropTypes.object,
    onCurrentFoodDetail: PropTypes.func,
    onRemoveItem: PropTypes.func,
    isReadOnly: PropTypes.bool,
    viewOrderFoodDetailFromCateringList: PropTypes.bool,
    primaryButtonLabel: PropTypes.string,
    primaryDisabled: PropTypes.bool,
    onClickPrimaryButton: PropTypes.func,
    secondaryButtonLabel: PropTypes.string,
    onClickSecondaryButton: PropTypes.func,
    onClose: PropTypes.func,
  };

  state = {
    openModal: false,
    localInstructions: "",
  };

  render() {
    const {
      className,
      currentOrderFoodDetail,
      viewOrderFoodDetailFromCateringList,
      isReadOnly,
      primaryButtonLabel,
      onClickPrimaryButton,
      primaryDisabled,
      secondaryButtonLabel,
      onClickSecondaryButton,
      onClose,
    } = this.props;
    return (
      <ComposedModal
        className={`${cssBase}__modalContainer`}
        open={true}
        size="md"
        onClose={() => onClose()}
        selectorPrimaryFocus=".bx--modal-close"
        aria-label={currentOrderFoodDetail.menuItem}
      >
        <ModalHeader
          iconDescription={this.props.appMessages[AppMsg.BUTTON.CLOSE]}
        >
          {currentOrderFoodDetail.menuItem}
        </ModalHeader>
        <ModalBody>
          <div className={classNames(cssBase, className)}>
            <div className={`${cssBase}__content`}>
              {currentOrderFoodDetail.image && (
                <TriImage
                  value={currentOrderFoodDetail.image}
                  className={`${cssBase}__image`}
                />
              )}
              <div className={`${cssBase}__description`}>
                {currentOrderFoodDetail.description}
              </div>
            </div>
          </div>
          {!viewOrderFoodDetailFromCateringList && this.renderOrderDetail()}
        </ModalBody>
        {!isReadOnly && !viewOrderFoodDetailFromCateringList && (
          <ModalFooter>
            <Button kind="secondary" onClick={() => onClickSecondaryButton()}>
              {secondaryButtonLabel}
            </Button>
            <Button
              kind="primary"
              disabled={primaryDisabled}
              onClick={() => onClickPrimaryButton()}
            >
              {primaryButtonLabel}
            </Button>
          </ModalFooter>
        )}
      </ComposedModal>
    );
  }

  renderOrderDetail = () => {
    const { currentOrderFoodDetail, appMessages, isReadOnly } = this.props;
    const { qty, instructions } = currentOrderFoodDetail;
    const { openModal, localInstructions } = this.state;
    return (
      <Accordion>
        <AccordionItem
          className={`${cssBase}__orderDetailContent`}
          title={appMessages[AppMsg.RESERVATION_MESSAGE.CATERING_ORDER_DETAIL]}
          open
        >
          {!isReadOnly && (
            <div className={`${cssBase}__instructionsQuanity`}>
              <div className={`${cssBase}__instructions`}>
                <InstructionsModel
                  localInstructions={localInstructions}
                  openModal={openModal}
                  onDoneClick={this.handleDoneClick}
                  onCancelClick={this.handleCancelClick}
                  onInstructionsChanged={this.handleInstructionsChanged}
                  label={
                    this.props.appMessages[
                      AppMsg.RESERVATION_MESSAGE.STEP_ROOMS_INSTRUCTIONS
                    ]
                  }
                />
                <Button
                  className={`${cssBase}__instructionsButton`}
                  kind="ghost"
                  size="small"
                  renderIcon={isEmpty(instructions) ? Add16 : Edit16}
                  onClick={() =>
                    this.setState({
                      openModal: !openModal,
                      localInstructions: instructions,
                    })
                  }
                  ref={this.addInstructionsButtonref}
                >
                  {isEmpty(instructions)
                    ? AppMsg.getMessage(
                        AppMsg.RESERVATION_MESSAGE.STEP_ROOMS_ADD_INSTRUCTIONS
                      )
                    : AppMsg.getMessage(
                        AppMsg.RESERVATION_MESSAGE.STEP_ROOMS_EDIT_INSTRUCTIONS
                      )}
                </Button>
              </div>
              <div className={`${cssBase}__orderForm`}>
                <div className={`${cssBase}__qty`}>
                  <Select
                    id="qty"
                    labelText={
                      this.props.appMessages[
                        AppMsg.RESERVATION_MESSAGE.QUANTITY
                      ]
                    }
                    className={`${cssBase}__quantityInput`}
                    value={qty}
                    onChange={this.handleQtyChanged}
                  >
                    {this.renderSelectItemQty()}
                  </Select>
                </div>
              </div>
            </div>
          )}
          {isReadOnly && (
            <div>
              <FormLabel className={`${cssBase}__readOnlyQuantity`}>
                {`${
                  this.props.appMessages[AppMsg.RESERVATION_MESSAGE.QUANTITY]
                }:`}
                &nbsp;
              </FormLabel>
              {qty}
            </div>
          )}
          {isReadOnly && !isEmpty(instructions) && (
            <div className={`${cssBase}__readOnlyInstructions`}>
              {isReadOnly && (
                <FormLabel className={`${cssBase}__instuctionsLabel`}>
                  {`${
                    this.props.appMessages[
                      AppMsg.RESERVATION_MESSAGE.STEP_ROOMS_INSTRUCTIONS
                    ]
                  }`}
                </FormLabel>
              )}
              {!isEmpty(instructions) && instructions}
            </div>
          )}
          {!isReadOnly && (
            <div className={`${cssBase}__removeItem`}>
              <Button
                kind="danger--ghost"
                size="small"
                renderIcon={TrashCan16}
                onClick={() => this.handleRemoveItem()}
              >
                {
                  this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE.REMOVE_FROM_ORDER
                  ]
                }
              </Button>
            </div>
          )}
        </AccordionItem>
      </Accordion>
    );
  };

  handleRemoveItem() {
    const { onRemoveItem, currentOrderFoodDetail } = this.props;
    onRemoveItem({
      ...currentOrderFoodDetail,
      qty: 0,
      instructions: "",
    });
    this.setState({ localInstructions: "", openModal: false });
  }

  renderSelectItemQty() {
    const selectItem = [];
    for (let i = 1; i <= 1000; i++) {
      selectItem.push(<SelectItem key={i} value={i} text={String(i)} />);
    }
    return selectItem;
  }

  handleInstructionsChanged = (e) => {
    this.setState({ localInstructions: e.target.value });
  };

  handleDoneClick = () => {
    const { localInstructions } = this.state;
    const { onCurrentFoodDetail, currentOrderFoodDetail } = this.props;
    onCurrentFoodDetail({
      ...currentOrderFoodDetail,
      instructions: localInstructions,
    });
    this.setState({ localInstructions: "", openModal: false });
    if (this.addInstructionsButtonref.current)
      setTimeout(() => this.addInstructionsButtonref.current.focus(), 1);
  };

  handleCancelClick = () => {
    this.setState({ openModal: false, localInstructions: "" });
    if (this.addInstructionsButtonref.current)
      setTimeout(() => this.addInstructionsButtonref.current.focus(), 1);
  };

  handleQtyChanged = (e) => {
    const { onCurrentFoodDetail, currentOrderFoodDetail } = this.props;
    const qty = parseInt(e.target.value);
    onCurrentFoodDetail({ ...currentOrderFoodDetail, qty });
  };
}

export default withTriDictionary(OrderFoodDetail);
