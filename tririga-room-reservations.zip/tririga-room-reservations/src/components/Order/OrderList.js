/* IBM Confidential· - OCO Source Materials· - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise· divested of its trade secrets, irrespective of what has been· deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import classNames from "classnames";
import PropTypes from "prop-types";
import { TrashCan16, ChevronRight16, ChevronLeft16 } from "@carbon/icons-react";
import { TooltipIcon } from "carbon-components-react";
import moment from "moment-timezone";
import { AppMsg, DefaultValues } from "../../utils";

const cssBase = "orderList";

class OrderList extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    className: PropTypes.string,
    selectedCatering: PropTypes.array,
    onRemoveOrder: PropTypes.func,
    onEditOrder: PropTypes.func,
    dir: PropTypes.string,
    isReadOnly: PropTypes.bool,
    eventStart: PropTypes.string,
  };

  render() {
    const {
      className,
      selectedCatering,
      onRemoveOrder,
      onEditOrder,
      dir,
      isReadOnly,
      eventStart,
    } = this.props;
    return (
      <div className={classNames(cssBase, className)}>
        <div className={`${cssBase}__content`}>
          {selectedCatering.map((order, key) => (
            <div
              className={`${cssBase}__details`}
              key={key}
              onClick={() => isReadOnly && onEditOrder(order, key)}
            >
              <div
                className={`${cssBase}__order`}
                onClick={() => !isReadOnly && onEditOrder(order, key)}
                tabIndex={0}
                role="link"
                onKeyDown={(e) =>
                  e.key === "Enter"
                    ? setTimeout(
                        () => !isReadOnly && onEditOrder(order, key),
                        1
                      )
                    : null
                }
              >
                <div className={`${cssBase}__title`}>
                  {order.additionalInformation.orderName ||
                    AppMsg.getMessage(AppMsg.RESERVATION_MESSAGE.FOOD_ORDER)}
                </div>
                <div className={`${cssBase}__date`}>
                  {!isReadOnly
                    ? `${moment(
                        order.additionalInformation.deliveryDate
                      ).format(DefaultValues.CATERING_DATE_FORMAT)}, ${
                        order.additionalInformation.deliveryTime
                      } ${order.additionalInformation.deliveryTimePeriod}`
                    : `${moment(eventStart).format(
                        DefaultValues.CATERING_DATE_FORMAT
                      )}, ${order.additionalInformation.deliveryTime} ${
                        order.additionalInformation.deliveryTimePeriod
                      }`}
                </div>
                <div className={`${cssBase}__orderStatus`}>
                  {order.additionalInformation.status}
                </div>
              </div>

              {!isReadOnly ? (
                <div
                  className={`${cssBase}__closeButton`}
                  onClick={() => onRemoveOrder(key)}
                >
                  <TooltipIcon
                    direction="left"
                    align={dir === "ltr" ? "start" : "end"}
                    tooltipText={this.props.appMessages[AppMsg.BUTTON.CLOSE]}
                    aria-label={this.props.appMessages[AppMsg.BUTTON.CLOSE]}
                  >
                    <TrashCan16 />
                  </TooltipIcon>
                </div>
              ) : (
                this.renderArrowIcon(dir)
              )}
            </div>
          ))}
        </div>
      </div>
    );
  }

  renderArrowIcon = (dir) => {
    if (dir === "rtl") {
      return <ChevronLeft16 className={`${cssBase}__icon`} />;
    } else {
      return <ChevronRight16 className={`${cssBase}__icon`} />;
    }
  };
}

export default withTriDictionary(OrderList);
