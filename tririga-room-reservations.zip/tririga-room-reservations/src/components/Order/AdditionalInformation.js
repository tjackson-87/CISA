/* IBM Confidential· - OCO Source Materials· - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise· divested of its trade secrets, irrespective of what has been· deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import classnames from "classnames";
import PropTypes from "prop-types";
import { ChevronDown16, ChevronUp16, Add16, Edit16 } from "@carbon/icons-react";
import moment from "moment-timezone";
import defaultTo from "lodash/defaultTo";
import {
  TextInput,
  DatePickerInput,
  DatePicker,
  Button,
  ToastNotification,
} from "carbon-components-react";
import isEmpty from "lodash/isEmpty";
import { AppMsg, DefaultValues } from "../../utils";
import { TimeInput, InstructionsModel } from "..";
import ReadOnlyInfo from "../ReadOnlyInfo/ReadOnlyInfo";
import { isNil } from "lodash";

const cssBase = "additionalInformation";

class AdditionalInformation extends React.PureComponent {
  constructor(props) {
    super(props);
    this.addInstructionsButtonRef = React.createRef();
  }

  static propTypes = {
    appMessages: PropTypes.object,
    viewAdditionalInformation: PropTypes.bool,
    onDisplayAdditionalInformation: PropTypes.func,
    onAdditionalInformation: PropTypes.func,
    dateAndTime: PropTypes.object,
    additionalInformation: PropTypes.object,
    currentUserLocale: PropTypes.string,
    isReadOnly: PropTypes.bool,
    cateringStartTime: PropTypes.string,
    cateringStartTimePeriod: PropTypes.string,
    cateringEndTime: PropTypes.string,
    cateringEndTimePeriod: PropTypes.string,
    eventStart: PropTypes.string,
  };

  state = {
    openModal: false,
    localInstructions: this.props.additionalInformation.instructions,
  };

  render() {
    const {
      viewAdditionalInformation,
      onDisplayAdditionalInformation,
      onAdditionalInformation,
      additionalInformation,
      currentUserLocale,
      isReadOnly,
      cateringStartTime,
      cateringStartTimePeriod,
      cateringEndTime,
      cateringEndTimePeriod,
      dateAndTime,
      eventStart,
    } = this.props;
    const { openModal, localInstructions } = this.state;
    const classes = classnames({
      [cssBase]: true,
      [`${cssBase}__noBorder`]: viewAdditionalInformation,
    });

    return (
      <div className={classes}>
        <div
          className={`${cssBase}__headerName`}
          onClick={onDisplayAdditionalInformation}
        >
          {
            this.props.appMessages[
              AppMsg.RESERVATION_MESSAGE.STEP_ADDITIONAL_INFORMATION
            ]
          }
          {viewAdditionalInformation ? (
            <ChevronUp16 className={`${cssBase}__icon`} />
          ) : (
            <ChevronDown16 className={`${cssBase}__icon`} />
          )}
        </div>
        {viewAdditionalInformation && (
          <div className={`${cssBase}__infoContent`}>
            {isReadOnly ? (
              <ReadOnlyInfo
                label={
                  this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE.STEP_ADDITIONAL_ORDER_NAME
                  ]
                }
                value={defaultTo(additionalInformation.orderName, "")}
              />
            ) : (
              <TextInput
                className={`${cssBase}__orderName`}
                id="orderName"
                labelText={
                  this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE.STEP_ADDITIONAL_ORDER_NAME
                  ]
                }
                label={
                  this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE.STEP_ADDITIONAL_ORDER_NAME
                  ]
                }
                light
                onChange={(e) =>
                  onAdditionalInformation(e.target.value, "orderName")
                }
                value={defaultTo(additionalInformation.orderName, "")}
                maxLength="50"
              />
            )}
            {isReadOnly && isNil(additionalInformation.purchaseOrderId) && (
              <ToastNotification
                className={`${cssBase}__notification`}
                kind="info"
                lowContrast
                hideCloseButton={true}
                title={
                  this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE.PURCHASE_ORDERS_NOT_CREATED_TITLE
                  ]
                }
                statusIconDescription={
                  this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE.PURCHASE_ORDERS_NOT_CREATED_TITLE
                  ]
                }
                subtitle={
                  <span>
                    {
                      this.props.appMessages[
                        AppMsg.RESERVATION_MESSAGE
                          .PURCHASE_ORDERS_NOT_CREATED_TEXT
                      ]
                    }
                  </span>
                }
              />
            )}
            {!isReadOnly && (
              <DatePicker
                dateFormat={DefaultValues.CARBON_DATE_FORMAT}
                datePickerType="single"
                value={defaultTo(dateAndTime.startDate, "")}
              >
                <DatePickerInput
                  id="deliveryDate"
                  placeholder={DefaultValues.DATE_FORMAT}
                  labelText={
                    this.props.appMessages[
                      AppMsg.RESERVATION_MESSAGE.STEP_ADDITIONAL_DELIVERY_DATE
                    ]
                  }
                  type="text"
                  disabled={!isReadOnly}
                />
              </DatePicker>
            )}
            {!isReadOnly && (
              <TimeInput
                id="deliveryTime"
                onTimeChange={(e) =>
                  onAdditionalInformation(e.target.value, "deliveryTime")
                }
                onTimePeriodChange={(e) =>
                  onAdditionalInformation(e.target.value, "deliveryTimePeriod")
                }
                label={
                  this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE.STEP_ADDITIONAL_DELIVERY_TIME
                  ]
                }
                startTime={cateringStartTime}
                startTimePeriod={cateringStartTimePeriod}
                time={defaultTo(dateAndTime.startTime, "")}
                timePeriod={defaultTo(dateAndTime.startTimePeriod, "")}
                endTime={cateringEndTime}
                endTimePeriod={cateringEndTimePeriod}
                isAllDayEvent={additionalInformation.isAllDayEvent}
                locale={currentUserLocale}
                additionalInformation={additionalInformation}
              />
            )}
            <div className={`${cssBase}__instruction`}>
              {isReadOnly && !isEmpty(localInstructions) ? (
                <ReadOnlyInfo
                  label={
                    this.props.appMessages[
                      AppMsg.RESERVATION_MESSAGE.STEP_ROOMS_INSTRUCTIONS
                    ]
                  }
                  value={localInstructions}
                />
              ) : (
                <InstructionsModel
                  localInstructions={localInstructions}
                  openModal={openModal}
                  onDoneClick={this.handleDoneClick}
                  onCancelClick={this.handleCancelClick}
                  onInstructionsChanged={this.handleInstructionsChanged}
                  label={
                    this.props.appMessages[
                      AppMsg.RESERVATION_MESSAGE.STEP_ROOMS_INSTRUCTIONS
                    ]
                  }
                />
              )}
              {isReadOnly && (
                <>
                  <ReadOnlyInfo
                    label={
                      this.props.appMessages[
                        AppMsg.RESERVATION_MESSAGE
                          .STEP_ADDITIONAL_PURCHASE_ORDER_STATUS
                      ]
                    }
                    value={additionalInformation.status}
                  />

                  <ReadOnlyInfo
                    label={
                      this.props.appMessages[
                        AppMsg.RESERVATION_MESSAGE
                          .STEP_ADDITIONAL_PURCHASE_ORDER_ID
                      ]
                    }
                    value={additionalInformation.purchaseOrderId}
                  />

                  <ReadOnlyInfo
                    label={
                      this.props.appMessages[
                        AppMsg.RESERVATION_MESSAGE
                          .STEP_ADDITIONAL_DELIVERY_DATE_TIME
                      ]
                    }
                    value={`${moment(eventStart).format(
                      DefaultValues.CATERING_DATE_FORMAT
                    )}, ${additionalInformation.deliveryTime} ${
                      additionalInformation.deliveryTimePeriod
                    }`}
                  />
                </>
              )}
              {!isReadOnly && (
                <Button
                  className={`${cssBase}__instructionsButton`}
                  kind="ghost"
                  size="small"
                  renderIcon={
                    isEmpty(additionalInformation.instructions) ? Add16 : Edit16
                  }
                  onClick={() => this.setState({ openModal: !openModal })}
                  ref={this.addInstructionsButtonRef}
                >
                  {isEmpty(additionalInformation.instructions)
                    ? AppMsg.getMessage(
                        AppMsg.RESERVATION_MESSAGE.STEP_ROOMS_ADD_INSTRUCTIONS
                      )
                    : AppMsg.getMessage(
                        AppMsg.RESERVATION_MESSAGE.STEP_ROOMS_EDIT_INSTRUCTIONS
                      )}
                </Button>
              )}
              {!isReadOnly && (
                <div className={`${cssBase}__readOnlyInstructions`}>
                  {!isEmpty(additionalInformation.instructions) &&
                    additionalInformation.instructions}
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    );
  }

  handleInstructionsChanged = (e) => {
    this.setState({ localInstructions: e.target.value });
  };

  handleDoneClick = () => {
    const { localInstructions } = this.state;
    const { onAdditionalInformation } = this.props;
    onAdditionalInformation(localInstructions, "instructions");
    this.setState({ openModal: false });
    if (this.addInstructionsButtonRef.current)
      setTimeout(() => this.addInstructionsButtonRef.current.focus(), 100);
  };

  handleCancelClick = () => {
    const {
      additionalInformation: { instructions },
    } = this.props;
    this.setState({ openModal: false, localInstructions: instructions });
    if (this.addInstructionsButtonRef)
      setTimeout(() => this.addInstructionsButtonRef.current.focus(), 100);
  };
}

export default withTriDictionary(AdditionalInformation);
