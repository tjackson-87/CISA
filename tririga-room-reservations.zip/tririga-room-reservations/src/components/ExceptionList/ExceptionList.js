/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import PropTypes from "prop-types";
import { WarningFilled16 } from "@carbon/icons-react";
import { AppMsg, DefaultValues } from "../../utils";
import { withTriDictionary } from "@tririga/tririga-react-components";
import { SelectedRoom } from "..";
import { isEmpty, sortBy } from "lodash";
import moment from "moment-timezone";

const cssBase = "exceptionList";

class ExceptionList extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    exceptions: PropTypes.array,
    onSelectRoom: PropTypes.func,
  };

  render() {
    const { appMessages, exceptions, onSelectRoom } = this.props;
    return (
      <div className={`${cssBase}__list`}>
        <div className={`${cssBase}__list-row ${cssBase}__list-headerRow`}>
          <div className={`${cssBase}__list-dateColumn header`}>
            {appMessages[AppMsg.RESERVATION_MESSAGE.DATE]}
          </div>
          <div className={`${cssBase}__list-roomColumn header`}>
            {appMessages[AppMsg.RESERVATION_MESSAGE.ROOM]}
          </div>
        </div>

        {exceptions &&
          sortBy(exceptions, ["start"]).map((exception, index) => (
            <div key={`exception-${index}`} className={`${cssBase}__list-row`}>
              <div className={`${cssBase}__list-dateColumn`}>
                {exception.startDate}
              </div>
              <div className={`${cssBase}__list-roomColumn`}>
                {isEmpty(exception.room) ? (
                  <>
                    <WarningFilled16 className={`${cssBase}__list-warnIcon`} />
                    <div
                      tabIndex={0}
                      onClick={() => onSelectRoom(exception)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") {
                          e.preventDefault();
                          onSelectRoom(exception);
                        }
                      }}
                      role="link"
                      aria-label={`${
                        appMessages[
                          AppMsg.RESERVATION_MESSAGE.CHOOSE_A_ROOM_FOR
                        ]
                      } ${moment(exception.startDate).format(
                        DefaultValues.DATE_READABLE_FORMAT
                      )}`}
                      className={`${cssBase}__list-room`}
                    >
                      {appMessages[AppMsg.RESERVATION_MESSAGE.CHOOSE_A_ROOM]}
                    </div>
                  </>
                ) : (
                  <div
                    tabIndex={0}
                    onClick={() => onSelectRoom(exception)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        e.preventDefault();
                        onSelectRoom(exception);
                      }
                    }}
                    role="link"
                  >
                    <SelectedRoom room={exception.room} nameAndAddressOnly />
                  </div>
                )}
              </div>
            </div>
          ))}
      </div>
    );
  }
}

export default withTriDictionary(ExceptionList);
