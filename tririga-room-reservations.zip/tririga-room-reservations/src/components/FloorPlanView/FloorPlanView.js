/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import classNames from "classnames";
import { isEmpty, isNaN } from "lodash";
import { Subject, from, EMPTY } from "rxjs";
import { switchMap } from "rxjs/operators";
import memo from "memoize-one";
import { SkeletonPlaceholder, Loading } from "carbon-components-react";
import { Bee32 } from "@carbon/icons-react";
import {
  TriFloorPlan,
  TriHighlightPlugin,
  TriLabelsPlugin,
  TriSelectablePlugin,
  TriPinPlugin,
  TriPanPlugin,
  TriZoomPlugin,
  withTriDictionary,
  TriNavPlugin,
  TriLastPositionPlugin,
} from "@tririga/tririga-react-components";
import { RoomCardView } from "../../components";
import { AppMsg, RoomsUtils, FloorPlanIcons } from "../../utils";
import { RoomSearchSelectors, ColleagueSelectors } from "../../store";
import FloorPlanLegend from "./FloorPlanLegend";

const cssBase = "floorPlanView";

class FloorPlanView extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    className: PropTypes.string,
    rooms: PropTypes.array,
    selectedRooms: PropTypes.array,
    isFloorPlanExpanded: PropTypes.bool,
    onChange: PropTypes.func,
    onClick: PropTypes.func,
    favorites: PropTypes.array,
    addFavoriteRoom: PropTypes.func.isRequired,
    removeFavoriteRoom: PropTypes.func.isRequired,
    setTappedRoomOnFloorplan: PropTypes.func,
    selectedRoom: PropTypes.object,
    onRecurrenceClick: PropTypes.func,
    isRecurring: PropTypes.bool,
    loadingMore: PropTypes.bool,
    labelStyles: PropTypes.array,
    zoomPadding: PropTypes.number,
    filters: PropTypes.object,
    selectedColleague: PropTypes.object,
    onFloorplanViewportChange: PropTypes.func,
    enableLastPositionPlugin: PropTypes.bool,
    setFloorPlanRef: PropTypes.func,
    disableSearchArea: PropTypes.bool,
  };

  state = {
    loading: false,
    floorPlanId: null,
    floorId: null,
    zoomToColleague: false,
    initialViewPortChanged: false,
  };

  constructor(props) {
    super(props);
    this.rooms$ = new Subject();
    this.floorplanId$ = this.rooms$.pipe(
      switchMap((rooms) => {
        if (isEmpty(rooms)) {
          return null;
        }
        if (rooms[0].floorSystemRecordID === this.state.floorId) {
          return EMPTY;
        }
        this.setState({
          loading: true,
          floorId: rooms[0].floorSystemRecordID,
        });
        return from(RoomsUtils.getFloorplanId(rooms[0].floorSystemRecordID));
      })
    );
    this.floorplanIdSubscription = this.floorplanId$.subscribe(
      (floorPlanId) => {
        this.setState({
          loading: false,
          floorPlanId,
        });
      }
    );
    this.floorPlanCoordinate = { x: null, y: null };
  }

  componentDidMount() {
    const { rooms } = this.props;
    if (rooms !== null) {
      this.rooms$.next(rooms);
    }
    if (this.shouldZoomToColleague()) {
      this.setState({ zoomToColleague: true });
      setTimeout(() => {
        this.setState({ zoomToColleague: false });
      }, 500);
    }
  }

  componentDidUpdate(prevProps) {
    const { rooms } = this.props;
    if (rooms !== prevProps.rooms) {
      this.rooms$.next(rooms);
    }
  }

  componentWillUnmount() {
    this.floorplanIdSubscription.unsubscribe();
    this.rooms$ = null;
    this.floorplanId$ = null;
    this.floorplanIdSubscription = null;
  }

  render() {
    const {
      className,
      selectedRooms,
      isFloorPlanExpanded,
      onChange,
      onClick,
      favorites,
      addFavoriteRoom,
      removeFavoriteRoom,
      selectedRoom,
      isRecurring,
      onRecurrenceClick,
      labelStyles,
      rooms,
      loadingMore,
      onFloorplanViewportChange,
      selectedColleague,
      zoomPadding,
      filters,
      enableLastPositionPlugin,
      setFloorPlanRef,
    } = this.props;
    const {
      floorPlanId,
      loading,
      zoomToColleague,
      initialViewPortChanged,
    } = this.state;
    const colleagueRoom = selectedColleague?.reservation?.room;
    return (
      <div className={classNames(`${cssBase}`, className)}>
        {loading && <SkeletonPlaceholder className={`${cssBase}__loading`} />}
        {this.renderNoFloorPlanMessage(floorPlanId, loading)}
        {floorPlanId != null && (
          <div
            className={classNames({
              [`${cssBase}__floorPlan`]: true,
              [`${cssBase}__floorPlan--expanded`]: isFloorPlanExpanded,
            })}
          >
            {loadingMore && <Loading className={`${cssBase}__loadingMore`} />}
            <TriFloorPlan
              floorPlanId={floorPlanId}
              ref={(ref) => setFloorPlanRef(ref)}
              onViewportChange={(e) => {
                if (
                  !initialViewPortChanged ||
                  this.floorPlanCoordinate.x === e.x ||
                  this.floorPlanCoordinate.y === e.y ||
                  isNaN(e.x) ||
                  isNaN(e.y)
                ) {
                  this.setState({ initialViewPortChanged: true });
                  this.floorPlanCoordinate = { x: e.x, y: e.y };
                } else {
                  onFloorplanViewportChange(e);
                }
              }}
              plugins={[
                {
                  type: TriLabelsPlugin.type,
                  id: "labelsPlugin",
                  labelId: labelStyles ? labelStyles[0]._id : "",
                },
                {
                  type: TriHighlightPlugin.type,
                  id: "highlightAvailablePlugin",
                  highlighted: this.getAvailableRooms(rooms),
                  className: `${cssBase}__availableRooms--highlighted`,
                  useInteractiveLayer: false,
                },
                {
                  type: TriHighlightPlugin.type,
                  id: "highlightUnavailablePlugin",
                  highlighted: this.getUnavailableRooms(rooms),
                  className: `${cssBase}__unavailableRooms--highlighted`,
                  useInteractiveLayer: false,
                },
                {
                  type: TriHighlightPlugin.type,
                  id: "highlightColleaguePlugin",
                  highlighted: this.getColleagueRoom(selectedColleague),
                  className: `${cssBase}__colleague--highlighted`,
                  useInteractiveLayer: false,
                },
                {
                  type: TriSelectablePlugin.type,
                  id: "singleSelectPlugin",
                  multi: false,
                  selectable: this.getSelectableRooms([
                    ...rooms,
                    {
                      ...colleagueRoom,
                      _id: colleagueRoom?.spaceRecordId,
                    },
                  ]),
                  selected: zoomToColleague
                    ? {
                        [TriSelectablePlugin.SPACE_ID]:
                          colleagueRoom.spaceRecordId,
                      }
                    : selectedRoom,
                  onSelectedChange: this.onSelectedChanged,
                  zoomToSelection: zoomToColleague,
                  zoomPadding,
                },
                {
                  type: TriPinPlugin.type,
                  id: "availablePinsPlugin",
                  pins: this.getPins(rooms, selectedRooms, selectedColleague),
                  icon: {
                    available: FloorPlanIcons.AvailableLocation,
                    unavailable: FloorPlanIcons.UnavailableLocation,
                    selected: FloorPlanIcons.SelectedLocation,
                    colleague: FloorPlanIcons.ColleagueLocation,
                  },
                },
                {
                  type: TriPinPlugin.type,
                  id: "colleaguePinPlugin",
                  pins: [
                    {
                      [TriPinPlugin.SPACE_ID]: colleagueRoom?.spaceRecordId,
                      [TriPinPlugin.PIN_TYPE]: "colleague",
                    },
                  ],
                  icon: {
                    colleague: FloorPlanIcons.ColleagueLocation,
                  },
                },
                { type: TriZoomPlugin.type, id: "zoomPlugin" },
                { type: TriPanPlugin.type, id: "panPlugin" },
                { type: TriNavPlugin.type, id: "TriNavPlugin" },
                enableLastPositionPlugin
                  ? {
                      type: TriLastPositionPlugin.type,
                      id: "lastPositionPlugin",
                    }
                  : {},
              ]}
            />
            <FloorPlanLegend
              unavailable={filters.showUnavailable}
              collegue={selectedColleague}
            />
            {!isEmpty(selectedRoom) && (
              <RoomCardView
                selectedRoom={selectedRoom.room}
                className={`${cssBase}__roomCard`}
                selectedClassName={`${cssBase}__roomCard--selected`}
                selectedRooms={selectedRooms}
                onChange={onChange}
                onClick={onClick}
                favorites={favorites}
                addFavoriteRoom={addFavoriteRoom}
                removeFavoriteRoom={removeFavoriteRoom}
                isRecurring={isRecurring}
                onRecurrenceClick={onRecurrenceClick}
                selectedColleagueRoom={colleagueRoom}
              />
            )}
          </div>
        )}
      </div>
    );
  }

  onSelectedChanged = (selectedRoom) => {
    this.props.setTappedRoomOnFloorplan(selectedRoom);
  };

  renderNoFloorPlanMessage = (floorPlanId, loading) => {
    if (floorPlanId == null && !loading)
      return (
        <div className={`${cssBase}__emptyFloorplan`}>
          <Bee32 className={`${cssBase}__emptyIcon`} />
          {
            this.props.appMessages[
              AppMsg.RESERVATION_MESSAGE.STEP_ROOM_NO_FLOORS_WITH_FLOORPLAN
            ]
          }
        </div>
      );
    return null;
  };

  handleBuildingChange = (e) => {
    const { buildings } = this.state;
    const selectedBuilding = buildings.find(
      (building) => building._id === e.target.value
    );
    this.setState({
      buildings,
      selectedBuilding,
      selectedFloor: selectedBuilding.floors[0],
    });
    this.props.setTappedRoomOnFloorplan(null);
  };

  handleFloorChange = (e) => {
    const { selectedBuilding } = this.state;
    const selectedFloor = selectedBuilding.floors.find(
      (floor) => floor._id === e.target.value
    );
    this.setState({
      selectedFloor,
    });
    this.props.setTappedRoomOnFloorplan(null);
  };

  getSelectableRooms = memo((rooms) =>
    rooms.map((room) => ({ room, [TriSelectablePlugin.SPACE_ID]: room._id }))
  );

  getAvailableRooms = memo((rooms) =>
    rooms
      .filter((room) => room.isAvailable)
      .map((room) => ({ [TriHighlightPlugin.SPACE_ID]: room._id }))
  );

  getUnavailableRooms = memo((rooms) =>
    rooms
      .filter((room) => !room.isAvailable)
      .map((room) => ({ [TriHighlightPlugin.SPACE_ID]: room._id }))
  );

  getColleagueRoom = memo((colleague) => [
    {
      [TriHighlightPlugin.SPACE_ID]:
        colleague?.reservation?.room?.spaceRecordId,
    },
  ]);

  getPins = memo((rooms, selectedRooms) =>
    rooms.map((room) => {
      let type = null;
      const isSelected = selectedRooms.some(
        (selected) => selected._id === room._id
      );
      if (isSelected) {
        type = "selected";
      } else if (room.isAvailable) {
        type = "available";
      } else {
        type = "unavailable";
      }
      return {
        [TriPinPlugin.SPACE_ID]: room._id,
        [TriPinPlugin.PIN_TYPE]: type,
      };
    })
  );

  shouldZoomToColleague = () => {
    const {
      selectedRoom,
      selectedColleague,
      zoomPadding,
      disableSearchArea,
      enableLastPositionPlugin,
    } = this.props;
    const colleagueRoom = selectedColleague?.reservation?.room;
    return (
      isEmpty(selectedRoom) &&
      !isEmpty(colleagueRoom) &&
      !!zoomPadding &&
      disableSearchArea &&
      !enableLastPositionPlugin
    );
  };
}

const mapStateToProps = (state) => {
  return {
    filters: RoomSearchSelectors.filtersSelector(state),
    selectedColleague: ColleagueSelectors.selectedColleagueSelector(state),
  };
};

export default withTriDictionary(connect(mapStateToProps, {})(FloorPlanView));
