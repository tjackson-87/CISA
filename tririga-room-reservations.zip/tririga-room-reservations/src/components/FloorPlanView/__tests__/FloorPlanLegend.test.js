/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import { screen } from "@testing-library/react";
import { AppMsg } from "../../../utils";
import { renderWithTriDictionaryProvider } from "../../../testUtils";
import FloorPlanLegend from "../FloorPlanLegend";

afterEach(() => jest.clearAllMocks());

describe("EquipmentListItem", () => {
  let props, unavailable, collegue;

  describe("Legends render correctly", () => {
    const appMessages = AppMsg.getAppMessages();
    beforeEach(() => {
      props = { props, unavailable, collegue };
    });
    it("Available legend is visble when unavailable and collegue flag are false", () => {
      const args = {
        ...props,
        unavailable: false,
        collegue: null,
      };
      renderWithTriDictionaryProvider(<FloorPlanLegend {...args} />, {
        appMessages,
      });

      const available = screen.getByTestId("available");
      expect(available).toBeInTheDocument();
    });

    it("Unavailable and available legend is visble when unavailable filter is true and collegue flag are false", () => {
      const args = {
        ...props,
        unavailable: true,
        collegue: null,
      };
      renderWithTriDictionaryProvider(<FloorPlanLegend {...args} />, {
        appMessages,
      });

      const unavailable = screen.getByTestId("unavailable");
      const available = screen.getByTestId("available");
      expect(available).toBeInTheDocument();
      expect(unavailable).toBeInTheDocument();
    });

    it("Collegue, Unavailable and available  legend is visble when user selected Collegue reservation and  unavailable filter is true ", () => {
      const args = {
        ...props,
        unavailable: true,
        collegue: { name: "Leela" },
      };
      renderWithTriDictionaryProvider(<FloorPlanLegend {...args} />, {
        appMessages,
      });

      const collegue = screen.getByTestId("collegue");
      const unavailable = screen.getByTestId("unavailable");
      const available = screen.getByTestId("available");
      expect(available).toBeInTheDocument();
      expect(unavailable).toBeInTheDocument();
      expect(collegue).toBeInTheDocument();
    });
  });
});
