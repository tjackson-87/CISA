/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import PropTypes from "prop-types";
import { withTriDictionary } from "@tririga/tririga-react-components";
import classNames from "classnames";
import { AppMsg } from "../../utils";

const cssBase = "floorPlanLegend";

class FloorPlanLegend extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    unavailable: PropTypes.bool,
    collegue: PropTypes.object,
  };

  render() {
    const { unavailable, collegue } = this.props;
    return (
      <ul
        className={classNames(
          `${cssBase}__legends-list`,
          `${cssBase}__legends-container`
        )}
      >
        <li data-testid="available">
          <span
            className={classNames(
              `${cssBase}__legend-box`,
              `${cssBase}__legend-box-green`
            )}
          />
          {this.props.appMessages[AppMsg.RESERVATION_MESSAGE.AVAILABLE]}
        </li>

        {unavailable && (
          <li data-testid="unavailable">
            <span
              className={classNames(
                `${cssBase}__legend-box`,
                `${cssBase}__legend-box-grey`
              )}
            />
            {this.props.appMessages[AppMsg.RESERVATION_MESSAGE.UNAVAILABLE]}
          </li>
        )}
        {collegue && (
          <li data-testid="collegue">
            <span
              className={classNames(
                `${cssBase}__legend-box`,
                `${cssBase}__legend-box-black`
              )}
            />
            {this.props.appMessages[AppMsg.RESERVATION_MESSAGE.COLLEAGUE]}
          </li>
        )}
      </ul>
    );
  }
}
export default withTriDictionary(FloorPlanLegend);
