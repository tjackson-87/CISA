/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import defaultTo from "lodash/defaultTo";
import { Select, SelectItem } from "carbon-components-react";
import { AppMsg, getTimezoneCode } from "../../utils";

const cssBase = "TimezoneInput";

class TimezoneInput extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    onTimezoneChange: PropTypes.func.isRequired,
    timezone: PropTypes.string,
    timezones: PropTypes.array,
  };

  render() {
    const { timezone, timezones } = this.props;

    return (
      <Select
        className={cssBase}
        id="timezone-input"
        value={defaultTo(timezone, "")}
        onChange={this.handleTimezoneChange}
        labelText={
          this.props.appMessages[AppMsg.RESERVATION_MESSAGE.STEP_TIME_TIMEZONE]
        }
      >
        {timezones &&
          timezones.map((timezone, index) => {
            return (
              <SelectItem
                key={index}
                text={timezone.name}
                value={getTimezoneCode(timezone.englishName)}
              />
            );
          })}
      </Select>
    );
  }

  handleTimezoneChange = (e) => {
    this.props.onTimezoneChange(e.target.value);
  };
}

export default withTriDictionary(TimezoneInput);
