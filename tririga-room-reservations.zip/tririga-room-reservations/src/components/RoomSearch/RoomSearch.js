/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2022 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import isEmpty from "lodash/isEmpty";
import { Search } from "carbon-components-react";
import { AppMsg, LocationConstants } from "../../utils";
import RoomSearchDropdown from "./RoomSearchDropdown";
import { USER_DIR } from "../../utils/constants/DefaultValues";
const cssBase = "RoomSearch";

class RoomSearch extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    searchText: PropTypes.string,
    onSearchTextChange: PropTypes.func,
    onSearchMore: PropTypes.func,
    onSelect: PropTypes.func,
    rooms: PropTypes.array,
    loading: PropTypes.bool,
    loadingMore: PropTypes.bool,
    dir: PropTypes.string,
  };

  state = {
    highlightedIndex: 0,
    searchInitialized: false,
    focused: false,
    ignoreFocused: false,
  };

  static defaultProps = {
    dir: USER_DIR,
    rooms: [],
  };

  render() {
    const { highlightedIndex, searchInitialized } = this.state;
    const {
      rooms,
      searchText,
      loading,
      loadingMore,
      dir,
      onSearchMore,
      onSelect,
    } = this.props;
    const dropdownOpen = this.isOpen();
    const inputAria = this.computeInputAria(dropdownOpen, highlightedIndex);
    return (
      <div className={cssBase}>
        <Search
          closeButtonLabelText={
            this.props.appMessages[AppMsg.SEARCH_LOCATION.CLEAR_LABEL]
          }
          id="roomSearch"
          ref={this.setSearchInputEl}
          className={`${cssBase}__searchInput`}
          labelText={this.props.appMessages[AppMsg.RESERVATION_MESSAGE.SEARCH]}
          light
          size="lg"
          onChange={this.handleSearchChange}
          placeholder={
            this.props.appMessages[AppMsg.RESERVATION_MESSAGE.SEARCH]
          }
          value={searchText}
          type="text"
          onFocus={this.handleInputFocus}
          onKeyDown={this.handleKeyDown}
          autoComplete="off"
          aria-label={
            this.props.appMessages[AppMsg.SEARCH_LOCATION.PLACEHOLDER]
          }
          {...inputAria}
        />
        {searchInitialized && (
          <RoomSearchDropdown
            id="roomSearchDropdown"
            open={dropdownOpen}
            highlightedIndex={highlightedIndex}
            onHighlightedIndexChange={this.handleHighlightedIndexChange}
            anchorEl={this.searchInput}
            rooms={rooms}
            searchText={searchText}
            loading={loading}
            loadingMore={loadingMore}
            dir={dir}
            onSelect={onSelect}
            onSearchMore={onSearchMore}
          />
        )}
      </div>
    );
  }

  componentDidMount() {
    window.addEventListener("orientationchange", this.handleOrientationchange);
    this.searchInput.focus();
  }

  componentWillUnmount() {
    window.removeEventListener(
      "orientationchange",
      this.handleOrientationchange
    );
  }

  handleOrientationchange = () => {
    const { focused } = this.state;
    if (focused && this.searchInput != null) {
      this.searchInput.blur();
      setTimeout(() => {
        this.searchInput.focus();
      }, 300);
    }
  };

  isOpen() {
    const { focused, ignoreFocused } = this.state;
    const { searchText } = this.props;
    return !ignoreFocused && focused && !isEmpty(searchText);
  }

  select(room) {
    this.setState({
      ignoreFocused: true,
    });
    this.props.onSelect(room);
  }

  handleSearchChange = (e) => {
    const searchText = e.target.value;
    this.setState({
      ignoreFocused: false,
      highlightedIndex: 0,
    });
    this.props.onSearchTextChange(searchText);
  };

  setSearchInputEl = (el) => {
    this.searchInput = el !== null ? el.input : null;
    this.setState({ searchInitialized: true });
  };

  handleInputFocus = () => {
    const { focused } = this.state;
    if (!focused) {
      this.setState({ focused: true, ignoreFocused: false });
    }
  };

  handleKeyDown = (event) => {
    const dropdownOpen = this.isOpen();
    const { rooms, loading, searchText } = this.props;
    const { highlightedIndex, ignoreFocused } = this.state;
    const hasRooms = !isEmpty(rooms);
    switch (event.key) {
      case "Home":
        if (dropdownOpen && !loading && hasRooms) {
          event.preventDefault();
          this.setHighlightedIndex(0);
        }
        break;
      case "End":
        if (dropdownOpen && !loading && hasRooms) {
          event.preventDefault();
          this.setHighlightedIndex(rooms.length - 1);
        }
        break;
      case "PageUp":
        if (dropdownOpen && !loading && hasRooms) {
          event.preventDefault();
          this.setHighlightedIndex(
            highlightedIndex - LocationConstants.LOCATION_SEARCH_QUERY_PAGE_SIZE
          );
        }
        break;
      case "PageDown":
        if (dropdownOpen && !loading && hasRooms) {
          event.preventDefault();
          this.setHighlightedIndex(
            highlightedIndex + LocationConstants.LOCATION_SEARCH_QUERY_PAGE_SIZE
          );
        }
        break;
      case "ArrowDown":
        event.preventDefault();
        if (dropdownOpen) {
          if (!loading && hasRooms) {
            this.setHighlightedIndex(highlightedIndex + 1);
          }
        } else if (!isEmpty(searchText) && ignoreFocused) {
          this.setState({ ignoreFocused: false });
        }
        break;
      case "ArrowUp":
        event.preventDefault();
        if (dropdownOpen) {
          if (!loading && hasRooms) {
            this.setHighlightedIndex(highlightedIndex - 1);
          }
        } else if (!isEmpty(searchText) && ignoreFocused) {
          this.setState({ ignoreFocused: false });
        }
        break;
      case "Enter":
        if (event.which === 229) {
          break;
        }
        if (dropdownOpen && !loading && hasRooms) {
          this.select(rooms);
        }
        break;
      case "Escape":
        if (dropdownOpen) {
          event.preventDefault();
          event.stopPropagation();
          this.setState({ ignoreFocused: true });
        }
        break;
      default:
    }
  };

  handleHighlightedIndexChange = (highlightedIndex) => {
    this.setHighlightedIndex(highlightedIndex);
  };

  setHighlightedIndex(highlightedIndex) {
    const { rooms } = this.props;
    const maxIndex = isEmpty(rooms) ? 0 : rooms.length - 1;
    const newHighlightedIndex =
      highlightedIndex < 0
        ? 0
        : highlightedIndex > maxIndex
        ? maxIndex
        : highlightedIndex;
    if (newHighlightedIndex !== this.state.highlightedIndex) {
      return this.setState({
        highlightedIndex: newHighlightedIndex,
        ignoreFocused: false,
      });
    }
  }

  computeInputAria(open, highlightedIndex) {
    const inputAria = {
      "aria-autocomplete": "list",
    };
    if (open) {
      inputAria["aria-controls"] = "roomSearchDropdown";
      inputAria[
        "aria-activedescendant"
      ] = `roomSearchDropdown-option-${highlightedIndex}`;
    }
    return inputAria;
  }
}

export default withTriDictionary(RoomSearch);
