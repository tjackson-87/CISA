/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2022 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import { SkeletonText } from "carbon-components-react";
import { connect } from "react-redux";
import Popper from "@material-ui/core/Popper";
import Paper from "@material-ui/core/Paper";
import Collapse from "@material-ui/core/Collapse";
import classnames from "classnames";
import isEmpty from "lodash/isEmpty";
import { Bee16 } from "@carbon/icons-react";
import { PropTypes } from "prop-types";
import { GroupedVirtuoso } from "react-virtuoso";
import Highlighter from "react-highlight-words";
import { AppMsg, getScrollParent } from "../../utils";
import { LocationSelectors } from "../../store";

const cssBase = "RoomSearchDropdown";

class RoomSearchDropdown extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    id: PropTypes.string,
    open: PropTypes.bool,
    anchorEl: PropTypes.object,
    searchText: PropTypes.string,
    rooms: PropTypes.array,
    highlightedIndex: PropTypes.number,
    loading: PropTypes.bool,
    loadingMore: PropTypes.bool,
    dir: PropTypes.string,
    onSelect: PropTypes.func,
    onSearchMore: PropTypes.func,
    onHighlightedIndexChange: PropTypes.func,
    floors: PropTypes.array,
  };

  static defaultProps = {
    open: false,
  };

  popperModifiers = {
    preventOverflow: {
      enabled: false,
    },
    hide: {
      enabled: false,
    },
    sameWidth: {
      enabled: true,
      order: 840,
      fn: (data) => {
        data.offsets.popper.width = data.styles.width = Math.round(
          data.offsets.reference.width
        );
        data.offsets.popper.top = Math.round(data.offsets.reference.bottom);
        return data;
      },
    },
    flip: {
      enabled: false,
    },
  };

  render() {
    const { id, open, anchorEl, dir } = this.props;
    return (
      <Popper
        className={cssBase}
        open={open}
        anchorEl={anchorEl}
        disablePortal={true}
        keepMounted
        transition
        placement="bottom-start"
        dir={dir}
        modifiers={this.popperModifiers}
      >
        {({ TransitionProps }) => (
          <Collapse {...TransitionProps} timeout={50}>
            <Paper
              id={id}
              square
              elevation={3}
              className={`${cssBase}__content`}
              ref={(paper) => {
                this.paper = paper;
              }}
              onMouseDown={(e) => e.preventDefault()}
            >
              {this.renderEmptyMessage()}
              {this.renderLoading()}
              {this.renderRecentSearchMessage()}
              {this.renderRooms()}
            </Paper>
          </Collapse>
        )}
      </Popper>
    );
  }

  renderLoading() {
    const { loading, open } = this.props;
    if (open && loading) {
      return (
        <div className={`${cssBase}__loading`}>
          <SkeletonText heading lineCount={1} paragraph={false} />
          <SkeletonText heading={false} lineCount={3} paragraph />
        </div>
      );
    }
    return null;
  }

  renderRecentSearchMessage() {
    if (this.showRecentSearchMessage()) {
      return (
        <div className={`${cssBase}__recentSearch`}>
          {this.props.appMessages[AppMsg.RESERVATION_MESSAGE.RECENT_SEARCHES]}
        </div>
      );
    }
    return null;
  }

  showRecentSearchMessage() {
    const { open, loading, searchText } = this.props;
    return open && !loading && isEmpty(searchText);
  }

  renderEmptyMessage() {
    const { loading, rooms, searchText, open } = this.props;
    if (open && !loading && isEmpty(rooms)) {
      return (
        <div className={`${cssBase}__empty`}>
          <Bee16 className={`${cssBase}__emptyIcon`} />
          <div>{`${
            this.props.appMessages[AppMsg.RESERVATION_MESSAGE.NO_MACTHES_FOUND]
          } ${searchText}`}</div>
        </div>
      );
    }
    return null;
  }

  renderRooms() {
    const {
      loading,
      rooms,
      searchText,
      onSearchMore,
      highlightedIndex,
      id,
      open,
      floors,
    } = this.props;
    if (!open || loading || isEmpty(rooms) || isEmpty(floors)) {
      return null;
    }
    const groupCounts = [];
    const floorName = [];

    floors.forEach((floor, index) => {
      let count = 0;
      rooms.forEach((room) => {
        if (floor._id === room.floorSystemRecordID) {
          count++;
        }
      });
      if (count > 0) {
        floorName.push(floor.name);
        groupCounts.push(count);
      }
    });

    const virtualHeight = this.computeVirtualListHeight(
      rooms.length,
      floorName.length
    );

    return (
      <GroupedVirtuoso
        ref={(virtuoso) => {
          this.virtuoso = virtuoso;
        }}
        style={{
          height: `${virtualHeight}px`,
        }}
        endReached={onSearchMore}
        components={{
          Footer: () => this.renderFooter(),
        }}
        groupCounts={groupCounts}
        groupContent={(index) => {
          return (
            <div className={`${cssBase}__floorDetails`}>{floorName[index]}</div>
          );
        }}
        role="listbox"
        itemContent={(index) =>
          this.renderRow(
            rooms[index],
            searchText,
            highlightedIndex === index,
            index,
            id
          )
        }
      />
    );
  }

  renderRow(room, searchText, highlighted, index, dropdownId) {
    const classes = classnames({
      [`${cssBase}__room`]: true,
      [`${cssBase}__room--highlighted`]: highlighted,
    });
    return (
      <div
        className={classes}
        data-option-index={index}
        onMouseDown={this.handleMouseDown}
        onMouseOver={this.handleOptionMouseOver}
        onClick={this.handleOptionClick}
        tabIndex={0}
        onKeyDown={(e) =>
          e.key === "Enter" ? this.handleOptionClick(e) : null
        }
        role="option"
        aria-selected="true"
        aria-label={`${room.roomId} ${room.name}`}
        id={`${dropdownId}-option-${index}`}
      >
        <div className={`${cssBase}__roomDetails`} tabIndex={-1}>
          <div className={`${cssBase}__roomId`} tabIndex={-1}>
            <Highlighter
              highlightClassName={`${cssBase}__highlightedText`}
              searchWords={[searchText]}
              textToHighlight={room.roomId}
            />
          </div>
          <div className={`${cssBase}__roomName`} tabIndex={-1}>
            <Highlighter
              highlightClassName={`${cssBase}__highlightedText`}
              searchWords={[searchText]}
              textToHighlight={room.name}
            />
          </div>
        </div>
      </div>
    );
  }

  renderFooter() {
    const { loadingMore } = this.props;
    if (loadingMore) {
      return (
        <div className={`${cssBase}__loadingMore`}>
          <SkeletonText heading={false} lineCount={1} />
        </div>
      );
    }
    return null;
  }

  computeVirtualListHeight = (count, floorCount) => {
    const ROW_HEIGHT = 59;
    const FLOOR_ROW_HEIGHT = 39;
    const ROW_DISPLAYABLE_COUNT = 3;
    const height = Math.min(
      Math.trunc(window.innerHeight - 150),
      ROW_HEIGHT * Math.min(ROW_DISPLAYABLE_COUNT, count) +
        FLOOR_ROW_HEIGHT * Math.min(ROW_DISPLAYABLE_COUNT - 1, floorCount) -
        1
    );
    return height < ROW_HEIGHT ? ROW_HEIGHT - 1 : height;
  };

  handleMouseDown = (event) => {
    event.preventDefault();
  };

  handleOptionMouseOver = (event) => {
    const { onHighlightedIndexChange } = this.props;
    if (onHighlightedIndexChange != null) {
      onHighlightedIndexChange(
        Number(event.currentTarget.getAttribute("data-option-index"))
      );
    }
  };

  handleOptionClick = (event) => {
    event.preventDefault();
    const { onSelect, rooms } = this.props;
    if (onSelect != null) {
      const index = Number(
        event.currentTarget.getAttribute("data-option-index")
      );
      onSelect(rooms.filter((room) => room === rooms[index]));
    }
  };

  componentDidUpdate(prevProps) {
    const { highlightedIndex, loading, rooms, open } = this.props;
    if (
      highlightedIndex !== prevProps.highlightedIndex &&
      open &&
      !loading &&
      !isEmpty(rooms)
    ) {
      this.scrollToIndex(
        highlightedIndex,
        highlightedIndex > prevProps.highlightedIndex ? "end" : "start"
      );
    }
  }

  scrollToIndex(highlightedIndex, align) {
    const option = this.paper.querySelector(
      `[data-option-index="${highlightedIndex}"]`
    );
    if (!option) {
      this.virtuoso.scrollToIndex({ index: highlightedIndex, align });
    } else {
      const parent = getScrollParent(option, this.paper);
      if (parent != null && parent.scrollHeight > parent.clientHeight) {
        const scrollBottom = parent.clientHeight + parent.scrollTop;
        const elementBottom = option.offsetTop + option.offsetHeight;
        if (elementBottom > scrollBottom) {
          parent.scrollTop = elementBottom - parent.clientHeight;
        } else if (option.offsetTop < parent.scrollTop) {
          parent.scrollTop = option.offsetTop;
        }
      }
    }
  }
}

const mapStateToProps = (state) => {
  return {
    floors: LocationSelectors.floorsSelector(state),
  };
};

export default withTriDictionary(
  connect(mapStateToProps, {})(RoomSearchDropdown)
);
