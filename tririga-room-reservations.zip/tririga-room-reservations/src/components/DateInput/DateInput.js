/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import classNames from "classnames";
import defaultTo from "lodash/defaultTo";
import {
  DatePickerInput,
  DatePicker,
  DatePickerSkeleton,
} from "carbon-components-react";
import moment from "moment-timezone";
import { AppMsg, DefaultValues, closeAllDatepickerPopups } from "../../utils";

const cssBase = "dateInput";
const datePickerPatterns = {
  short: "\\d{1,2}/\\d{4}",
  regular: "\\d{1,2}/\\d{1,2}/\\d{4}",
};

class DateInput extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    onValueChange: PropTypes.func.isRequired,
    value: PropTypes.instanceOf(Date),
    carbonDateFormat: PropTypes.string,
    dateFormat: PropTypes.string,
    carbonLocale: PropTypes.string,
    label: PropTypes.string,
    id: PropTypes.string,
    light: PropTypes.bool,
    defaultBlank: PropTypes.bool,
    className: PropTypes.string,
  };

  static defaultProps = {
    carbonDateFormat: DefaultValues.CARBON_DATE_FORMAT,
    dateFormat: DefaultValues.DATE_FORMAT,
    carbonLocale: DefaultValues.CARBON_LOCALE,
  };

  state = {
    dateContainer: null,
  };

  render() {
    const {
      carbonDateFormat,
      dateFormat,
      carbonLocale,
      value,
      label,
      id,
      light,
      defaultBlank,
      className,
    } = this.props;
    const { dateContainer } = this.state;
    return (
      <div
        className={classNames(cssBase, className)}
        ref={(element) => {
          this.setState({ dateContainer: element });
        }}
      >
        {dateContainer && carbonLocale ? (
          <DatePicker
            className={`${cssBase}__datePicker`}
            dateFormat={defaultTo(
              carbonDateFormat,
              DefaultValues.CARBON_DATE_FORMAT
            )}
            ref={(datePicker) => {
              this.datePicker = datePicker;
            }}
            datePickerType="single"
            value={defaultTo(value, defaultBlank ? undefined : new Date())}
            onChange={this.handleDateChange}
            locale={defaultTo(carbonLocale, DefaultValues.CARBON_LOCALE)}
            onClick={(e) => this.datePicker.inputField.scrollIntoView(true)}
            appendTo={dateContainer}
            light={light}
            onFocus={() => this.onfocus()}
          >
            <DatePickerInput
              id={id}
              placeholder={defaultTo(dateFormat, DefaultValues.DATE_FORMAT)}
              labelText={label}
              invalidText={
                this.props.appMessages[
                  AppMsg.RESERVATION_MESSAGE.STEP_TIME_MEETING_DATE_INVALID
                ]
              }
              pattern={datePickerPatterns.regular}
              type="text"
              readOnly // CISA
              aria-label={AppMsg.getMessage(AppMsg.CALENDAR)}
            />
          </DatePicker>
        ) : (
          <DatePickerSkeleton />
        )}
      </div>
    );
  }

  onfocus() {
    closeAllDatepickerPopups();
    if (this.state.dateContainer) {
      const nodes = this.state.dateContainer.childNodes;
      if (nodes && nodes.length > 1) {
        const e = nodes[1];
        e.classList.add("open");
      }
    }
  }

  handleDateChange = (result) => {
    const { value } = this.props;
    const selectedDate = result[0];
    if (value != null) {
      const isSameDay = moment(value).isSame(selectedDate, "days");
      if (!isSameDay) {
        this.props.onValueChange(selectedDate);
      }
    } else {
      this.props.onValueChange(selectedDate);
    }
  };
}

export default withTriDictionary(DateInput);
