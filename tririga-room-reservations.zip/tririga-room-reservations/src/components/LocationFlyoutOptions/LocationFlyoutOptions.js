/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import { Button } from "carbon-components-react";
import MenuItem from "@mui/material/MenuItem";
import Divider from "@material-ui/core/Divider";
import { Enterprise16, CaretDown16 } from "@carbon/icons-react";
import { AppMsg } from "../../utils";
import { Menu } from "@material-ui/core";

const cssBase = "locationFlyoutButton";

class LocationFlyoutOptions extends React.PureComponent {
  static propTypes = {
    changeLocationButtonRef: PropTypes.any,
    onHandleAddLocationsClick: PropTypes.func,
    onHandleRemoveBuilding: PropTypes.func,
    appMessages: PropTypes.object,
    selectedBuilding: PropTypes.object,
    dir: PropTypes.string,
  };

  state = {
    isOpen: false,
  };

  render() {
    const { selectedBuilding, changeLocationButtonRef, dir } = this.props;
    const { anchorEl } = this.state;

    const open = Boolean(anchorEl);

    const handleClose = () => {
      this.setState({ isOpen: false });
    };

    const handleClick = (event) => {
      this.setState({ isOpen: true });
    };

    return (
      <>
        <Button
          id="location-button"
          kind="ghost"
          size="sm"
          ref={changeLocationButtonRef}
          onClick={handleClick}
          renderIcon={open ? CaretDown16 : Enterprise16}
          className={`${cssBase}__locationButton`}
          iconDescription={`${selectedBuilding.name}`}
          data-testid="location-button"
        >
          {selectedBuilding.name}
        </Button>
        <Menu
          className={`${cssBase}__menu`}
          id="location-button"
          MenuListProps={{
            "aria-labelledby": "location-button",
          }}
          anchorEl={changeLocationButtonRef.current}
          onClose={handleClose}
          open={this.state.isOpen}
          anchorOrigin={{
            vertical: "bottom",
            horizontal: dir === "rtl" ? "left" : "right",
          }}
          transformOrigin={{
            vertical: "top",
            horizontal: dir === "rtl" ? "left" : "right",
          }}
          getContentAnchorEl={null}
        >
          <MenuItem
            onClick={this.handleChangeLocation}
            className={`${cssBase}__menuItem`}
            data-testid="menuItem1"
          >
            <Button
              kind="ghost"
              size="sm"
              className={`${cssBase}__menuButtons`}
            >
              {
                this.props.appMessages[
                  AppMsg.RESERVATION_MESSAGE.CHANGE_LOCATION
                ]
              }
            </Button>
          </MenuItem>
          <Divider />
          <MenuItem
            onClick={this.handleClearLocation}
            className={`${cssBase}__menuItem`}
            data-testid="menuItem2"
          >
            <Button
              kind="ghost"
              size="sm"
              className={`${cssBase}__menuButtons`}
            >
              {
                this.props.appMessages[
                  AppMsg.RESERVATION_MESSAGE.CLEAR_LOCATION
                ]
              }
            </Button>
          </MenuItem>
        </Menu>
      </>
    );
  }

  handleChangeLocation = (e) => {
    const { onHandleAddLocationsClick } = this.props;
    this.setState({ isOpen: false });
    onHandleAddLocationsClick(e);
  };

  handleClearLocation = () => {
    const { onHandleRemoveBuilding } = this.props;
    this.setState({ isOpen: false });
    onHandleRemoveBuilding();
  };
}

export default withTriDictionary(LocationFlyoutOptions);
