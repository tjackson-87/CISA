import React from "react";
import { screen, fireEvent } from "@testing-library/react";
import { AppMsg } from "../../../utils";
import { renderWithTriDictionaryProvider } from "../../../testUtils";
import LocationFlyoutOptions from "../LocationFlyoutOptions";

afterEach(() => jest.clearAllMocks());

describe("LocationFlyoutOptions", () => {
  const onHandleAddLocationsClick = jest.fn();
  const handleRemoveBuilding = jest.fn();
  const selectedBuilding = {};
  const appMessages = AppMsg.getAppMessages();
  const props = {
    appMessages,
    onHandleAddLocationsClick,
    handleRemoveBuilding,
    selectedBuilding,
  };

  it("should render a button with the selected building name", () => {
    renderWithTriDictionaryProvider(<LocationFlyoutOptions {...props} />, {
      appMessages,
    });
    const locationButton = screen.getByTestId("location-button");
    expect(locationButton).toBeInTheDocument();
  });

  it("should render menu items when selected building is clicked", () => {
    renderWithTriDictionaryProvider(<LocationFlyoutOptions {...props} />, {
      appMessages,
    });
    const locationButton = screen.getByTestId("location-button");
    fireEvent.click(locationButton);
    const menuItem1 = screen.getByText(appMessages.CHANGE_LOCATION);
    const menuItem2 = screen.getByText(appMessages.CLEAR_LOCATION);
    expect(menuItem1).toBeInTheDocument();
    expect(menuItem2).toBeInTheDocument();
  });

  it("should open location modal when change location button is clicked", () => {
    renderWithTriDictionaryProvider(<LocationFlyoutOptions {...props} />, {
      appMessages,
    });
    const locationButton = screen.getByTestId("location-button");
    fireEvent.click(locationButton);
    const changeLocationButton = screen.getByText(appMessages.CHANGE_LOCATION);
    fireEvent.click(changeLocationButton);
    expect(props.onHandleAddLocationsClick).toHaveBeenCalled();
  });

  it("should clear selected building when clear location button is clicked", () => {
    renderWithTriDictionaryProvider(<LocationFlyoutOptions {...props} />, {
      appMessages,
    });
    const locationButton = screen.getByTestId("location-button");
    fireEvent.click(locationButton);
    const changeLocationButton = screen.getByText(appMessages.CLEAR_LOCATION);
    fireEvent.click(changeLocationButton);
    expect(props.handleRemoveBuilding).toHaveBeenCalled();
  });
});
