/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import PropTypes from "prop-types";
import defaultTo from "lodash/defaultTo";
import { TextInput } from "carbon-components-react";

export default class AdditionalLocationInfoInput extends React.PureComponent {
  static propTypes = {
    onValueChanged: PropTypes.func.isRequired,
    hideLabel: PropTypes.bool,
    value: PropTypes.string,
    onBlur: PropTypes.func,
    labelText: PropTypes.string,
    className: PropTypes.string,
    id: PropTypes.string,
  };

  static defaultProps = {
    hideLabel: true,
  };

  componentDidMount() {
    this.textInputRef.focus();
  }

  handleInput(e) {
    this.props.onValueChanged(e.target.value);
  }

  render() {
    const { value, onBlur, labelText, className, id, hideLabel } = this.props;
    return (
      <TextInput
        id={id}
        className={className}
        onBlur={onBlur}
        ref={(element) => {
          this.textInputRef = element;
        }}
        labelText={labelText}
        hideLabel={hideLabel}
        onChange={(value) => this.handleInput(value)}
        type="text"
        value={defaultTo(value, "")}
        maxLength="150"
      />
    );
  }
}
