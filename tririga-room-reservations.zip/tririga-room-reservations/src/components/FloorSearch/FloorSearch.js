/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import { USER_DIR } from "../../utils/constants/DefaultValues";
import FloorSearchTable from "./FloorSearchTable";
const cssBase = "floorSearch";

class FloorSearch extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    onSearchLoad: PropTypes.func,
    onSelect: PropTypes.func,
    floors: PropTypes.array,
    loading: PropTypes.bool,
    isModalOpen: PropTypes.bool,
  };

  state = {

  };

  static defaultProps = {
    dir: USER_DIR,
    floors: [],
  };

  render() {
    const {
      floors,
      loading,
      onSelect,
    } = this.props;
    const modalOpen = this.isOpen();
    return (
      <div className={cssBase}>
          <FloorSearchTable
            id="locationSearchDropdown"
            open={modalOpen}
            floors={floors}
            loading={loading}
            onSelect={onSelect}
          />
      </div>
    );
  }

  componentDidMount() {

  }

  componentWillUnmount() {

  }

  isOpen() {
    const { isModalOpen } = this.props;
    return isModalOpen;
  }
  
}

export default withTriDictionary(FloorSearch);
