/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import {
  DataTable,
  DataTableSkeleton,
  Table,
  TableHead,
  TableRow,
  TableHeader,
  TableBody,
  TableCell
} from 'carbon-components-react';
import isEmpty from "lodash/isEmpty";
import { Bee16 } from "@carbon/icons-react";
import { PropTypes} from "prop-types";
import { AppMsg} from "../../utils";
import {FLOOR_TABLE_HEADERS, FLOOR_TABLE_HEADERS_LOADING} from "../../utils/constants/DataTableHeaders";

const cssBase = "floorSearchTable";

class FloorSearchTable extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    id: PropTypes.string,
    open: PropTypes.bool,
    floors: PropTypes.array,
    loading: PropTypes.bool,
    dir: PropTypes.string,
    onSelect: PropTypes.func
  };

  static defaultProps = {
    open: true,
    headers: FLOOR_TABLE_HEADERS,
    loadingHeaders: FLOOR_TABLE_HEADERS_LOADING,
    useZebraStyles: true,
    stickyHeader: true,
    showHeader: false,
    showToolbar: false,
    loadingColumnCount: 2
  };

  render() {
    return (
      <div>
        {this.renderTable()}
        {this.renderEmptyMessage()}
        {this.renderLoading()}
      </div>
    );
  }

  renderTable(){
    const {open, loading, floors, headers, useZebraStyles, stickyHeader} = this.props;
    if(open && !loading && floors){
      return (
        <div>
          <DataTable className={`${cssBase}__Table`}  rows={floors} useZebraStyles={useZebraStyles} headers={headers} stickyHeader={stickyHeader}>
            {({ rows, headers, getTableProps, getHeaderProps, getRowProps }) => (
              <Table {...getTableProps()}>
                <TableHead>
                  <TableRow>
                    {headers.map((header) => (
                      <TableHeader {...getHeaderProps({ header, isSortable: true })}>
                        {header.header}
                      </TableHeader>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {rows.map((row) => (
                      <TableRow floor-id={row.id} onClick={this.handleOptionClick} {...getRowProps({ row})}>
                        {row.cells.map((cell) => (
                          <TableCell key={cell.id}>{cell.value}</TableCell>
                        ))}
                      </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </DataTable>
        </div>
      );
    } else {
      return null;
    }
  }

  renderLoading() {
    const { loading, open, loadingHeaders, showHeader, showToolbar, loadingColumnCount} = this.props;
    if (open && loading) {
      return (
        <div className={`${cssBase}__loading`}>
           <DataTableSkeleton headers={loadingHeaders} showHeader={showHeader} showToolbar={showToolbar} columnCount={loadingColumnCount} aria-label="floors Table" />
        </div>
      );
    }
    return null;
  }

  renderEmptyMessage() {
    const { loading, floors, open } = this.props;
    if (open && !loading && isEmpty(floors)) {
      return (
        <div className={`${cssBase}__empty`}>
          <Bee16 className={`${cssBase}__emptyIcon`} />
          <div>{`${ this.props.appMessages[AppMsg.RESERVATION_MESSAGE.NO_FLOOR_MATCHES_FOUND] }`}</div>
        </div>
      );
    }
    return null;
  }

  handleOptionClick = (event) => {
    const { onSelect, floors} = this.props;
    if (onSelect != null) {
      const id = Number(
        event.currentTarget.getAttribute("floor-id")
      );
      let floor = floors.find(element => element.id === id.toString())
      onSelect(floor);
    }
  };

  componentDidUpdate() {
    
  }

}

export default withTriDictionary(FloorSearchTable);
