/* IBM Confidential· - OCO Source Materials· - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise· divested of its trade secrets, irrespective of what has been· deposited with the U.S. Copyright Office. */

import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import { ContentSwitcher, Switch } from "carbon-components-react";
import { AppMsg, DateTimeConstants } from "../../utils";

const { DateTimeViewMode } = DateTimeConstants;

const switches = [
  {
    name: DateTimeViewMode.SIMPLE,
    messageKey: AppMsg.BUTTON.SWITCH_SIMPLE_VIEW,
  },
  {
    name: DateTimeViewMode.ADVANCED,
    messageKey: AppMsg.BUTTON.SWITCH_ADVANCED_VIEW,
  },
];

function getDateTimeViewModeIndex(mode) {
  const index = switches.findIndex((switchInfo) => switchInfo.name === mode);
  return index >= 0 ? index : 0;
}

class DateTimeViewSwitcher extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    mode: PropTypes.string.isRequired,
    onChange: PropTypes.func,
    className: PropTypes.string,
  };

  static defaultProps = {
    mode: DateTimeViewMode.SIMPLE,
  };

  render() {
    const { className, mode } = this.props;

    return (
      <ContentSwitcher
        onChange={this.handleOnChange}
        selectionMode="manual"
        className={className}
        selectedIndex={getDateTimeViewModeIndex(mode)}
      >
        {switches.map((switchInfo, index) => (
          <Switch
            name={switchInfo.name}
            text={this.props.appMessages[switchInfo.messageKey]}
            key={switchInfo.name}
            index={index}
            onClick={() => {}}
            onKeyDown={() => {}}
          />
        ))}
      </ContentSwitcher>
    );
  }

  handleOnChange = (selected) => {
    const { onChange } = this.props;
    if (onChange) {
      onChange(selected.name);
    }
  };
}

export default withTriDictionary(DateTimeViewSwitcher);
