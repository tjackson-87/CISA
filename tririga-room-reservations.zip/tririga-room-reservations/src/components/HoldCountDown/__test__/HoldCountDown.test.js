/* IBM Confidential· - OCO Source Materials· - (C) COPYRIGHT IBM CORP. 2023 - The source code for this program is not published or otherwise· divested of its trade secrets, irrespective of what has been· deposited with the U.S. Copyright Office. */

import React from "react";
import { fireEvent, screen } from "@testing-library/react";
import HoldCountDown from "../HoldCountDown";
import { AppMsg, ReservationUtils, ReservationTypes } from "../../../utils";
import { renderWithTriDictionaryProvider } from "../../../testUtils";
import moment from "moment-timezone";

afterEach(() => jest.clearAllMocks());

describe("HoldCountDown", () => {
  let props;
  const appMessages = AppMsg.getAppMessages();
  beforeEach(() => {
    props = {
      appMessages,
      holdTimeEnd: moment().add(10, "minutes").toISOString(),
      onRenewHoldTime: jest.fn(),
      className: "holdDownCount",
      reservationType: ReservationTypes.MEETING,
    };
  });

  it("Should not render if holdTimeEnd is null", () => {
    const args = { ...props, holdTimeEnd: null };
    renderWithTriDictionaryProvider(<HoldCountDown {...args} />, {
      appMessages,
    });
    const btn = screen.queryAllByRole("button", {
      name: appMessages.BUTTON_RENEW,
    });
    expect(btn.length).toBe(0);
  });

  it("renders correctly for Meeting Space reservation type", () => {
    const mock = jest.spyOn(ReservationUtils, "computeTimeDifferenceDuration");
    mock.mockReturnValue(600000);
    renderWithTriDictionaryProvider(<HoldCountDown {...props} />, {
      appMessages,
    });
    const text = screen.queryAllByText(
      `${appMessages.ROOM_HOLD_EXPIRES_IN} 10:00`
    );
    expect(text.length).toBeGreaterThan(0);
  });

  it("Should render correct message when reservation room is expired", () => {
    const mock = jest.spyOn(ReservationUtils, "computeTimeDifferenceDuration");
    mock.mockReturnValue(0);
    renderWithTriDictionaryProvider(<HoldCountDown {...props} />, {
      appMessages,
    });
    const text = screen.queryAllByText(appMessages.ROOM_HOLD_EXPIRED);
    expect(text.length).toBeGreaterThan(0);
  });

  it("Should call onRenewHoldTime callback when recheck button is clicked", () => {
    const mock = jest.spyOn(ReservationUtils, "computeTimeDifferenceDuration");
    mock.mockReturnValue(600000);
    renderWithTriDictionaryProvider(<HoldCountDown {...props} />, {
      appMessages,
    });
    const recheckButton = screen.getByRole("button", {
      name: appMessages.BUTTON_RENEW,
    });
    fireEvent.click(recheckButton);
    expect(props.onRenewHoldTime).toHaveBeenCalled();
  });

  it("renders correctly for workspace reservation type", () => {
    const mock = jest.spyOn(ReservationUtils, "computeTimeDifferenceDuration");
    mock.mockReturnValue(600000);
    const args = { ...props, reservationType: ReservationTypes.WORKSPACE };
    renderWithTriDictionaryProvider(<HoldCountDown {...args} />, {
      appMessages,
    });
    const text = screen.queryAllByText(
      `${appMessages.WORKSPACE_HOLD_EXPIRES_IN} 10:00`
    );
    expect(text.length).toBeGreaterThan(0);
  });

  it("Should render correct message when workspace is expired", () => {
    const mock = jest.spyOn(ReservationUtils, "computeTimeDifferenceDuration");
    mock.mockReturnValue(0);
    const args = { ...props, reservationType: ReservationTypes.WORKSPACE };
    renderWithTriDictionaryProvider(<HoldCountDown {...args} />, {
      appMessages,
    });
    const text = screen.queryAllByText(appMessages.WORKSPACE_HOLD_EXPIRED);
    expect(text.length).toBeGreaterThan(0);
  });
});
