/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2022 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import classnames from "classnames";
import {
  InlineNotification,
  NotificationActionButton,
} from "carbon-components-react";
import moment from "moment-timezone";
import momentDurationFormatSetup from "moment-duration-format";
import {
  AppMsg,
  ReservationTypes,
  ReservationUtils,
  DateTimeConstants,
} from "../../utils";

momentDurationFormatSetup(moment);

const cssBase = "holdCountDown";

class HoldCountDown extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    holdTimeEnd: PropTypes.string,
    onRenewHoldTime: PropTypes.func,
    className: PropTypes.string,
    reservationType: PropTypes.string,
  };

  constructor(props) {
    super(props);
    this.intervalId = null;
    this.ariaLiveIntervalMin = null;
  }

  state = {
    holdDuration: null,
    ariaLiveCountdown: null,
  };

  render() {
    const {
      className,
      onRenewHoldTime,
      holdTimeEnd,
      reservationType,
    } = this.props;
    const { holdDuration, ariaLiveCountdown } = this.state;
    if (holdTimeEnd == null) return null;
    const expired = holdDuration === 0;
    const title = this.computeTitle(holdDuration, expired, reservationType);
    const alertTitle = this.computeTitle(
      ariaLiveCountdown,
      expired,
      reservationType
    );
    return (
      <>
        <InlineNotification
          role="timer"
          className={classnames(cssBase, className)}
          kind={expired ? "warning" : "info"}
          hideCloseButton
          lowContrast
          title={title}
          statusIconDescription={title}
          actions={
            <NotificationActionButton onClick={onRenewHoldTime}>
              {this.props.appMessages[AppMsg.BUTTON.RENEW]}
            </NotificationActionButton>
          }
        />
        <div
          id="alert"
          role="alert"
          aria-live="assertive"
          className={`${cssBase}__inlineTimer`}
        >
          {alertTitle}
        </div>
      </>
    );
  }

  computeTitle(holdDuration, expired, reservationType) {
    if (reservationType === ReservationTypes.MEETING) {
      return expired
        ? AppMsg.getMessage(AppMsg.RESERVATION_MESSAGE.ROOM_HOLD_EXPIRED)
        : `${
            this.props.appMessages[
              AppMsg.RESERVATION_MESSAGE.ROOM_HOLD_EXPIRES_IN
            ]
          } ${moment.duration(holdDuration).format("mm:ss")}`;
    // CISA
    } else if (reservationType === ReservationTypes.OFFICE) {
      return expired
        ? AppMsg.getMessage(AppMsg.RESERVATION_MESSAGE.OFFICE_HOLD_EXPIRED)
        : `${
            this.props.appMessages[
              AppMsg.RESERVATION_MESSAGE.OFFICE_HOLD_EXPIRES_IN
            ]
          } ${moment.duration(holdDuration).format("mm:ss")}`;
    } else {
      return expired
        ? AppMsg.getMessage(AppMsg.RESERVATION_MESSAGE.WORKSPACE_HOLD_EXPIRED)
        : `${
            this.props.appMessages[
              AppMsg.RESERVATION_MESSAGE.WORKSPACE_HOLD_EXPIRES_IN
            ]
          } ${moment.duration(holdDuration).format("mm:ss")}`;
    }
  }

  componentDidMount() {
    const { holdTimeEnd } = this.props;
    this.runTimer(holdTimeEnd);
    this.runMinuteTimer(holdTimeEnd);
  }

  componentDidUpdate(prevProps) {
    const { holdTimeEnd } = this.props;
    if (holdTimeEnd !== prevProps.holdTimeEnd) {
      this.runTimer(holdTimeEnd);
      this.runMinuteTimer(holdTimeEnd);
    }
  }

  componentWillUnmount() {
    this.clearTimer();
  }

  clearTimer() {
    if (this.intervalId != null) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
    if (this.ariaLiveIntervalMin != null) {
      clearInterval(this.ariaLiveIntervalMin);
      this.ariaLiveIntervalMin = null;
    }
  }

  runTimer(holdTimeEnd) {
    this.clearTimer();
    if (holdTimeEnd != null) {
      this.computeHoldDuration(holdTimeEnd);
      this.intervalId = setInterval(
        () => this.computeHoldDuration(holdTimeEnd),
        1000
      );
    }
  }

  computeHoldDuration(holdTimeEnd) {
    const holdDuration = ReservationUtils.computeTimeDifferenceDuration(
      holdTimeEnd
    );
    this.setState({
      holdDuration,
    });
    if (holdDuration === 0) {
      this.clearTimer();
    }
  }

  runMinuteTimer(holdTimeEnd) {
    if (holdTimeEnd != null) {
      this.computeHoldDurationMinuteTimer(holdTimeEnd);
      this.ariaLiveIntervalMin = setInterval(
        () => this.computeHoldDurationMinuteTimer(holdTimeEnd),
        DateTimeConstants.HOLDTIME_TIMER_IN_SECONDS
      );
    }
  }

  computeHoldDurationMinuteTimer(holdTimeEnd) {
    const ariaLiveCountdown = ReservationUtils.computeTimeDifferenceDuration(
      holdTimeEnd
    );
    this.setState({
      ariaLiveCountdown,
    });
  }
}

export default withTriDictionary(HoldCountDown);
