/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import classnames from "classnames";
import { Button } from "carbon-components-react";
import { AppMsg, CateringUtils } from "../../utils";

const cssBase = "cateringFooter";

class CateringFooter extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    className: PropTypes.string,
    primaryLabel: PropTypes.string.isRequired,
    primaryClickedHandler: PropTypes.func,
    primaryDisabled: PropTypes.bool,
    addedCatering: PropTypes.array,
    viewOrder: PropTypes.bool,
    secondaryLabel: PropTypes.string.isRequired,
    secondaryClickedHandler: PropTypes.func,
    currency: PropTypes.string,
    viewAddAnotherOrder: PropTypes.bool,
    currentUserLocale: PropTypes.string,
    viewOrderFoodDetail: PropTypes.bool,
    onlyOneOrderReadOnly: PropTypes.bool,
    showViewOrderDoneButton: PropTypes.bool,
    onViewOrderDoneClick: PropTypes.func,
    isReadOnly: PropTypes.bool,
    viewReadOnlyOrderList: PropTypes.bool,
  };

  state = {
    openModal: false,
    localInstructions: "",
  };

  render() {
    const {
      className,
      addedCatering,
      viewAddAnotherOrder,
      viewOrder,
      viewOrderFoodDetail,
      viewReadOnlyOrderList,
      onlyOneOrderReadOnly,
    } = this.props;
    const itemsCount = CateringUtils.getItemsOrderCount(addedCatering);
    return (
      <div className={classnames(cssBase, className)}>
        {viewOrderFoodDetail && this.renderAddToOrder()}
        {!viewOrderFoodDetail &&
          !viewAddAnotherOrder &&
          (!viewReadOnlyOrderList || onlyOneOrderReadOnly) && (
            <>
              {this.renderOrderSummary(itemsCount)}
              {this.renderConfirmOrder()}
            </>
          )}
        {!viewOrderFoodDetail && !viewOrder && this.renderViewOrder()}
        {viewReadOnlyOrderList && this.renderDoneBtnForReadOnly()}
      </div>
    );
  }

  renderAddToOrder = () => {
    const { secondaryLabel, secondaryClickedHandler } = this.props;
    return (
      <div className={`${cssBase}__confirmOrder`}>
        <Button
          className={`${cssBase}__button`}
          kind="secondary"
          size="small"
          onClick={secondaryClickedHandler}
          aria-label={secondaryLabel}
        >
          {secondaryLabel}
        </Button>
      </div>
    );
  };

  renderOrderSummary = (itemsCount) => {
    const { addedCatering, currency, currentUserLocale } = this.props;
    const itemsTotal = CateringUtils.getItemsOrderTotal(addedCatering);
    const foodCost = CateringUtils.getFoodCost(
      currentUserLocale,
      currency,
      itemsTotal.toFixed(2)
    );
    return (
      <div className={`${cssBase}__orderSummary`}>
        <div className={`${cssBase}__orderTotal`}>
          {itemsCount}{" "}
          {this.props.appMessages[AppMsg.RESERVATION_MESSAGE.ITEMS]}
        </div>
        <div className={`${cssBase}__orderTotal`}>
          {`${this.props.appMessages[AppMsg.RESERVATION_MESSAGE.ORDER_TOTAL]}: 
            ${foodCost}`}
        </div>
      </div>
    );
  };

  renderConfirmOrder = () => {
    const {
      primaryLabel,
      primaryClickedHandler,
      primaryDisabled,
      viewOrder,
      secondaryLabel,
      secondaryClickedHandler,
      isReadOnly,
    } = this.props;
    return (
      viewOrder && (
        <div className={`${cssBase}__confirmOrder`}>
          {isReadOnly ? (
            <Button
              className={`${cssBase}__button`}
              kind="secondary"
              size="small"
              onClick={secondaryClickedHandler}
              aria-label={secondaryLabel}
            >
              {secondaryLabel}
            </Button>
          ) : (
            <>
              <Button
                className={`${cssBase}__button`}
                kind="danger--tertiary"
                size="small"
                onClick={secondaryClickedHandler}
                aria-labelledby="cancelOrderNote"
              >
                <span hidden id="cancelOrderNote">
                  {secondaryLabel}
                </span>
                {secondaryLabel}
              </Button>
              <Button
                className={`${cssBase}__button`}
                kind="primary"
                size="small"
                disabled={primaryDisabled}
                onClick={primaryClickedHandler}
                aria-label={primaryLabel}
              >
                {primaryLabel}
              </Button>
            </>
          )}
        </div>
      )
    );
  };

  renderViewOrder = () => {
    const {
      primaryLabel,
      primaryClickedHandler,
      primaryDisabled,
      showViewOrderDoneButton,
      appMessages,
      onViewOrderDoneClick,
      isReadOnly,
    } = this.props;
    return (
      <div className={`${cssBase}__viewOrderContainer`}>
        {showViewOrderDoneButton && (
          <Button
            className={`${cssBase}__viewOrderDoneButton`}
            kind="secondary"
            size="small"
            onClick={onViewOrderDoneClick}
            aria-label={appMessages[AppMsg.BUTTON.DONE]}
          >
            {appMessages[AppMsg.BUTTON.DONE]}
          </Button>
        )}
        {!isReadOnly && (
          <Button
            className={`${cssBase}__viewOrderbutton`}
            kind="primary"
            size="small"
            disabled={primaryDisabled}
            onClick={primaryClickedHandler}
            aria-label={primaryLabel}
          >
            {primaryLabel}
          </Button>
        )}
      </div>
    );
  };

  renderDoneBtnForReadOnly = () => {
    const { secondaryLabel, secondaryClickedHandler } = this.props;

    return (
      <div className={`${cssBase}__confirmOrder`}>
        <Button
          className={`${cssBase}__button`}
          kind="secondary"
          size="small"
          onClick={secondaryClickedHandler}
          aria-label={secondaryLabel}
        >
          {secondaryLabel}
        </Button>
      </div>
    );
  };
}

export default withTriDictionary(CateringFooter);
