/* IBM Confidential· - OCO Source Materials· - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise· divested of its trade secrets, irrespective of what has been· deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import classNames from "classnames";
import PropTypes from "prop-types";
import { TriImage, withTriDictionary } from "@tririga/tririga-react-components";
import { isEmpty } from "lodash";
import { Select, SelectItem, Button } from "carbon-components-react";
import { Add16, Edit16 } from "@carbon/icons-react";
import { AppMsg, CateringUtils } from "../../utils";
import { InstructionsModel } from "../";

const cssBase = "cateringListItem";

class CateringListItem extends React.PureComponent {
  constructor(props) {
    super(props);
    this.addInstructionsButtonRef = React.createRef();
  }

  static propTypes = {
    appMessages: PropTypes.object,
    menu: PropTypes.object,
    className: PropTypes.string,
    handleListChange: PropTypes.func,
    qty: PropTypes.number,
    currency: PropTypes.string,
    currentUserLocale: PropTypes.string,
    instructions: PropTypes.string,
    onClick: PropTypes.func,
    setMenuItemRef: PropTypes.func,
  };

  state = {
    openModal: false,
    localInstructions: this.props.instructions || "",
  };

  render() {
    const {
      menu,
      className,
      qty,
      currency,
      currentUserLocale,
      instructions,
      onClick,
      setMenuItemRef,
    } = this.props;
    const { openModal, localInstructions } = this.state;
    return (
      <div className={classNames(cssBase, className)}>
        <div className={`${cssBase}__content`}>
          <div
            className={`${cssBase}__content-top`}
            ref={(ref) => {
              setMenuItemRef(ref, menu._id);
            }}
            onClick={onClick}
            tabIndex={0}
            role="link"
            onKeyPress={(e) => (e.key === "Enter" ? onClick() : null)}
          >
            {menu.image && (
              <TriImage value={menu.image} className={`${cssBase}__image`} />
            )}
            <div className={`${cssBase}__cateringDetails`}>
              <div className={`${cssBase}__title`}>{menu.menuItem}</div>
              <div className={`${cssBase}__description`}>
                {menu.description}
              </div>
              <div className={`${cssBase}__cost`}>
                {CateringUtils.getFoodCost(
                  currentUserLocale,
                  currency,
                  menu.costPerItem.value.toFixed(2)
                )}
              </div>
            </div>
          </div>
          <div className={`${cssBase}__content-bottom`}>
            <div className={`${cssBase}__instructionsQuanity`}>
              <div className={`${cssBase}__qty`}>
                <Select
                  id={`qty_${menu._id}`}
                  light
                  labelText={
                    this.props.appMessages[AppMsg.RESERVATION_MESSAGE.QUANTITY]
                  }
                  className={`${cssBase}__quantityInput`}
                  value={qty}
                  onChange={this.handleQtyChanged}
                >
                  {this.renderSelectItemQty()}
                </Select>
              </div>
              <div className={`${cssBase}__instructions`}>
                <InstructionsModel
                  localInstructions={localInstructions}
                  openModal={openModal}
                  onDoneClick={this.handleDoneClick}
                  onCancelClick={this.handleCancelClick}
                  onInstructionsChanged={this.handleInstructionsChanged}
                  label={
                    this.props.appMessages[
                      AppMsg.RESERVATION_MESSAGE.STEP_ROOMS_INSTRUCTIONS
                    ]
                  }
                />
                <Button
                  className={`${cssBase}__instructionsButton`}
                  kind="ghost"
                  size="small"
                  renderIcon={isEmpty(instructions) ? Add16 : Edit16}
                  disabled={qty === 0}
                  onClick={(e) => {
                    this.setState({
                      openModal: !openModal,
                      localInstructions: instructions,
                    });
                    e.stopPropagation();
                  }}
                  ref={this.addInstructionsButtonRef}
                >
                  {isEmpty(instructions)
                    ? this.props.appMessages[
                        AppMsg.RESERVATION_MESSAGE.STEP_ROOMS_ADD_INSTRUCTIONS
                      ]
                    : this.props.appMessages[
                        AppMsg.RESERVATION_MESSAGE.STEP_ROOMS_EDIT_INSTRUCTIONS
                      ]}
                </Button>
              </div>
            </div>
            {instructions && (
              <div className={`${cssBase}__readOnlyInstructions`}>
                {instructions}
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  handleQtyChanged = (e) => {
    const { handleListChange, menu } = this.props;
    const qty = parseInt(e.target.value);
    handleListChange({ ...menu, qty });
  };

  renderSelectItemQty() {
    const selectItem = [];
    for (let i = 0; i <= 1000; i++) {
      selectItem.push(<SelectItem key={i} value={i} text={String(i)} />);
    }
    return selectItem;
  }

  handleInstructionsChanged = (e) => {
    this.setState({ localInstructions: e.target.value });
  };

  handleDoneClick = () => {
    const { handleListChange, menu, qty } = this.props;
    const { localInstructions } = this.state;

    handleListChange({ ...menu, qty, instructions: localInstructions });
    this.setState({ localInstructions: "", openModal: false });
    if (this.addInstructionsButtonRef.current)
      setTimeout(() => this.addInstructionsButtonRef.current.focus(), 1);
  };

  handleCancelClick = () => {
    this.setState({ openModal: false, localInstructions: "" });
    if (this.addInstructionsButtonRef.current)
      setTimeout(() => this.addInstructionsButtonRef.current.focus(), 1);
  };
}

export default withTriDictionary(CateringListItem);
