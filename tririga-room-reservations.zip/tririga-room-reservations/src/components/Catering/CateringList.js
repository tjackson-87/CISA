/* IBM Confidential· - OCO Source Materials· - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise· divested of its trade secrets, irrespective of what has been· deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import classNames from "classnames";
import PropTypes from "prop-types";
import { Accordion, AccordionItem } from "carbon-components-react";
import CateringListItem from "./CateringListItem";
import isEmpty from "lodash/isEmpty";
import { AppMsg, CateringUtils } from "../../utils";

const cssBase = "cateringList";

class CateringList extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    availableCatering: PropTypes.object.isRequired,
    className: PropTypes.string,
    handleListChange: PropTypes.func,
    addedCatering: PropTypes.array,
    currencies: PropTypes.array,
    currentUserLocale: PropTypes.string,
    onOrderFoodDetail: PropTypes.func,
    setMenuItemRef: PropTypes.func,
  };

  render() {
    const { className, availableCatering } = this.props;
    return (
      <Accordion className={classNames(cssBase, className)} align="end">
        {Object.keys(availableCatering).map(this.renderCategory)}
      </Accordion>
    );
  }

  renderCategory = (key) => {
    const { availableCatering } = this.props;
    return (
      <AccordionItem
        className={`${cssBase}__category`}
        key={key}
        title={`${key} ${this.computeSelectedQty(key)}`}
        data-category-id={key}
      >
        {this.renderMenuItem(availableCatering[key])}
      </AccordionItem>
    );
  };

  renderMenuItem = (menuItems) => {
    const {
      handleListChange,
      currentUserLocale,
      currencies,
      onOrderFoodDetail,
      setMenuItemRef,
    } = this.props;
    return menuItems.map((menu) => (
      <CateringListItem
        key={menu._id}
        menu={menu}
        qty={this.getCateringQty(menu)}
        instructions={this.getCateringInstructions(menu)}
        currency={CateringUtils.getCurrency(currencies, menu)}
        handleListChange={handleListChange}
        currentUserLocale={currentUserLocale}
        onClick={() => onOrderFoodDetail(menu)}
        setMenuItemRef={setMenuItemRef}
      />
    ));
  };

  computeSelectedQty = (key) => {
    const selectedQty = this.getOrderItemsCount(key);
    return selectedQty !== 0
      ? `(${selectedQty} ${this.props.appMessages[AppMsg.SELECTED]})`
      : ``;
  };

  getCateringQty = (menu) => {
    const { addedCatering } = this.props;
    if (isEmpty(addedCatering)) return 0;
    const selectedCatering = addedCatering.find(
      (selected) => selected._id === menu._id
    );
    return !isEmpty(selectedCatering) ? selectedCatering.qty : 0;
  };

  getOrderItemsCount = (category) => {
    const { addedCatering } = this.props;
    return addedCatering
      .filter((it) => it.specClass === category)
      .reduce((count, { qty }) => qty + count, 0);
  };

  getCateringInstructions(menu) {
    const { addedCatering } = this.props;
    if (isEmpty(addedCatering)) return "";
    const selectedCatering = addedCatering.find(
      (selected) => selected._id === menu._id
    );
    return !isEmpty(selectedCatering) ? selectedCatering.instructions : "";
  }
}

export default withTriDictionary(CateringList);
