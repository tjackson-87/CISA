/* IBM Confidential· - OCO Source Materials· - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise· divested of its trade secrets, irrespective of what has been· deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import classNames from "classnames";
import PropTypes from "prop-types";
import { TextArea, Modal } from "carbon-components-react";
import { AppMsg } from "../../utils";

const cssBase = "instructionsModel";

class InstructionsModel extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    className: PropTypes.string,
    openModal: PropTypes.bool,
    localInstructions: PropTypes.string,
    onDoneClick: PropTypes.func,
    onCancelClick: PropTypes.func,
    onInstructionsChanged: PropTypes.func,
    label: PropTypes.string,
  };

  render() {
    const {
      className,
      localInstructions,
      openModal,
      onInstructionsChanged,
      onCancelClick,
      onDoneClick,
      label,
    } = this.props;
    return (
      openModal && (
        <Modal
          className={classNames(cssBase, className)}
          preventCloseOnClickOutside
          aria-label={label}
          modalHeading={label}
          modalAriaLabel={label}
          primaryButtonText={this.props.appMessages[AppMsg.BUTTON.DONE]}
          secondaryButtonText={this.props.appMessages[AppMsg.BUTTON.CANCEL]}
          onRequestSubmit={onDoneClick}
          onSecondarySubmit={onCancelClick}
          onRequestClose={onCancelClick}
          open={openModal}
          size="xs"
          iconDescription={this.props.appMessages[AppMsg.BUTTON.CLOSE]}
          selectorPrimaryFocus=".bx--modal-close"
        >
          <TextArea
            className={`${cssBase}__instructionsText`}
            labelText=""
            hideLabel
            value={localInstructions}
            placeholder={label}
            onChange={onInstructionsChanged}
            maxLength="150"
          />
        </Modal>
      )
    );
  }
}

export default withTriDictionary(InstructionsModel);
