/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import { Select, SelectItem } from "carbon-components-react";
import { RecurOccurencesInput } from "./";
import { AppMsg, RecurrenceConstants } from "../../utils";

const cssBase = "recurrenceMonthly";

class RecurrenceMonthly extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    monthlyProperties: PropTypes.object,
    onMonthlyPropertiesChange: PropTypes.func,
  };

  static defaultProps = {
    type: RecurrenceConstants.RECUR_MONTH_VALUES.DAY_OF_EVERY_MONTH,
    dayOfMonth: RecurrenceConstants.MONTH_DAYS[0],
    dayOfWeek: RecurrenceConstants.RECUR_DAY_OF_WEEK_VALUES.DAY,
    weekOfMonth: RecurrenceConstants.RECUR_WEEK_OF_VALUES.DAY,
    interval: RecurrenceConstants.RECUR_OCCURRENCES_DEFAULT,
  };

  render() {
    const {
      monthlyProperties: { weekOfMonth, dayOfMonth, dayOfWeek, interval },
    } = this.props;

    const daysOfSelect =
      weekOfMonth === RecurrenceConstants.RECUR_WEEK_OF_VALUES.DAY ? (
        <Select
          id="recur-month-day-of-month"
          aria-label={
            this.props.appMessages[AppMsg.RECURRENCE.RECURRENCE_DAY_OF_MONTH]
          }
          light
          className={`${cssBase}__dayOfMonth`}
          value={dayOfMonth}
          onChange={(e) => {
            this.handleValueChange(e.target.value, "dayOfMonth");
          }}
        >
          {RecurrenceConstants.MONTH_DAYS.map((day) => (
            <SelectItem key={day} value={day} text={day} />
          ))}
        </Select>
      ) : (
        <Select
          id="recur-month-day-of-week"
          light
          className={`${cssBase}__dayOfWeek`}
          value={dayOfWeek}
          onChange={(e) => {
            this.handleValueChange(e.target.value, "dayOfWeek");
          }}
        >
          {RecurrenceConstants.DAY_OF_WEEK_OPTIONS.map((option) => (
            <SelectItem
              key={option.value}
              value={option.value}
              text={this.props.appMessages[option.messageKey]}
            />
          ))}
        </Select>
      );

    return (
      <div className={cssBase}>
        <RecurOccurencesInput
          className={`${cssBase}__interval`}
          showHeaderLabel
          label={this.props.appMessages[AppMsg.RECURRENCE.REPEAT_EVERY]}
          value={interval}
          onChange={(value) => this.handleValueChange(value, "interval")}
          unitLabel={
            this.props.appMessages[AppMsg.RECURRENCE.MONTHLY_MONTHS_UNIT]
          }
        />
        <div className={`${cssBase}__label`}>
          <label htmlFor="recur-month-week-of-month">
            {this.props.appMessages[AppMsg.RECURRENCE.ON]}
          </label>
        </div>
        <div className={`${cssBase}__onInputs`}>
          <Select
            id="recur-month-week-of-month"
            aria-label={this.props.appMessages[AppMsg.RECURRENCE.ON]}
            light
            className={`${cssBase}__weekOfMonth`}
            value={weekOfMonth}
            onChange={(e) => {
              this.handleValueChange(e.target.value, "weekOfMonth");
            }}
          >
            {RecurrenceConstants.WEEK_OF_OPTIONS.map((option) => (
              <SelectItem
                key={option.value}
                value={option.value}
                text={this.props.appMessages[option.messageKey]}
              />
            ))}
          </Select>
          {daysOfSelect}
        </div>
      </div>
    );
  }

  handleValueChange = (value, key) => {
    const newValue = { ...this.props.monthlyProperties };
    newValue[key] = value;
    newValue.type =
      newValue.weekOfMonth === RecurrenceConstants.RECUR_WEEK_OF_VALUES.DAY
        ? RecurrenceConstants.RECUR_MONTH_VALUES.DAY_OF_EVERY_MONTH
        : RecurrenceConstants.RECUR_MONTH_VALUES.WEEK_OF_EVERY_MONTH;
    this.props.onMonthlyPropertiesChange(newValue);
  };
}

export default withTriDictionary(RecurrenceMonthly);
