/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import { RadioButtonGroup, RadioButton } from "carbon-components-react";
import { RecurOccurencesInput } from "./";
import { AppMsg, RecurrenceConstants } from "../../utils";

const cssBase = "recurrenceDaily";
const RADIO_BUTTON_GROUP_LEGEND_NAME = "Recurrence Daily Options Group Legend";
const ID_PREFIX = "recurrence-daily-";

const dailyOptions = [
  {
    messageKey: AppMsg.RECURRENCE.DAILY_EVERY,
    value: RecurrenceConstants.RECUR_DAILY_VALUES.DAY,
  },

  {
    messageKey: AppMsg.RECURRENCE.DAILY_WEEKDAY,
    value: RecurrenceConstants.RECUR_DAILY_VALUES.WEEKDAY,
  },

  {
    messageKey: AppMsg.RECURRENCE.DAILY_WEEKEND_DAY,
    value: RecurrenceConstants.RECUR_DAILY_VALUES.WEEKEND_DAY,
  },
];

class RecurrenceDaily extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    dailyProperties: PropTypes.object,
    onDailyPropertiesChange: PropTypes.func,
  };

  static defaultProps = {
    dailyProperties: {
      type: RecurrenceConstants.RECUR_DAILY_VALUES.DAY,
      interval: RecurrenceConstants.RECUR_OCCURRENCES_DEFAULT,
    },
  };

  render() {
    const {
      dailyProperties: { type, interval },
    } = this.props;

    return (
      <div className={cssBase}>
        <div className={`${cssBase}__radioBtnGroup`}>
          <RadioButtonGroup
            orientation="vertical"
            legend={RADIO_BUTTON_GROUP_LEGEND_NAME}
            legendText={this.props.appMessages[AppMsg.RECURRENCE.DAILY_HEADING]}
            name="recurrence-daily-options-group"
            valueSelected={type}
            onChange={(value) => this.handleValueChange(value, "type")}
          >
            {dailyOptions.map((option) => {
              const label =
                option.value === RecurrenceConstants.RECUR_DAILY_VALUES.DAY ? (
                  <div className={`${cssBase}__dayOption`}>
                    <span>{this.props.appMessages[option.messageKey]}</span>
                    <RecurOccurencesInput
                      className={`${cssBase}__interval`}
                      value={interval}
                      onChange={(value) =>
                        this.handleValueChange(value, "interval")
                      }
                      unitLabel={
                        this.props.appMessages[
                          AppMsg.RECURRENCE.DAILY_DAYS_UNIT
                        ]
                      }
                    />
                  </div>
                ) : (
                  AppMsg.getMessage(option.messageKey)
                );
              return (
                <RadioButton
                  id={`${ID_PREFIX}${option.value}`}
                  key={`${ID_PREFIX}${option.value}`}
                  labelText={label}
                  value={option.value}
                />
              );
            })}
          </RadioButtonGroup>
        </div>
      </div>
    );
  }

  handleValueChange = (value, key) => {
    const newValue = { ...this.props.dailyProperties };
    newValue[key] = value;
    this.props.onDailyPropertiesChange(newValue);
  };
}

export default withTriDictionary(RecurrenceDaily);
