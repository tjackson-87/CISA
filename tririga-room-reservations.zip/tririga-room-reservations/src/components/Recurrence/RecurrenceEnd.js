/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import { RadioButtonGroup, RadioButton } from "carbon-components-react";
import { DateInput } from "../";
import { RecurOccurencesInput } from "./";
import { AppMsg, RecurrenceConstants } from "../../utils";

const cssBase = "recurrenceEnd";
const RADIO_BUTTON_GROUP_LEGEND_NAME = "Recurrence End Options Group Legend";
const ID_PREFIX = "recurrence-end-";
const endOptions = [
  {
    messageKey: AppMsg.RECURRENCE.END_AFTER,
    value: RecurrenceConstants.RECUR_END_VALUES.END_AFTER,
  },
  {
    messageKey: AppMsg.RECURRENCE.END_DATE,
    value: RecurrenceConstants.RECUR_END_VALUES.END_DATE,
  },
  {
    messageKey: AppMsg.RECURRENCE.NO_END_DATE,
    value: RecurrenceConstants.RECUR_END_VALUES.NO_END_DATE,
  },
];

class RecurrenceEnd extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    end: PropTypes.object,
    onEndChange: PropTypes.func,
    dateFormats: PropTypes.object,
  };

  static defaultProps = {
    end: {
      type: RecurrenceConstants.RECUR_END_VALUES.END_AFTER,
      numberOfOccurrencesBeforeEnd:
        RecurrenceConstants.RECUR_OCCURRENCES_DEFAULT,
      endDate: null,
    },
  };

  render() {
    const {
      end: { type, numberOfOccurrencesBeforeEnd, endDate },
      dateFormats,
    } = this.props;

    return (
      <div className={cssBase}>
        {" "}
        <div className={`${cssBase}__radioBtnGroup`}>
          <RadioButtonGroup
            orientation="horizontal"
            legend={RADIO_BUTTON_GROUP_LEGEND_NAME}
            legendText={this.props.appMessages[AppMsg.RECURRENCE.END_HEADING]}
            name="recurrence-end-options-group"
            valueSelected={type}
            onChange={(value) => this.handleValueChange(value, "type")}
          >
            {endOptions.map((option) => {
              return (
                <RadioButton
                  id={`${ID_PREFIX}${option.value}`}
                  key={`${ID_PREFIX}${option.value}`}
                  labelText={this.props.appMessages[option.messageKey]}
                  value={option.value}
                  onClick={this.handleClick}
                />
              );
            })}
          </RadioButtonGroup>
        </div>
        {type === RecurrenceConstants.RECUR_END_VALUES.END_AFTER && (
          <RecurOccurencesInput
            ref={(occurencesInput) => {
              this.occurencesInput = occurencesInput;
            }}
            showHeaderLabel
            label={
              this.props.appMessages[AppMsg.RECURRENCE.END_AFTER_OCCURENCES]
            }
            value={numberOfOccurrencesBeforeEnd}
            onChange={(value) =>
              this.handleValueChange(value, "numberOfOccurrencesBeforeEnd")
            }
          />
        )}
        {type === RecurrenceConstants.RECUR_END_VALUES.END_DATE && (
          <DateInput
            id="recurEndDateInput"
            ref={(dateInput) => {
              this.dateInput = dateInput;
            }}
            carbonDateFormat={dateFormats.carbonDateFormat}
            dateFormat={dateFormats.dateFormat}
            carbonLocale={dateFormats.carbonLocale}
            onValueChange={(value) => this.handleValueChange(value, "endDate")}
            value={endDate}
            label={this.props.appMessages[AppMsg.RECURRENCE.END_DATE]}
            light
            defaultBlank
          />
        )}
      </div>
    );
  }

  handleValueChange = (value, key) => {
    const newValue = { ...this.props.end };
    newValue[key] = value;
    this.props.onEndChange(newValue);
  };

  handleClick = (e) => {
    const value = e.target.value;
    switch (value) {
      case RecurrenceConstants.RECUR_END_VALUES.END_AFTER:
        setTimeout(() => {
          this.occurencesInput.select.scrollIntoView(true);
        });
        break;
      case RecurrenceConstants.RECUR_END_VALUES.END_DATE:
        setTimeout(() => {
          this.dateInput.datePicker.inputField.scrollIntoView(true);
        });
        break;
      default:
        break;
    }
  };
}

export default withTriDictionary(RecurrenceEnd);
