/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import { Select, SelectItem } from "carbon-components-react";
import { AppMsg, RecurrenceConstants } from "../../utils";

const cssBase = "recurrenceYearly";

class RecurrenceYearly extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    yearlyProperties: PropTypes.object,
    onYearlyPropertiesChange: PropTypes.func,
  };

  static defaultProps = {
    yearlyProperties: {
      type: RecurrenceConstants.RECUR_YEAR_VALUES.DAY_OF_MONTH,
      dayOfMonth: RecurrenceConstants.MONTH_DAYS[0],
      dayOfWeek: RecurrenceConstants.RECUR_DAY_OF_WEEK_VALUES.DAY,
      weekOfMonth: RecurrenceConstants.RECUR_WEEK_OF_VALUES.DAY,
      month: RecurrenceConstants.MONTHS.JANUARY,
    },
  };

  render() {
    const {
      yearlyProperties: { weekOfMonth, dayOfMonth, dayOfWeek, month },
    } = this.props;

    const daysOfSelect =
      weekOfMonth === RecurrenceConstants.RECUR_WEEK_OF_VALUES.DAY ? (
        <Select
          id="recur-yearly-day-of-month"
          aria-label={
            this.props.appMessages[
              AppMsg.RECURRENCE.RECURRENCE_YEARLY_DAY_MONTH
            ]
          }
          light
          className={`${cssBase}__dayOfMonth`}
          value={dayOfMonth}
          onChange={(e) => {
            this.handleValueChange(e.target.value, "dayOfMonth");
          }}
        >
          {RecurrenceConstants.MONTH_DAYS.map((day) => (
            <SelectItem key={day} value={day} text={day} />
          ))}
        </Select>
      ) : (
        <Select
          id="recur-yearly-day-of-week"
          light
          className={`${cssBase}__dayOfWeek`}
          value={dayOfWeek}
          onChange={(e) => {
            this.handleValueChange(e.target.value, "dayOfWeek");
          }}
        >
          {RecurrenceConstants.DAY_OF_WEEK_OPTIONS.map((option) => (
            <SelectItem
              key={option.value}
              value={option.value}
              text={this.props.appMessages[option.messageKey]}
            />
          ))}
        </Select>
      );

    return (
      <div className={cssBase}>
        <div className={`${cssBase}__month`}>
          <Select
            id="recur-yearly-month"
            light
            className={`${cssBase}__monthSelect`}
            labelText={this.props.appMessages[AppMsg.RECURRENCE.REPEAT_EVERY]}
            value={month}
            onChange={(e) => {
              this.handleValueChange(e.target.value, "month");
            }}
          >
            {RecurrenceConstants.MONTH_OPTIONS.map((option) => (
              <SelectItem
                key={option.value}
                value={option.value}
                text={this.props.appMessages[option.messageKey]}
              />
            ))}
          </Select>
        </div>
        <div className={`${cssBase}__label`}>
          <label htmlFor="recur-yearly-week-of-month">
            {this.props.appMessages[AppMsg.RECURRENCE.ON]}
          </label>
        </div>
        <div className={`${cssBase}__onInputs`}>
          <Select
            id="recur-yearly-week-of-month"
            aria-label={this.props.appMessages[AppMsg.RECURRENCE.ON]}
            light
            className={`${cssBase}__weekOfMonth`}
            value={weekOfMonth}
            onChange={(e) => {
              this.handleValueChange(e.target.value, "weekOfMonth");
            }}
          >
            {RecurrenceConstants.WEEK_OF_OPTIONS.map((option) => (
              <SelectItem
                key={option.value}
                value={option.value}
                text={this.props.appMessages[option.messageKey]}
              />
            ))}
          </Select>
          {daysOfSelect}
        </div>
      </div>
    );
  }

  handleValueChange = (value, key) => {
    const newValue = { ...this.props.yearlyProperties };
    newValue[key] = value;
    newValue.type =
      newValue.weekOfMonth === RecurrenceConstants.RECUR_WEEK_OF_VALUES.DAY
        ? RecurrenceConstants.RECUR_YEAR_VALUES.DAY_OF_MONTH
        : RecurrenceConstants.RECUR_YEAR_VALUES.WEEK_OF_MONTH;
    this.props.onYearlyPropertiesChange(newValue);
  };
}

export default withTriDictionary(RecurrenceYearly);
