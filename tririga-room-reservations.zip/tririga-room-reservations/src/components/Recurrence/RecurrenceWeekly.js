/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import { Checkbox } from "carbon-components-react";
import { RecurOccurencesInput } from "./";
import { AppMsg, RecurrenceConstants } from "../../utils";

const cssBase = "recurrenceWeekly";
const ID_PREFIX = "recurrence-weekly-";
const weekdayMessageKeys = [
  AppMsg.RECURRENCE.SUNDAY,
  AppMsg.RECURRENCE.MONDAY,
  AppMsg.RECURRENCE.TUESDAY,
  AppMsg.RECURRENCE.WEDNESDAY,
  AppMsg.RECURRENCE.THURSDAY,
  AppMsg.RECURRENCE.FRIDAY,
  AppMsg.RECURRENCE.SATURDAY,
];

class RecurrenceWeekly extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    weeklyProperties: PropTypes.object,
    onWeeklyPropertiesChange: PropTypes.func,
  };

  static defaultProps = {
    weeklyProperties: {
      weeklyDays: new Array(7).fill(false),
      interval: RecurrenceConstants.RECUR_OCCURRENCES_DEFAULT,
    },
  };

  render() {
    const {
      weeklyProperties: { weeklyDays, interval },
    } = this.props;

    return (
      <div className={cssBase}>
        <div className={`${cssBase}__label`}>
          {this.props.appMessages[AppMsg.RECURRENCE.WEEKLY_HEADING]}
        </div>
        <div className={`${cssBase}__weekdays`}>
          {weekdayMessageKeys.map((messageKey, idx) => (
            <Checkbox
              id={`${ID_PREFIX}${messageKey}`}
              key={`${ID_PREFIX}${messageKey}`}
              labelText={this.props.appMessages[messageKey]}
              checked={weeklyDays[idx]}
              onChange={(checked) => this.handleWeeklydaysChange(idx, checked)}
            />
          ))}
        </div>
        <RecurOccurencesInput
          showHeaderLabel
          label={this.props.appMessages[AppMsg.RECURRENCE.REPEAT_EVERY]}
          value={interval}
          onChange={(value) => this.handleValueChange(value, "interval")}
          unitLabel={
            this.props.appMessages[AppMsg.RECURRENCE.WEEKLY_WEEKS_UNIT]
          }
        />
      </div>
    );
  }

  handleWeeklydaysChange = (idx, checked) => {
    const newWeekdays = this.props.weeklyProperties.weeklyDays.slice();
    newWeekdays[idx] = checked;
    this.handleValueChange(newWeekdays, "weeklyDays");
  };

  handleValueChange = (value, key) => {
    const newValue = { ...this.props.weeklyProperties };
    newValue[key] = value;
    this.props.onWeeklyPropertiesChange(newValue);
  };
}

export default withTriDictionary(RecurrenceWeekly);
