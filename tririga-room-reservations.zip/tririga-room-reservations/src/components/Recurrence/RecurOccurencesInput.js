/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import PropTypes from "prop-types";
import { Select, SelectItem } from "carbon-components-react";
import { RecurrenceConstants } from "../../utils";
import classnames from "classnames";

const cssBase = "recurOccurencesInput";

export default class RecurOccurencesInput extends React.PureComponent {
  static propTypes = {
    className: PropTypes.string,
    showHeaderLabel: PropTypes.bool,
    label: PropTypes.string,
    value: PropTypes.string,
    onChange: PropTypes.func.isRequired,
    unitLabel: PropTypes.string,
  };

  static defaultProps = {
    value: RecurrenceConstants.RECUR_OCCURRENCES_DEFAULT,
  };

  render() {
    const { className, showHeaderLabel, label, value, unitLabel } = this.props;

    return (
      <div className={classnames(cssBase, className)}>
        {showHeaderLabel ? (
          <div className={`${cssBase}__label`}>
            <label htmlFor={`${label}__recur-every-input`}>{label}</label>
          </div>
        ) : null}
        <div className={`${cssBase}__input`}>
          <Select
            id={`${label}__recur-every-input`}
            aria-label={label}
            ref={(select) => {
              this.select = select;
            }}
            light
            className={`${cssBase}__intervalPicker`}
            value={value}
            onChange={this.handleChange}
          >
            {RecurrenceConstants.RECUR_OCCURENCES_LIST.map((item) => (
              <SelectItem key={item} value={item} text={item} />
            ))}
          </Select>
          <span>{unitLabel}</span>
        </div>
      </div>
    );
  }

  handleChange = (e) => {
    this.props.onChange(e.target.value);
  };
}
