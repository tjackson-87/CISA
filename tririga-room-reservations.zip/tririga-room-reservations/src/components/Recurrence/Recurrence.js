/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import PropTypes from "prop-types";
import {
  RecurrenceType,
  RecurrenceDaily,
  RecurrenceWeekly,
  RecurrenceMonthly,
  RecurrenceYearly,
  RecurrenceEnd,
} from "./";
import { RecurrenceConstants } from "../../utils";

const cssBase = "recurrence";

export default class Recurrence extends React.PureComponent {
  static propTypes = {
    recurrence: PropTypes.object,
    onRecurrenceChange: PropTypes.func,
    dateFormats: PropTypes.object,
  };

  render() {
    const {
      recurrence: {
        type,
        dailyProperties,
        weeklyProperties,
        monthlyProperties,
        yearlyProperties,
        end,
      },
      dateFormats,
      onRecurrenceChange,
    } = this.props;

    let recurrenceTypeDetails;

    switch (type) {
      case RecurrenceConstants.RECUR_TYPE_VALUES.DAILY:
        recurrenceTypeDetails = (
          <RecurrenceDaily
            dailyProperties={dailyProperties}
            onDailyPropertiesChange={(value) =>
              onRecurrenceChange(value, "dailyProperties")
            }
          />
        );
        break;
      case RecurrenceConstants.RECUR_TYPE_VALUES.WEEKLY:
        recurrenceTypeDetails = (
          <RecurrenceWeekly
            weeklyProperties={weeklyProperties}
            onWeeklyPropertiesChange={(value) =>
              onRecurrenceChange(value, "weeklyProperties")
            }
          />
        );
        break;
      case RecurrenceConstants.RECUR_TYPE_VALUES.MONTHLY:
        recurrenceTypeDetails = (
          <RecurrenceMonthly
            monthlyProperties={monthlyProperties}
            onMonthlyPropertiesChange={(value) =>
              onRecurrenceChange(value, "monthlyProperties")
            }
          />
        );
        break;
      case RecurrenceConstants.RECUR_TYPE_VALUES.YEARLY:
        recurrenceTypeDetails = (
          <RecurrenceYearly
            yearlyProperties={yearlyProperties}
            onYearlyPropertiesChange={(value) =>
              onRecurrenceChange(value, "yearlyProperties")
            }
          />
        );
        break;
      default:
        break;
    }

    return (
      <div className={cssBase}>
        <RecurrenceType
          type={type}
          onChange={(value) => onRecurrenceChange(value, "type")}
        />
        {type !== RecurrenceConstants.RECUR_TYPE_VALUES.NONE && (
          <>
            {recurrenceTypeDetails}
            <RecurrenceEnd
              dateFormats={dateFormats}
              end={end}
              onEndChange={(value) => onRecurrenceChange(value, "end")}
            />
          </>
        )}
      </div>
    );
  }
}
