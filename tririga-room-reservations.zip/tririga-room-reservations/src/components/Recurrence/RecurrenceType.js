/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import { RadioButtonGroup, RadioButton } from "carbon-components-react";
import { AppMsg, RecurrenceConstants } from "../../utils";

const cssBase = "recurrenceType";
const ID_PREFIX = "recurrence-type-";
const RADIO_BUTTON_GROUP_LEGEND_NAME = "Recurrence Type Group Legend";

const recurrenceTypeOptions = Object.keys(
  RecurrenceConstants.RECUR_TYPE_VALUES
).map((key) => {
  return {
    messageKey: AppMsg.RECURRENCE[key],
    value: RecurrenceConstants.RECUR_TYPE_VALUES[key],
  };
});

class RecurrenceType extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    onChange: PropTypes.func,
    type: PropTypes.string,
  };

  static defaultProps = {
    type: RecurrenceConstants.RECUR_TYPE_VALUES.NONE,
  };

  render() {
    const { onChange, type } = this.props;

    return (
      <div className={cssBase}>
        <div className={`${cssBase}__radioBtnGroup`}>
          <RadioButtonGroup
            orientation="vertical"
            legend={RADIO_BUTTON_GROUP_LEGEND_NAME}
            legendText={this.props.appMessages[AppMsg.RECURRENCE.TYPE_HEADING]}
            name="recurrence-type-group"
            valueSelected={type}
            onChange={onChange}
          >
            {recurrenceTypeOptions.map((option) => (
              <RadioButton
                id={`${ID_PREFIX}${option.value}`}
                key={`${ID_PREFIX}${option.value}`}
                labelText={this.props.appMessages[option.messageKey]}
                value={option.value}
              />
            ))}
          </RadioButtonGroup>
        </div>
      </div>
    );
  }
}

export default withTriDictionary(RecurrenceType);
