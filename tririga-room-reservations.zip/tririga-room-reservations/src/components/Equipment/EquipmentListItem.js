/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import isEmpty from "lodash/isEmpty";
import { TriImage, withTriDictionary } from "@tririga/tririga-react-components";
import { Add16, Edit16 } from "@carbon/icons-react";
import {
  TextArea,
  Modal,
  Button,
  FormLabel,
  TextInput,
} from "carbon-components-react";
import { AppMsg } from "../../utils";

const cssBase = "equipmentListItem";

class EquipmentListItem extends React.PureComponent {
  constructor(props) {
    super(props);
    this.equipNameRef = React.createRef();
    this.instructionsRef = React.createRef();
    this.instructionDom = null;
  }

  static propTypes = {
    appMessages: PropTypes.object,
    className: PropTypes.string,
    item: PropTypes.object,
    quantity: PropTypes.number,
    instructions: PropTypes.string,
    onClick: PropTypes.func,
    onChange: PropTypes.func,
    isReadOnly: PropTypes.bool,
    equipImageModalDomRef: PropTypes.func,
  };

  state = {
    openModal: false,
    localInstructions: this.props.instructions || "",
  };

  render() {
    const { className, item, quantity, instructions, isReadOnly } = this.props;
    const { openModal, localInstructions } = this.state;

    return (
      <div className={classNames(cssBase, className)}>
        <div className={`${cssBase}__content`}>
          <div
            className={`${cssBase}__header`}
            onClick={this.handleEquipNameClick}
            onKeyDown={(e) =>
              e.key === "Enter" ? this.handleEquipNameClick() : null
            }
          >
            <TriImage value={item.image} className={`${cssBase}__image`} />
            <div className={`${cssBase}__equipmentDetails`}>
              <div
                data-testid="name"
                tabIndex={0}
                role="link"
                ref={this.equipNameRef}
              >
                {item.name}
              </div>
              <div className={`${cssBase}__description`}>
                {item.description}
              </div>
            </div>
          </div>
          {isReadOnly && (
            <span>
              <FormLabel className={`${cssBase}__quantityAndInstuctionsLabel`}>
                {`${
                  this.props.appMessages[AppMsg.RESERVATION_MESSAGE.QUANTITY]
                }:`}
                &nbsp;
              </FormLabel>
              {quantity}
            </span>
          )}
          {!isReadOnly && (
            <div className={`${cssBase}__quantityInstructions`}>
              {this.renderQuantity(quantity, item)}
              <Button
                className={`${cssBase}__instructions`}
                kind="ghost"
                size="small"
                tabIndex={0}
                ref={this.instructionsRef}
                aria-label={
                  isEmpty(instructions) || quantity === 0
                    ? AppMsg.getMessage(
                        AppMsg.RESERVATION_MESSAGE.STEP_ROOMS_ADD_INSTRUCTIONS
                      )
                    : AppMsg.getMessage(
                        AppMsg.RESERVATION_MESSAGE.STEP_ROOMS_EDIT_INSTRUCTIONS
                      )
                }
                renderIcon={isEmpty(instructions) ? Add16 : Edit16}
                onClick={() => {
                  this.instructionDom = this.instructionsRef;
                  this.setState({ openModal: !openModal });
                }}
                disabled={quantity === 0}
              >
                {isEmpty(instructions) || quantity === 0
                  ? AppMsg.getMessage(
                      AppMsg.RESERVATION_MESSAGE.STEP_ROOMS_ADD_INSTRUCTIONS
                    )
                  : AppMsg.getMessage(
                      AppMsg.RESERVATION_MESSAGE.STEP_ROOMS_EDIT_INSTRUCTIONS
                    )}
              </Button>
            </div>
          )}
          {this.renderInstructionsModal(localInstructions, openModal)}
          {this.renderAddedInstructions(instructions, quantity)}
        </div>
      </div>
    );
  }

  handleEquipNameClick = () => {
    this.props.equipImageModalDomRef(this.equipNameRef);
    this.props.onClick();
  };

  renderQuantity = (quantity, item) => {
    return (
      <TextInput
        size="lg"
        id={`qty-${item._id}`}
        labelText={this.props.appMessages[AppMsg.RESERVATION_MESSAGE.QUANTITY]}
        className={`${cssBase}__quantityInput`}
        onChange={this.handleQuantityChanged}
        value={quantity}
        maxLength="150"
      />
    );
  };

  renderInstructionsModal = (localInstructions, openModal) => {
    const label = AppMsg.getMessage(
      AppMsg.RESERVATION_MESSAGE.STEP_ROOMS_INSTRUCTIONS
    );
    return (
      openModal && (
        <Modal
          className={`${cssBase}__modalInstructions`}
          preventCloseOnClickOutside
          modalHeading={label}
          modalAriaLabel={label}
          primaryButtonText={this.props.appMessages[AppMsg.BUTTON.DONE]}
          secondaryButtonText={this.props.appMessages[AppMsg.BUTTON.CANCEL]}
          onRequestSubmit={this.handleDoneClick}
          onSecondarySubmit={this.handleCancelClick}
          onRequestClose={this.handleCancelClick}
          open={openModal}
          size="xs"
          iconDescription={this.props.appMessages[AppMsg.BUTTON.CLOSE]}
        >
          <TextArea
            className={`${cssBase}__instructionsText`}
            labelText=""
            value={localInstructions}
            placeholder={label}
            onChange={this.handleInstructionsChanged}
            maxLength="150"
          />
        </Modal>
      )
    );
  };

  renderAddedInstructions = (instructions, quantity) => {
    const { isReadOnly } = this.props;
    if (!isEmpty(instructions) && quantity > 0)
      return (
        <>
          {isReadOnly && (
            <FormLabel className={`${cssBase}__instuctionsLabel`}>
              {`${
                this.props.appMessages[
                  AppMsg.RESERVATION_MESSAGE.STEP_ROOMS_INSTRUCTIONS
                ]
              }:`}
              &nbsp;
            </FormLabel>
          )}
          <div
            className={classNames(`${cssBase}__readOnlyInstructions`, {
              [`${cssBase}__readOnlyPageInstructions`]: isReadOnly,
            })}
          >
            {instructions}
          </div>
        </>
      );
    return null;
  };

  handleQuantityChanged = (e) => {
    const { onChange, item } = this.props;
    const quantity = !isEmpty(e.target.value) ? parseInt(e.target.value) : 0;
    if (quantity === 0) {
      this.setState({ localInstructions: "" });
    }
    const { localInstructions } = this.state;
    onChange(
      { ...item, quantity, instructions: localInstructions },
      quantity > 0
    );
  };

  handleInstructionsChanged = (e) => {
    this.setState({ localInstructions: e.target.value });
  };

  handleDoneClick = () => {
    const { localInstructions } = this.state;
    const { quantity, onChange } = this.props;
    onChange(
      { ...this.props.item, instructions: localInstructions, quantity },
      quantity > 0
    );
    this.setState({ openModal: false });
    setTimeout(() => {
      if (this.instructionDom && this.instructionDom.current) {
        this.instructionDom.current.focus();
      }
    }, 1);
  };

  handleCancelClick = () => {
    const { instructions } = this.props;
    this.setState({ openModal: false, localInstructions: instructions });

    setTimeout(() => {
      if (this.instructionDom && this.instructionDom.current) {
        this.instructionDom.current.focus();
      }
    }, 1);
  };
}

export default withTriDictionary(EquipmentListItem);
