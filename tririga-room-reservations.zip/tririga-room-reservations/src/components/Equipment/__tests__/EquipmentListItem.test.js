/* IBM Confidential· - OCO Source Materials· - (C) COPYRIGHT IBM CORP. 2023 - The source code for this program is not published or otherwise· divested of its trade secrets, irrespective of what has been· deposited with the U.S. Copyright Office. */

import React from "react";
import { screen, fireEvent } from "@testing-library/react";
import { AppMsg } from "../../../utils";
import { renderWithTriDictionaryProvider } from "../../../testUtils";
import EquipmentListItem from "../EquipmentListItem";
import * as tririga from "@tririga/tririga-react-components";

afterEach(() => jest.clearAllMocks());

const triImageSpy = jest.spyOn(tririga, "TriImage");
triImageSpy.mockImplementation(() => <img data-testid="equipmentImage" />);

describe("EquipmentListItem", () => {
  let appMessages,
    props,
    className,
    item,
    quantity,
    instructions,
    onClick,
    onChange,
    isReadOnly,
    equipImageModalDomRef;

  describe("Readonly EquipmentListItem", () => {
    beforeEach(() => {
      item = {
        _id: 1,
        name: "1",
        description: "one",
        image: "/image",
      };
      className = "equipmentStyle";
      instructions = "Deliver at end";
      isReadOnly = true;
      quantity = 2;
      equipImageModalDomRef = jest.fn();
      onClick = jest.fn();
      onChange = jest.fn();
      appMessages = AppMsg.getAppMessages();
      props = {
        item,
        className,
        instructions,
        quantity,
        equipImageModalDomRef,
        onClick,
        onChange,
        isReadOnly,
      };
    });

    it("Equipment renders correctly", () => {
      renderWithTriDictionaryProvider(<EquipmentListItem {...props} />, {
        appMessages,
      });
      const itemName = screen.getByTestId("name");
      const imageName = screen.getByTestId("equipmentImage");
      expect(triImageSpy).toHaveBeenCalledTimes(1);
      expect(itemName).toBeInTheDocument();
      expect(imageName).toBeInTheDocument();
    });
  });
  describe("Non Readonly EquipmentListItem", () => {
    beforeEach(() => {
      item = {
        _id: 1,
        name: "1",
        description: "one",
        image: "/image",
      };
      className = "equipmentStyle";
      instructions = "Deliver at end";
      isReadOnly = false;
      quantity = 2;
      equipImageModalDomRef = jest.fn();
      onClick = jest.fn();
      onChange = jest.fn();
      appMessages = AppMsg.getAppMessages();
      props = {
        item,
        className,
        instructions,
        quantity,
        equipImageModalDomRef,
        onClick,
        onChange,
        isReadOnly,
      };
    });

    it("Equipment renders correctly", () => {
      renderWithTriDictionaryProvider(<EquipmentListItem {...props} />, {
        appMessages,
      });
      const itemName = screen.getByTestId("name");
      const imageName = screen.getByTestId("equipmentImage");
      expect(triImageSpy).toHaveBeenCalledTimes(1);
      expect(itemName).toBeInTheDocument();
      expect(imageName).toBeInTheDocument();
    });

    it("Should render Add Instruction button when quantity is 0", () => {
      const args = { ...props, quantity: 0, instructions: "" };
      renderWithTriDictionaryProvider(<EquipmentListItem {...args} />, {
        appMessages,
      });
      const button = screen.getByRole("button", {
        name: appMessages.STEP_ROOMS_ADD_INSTRUCTIONS,
      });
      expect(button).toBeInTheDocument();
      expect(button.textContent).toEqual(
        appMessages[AppMsg.RESERVATION_MESSAGE.STEP_ROOMS_ADD_INSTRUCTIONS]
      );
    });

    it("Add Instruction button should open modal on click", () => {
      const args = { ...props, quantity: 1, instructions: "" };
      renderWithTriDictionaryProvider(<EquipmentListItem {...args} />, {
        appMessages,
      });
      const button = screen.getByRole("button", {
        name: appMessages.STEP_ROOMS_ADD_INSTRUCTIONS,
      });
      fireEvent.click(button);
      const instructionText = screen.getByPlaceholderText(
        appMessages[AppMsg.RESERVATION_MESSAGE.STEP_ROOMS_INSTRUCTIONS]
      );
      expect(instructionText).toBeInTheDocument();
    });

    it("Should close modal when Done button is clicked", () => {
      const args = { ...props, quantity: 1, instructions: "" };
      renderWithTriDictionaryProvider(<EquipmentListItem {...args} />, {
        appMessages,
      });
      const button = screen.getByRole("button", {
        name: appMessages.STEP_ROOMS_ADD_INSTRUCTIONS,
      });
      fireEvent.click(button);
      const doneButton = screen.getByText("Done");
      fireEvent.click(doneButton);
      const instructionText = screen.queryByPlaceholderText(
        appMessages[AppMsg.RESERVATION_MESSAGE.STEP_ROOMS_INSTRUCTIONS]
      );
      expect(instructionText).not.toBeInTheDocument();
    });

    it("Should close modal when cancel button is clicked", () => {
      const args = { ...props, quantity: 1, instructions: "" };
      renderWithTriDictionaryProvider(<EquipmentListItem {...args} />, {
        appMessages,
      });
      const button = screen.getByRole("button", {
        name: appMessages.STEP_ROOMS_ADD_INSTRUCTIONS,
      });
      fireEvent.click(button);
      const cancelButton = screen.getByText("Cancel");
      fireEvent.click(cancelButton);
      const instructionText = screen.queryByPlaceholderText(
        appMessages[AppMsg.RESERVATION_MESSAGE.STEP_ROOMS_INSTRUCTIONS]
      );
      expect(instructionText).not.toBeInTheDocument();
    });

    it("Should call onChange function with correct instructions details when quantity is changed", () => {
      const args = { ...props, quantity: 1, instructions: "" };
      renderWithTriDictionaryProvider(<EquipmentListItem {...args} />, {
        appMessages,
      });
      const button = screen.getByRole("button", {
        name: appMessages.STEP_ROOMS_ADD_INSTRUCTIONS,
      });
      fireEvent.click(button);
      const instruction = screen.queryByPlaceholderText(
        appMessages[AppMsg.RESERVATION_MESSAGE.STEP_ROOMS_INSTRUCTIONS]
      );
      fireEvent.change(instruction, { target: { value: "Hello" } });
      const tb = screen.getByLabelText("Quantity");
      fireEvent.change(tb, { target: { value: 2 } });
      const expectedArgs = {
        _id: 1,
        name: "1",
        description: "one",
        image: "/image",
        quantity: 2,
        instructions: "Hello",
      };

      expect(props.onChange).toHaveBeenCalledWith(expectedArgs, true);
    });

    it("Should render instructions details as empty if quantity is empty/0", () => {
      const args = { ...props, quantity: 1, instructions: "" };
      renderWithTriDictionaryProvider(<EquipmentListItem {...args} />, {
        appMessages,
      });
      const button = screen.getByRole("button", {
        name: appMessages.STEP_ROOMS_ADD_INSTRUCTIONS,
      });
      fireEvent.click(button);
      const instruction = screen.queryByPlaceholderText(
        appMessages[AppMsg.RESERVATION_MESSAGE.STEP_ROOMS_INSTRUCTIONS]
      );
      fireEvent.change(instruction, { target: { value: "Hello" } });
      const tb = screen.getByLabelText("Quantity");
      fireEvent.change(tb, { target: { value: "" } });
      const expectedArgs = {
        _id: 1,
        name: "1",
        description: "one",
        image: "/image",
        quantity: 0,
        instructions: "",
      };
      setTimeout(() => {
        expect(props.onChange).toHaveBeenCalledWith(expectedArgs, false);
      }, 1000);
    });

    it("Should call onClick function when eqipment link is clicked", () => {
      const args = { ...props, quantity: 1, instructions: "" };
      renderWithTriDictionaryProvider(<EquipmentListItem {...args} />, {
        appMessages,
      });
      const link = screen.getByRole("link");
      fireEvent.click(link);
      expect(props.onClick).toHaveBeenCalled();
    });

    it("Should call onClick function when eqipment link is accessed using Enter key", () => {
      const args = { ...props, quantity: 1, instructions: "" };
      renderWithTriDictionaryProvider(<EquipmentListItem {...args} />, {
        appMessages,
      });
      const link = screen.getByRole("link");
      fireEvent.keyDown(link, { key: "Enter" });
      expect(props.onClick).toHaveBeenCalled();
    });

    it("Should not call onClick function when eqipment link is accessed using any other key but not Enter key", () => {
      const args = { ...props, quantity: 1, instructions: "" };
      renderWithTriDictionaryProvider(<EquipmentListItem {...args} />, {
        appMessages,
      });
      const link = screen.getByRole("link");
      fireEvent.keyDown(link);
      expect(props.onClick).not.toHaveBeenCalled();
    });

    it("Should render Edit Instruction button when instructions is empty", () => {
      const args = { ...props, quantity: 1, instructions: "Deliver at End" };
      renderWithTriDictionaryProvider(<EquipmentListItem {...args} />, {
        appMessages,
      });
      const button = screen.getByRole("button", {
        name: appMessages.STEP_ROOMS_EDIT_INSTRUCTIONS,
      });
      expect(button).toBeInTheDocument();
    });
  });
});
