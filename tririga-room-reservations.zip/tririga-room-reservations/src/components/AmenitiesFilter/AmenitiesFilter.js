/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2022 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { AppMsg, ReservationTypes } from "../../utils";
import { Checkbox } from "carbon-components-react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import {
  Restaurant16,
  Accessibility16,
  Run16,
  Rss16,
  Phone16,
  Video16,
  Screen16,
  Light16,
  VolumeMute16,
  BatteryCharging16,
} from "@carbon/icons-react";
import { ReactComponent as ipPhone } from "../../utils/icons/ipPhone.svg";
import { ReactComponent as adjustableDesk } from "../../utils/icons/adjustableDesk.svg";

const cssBase = "amenitiesFilter";

const amenititesArray = [
  {
    id: "catering-checkbox",
    label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_CATERING,
    icon: Restaurant16,
    filter: "cateringAvailable",
    workspace: false, // CISA
    meeting: false, // CISA
    header: "", // CISA

  },
  {
    id: "accessible-checkbox",
    label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_ACCESSIBLE,
    icon: Accessibility16,
    filter: "adaAvailable",
    workspace: false, // CISA
    meeting: false, // CISA
    header: "", // CISA

  },
  {
    id: "network-connection-checkbox",
    label:
      AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_NETWORK_CONNECTION,
    icon: Rss16,
    filter: "networkConnection",
    workspace: false, // CISA
    meeting: false, // CISA
    header: "Network", // CISA

  },
  {
    id: "projector-checkbox",
    label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_PROJECTOR,
    icon: Run16,
    filter: "inRoomProjector",
    workspace: false, // CISA
    meeting: false, // CISA
    header: "", // CISA
  },
  {
    id: "telephone-conference-checkbox",
    label:
      AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_TELEPHONE_CONFERENCE,
    icon: Phone16,
    filter: "telephoneConference",
    workspace: false, // CISA
    meeting: false, // CISA
    header: "", // CISA
  },
  {
    id: "video-conference-checkbox",
    label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_VIDEO_CONFERENCE,
    icon: Video16,
    filter: "videoConferenceRoom",
    workspace: false, // CISA
    meeting: false, // CISA
    header: "", // CISA

  },
  {
    id: "whiteboard-checkbox",
    label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_WHITEBOARD,
    icon: Screen16,
    filter: "whiteboard",
    workspace: false,
    meeting: true,
    header: "Equipment", // CISA
  },
  {
    id: "ipPhone-checkbox",
    label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_IP_PHONE,
    icon: ipPhone,
    filter: "ipPhone",
    workspace: false, // CISA
    meeting: false,
    header: "", // CISA
  },
  {
    id: "naturalLight-checkbox",
    label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_NATURAL_LIGHT,
    icon: Light16,
    filter: "naturalLight",
    workspace: false, // CISA
    meeting: false, // CISA
    header: "", // CISA
  },
  {
    id: "adjustableHeightDesk-checkbox",
    label:
      AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_ADJUSTABLE_HEIGHT_DESK,
    icon: adjustableDesk,
    filter: "adjustableHeightDesk",
    workspace: false, // CISA
    meeting: false, // CISA
    header: "", // CISA  },
  },
  {
    id: "noiseBarrier-checkbox",
    label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_NOISE_BARRIER,
    icon: VolumeMute16,
    filter: "noiseBarrier",
    workspace: false,
    meeting: false,
    header: "",
  },
  // CISA Amenities
  {
    id: "vtc-checkbox",
    label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_VTC,
    icon: Video16,
    filter: "vtc",
    workspace: false,
    meeting: true,
    header: "",
  },
  {
    id: "hdmi-checkbox",
    label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_HDMI,
    icon: Rss16,
    filter: "hdmi",
    workspace: false,
    meeting: true,
    header: "",
  },
  {
    id: "pivEnrollmentStation-checkbox",
    label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_PIV_ENROLLMENT,
    icon: ipPhone,
    filter: "pivEnrollmentStation",
    workspace: false,
    meeting: false,
    header: "",
  },
  {
    id: "smartWhiteboard-checkbox",
    label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_SMART_WHITEBOARD,
    icon: Screen16,
    filter: "smartWhiteboard",
    workspace: false,
    meeting: false,
    header: "",
  },
  {
    id: "universalDockingStation-checkbox",
    label:
      AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_UNIVERSAL_DOCKING_STATION,
    icon: BatteryCharging16,
    filter: "universalDockingStation",
    workspace: true,
    meeting: false,
    //header: "Docking Station",
  },
  {
    id: "dellK09A-checkbox",
    label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_DELL_K09A,
    icon: BatteryCharging16,
    filter: "dellK09A",
    workspace: false,
    meeting: false,
    header: "",
  },
  {
    id: "dellOPS395-checkbox",
    label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_DELL_OPW_395,
    icon: BatteryCharging16,
    filter: "dellOPW395",
    workspace: false,
    meeting: false,
    header: "",
  },
  {
    id: "dellWYSE-checkbox",
    label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_DELL_WYSE,
    icon: BatteryCharging16,
    filter: "dellWYSE",
    workspace: false,
    meeting: false,
    header: "",
  },
  {
    id: "dellWYSE3040-checkbox",
    label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_DELL_WYSE_3040,
    icon: BatteryCharging16,
    filter: "dellWYSE3040",
    workspace: false,
    meeting: false,
    header: "",
  },
  {
    id: "dellWYSE5070-checkbox",
    label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_DELL_WYSE_5070,
    icon: BatteryCharging16,
    filter: "dellWYSE5070",
    workspace: false,
    meeting: false,
    header: "",
  },
  {
    id: "dellPro2XDockingStation-checkbox",
    label:
      AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_DELL_PRO_2X_DOCKING_STATION,
    icon: BatteryCharging16,
    filter: "dellPro2X",
    workspace: true,
    meeting: false,
    header: "",
  },
  {
    id: "hpUSBG5-checkbox",
    label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_HP_USB_G5,
    icon: BatteryCharging16,
    filter: "hpUSBG5",
    workspace: false,
    meeting: false,
    header: "",
  },
  {
    id: "hpUltraSlim-checkbox",
    label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_HP_ULTRASLIM,
    icon: BatteryCharging16,
    filter: "hpUltraSlimDockingStation",
    workspace: true,
    meeting: false,
    header: "",
  },
  {
    id: "networkTypeA-checkbox",
    label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_NETWORK_TYPE_A,
    icon: Rss16,
    filter: "networkTypeA",
    workspace: true,
    meeting: false,
    header: "Network",
  },
  {
    id: "networkTypeB-checkbox",
    label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_NETWORK_TYPE_B,
    icon: Rss16,
    filter: "networkTypeB",
    workspace: true,
    meeting: false,
    header: "",
  },
  {
    id: "networkTypeC-checkbox",
    label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_NETWORK_TYPE_C,
    icon: Rss16,
    filter: "networkTypeC",
    workspace: true,
    meeting: false,
    header: "",
  },
  {
    id: "networkTypeCAL-checkbox",
    label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_NETWORK_TYPE_CAL,
    icon: Rss16,
    filter: "networkTypeCAL",
    workspace: true,
    meeting: false,
    header: "",
  },
  {
    id: "networkTypeM-checkbox",
    label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_NETWORK_TYPE_M,
    icon: Rss16,
    filter: "networkTypeM",
    workspace: true,
    meeting: false,
    header: "",
  },
  {
    id: "networkTypeTEN-checkbox",
    label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_NETWORK_TYPE_TEN,
    icon: Rss16,
    filter: "networkTypeTEN",
    workspace: true,
    meeting: false,
    header: "",
  },
  {
    id: "networkTypeTM-checkbox",
    label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_NETWORK_TYPE_TM,
    icon: Rss16,
    filter: "networkTypeTM",
    workspace: true,
    meeting: false,
    header: "",
  },
  {
    id: "networkTypeCOOL-checkbox",
    label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_NETWORK_TYPE_COOL,
    icon: Rss16,
    filter: "networkTypeCOOL",
    workspace: false,
    meeting: false,
    header: "",
  },
  {
    id: "networkTypeF-checkbox",
    label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_NETWORK_TYPE_F,
    icon: Rss16,
    filter: "networkTypeF",
    workspace: true,
    meeting: false,
    header: "",
  },
  {
    id: "networkTypeG-checkbox",
    label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_NETWORK_TYPE_G,
    icon: Rss16,
    filter: "networkTypeG",
    workspace: true,
    meeting: false,
    header: "",
  },
  {
    id: "networkTypeMOE-checkbox",
    label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_NETWORK_TYPE_MOE,
    icon: Rss16,
    filter: "networkTypeMOE",
    workspace: false,
    meeting: false,
    header: "",
  },
  {
    id: "networkTypeN-checkbox",
    label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_NETWORK_TYPE_N,
    icon: Rss16,
    filter: "networkTypeN",
    workspace: true,
    meeting: false,
    header: "",
  },

  {
    id: "msTeams-checkbox",
    label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_MS_TEAMS,
    icon: Screen16,
    filter: "msTeams",
    workspace: false,
    meeting: true,
    header: "",
  },

  {
    id: "surfaceHub-checkbox",
    label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_SURFACE_HUB,
    icon: Screen16,
    filter: "surfaceHub",
    workspace: false,
    meeting: true,
    header: "",
  },
];

class AmenitiesFilter extends React.PureComponent {
  static propTypes = {
    amenities: PropTypes.object,
    onChange: PropTypes.func.isRequired,
    reservationType: PropTypes.string,
    appMessages: PropTypes.object,
  };

  render() {
    const { amenities, reservationType, appMessages } = this.props;
    return (
      <div className={cssBase}>
        <div className={`${cssBase}__amentities__header`}>
          <span>
            {
              appMessages[
                AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_AMENITIES
              ]
            }
          </span>
        </div>
        <Checkbox
          id="all-amenities-checkbox"
          className={`${cssBase}__amentities__selectAll`}
          labelText={this.handleLabelForAllAmenities(amenities)}
          indeterminate={this.computeAllAmenitiesIndeterminate(amenities)}
          onChange={this.handleSelectAllChange}
          checked={this.computeAllAmenitiesChecked(amenities)}
          aria-labelledby="amenitiesNote"
        />
        <span hidden id="amenitiesNote">
          {appMessages[
            AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_AMENITIES
          ] + this.handleLabelForAllAmenities(amenities)}
        </span>
        {amenititesArray &&
          amenititesArray
            .filter((amenity) =>
              reservationType === ReservationTypes.MEETING
                ? amenity.meeting
                : amenity.workspace
            )
            .map((amenity, index) => {
              return (
                <Checkbox
                  key={index}
                  id={amenity.id}
                  className={`${cssBase}__amentities__singleAmenity`}
                  labelText={this.computeAmenityLabel(
                    amenity.icon,
                    amenity.label
                  )}
                  onChange={(checked) =>
                    this.handleCheckboxChange(amenity.filter, checked)
                  }
                  checked={amenities[amenity.filter]}
                />
              );
            })}
      </div>
    );
  }

  handleSelectAllChange = (checked) => {
    const { reservationType } = this.props;
    this.props.onChange(
      amenititesArray
        .filter(
          (amenity) =>
            reservationType === ReservationTypes.MEETING || amenity.workspace
        )
        .reduce((allAmenities, amenity) => {
          allAmenities[amenity.filter] = checked;
          return allAmenities;
        }, {})
    );
  };

  handleCheckboxChange = (amenityFilter, checked) => {
    const { amenities } = this.props;
    this.props.onChange({ ...amenities, [amenityFilter]: checked });
  };

  computeAmenityLabel = (Icon, message) => {
    const { appMessages } = this.props;
    return (
      <>
        <Icon />
        <span className={`${cssBase}__amentities__label`}>
          {appMessages[`${message}`]}
        </span>
      </>
    );
  };

  handleLabelForAllAmenities = (amenities) => {
    const { appMessages } = this.props;
    const { isAllChecked } = this.getAllAmenitiesChecked(amenities);
    return amenities && isAllChecked
      ? appMessages[
          AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_CLEAR_ALL
        ]
      : appMessages[
          AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_SELECT_All
        ];
  };

  computeAllAmenitiesIndeterminate = (amenities) => {
    const { isAllChecked, atleastOneChecked } = this.getAllAmenitiesChecked(
      amenities
    );
    return atleastOneChecked && !isAllChecked;
  };

  computeAllAmenitiesChecked = (amenities) => {
    const { isAllChecked } = this.getAllAmenitiesChecked(amenities);
    return isAllChecked;
  };

  getAllAmenitiesChecked = (amenities) => {
    const { reservationType } = this.props;
    return amenititesArray
      .filter((amenity) =>
        reservationType === ReservationTypes.MEETING
          ? amenity.meeting
          : amenity.workspace
      )
      .reduce(
        (result, amenity) => {
          result.isAllChecked =
            result.isAllChecked && amenities[amenity.filter];
          result.atleastOneChecked =
            result.atleastOneChecked || amenities[amenity.filter];
          return result;
        },
        { isAllChecked: true, atleastOneChecked: false }
      );
  };
}

export default withTriDictionary(AmenitiesFilter);
