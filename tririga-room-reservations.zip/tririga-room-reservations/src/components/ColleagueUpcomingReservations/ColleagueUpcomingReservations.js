/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import { MyCalendarUtils, AppMsg, DefaultValues } from "../../utils";
import memo from "memoize-one";
import moment from "moment-timezone";
import { Loading } from "carbon-components-react";
import debounce from "debounce";
import { groupBy, isEmpty } from "lodash";
import ReservationListGroup from "./ReservationListGroup";
import { EmptyState } from "carbon-addons-iot-react";
import ReservationListSkeleton from "../ReservationList/ReservationListSkeleton";

const cssBase = "colleagueUpcomingReservations";

class ColleagueUpcomingReservations extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    upcomingReservations: PropTypes.array,
    timezone: PropTypes.string,
    loading: PropTypes.bool,
    loadingMoreEventsAfter: PropTypes.bool,
    loadMore: PropTypes.func,
    content: PropTypes.any,
    onKeyDown: PropTypes.func,
    onClick: PropTypes.func,
    shareWorkSpace: PropTypes.bool,
  };

  getGroups = memo((calendarEvents, timezone) =>
    Object.entries(
      groupBy(calendarEvents, (event) => {
        const start = moment
          .tz(event.start, timezone)
          .format(DefaultValues.DATE_OBJECT_FORMAT);
        return start;
      })
    )
  );

  getScrollIds = memo((groups) => {
    if (!groups.length) return [];
    const ids = [];
    groups.map((group) => {
      ids.push(group[0]);
      group[1].map((row, index) => {
        return ids.push(group[0] + "-" + index);
      });
      return true;
    });
    return ids;
  });

  constructor() {
    super();
    this.list = React.createRef();
    this.scrollIds = [];
  }

  state = {
    page: 1,
    eventLoad: 0,
  };

  render() {
    const {
      upcomingReservations,
      timezone,
      loading,
      loadingMoreEventsAfter,
      onKeyDown,
      onClick,
      shareWorkSpace,
    } = this.props;
    if (loading) {
      return <ReservationListSkeleton />;
    } else if (
      (upcomingReservations && !upcomingReservations.length) ||
      !shareWorkSpace
    ) {
      return this.loadNoEvent();
    }

    const groups = this.getGroups(upcomingReservations, timezone);
    this.scrollIds = this.getScrollIds(groups);
    return (
      <div
        className={`${cssBase}`}
        ref={(element) => {
          this.list = element;
        }}
        onScroll={this.handleScroll}
      >
        <div className={`${cssBase}__reservationList`}>
          {!isEmpty(groups) &&
            groups.map(([group, events]) => (
              <ReservationListGroup
                key={group}
                group={group}
                events={events}
                timezone={timezone}
                onKeyDown={onKeyDown}
                onClick={onClick}
              />
            ))}
        </div>
        {loadingMoreEventsAfter && (
          <Loading
            small
            className={`${cssBase}__loadingMore`}
            withOverlay={false}
          />
        )}
      </div>
    );
  }

  loadLsData = () => {
    const { loadMore } = this.props;
    loadMore(
      DefaultValues.UPCOMING_RESERVATION_COUNT,
      DefaultValues.UPCOMING_RESERVATION_COUNT_LS - 1
    );
  };

  handleScroll = debounce(() => {
    const { page } = this.state;
    const { loadMore, content } = this.props;
    const scrollTop = this.list.scrollTop;
    const scrollBottom = scrollTop + this.list.offsetHeight;
    const totalHeight = this.list.scrollHeight;
    if (
      totalHeight - scrollBottom <
      MyCalendarUtils.RESERVATION_LIST_PAGINATION_THRESHOLD
    ) {
      const newPage = page + 1;
      const count =
        content > 1000
          ? DefaultValues.UPCOMING_RESERVATION_COUNT_LS
          : DefaultValues.UPCOMING_RESERVATION_COUNT;
      const indexFrom = page * count;
      const indexTo = newPage * count - 1;
      loadMore(indexFrom, indexTo);
      this.setState({ page: newPage });
      const scrollIndex = this.state.page * count - 1;
      const scrollId = this.scrollIds[scrollIndex];
      if (scrollId) {
        const focusEle = document.getElementById(scrollId);
        if (focusEle) {
          focusEle.scrollIntoView();
        }
      }
    }
  }, 500);

  loadNoEvent() {
    return (
      <pre tabIndex={0}>
        <EmptyState
          icon="no-result"
          title={
            this.props.appMessages[
              AppMsg.RESERVATION_MESSAGE.NO_COLLEAGUE_RESERVATION_HEADER
            ]
          }
          className={`${cssBase}__noReservation`}
          body={
            this.props.appMessages[
              AppMsg.RESERVATION_MESSAGE.NO_COLLEAGUE_RESERVATION_CONTENT_LINE
            ]
          }
        />
      </pre>
    );
  }
}
export default withTriDictionary(ColleagueUpcomingReservations);
