/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import PropTypes from "prop-types";
import { ColleagueReservationStepLink } from "../../components";
import moment from "moment-timezone";
import { ColleagueReservationUtils } from "../../utils";

const cssBase = "upcomingReservationListGroup";

export default class ReservationListGroup extends React.PureComponent {
  static propTypes = {
    events: PropTypes.array,
    group: PropTypes.string,
    timezone: PropTypes.string,
    onKeyDown: PropTypes.func,
    onClick: PropTypes.func,
  };

  componentDidMount() {
    window.addEventListener("onKeyDown", () => true);
  }

  componentWillUnmount() {
    window.removeEventListener("onKeyDown", () => true);
  }

  render() {
    const { group, events, timezone, onKeyDown } = this.props;
    return (
      <>
        <div
          className={`${cssBase}__groupHeader`}
          data-group={group}
          tabIndex={0}
          aria-label={moment.tz(group, timezone).format("ddd MMM D, YYYY")}
          onKeyDown={onKeyDown}
          id={group}
        >
          {moment.tz(group, timezone).format("ddd MMM D, YYYY")}
        </div>
        {events &&
          events.length &&
          events.map((evt, index) => (
            <ColleagueReservationStepLink
              key={evt.eventId != null ? evt.eventId : `${group}-${index}`}
              onKeyDown={onKeyDown}
              id={group + "-" + index}
              onClick={() => this.handleClick(evt)}
              name={[
                <span className={`${cssBase}__stepName`} key={Math.random()}>
                  <strong key={Math.random()}>{evt.rooms[0].name}, </strong>
                  {ColleagueReservationUtils.getTimeRange(evt, timezone)}
                </span>,
              ]}
              ariaLabel={
                evt.rooms[0]?.name +
                " " +
                ColleagueReservationUtils.getTimeRange(evt, timezone) +
                " " +
                this.computeAddress(evt.rooms[0])
              }
              children={
                <div className={`${cssBase}__dateAndTime`}>
                  <div className={`${cssBase}__date`}>
                    {this.computeAddress(evt.rooms[0])}
                  </div>
                </div>
              }
              className={`${cssBase}__stepLink`}
            />
          ))}
      </>
    );
  }

  handleClick = (evt) => {
    this.props.onClick(evt);
  };

  computeAddress(room) {
    if (!room) return "";
    const { floor, building, city, country } = room;
    const addressArr = [floor, building, city, country];
    return addressArr.filter((e) => e !== null).join(", ");
  }
}
