/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2023 The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import "mutationobserver-shim";
import { fireEvent, screen } from "@testing-library/react";
import { renderWithTriDictionaryProvider } from "../../../testUtils";
import SimpleMenu from "../SimpleMenu";
import {  User16 } from "@carbon/icons-react";
import { AppMsg } from "../../../utils";

afterEach(() => jest.clearAllMocks());

describe("SimpleMenu", () => {
  let props;
  const appMessages = AppMsg.getAppMessages();
  beforeEach(() => {
    props = {
      menuList: ["create","update"],
      onSelect: jest.fn(),
      title: "Simple Menu",
      toggleIcon: User16,
    };
  })

  it("Should render properly", () => {
    renderWithTriDictionaryProvider(<SimpleMenu {...props} />, {
      appMessages,
    });
    const title = screen.getByTestId("colleague-button");
    expect(title).toBeInTheDocument();
  })

  it("Should show menu with options when button is clicked", () => {
    renderWithTriDictionaryProvider(<SimpleMenu {...props} />, {
      appMessages,
    });
    const btn = screen.getByTestId("colleague-button");
    fireEvent.click(btn);
    const menuList = screen.getByTestId("menulist");
    expect(menuList).toBeInTheDocument();
  })

  it("Should call onSelect method when any menu option is clicked", () => {
    renderWithTriDictionaryProvider(<SimpleMenu {...props} />, {
      appMessages,
    });
    const btn = screen.getByTestId("colleague-button");
    fireEvent.click(btn);
    const option =  screen.getByText("create");
    fireEvent.click(option);
    expect(props.onSelect).toHaveBeenCalled();
  })
})