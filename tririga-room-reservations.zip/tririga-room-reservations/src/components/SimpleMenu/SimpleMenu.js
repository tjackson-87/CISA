/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2023 The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import { Button } from "carbon-components-react";
import MenuItem from "@mui/material/MenuItem";
import { CaretDown16 } from "@carbon/icons-react";
import ClickAwayListener from "@mui/material/ClickAwayListener";
import Grow from "@mui/material/Grow";
import Paper from "@mui/material/Paper";
import Popper from "@mui/material/Popper";

import MenuList from "@mui/material/MenuList";

const cssBase = "simpleMenu";

class SimpleMenu extends React.PureComponent {

  constructor(props) {
    super(props);
    this.anchorRef = React.createRef();
    this.state = {
      isOpen: false,
    };
    this.handleMenuKeyDown = this.handleMenuKeyDown.bind(this);
  }

  static propTypes = {
    menuList: PropTypes.array,
    onSelect: PropTypes.func,
    title: PropTypes.string,
    toggleIcon: PropTypes.any,
  };

  handleClick = (event) => {
    this.setState({ isOpen: true });
  };

  handleClose = (event) => {
    this.setState({ isOpen: false });
  };

  handleMenuKeyDown(event) {
    if (event.key === "Tab") {
      event.preventDefault();
      this.setState({ isOpen: false });
      if(this.anchorRef) {
        this.anchorRef.current.focus();
      }
    }
  }
  
  render() {
    const { title, menuList, onSelect, toggleIcon } = this.props;
    const { isOpen } = this.state;

    return (
      <div>
        <Button
          ref={this.anchorRef}
          id="colleague-button"
          kind="ghost"
          size="sm"
          onClick={this.handleClick}
          renderIcon={isOpen ? CaretDown16 : toggleIcon}
          className={isOpen ? `${cssBase}__label` : `${cssBase}__menuButton`}
          iconDescription={title}
          aria-controls={isOpen ? 'colleague-menu' : undefined}
          aria-haspopup="true"
          aria-expanded={isOpen ? 'true' : undefined}
          data-testid="colleague-button"
        >
          {title}
        </Button>
        <Popper
          sx={{
            zIndex: 1,
          }}
          open={isOpen}
          anchorEl={this.anchorRef.current}
          role={undefined}
          transition
          disablePortal
          onKeyDown={this.handleMenuKeyDown}
        >
          {({ TransitionProps, placement }) => (
            <Grow
              {...TransitionProps}
              style={{
                transformOrigin: "bottom",
              }}
            >
              <Paper>
                <ClickAwayListener onClickAway={this.handleClose}>
                  <MenuList
                    id="colleague-menu"
                    data-testid="menulist"
                    autoFocusItem
                  >
                    {menuList.map((list, index) => (
                      <MenuItem
                        key={index}
                        className={`${cssBase}__menuItem`}
                        divider={index !== menuList.length - 1}
                        onClick={() =>
                          onSelect(list)
                        }
                      >
                        {list}
                      </MenuItem>
                    ))}
                  </MenuList>
                </ClickAwayListener>
              </Paper>
            </Grow>
          )}
        </Popper>
      </div>
    );
  }
}

export default withTriDictionary(SimpleMenu);
