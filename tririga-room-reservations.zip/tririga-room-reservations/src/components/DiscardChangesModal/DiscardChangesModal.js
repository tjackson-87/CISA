/* IBM Confidential· - OCO Source Materials· - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise· divested of its trade secrets, irrespective of what has been· deposited with the U.S. Copyright Office. */

import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import { PropTypes } from "prop-types";
import {
  Button,
  ComposedModal,
  ModalHeader,
  ModalFooter,
  ModalBody,
} from "carbon-components-react";
import { AppMsg } from "../../utils";

class DiscardChangesModel extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    header: PropTypes.string,
    content: PropTypes.string,
    viewDiscardChangeModal: PropTypes.bool,
    onClose: PropTypes.func,
    handleDiscard: PropTypes.func,
  };

  render() {
    const {
      header,
      content,
      viewDiscardChangeModal,
      onClose,
      handleDiscard,
    } = this.props;
    return (
      viewDiscardChangeModal && (
        <ComposedModal
          aria-label={header}
          preventCloseOnClickOutside
          open={viewDiscardChangeModal}
          onClose={() => onClose()}
          size="xs"
          selectorPrimaryFocus=".bx--modal-close"
        >
          <ModalHeader>
            <h4>{header}</h4>
          </ModalHeader>
          <ModalBody>
            <p className="bx--modal-content__text">{content}</p>
          </ModalBody>
          <ModalFooter>
            <Button
              kind="secondary"
              onClick={() => onClose()}
              aria-label={this.props.appMessages[AppMsg.BUTTON.CANCEL]}
            >
              {this.props.appMessages[AppMsg.BUTTON.CANCEL]}
            </Button>
            <Button
              kind="danger"
              onClick={() => handleDiscard()}
              aria-label={this.props.appMessages[AppMsg.BUTTON.DISCARD]}
            >
              {this.props.appMessages[AppMsg.BUTTON.DISCARD]}
            </Button>
          </ModalFooter>
        </ComposedModal>
      )
    );
  }
}
export default withTriDictionary(DiscardChangesModel);
