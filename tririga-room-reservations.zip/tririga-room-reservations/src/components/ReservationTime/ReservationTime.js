/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import {
  withTriDictionary,
  TriDateTimeUtils,
} from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import { defaultTo, isEmpty } from "lodash";
import classnames from "classnames";
import moment from "moment-timezone";
import { Button, Checkbox, ToastNotification } from "carbon-components-react";
import { DateInput, TimeInput, TimezoneInput } from "..";
import { Warning16 } from "@carbon/icons-react";
import {
  AppMsg,
  computeEndDateFromStartChange,
  computeMomentStartAndEndDates,
  getMomentFrom,
  TimezoneUtils,
  DefaultValues,
  closeAllDatepickerPopups,
} from "../../utils";
import ReserveNotification from "../ReserveNotification/ReserveNotification";

const cssBase = "reservationTime";

class ReservationTime extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    className: PropTypes.string,
    dateAndTime: PropTypes.object,
    timezones: PropTypes.array,
    recurrenceMessage: PropTypes.string,
    meetingTimeStep: PropTypes.bool,
    onChange: PropTypes.func,
    onRecurrenceClick: PropTypes.func,
    hideRecurrence: PropTypes.bool,
    defaultTimezone: PropTypes.string,
    resourcesTimezoneDetails: PropTypes.array,
    focusRecurrence: PropTypes.bool,
  };

  static defaultProps = {
    //hideRecurrence: false, // OOB
    hideRecurrence: true, // CISA
  };

  render() {
    const {
      className,
      dateAndTime,
      recurrenceMessage,
      timezones,
      meetingTimeStep,
      onRecurrenceClick,
      hideRecurrence,
      defaultTimezone,
      resourcesTimezoneDetails,
    } = this.props;

    const {
      carbonDateFormat,
      dateFormat,
      allDayEvent,
      carbonLocale,
      locale,
      startDate,
      startTime,
      startTimePeriod,
      endDate,
      endTime,
      endTimePeriod,
      timezone,
    } = dateAndTime;

    const invalidStartDate = this.isStartDateInvalid(dateAndTime);
    const isSelectedTimezoneDifferent = TimezoneUtils.areTimezonesDifferent(
      timezone,
      defaultTimezone
    );

    return (
      <section className={classnames(cssBase, className)}>
        {meetingTimeStep && (
          <section>
            <Checkbox
              autoFocus={true}
              id="all-day-checkbox"
              role="checkbox"
              labelText={
                this.props.appMessages[
                  AppMsg.RESERVATION_MESSAGE.STEP_TIME_ALL_DAY
                ]
              }
              onChange={(value) => this.handleChange(value, "allDayEvent")}
              checked={defaultTo(allDayEvent, false)}
              onFocus={() => closeAllDatepickerPopups()}
            />
          </section>
        )}
        <div
          className={classnames(`${cssBase}__dateTimeInputs`, {
            [`page__section`]:
              !invalidStartDate && !isSelectedTimezoneDifferent,
          })}
        >
          <DateInput
            id="startDateInput"
            carbonDateFormat={carbonDateFormat}
            dateFormat={dateFormat}
            carbonLocale={carbonLocale}
            onValueChange={(value) => this.handleChange(value, "startDate")}
            value={startDate}
            label={
              <span className={`${cssBase}__labelAlignBottom`}>
                {
                  this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE.STEP_TIME_START_DATE
                  ]
                }
              </span>
            }
          />
          {!allDayEvent && (
            <TimeInput
              id="startTimeInput"
              onTimeChange={(e) =>
                this.handleChange(e.target.value, "startTime")
              }
              onTimePeriodChange={(e) =>
                this.handleChange(e.target.value, "startTimePeriod")
              }
              locale={locale}
              time={startTime}
              timePeriod={startTimePeriod}
              label={
                <span className={`${cssBase}__labelAlignBottom`}>
                  {
                    this.props.appMessages[
                      AppMsg.RESERVATION_MESSAGE.STEP_TIME_START_TIME
                    ]
                  }
                </span>
              }
              labelText={
                <span className={`${cssBase}__labelAlignBottom`}>
                  {this.props.appMessages[AppMsg.SEARCH_LOCATION.SELECT]}
                </span>
              }
            />
          )}
        </div>
        {invalidStartDate && (
          <div className={`${cssBase}__pastDateWarningSection`}>
            <Warning16
              aria-label="Info"
              className={`${cssBase}__pastDateWarningIcon`}
            />
            <span className={`${cssBase}__pastDateWarningMessage`}>
              {
                this.props.appMessages[
                  AppMsg.RESERVATION_MESSAGE
                    .STEP_TIME_MEETING_START_DATE_INVALID
                ]
              }
            </span>
          </div>
        )}
        {isSelectedTimezoneDifferent &&
          !allDayEvent &&
          this.renderDefaultTimezoneTimeStatus(
            startDate,
            startTime,
            startTimePeriod,
            timezone,
            defaultTimezone,
            timezones,
            locale
          )}

        <div
          className={classnames(`${cssBase}__dateTimeInputs`, {
            [`page__section`]:
              !invalidStartDate && !isSelectedTimezoneDifferent,
          })}
        >
          <DateInput
            id="endDateInput"
            carbonDateFormat={carbonDateFormat}
            dateFormat={dateFormat}
            carbonLocale={carbonLocale}
            onValueChange={(value) => this.handleChange(value, "endDate")}
            value={endDate}
            label={
              <span className={`${cssBase}__labelAlignBottom`}>
                {
                  this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE.STEP_TIME_END_DATE
                  ]
                }
              </span>
            }
          />
          {!allDayEvent && (
            <TimeInput
              id="endTimeInput"
              onTimeChange={(e) => this.handleChange(e.target.value, "endTime")}
              onTimePeriodChange={(e) =>
                this.handleChange(e.target.value, "endTimePeriod")
              }
              locale={locale}
              time={endTime}
              timePeriod={endTimePeriod}
              label={
                <span className={`${cssBase}__labelAlignBottom`}>
                  {
                    this.props.appMessages[
                      AppMsg.RESERVATION_MESSAGE.STEP_TIME_END_TIME
                    ]
                  }
                </span>
              }
              labelText={
                <span className={`${cssBase}__labelAlignBottom`}>
                  {this.props.appMessages[AppMsg.SEARCH_LOCATION.SELECT]}
                </span>
              }
            />
          )}
        </div>

        {isSelectedTimezoneDifferent &&
          !allDayEvent &&
          this.renderDefaultTimezoneTimeStatus(
            endDate,
            endTime,
            endTimePeriod,
            timezone,
            defaultTimezone,
            timezones,
            locale
          )}

        {!allDayEvent && (
          <div
            className={classnames(
              "page__section",
              `${cssBase}__defaultTimeStatus`
            )}
          >
            <TimezoneInput
              timezone={timezone}
              timezones={timezones}
              onTimezoneChange={(value) => this.handleChange(value, "timezone")}
            />
          </div>
        )}
        {resourcesTimezoneDetails.length > 0 && (
          <ToastNotification
            className={`${cssBase}__buildingTimezoneNotification`}
            lowContrast
            kind="info"
            title={
              this.props.appMessages[
                AppMsg.RESERVATION_MESSAGE.STEP_TIME_TIMEZONE_STATUS_TITLE
              ]
            }
            subtitle={this.getTextForBuildingTimezoneNotification(
              resourcesTimezoneDetails
            )}
            iconDescription={this.props.appMessages[AppMsg.BUTTON.CLOSE]}
          />
        )}

        {!hideRecurrence && (
          <div className="page__section">
            <Button
              ref={(input) =>
                input && this.props.focusRecurrence && input.focus()
              }
              className={classnames(`${cssBase}__recurrenceButton`)}
              kind="ghost"
              size="small"
              onClick={onRecurrenceClick}
              onFocus={() => closeAllDatepickerPopups()}
            >
              {recurrenceMessage}
            </Button>
          </div>
        )}
      </section>
    );
  }

  isStartDateInvalid = (dateAndTime) => {
    const { startDateTime } = computeMomentStartAndEndDates(dateAndTime);
    if (startDateTime === null || dateAndTime.timezone === null) return false;
    const currentDate = moment.tz(moment(), dateAndTime.timezone);
    const startDate = moment(startDateTime).tz(dateAndTime.timezone);
    return moment(startDate).isBefore(
      currentDate,
      dateAndTime.allDayEvent ? "day" : "minutes"
    );
  };

  renderDefaultTimezoneTimeStatus = (
    date,
    time,
    timePeriod,
    timezone,
    defaultTimezone,
    timezones,
    locale
  ) => {
    const timezoneTimeDate = getMomentFrom(
      date,
      time,
      timePeriod,
      timezone
    ).toISOString(true);
    if (isEmpty(timezoneTimeDate) || isEmpty(timezone)) return null;
    const defaultTime =
      TriDateTimeUtils.formatDate(
        moment.tz(timezoneTimeDate, defaultTimezone).toISOString(true),
        DefaultValues.DATE_TIME_DIFFERENT_TIMEZONE_FORMAT,
        locale
      ) +
      " " +
      TimezoneUtils.getTimezoneAbbr(defaultTimezone, timezones) +
      " " +
      this.props.appMessages[AppMsg.RESERVATION_MESSAGE.LOCAL];
    return (
      <ReserveNotification
        message={defaultTime}
        className={`${cssBase}__defaultTimeStatus`}
      />
    );
  };

  getTextForBuildingTimezoneNotification(resourcesTimezoneDetails) {
    let text = "";
    if (resourcesTimezoneDetails.length === 1) {
      text = this.props.appMessages[
        AppMsg.RESERVATION_MESSAGE.STEP_TIME_TIMEZONE_STATUS_TEXT
      ]
        .replace("{1}", resourcesTimezoneDetails[0].resourceBuildingName)
        .replace("{2}", resourcesTimezoneDetails[0].resourceTimezone);
    } else {
      const anyOneTimezone = resourcesTimezoneDetails[0].resourceTimezone;
      if (
        resourcesTimezoneDetails.every(
          (data) => data.resourceTimezone === anyOneTimezone
        )
      ) {
        text = this.props.appMessages[
          AppMsg.RESERVATION_MESSAGE
            .STEP_TIME_TIMEZONE_STATUS_TEXT_MULTIPLE_LOCATION
        ].replace("{1}", anyOneTimezone);
      } else {
        text = this.props.appMessages[
          AppMsg.RESERVATION_MESSAGE.STEP_TIME_MULTIPLE_TIMEZONE_ROOMS_STATUS
        ];
      }
    }
    return text;
  }

  handleChange = (value, key) => {
    let computedEndDate = {};
    if (["startDate", "startTime", "startTimePeriod"].includes(key)) {
      computedEndDate = computeEndDateFromStartChange(
        this.props.dateAndTime,
        key,
        value
      );
    }
    this.props.onChange(key, value, computedEndDate);
  };
}

export default withTriDictionary(ReservationTime);
