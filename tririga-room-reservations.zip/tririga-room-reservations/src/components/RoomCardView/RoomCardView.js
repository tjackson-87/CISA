/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import isEmpty from "lodash/isEmpty";
import RoomListItem from "../RoomList/RoomListItem";
import { RoomsUtils } from "../../utils";

const cssBase = "roomCardView";

export default class RoomCardView extends React.PureComponent {
  static propTypes = {
    className: PropTypes.string,
    selectedClassName: PropTypes.string,
    selectedRoom: PropTypes.object,
    selectedRooms: PropTypes.array,
    onChange: PropTypes.func,
    onClick: PropTypes.func,
    favorites: PropTypes.array,
    addFavoriteRoom: PropTypes.func.isRequired,
    removeFavoriteRoom: PropTypes.func.isRequired,
    onRecurrenceClick: PropTypes.func,
    isRecurring: PropTypes.bool,
    selectedColleagueRoom: PropTypes.object,
  };

  state = { loading: true, floorPlanId: null };

  render() {
    const {
      className,
      selectedClassName,
      selectedRooms,
      selectedRoom,
      onChange,
      onClick,
      favorites,
      addFavoriteRoom,
      removeFavoriteRoom,
      isRecurring,
      onRecurrenceClick,
      selectedColleagueRoom,
    } = this.props;
    const isSelected = this.isSelected(selectedRoom, selectedRooms);
    const room = this.selectedRoomData(selectedRoom, selectedColleagueRoom);
    return (
      <div className={classNames(`${cssBase}`, className)}>
        {!isEmpty(selectedRoom) && (
          <RoomListItem
            className={classNames({
              [`${cssBase}__roomDetails`]: true,
              [selectedClassName]: isSelected,
            })}
            disableOnTap
            onClick={onClick}
            key={room._id}
            room={room}
            selected={isSelected}
            onChange={onChange}
            maxVisibleAmenities={RoomsUtils.computeMaxVisibleAmenities()}
            addFavoriteRoom={addFavoriteRoom}
            removeFavoriteRoom={removeFavoriteRoom}
            favorites={favorites}
            isRecurring={isRecurring}
            onRecurrenceClick={onRecurrenceClick}
          />
        )}
      </div>
    );
  }

  isSelected = (room, selectedRooms) => {
    if (isEmpty(selectedRooms)) {
      return false;
    }
    return (
      selectedRooms.findIndex(
        (selected) =>
          selected._id === room._id &&
          selected.layoutTypeInternal === room.layoutTypeInternal
      ) >= 0
    );
  };

  selectedRoomData = (selectedRoom, colleagueRoom) => {
    if (colleagueRoom != null && selectedRoom.roomId === colleagueRoom.roomId) {
      const colleagueReservedRoom = { ...selectedRoom, reservedRoom: true };
      return colleagueReservedRoom;
    } else {
      return selectedRoom;
    }
  };
}
