/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import classNames from "classnames";
import isEmpty from "lodash/isEmpty";
import { Tag } from "carbon-components-react";
import { Exchange } from "../../model";
import { AppMsg } from "../../utils";

const cssBase = "attendeeTags";

class AttendeeTags extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    attendees: PropTypes.array,
    className: PropTypes.string,
    onRemove: PropTypes.func,
  };

  render() {
    const { attendees, className, onRemove } = this.props;
    const tags = isEmpty(attendees)
      ? []
      : attendees.map((attendee) => (
          <Tag
            key={attendee.email}
            type={
              attendee.type === Exchange.NON_EXCHANGE_TYPE
                ? "cool-gray"
                : "blue"
            }
            title={
              this.props.appMessages[AppMsg.RESERVATION_MESSAGE.REMOVE_ATTENDEE]
            }
            onClick={() => onRemove(attendee)}
            filter
          >
            {attendee.displayName}
          </Tag>
        ));
    return <div className={classNames(cssBase, className)}>{tags}</div>;
  }
}

export default withTriDictionary(AttendeeTags);
