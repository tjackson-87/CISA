/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2022 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import { TextInput } from "carbon-components-react";
import defaultTo from "lodash/defaultTo";
import isEmpty from "lodash/isEmpty";
import { validate as isValidEmail } from "email-validator";
import { Exchange } from "../../model";
import { AppMsg, DefaultValues } from "../../utils";
import AttendeesSearchDropdown from "./AttendeesSearchDropdown";

const PAGE_SIZE = 10;
const MAX_EMAIL_LENGTH = 320;

const cssBase = "attendeesSearch";

class AttendeesSearch extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    attendees: PropTypes.array,
    searchText: PropTypes.string,
    hasMore: PropTypes.bool,
    loading: PropTypes.bool,
    loadingMore: PropTypes.bool,
    dir: PropTypes.string,
    onSearchTextChange: PropTypes.func,
    onSelect: PropTypes.func,
    onLoadMore: PropTypes.func,
    getPhoto: PropTypes.func,
    disableSearch: PropTypes.bool,
  };

  static defaultProps = {
    loading: false,
    loadingMore: false,
    hasMore: false,
    disableSearch: false,
  };

  state = {
    invalidAttendee: false,
    searchInitialized: false,
    focused: false,
    ignoreFocused: false,
    highlightedIndex: 0,
  };

  render() {
    const { loading, loadingMore, getPhoto, disableSearch } = this.props;
    const attendees = defaultTo(this.props.attendees, []);
    const searchText = defaultTo(this.props.searchText, "");
    const dir = defaultTo(this.props.dir, DefaultValues.USER_DIR);
    const { invalidAttendee, searchInitialized, highlightedIndex } = this.state;
    const open = this.isOpen();
    const inputAria = this.computeInputAria(open, highlightedIndex);
    return (
      <div className={cssBase}>
        <TextInput
          id="attendeesSearch"
          labelText={
            this.props.appMessages[AppMsg.RESERVATION_MESSAGE.OPTIONAL]
          }
          placeholder={
            this.props.appMessages[
              AppMsg.RESERVATION_MESSAGE.ADD_ATTENDEE_PLACEHOLDER
            ]
          }
          type="text"
          invalid={invalidAttendee}
          invalidText={
            this.props.appMessages[
              AppMsg.RESERVATION_MESSAGE.ADD_VALID_ATTENDEE
            ]
          }
          value={searchText}
          onChange={this.handleSearchChanged}
          onFocus={this.handleInputFocus}
          onKeyDown={this.handleKeyDown}
          onClick={this.handleInputClick}
          autoComplete="off"
          ref={(element) => {
            this.searchInput = element;
            this.setState({ searchInitialized: true });
          }}
          {...inputAria}
        />
        {searchInitialized && !disableSearch && (
          <AttendeesSearchDropdown
            id="attendess-dropdown"
            anchorEl={this.searchInput}
            open={open}
            searchText={searchText}
            attendees={attendees}
            dir={dir}
            loading={loading}
            loadingMore={loadingMore}
            getPhoto={getPhoto}
            onLoadMore={this.handleLoadMore}
            onSelect={this.handleMouseSelect}
            highlightedIndex={highlightedIndex}
            onHighlightedIndexChange={this.handleHighlightedIndexChange}
          />
        )}
      </div>
    );
  }

  componentDidMount() {
    window.addEventListener("orientationchange", this.handleOrientationchange);
    this.searchInput.focus();
  }

  componentWillUnmount() {
    window.removeEventListener(
      "orientationchange",
      this.handleOrientationchange
    );
    if (this.inputFocusCallbackTimeout != null) {
      clearTimeout(this.inputFocusCallbackTimeout);
    }
  }

  handleOrientationchange = () => {
    const { focused } = this.state;
    if (focused && this.searchInput != null) {
      this.searchInput.blur();
      setTimeout(() => {
        this.searchInput.focus();
      }, 300);
    }
  };

  isOpen() {
    const { invalidAttendee, ignoreFocused, focused } = this.state;
    const { loading, searchText, attendees } = this.props;
    return (
      !ignoreFocused &&
      focused &&
      !invalidAttendee &&
      (!isEmpty(searchText) || !isEmpty(attendees) || loading)
    );
  }

  handleMouseSelect = (attendee) => {
    this.select([attendee]);
  };

  select(attendees) {
    this.setState({
      ignoreFocused: true,
    });
    this.props.onSelect(attendees);
  }

  handleInputClick = () => {
    const { attendees, loading, searchText } = this.props;
    const { focused, ignoreFocused } = this.state;
    if (focused && ignoreFocused) {
      this.setState({ ignoreFocused: false });
      if (isEmpty(searchText) && isEmpty(attendees) && !loading) {
        this.search(searchText);
      }
    }
  };

  handleInputFocus = () => {
    const { attendees, loading, searchText } = this.props;
    if (isEmpty(searchText) && isEmpty(attendees) && !loading) {
      this.search(searchText);
    }
    this.inputFocusCallbackTimeout = setTimeout(() => {
      this.setState({ focused: true, ignoreFocused: false });
    }, 300);
  };

  handleHighlightedIndexChange = (highlightedIndex) => {
    this.setHighlightedIndex(highlightedIndex);
  };

  setHighlightedIndex(highlightedIndex) {
    const { attendees } = this.props;
    const maxIndex = isEmpty(attendees) ? 0 : attendees.length - 1;
    const newHighlightedIndex =
      highlightedIndex < 0
        ? 0
        : highlightedIndex > maxIndex
        ? maxIndex
        : highlightedIndex;
    if (newHighlightedIndex !== this.state.highlightedIndex) {
      return this.setState({
        highlightedIndex: newHighlightedIndex,
        ignoreFocused: false,
      });
    }
  }

  handleKeyDown = (event) => {
    const isOpen = this.isOpen();
    const { attendees, loading, searchText } = this.props;
    const { highlightedIndex } = this.state;
    const hasAttendees = !isEmpty(attendees);
    switch (event.key) {
      case "Home":
        if (isOpen && !loading && hasAttendees) {
          event.preventDefault();
          this.setHighlightedIndex(0);
        }
        break;
      case "End":
        if (isOpen && !loading && hasAttendees) {
          event.preventDefault();
          this.setHighlightedIndex(attendees.length - 1);
        }
        break;
      case "PageUp":
        if (!loading && hasAttendees) {
          event.preventDefault();
          this.setHighlightedIndex(highlightedIndex - PAGE_SIZE);
        }
        break;
      case "PageDown":
        if (!loading && hasAttendees) {
          event.preventDefault();
          this.setHighlightedIndex(highlightedIndex + PAGE_SIZE);
        }
        break;
      case "ArrowDown":
        if (!loading) {
          event.preventDefault();
          if (hasAttendees) {
            this.setHighlightedIndex(highlightedIndex + 1);
          } else {
            this.search(searchText);
          }
        }
        break;
      case "ArrowUp":
        if (!loading) {
          event.preventDefault();
          if (hasAttendees) {
            this.setHighlightedIndex(highlightedIndex - 1);
          } else {
            this.search(searchText);
          }
        }
        break;
      case "Enter":
        if (event.which === 229) {
          break;
        }
        if (!loading && hasAttendees) {
          this.select([attendees[highlightedIndex]]);
        } else {
          const { validEmails } = this.getAttendeesFromInput();
          if (validEmails && validEmails.length > 0) this.select(validEmails);
        }
        break;
      case "Escape":
        if (isOpen) {
          event.preventDefault();
          event.stopPropagation();
          this.setState({ ignoreFocused: true });
        }
        break;
      default:
    }
  };

  getAttendeesFromInput() {
    const { searchText } = this.props;
    const emails = searchText.split(",");
    const { validEmails, invalidEmails } = this.getValidAndInvalidEmails(
      emails
    );
    if (invalidEmails.length > 0) {
      this.setState({ invalidAttendee: true });
      return { invalidInput: true };
    } else if (validEmails.length > 0) {
      return { invalidInput: false, validEmails };
    }
  }

  getValidAndInvalidEmails = (emails) => {
    const validEmails = [];
    const invalidEmails = [];
    emails.forEach((email) => {
      const emailTrimmed = email.trim();
      if (isValidEmail(emailTrimmed)) {
        validEmails.push({
          email: emailTrimmed,
          displayName: emailTrimmed,
          name: emailTrimmed,
          type: Exchange.NON_EXCHANGE_TYPE,
        });
      } else {
        invalidEmails.push(email);
      }
    });
    return { validEmails, invalidEmails };
  };

  handleLoadMore = async () => {
    const { loadingMore, hasMore, onLoadMore } = this.props;
    if (!loadingMore && hasMore) {
      onLoadMore();
    }
  };

  handleSearchChanged = (event) => {
    const searchText = event.target.value;
    const maxSize = this.computeMaxSize(searchText);
    this.search(searchText.substr(0, maxSize));
  };

  computeMaxSize(searchText) {
    const commaIndex = searchText.indexOf(",");
    return commaIndex < 0 || commaIndex > MAX_EMAIL_LENGTH
      ? MAX_EMAIL_LENGTH
      : commaIndex + 1 + this.computeMaxSize(searchText.slice(commaIndex + 1));
  }

  search(searchText) {
    this.setState({
      invalidAttendee: false,
      ignoreFocused: false,
      highlightedIndex: 0,
    });
    this.props.onSearchTextChange(searchText);
  }

  computeInputAria(open, highlightedIndex) {
    const inputAria = {
      "aria-autocomplete": "list",
    };
    if (open) {
      inputAria["aria-controls"] = "attendess-dropdown";
      inputAria[
        "aria-activedescendant"
      ] = `attendess-dropdown-option-${highlightedIndex}`;
    }
    return inputAria;
  }
}

export default withTriDictionary(AttendeesSearch);
