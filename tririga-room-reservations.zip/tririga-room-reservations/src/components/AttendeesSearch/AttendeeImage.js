/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import classNames from "classnames";
import { Subject, from } from "rxjs";
import { switchMap } from "rxjs/operators";
import { AppMsg } from "../../utils";

const cssBase = "attendeeImage";

class AttendeeImage extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    attendee: PropTypes.object,
    className: PropTypes.string,
    getPhoto: PropTypes.func,
  };

  state = {
    image: null,
  };

  constructor(props) {
    super(props);
    this.attendee$ = new Subject();
    this.photo$ = this.attendee$.pipe(
      switchMap((attendee) => from(this.props.getPhoto(attendee)))
    );
    this.photoSubscription = this.photo$.subscribe((image) => {
      this.setState({ image });
    });
  }

  render() {
    const { attendee, className } = this.props;
    const { image } = this.state;

    return (
      <>
        {image !== null && (
          <img
            className={classNames(`${cssBase}__image`, className)}
            src={image}
            alt={
              this.props.appMessages[
                AppMsg.RESERVATION_MESSAGE.STEP_MEETING_ATTENDEES
              ]
            }
          />
        )}
        {image == null && (
          <div className={classNames(`${cssBase}__nameInitials`, className)}>
            {this.computeInitials(attendee)}
          </div>
        )}
      </>
    );
  }

  componentDidMount() {
    const { attendee } = this.props;
    if (attendee != null) {
      this.attendee$.next(attendee);
    }
  }

  componentDidUpdate(prevProps) {
    const { attendee } = this.props;
    if (attendee !== prevProps.attendee) {
      this.attendee$.next(attendee);
    }
  }

  componentWillUnmount() {
    this.photoSubscription.unsubscribe();
    this.attendee$ = null;
    this.photo$ = null;
    this.photoSubscription = null;
  }

  computeInitials({ firstName, lastName, displayName }) {
    if (firstName != null && lastName != null) {
      return `${firstName
        .toUpperCase()
        .charAt(0)}${lastName.toUpperCase().charAt(0)}`;
    } else {
      return displayName.toUpperCase().charAt(0);
    }
  }
}

export default withTriDictionary(AttendeeImage);
