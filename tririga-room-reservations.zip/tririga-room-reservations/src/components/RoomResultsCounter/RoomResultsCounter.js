/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import classNames from "classnames";
import { TooltipIcon, Button, InlineLoading } from "carbon-components-react";
import { Repeat16, Information16 } from "@carbon/icons-react";
import { AppMsg, ReservationTypes } from "../../utils";

const cssBase = "roomResultsCounter";

class RoomResultsCounter extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    checkedCount: PropTypes.number,
    availableCount: PropTypes.number,
    totalSize: PropTypes.number,
    formattedDate: PropTypes.string,
    className: PropTypes.string,
    dir: PropTypes.string,
    recurrence: PropTypes.object,
    isRecurring: PropTypes.bool,
    showCheckMore: PropTypes.bool,
    reservationType: PropTypes.string,
    onCheckMore: PropTypes.func,
    searchingMoreRooms: PropTypes.bool,
    showSearchArea: PropTypes.bool,
    disableSearchArea: PropTypes.bool,
    onSearchArea: PropTypes.func,
  };

  render() {
    const {
      availableCount,
      checkedCount,
      totalSize,
      formattedDate,
      className,
      isRecurring,
      recurrence,
      dir,
      showCheckMore,
      showSearchArea,
      onCheckMore,
      onSearchArea,
      reservationType,
      searchingMoreRooms,
      disableSearchArea,
    } = this.props;
    return (
      <div className={classNames(cssBase, className)}>
        <div className={`${cssBase}__dateSpacesContainer`}>
          <div className={`${cssBase}__date`}>
            {formattedDate}
            {isRecurring && (
              <TooltipIcon
                direction="top"
                align={dir === "rtl" ? "start" : "end"}
                tooltipText={recurrence.details.ruleLabel}
                className={`${cssBase}__recurrenceTooltip`}
              >
                <Repeat16 />
              </TooltipIcon>
            )}
          </div>
          {!showSearchArea && (
            <div className={`${cssBase}__spaces`}>
              <span className={`${cssBase}__available`}>
                {this.getAvailableMessage(availableCount, reservationType)}
              </span>
              &nbsp;
              <span className={`${cssBase}__checked`}>
                {this.getCheckedRoomMessage(checkedCount, totalSize)}
              </span>
            </div>
          )}
        </div>
        <div className={`${cssBase}__buttonContainer`}>
          {showCheckMore && (
            <div className={`${cssBase}__checkmore`}>
              <Button
                kind="ghost"
                size="small"
                onClick={onCheckMore}
                disabled={
                  searchingMoreRooms || (!disableSearchArea && showSearchArea)
                }
              >
                {searchingMoreRooms && (
                  <InlineLoading className={`${cssBase}__searchingMoreRooms`} />
                )}
                {this.props.appMessages[AppMsg.CHECK_MORE]}
              </Button>
            </div>
          )}
          {showCheckMore && showSearchArea && (
            <div className={`${cssBase}__buttonSeparator`} />
          )}
          {showSearchArea && (
            <div className={`${cssBase}__searchArea`}>
              <Button
                kind="ghost"
                size="small"
                onClick={onSearchArea}
                disabled={disableSearchArea}
              >
                {this.props.appMessages[AppMsg.SEARCH_THIS_AREA]}
              </Button>
            </div>
          )}
          {(showCheckMore || showSearchArea) && (
            <TooltipIcon
              direction="top"
              align={dir === "rtl" ? "start" : "end"}
              tooltipText={this.computeButtonTooltipText(
                showCheckMore,
                showSearchArea
              )}
            >
              <Information16 />
            </TooltipIcon>
          )}
        </div>
      </div>
    );
  }

  getAvailableMessage(availableCount, reservationType) {
    return `${availableCount} ${
      reservationType === ReservationTypes.MEETING
        ? availableCount > 1
          ? this.props.appMessages[AppMsg.ROOMS_AVAILABLE]
          : this.props.appMessages[AppMsg.ROOM_AVAILABLE]
      // CISA, OFFICE
      : reservationType === ReservationTypes.OFFICE ? availableCount > 1
        ? this.props.appMessages[AppMsg.OFFICES_AVAILABLE]
        : this.props.appMessages[AppMsg.OFFICE_AVAILABLE]
        : availableCount > 1
        ? this.props.appMessages[AppMsg.WORKSPACES_AVAILABLE] + ";"
        : this.props.appMessages[AppMsg.WORKSPACE_AVAILABLE] + ";"
    }`;
  }

  getCheckedRoomMessage(checkedCount, totalSize) {
    return `${checkedCount} ${
      this.props.appMessages[AppMsg.CHECKED]
    }; ${totalSize} ${this.props.appMessages[AppMsg.TOTAL]}`;
  }

  computeButtonTooltipText(showCheckMore, showSearchArea) {
    if (showCheckMore && showSearchArea) {
      return (
        this.props.appMessages[AppMsg.CHECK_MORE_TOOLTIP] +
        " " +
        this.props.appMessages[AppMsg.SEARCH_THIS_AREA_TOOLTIP]
      );
    } else if (showCheckMore) {
      return this.props.appMessages[AppMsg.CHECK_MORE_TOOLTIP];
    } else if (showSearchArea) {
      return this.props.appMessages[AppMsg.SEARCH_THIS_AREA_TOOLTIP];
    }
  }
}

export default withTriDictionary(RoomResultsCounter);
