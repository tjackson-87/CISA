/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - 2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { isEmpty } from "lodash";
import PropTypes from "prop-types";
import { TimezoneUtils } from "../../utils";
import { ReserveNotification } from "..";
import { TimezonesSelectors } from "../../store";
import { connect } from "react-redux";

class TimezoneStatus extends React.PureComponent {
  static propTypes = {
    timezone: PropTypes.string,
    defaultTimezone: PropTypes.string,
    cssBase: PropTypes.string,
    timezones: PropTypes.array,
  };

  render() {
    const { timezone, defaultTimezone, cssBase, timezones } = this.props;
    const zone = !isEmpty(timezone)
      ? TimezoneUtils.getTimeZoneName(timezone)
      : "";
    if (isEmpty(timezone) || isEmpty(defaultTimezone) || isEmpty(zone))
      return null;
    const timezoneObj = timezones.find(
      (z) => TimezoneUtils.getTimeZoneName(z.englishName) === zone
    );
    return (
      !isEmpty(timezone) &&
      !isEmpty(timezoneObj) &&
      TimezoneUtils.areTimezonesDifferent(
        timezoneObj.englishName,
        defaultTimezone
      ) && (
        <div className={`${cssBase}__timeZoneStatus`}>
          <ReserveNotification message={timezoneObj.name} noInfoIcon={true} />
        </div>
      )
    );
  }
}

const mapStateToProps = (state) => {
  return {
    timezones: TimezonesSelectors.timezonesSelector(state),
  };
};

export default connect(mapStateToProps, {})(TimezoneStatus);
