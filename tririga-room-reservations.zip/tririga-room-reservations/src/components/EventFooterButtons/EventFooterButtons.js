/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import classnames from "classnames";
import isEmpty from "lodash/isEmpty";
import {
  Button,
  Modal,
  RadioButtonGroup,
  RadioButton,
} from "carbon-components-react";
import Popper from "@material-ui/core/Popper";
import ClickAwayListener from "@material-ui/core/ClickAwayListener";
import { Exchange } from "../../model";
import {
  AppMsg,
  ReservationEditMode,
  LayoutTypesConstants,
  ReservationTypes,
} from "../../utils";
import MediaQuery from "react-responsive";

const cssBase = "eventFooterButtons";

class EventFooterButtons extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    className: PropTypes.string,
    event: PropTypes.object,
    onEditReservation: PropTypes.func,
    onUpdateResponse: PropTypes.func,
    onDeleteEvent: PropTypes.func,
    dir: PropTypes.string,
    isExchangeIntegrated: PropTypes.bool,
    onSyncWithOutlook: PropTypes.func,
  };

  state = {
    showResponseList: false,
    showRecurrenceResponse: false,
    showDeleteOptions: false,
    showEditOptions: false,
    openConfirmDeleteModal: false,
    reservationEditMode: "",
    responseStatus: "accept",
  };

  popperModifiers = {
    sameWidth: {
      enabled: true,
      order: 840,
      fn: (data) => {
        data.offsets.popper.width = data.styles.width = Math.round(
          data.offsets.reference.width - 32
        );
        data.offsets.popper.left = data.offsets.reference.left + 16;
        data.offsets.popper.top = Math.round(
          data.offsets.reference.bottom - data.offsets.popper.height - 16
        );
        return data;
      },
    },
  };

  popperModifiersLargeScreen = {
    sameWidth: {
      enabled: true,
      order: 840,
      fn: (data) => {
        data.offsets.popper.left =
          data.originalPlacement === "bottom-end" ||
          data.originalPlacement === "left-end"
            ? data.originalPlacement === "left-end"
              ? data.offsets.reference.left + 64
              : data.offsets.reference.left + 280
            : data.originalPlacement === "bottom-start"
            ? data.offsets.reference.right - 480
            : data.offsets.reference.right - 264;
        data.offsets.popper.top = Math.round(
          data.offsets.reference.bottom - data.offsets.popper.height - 64
        );
        return data;
      },
    },
  };

  constructor(props) {
    super(props);
    this.deleteRef = React.createRef();
    this.editRef = React.createRef();
    this.deleteOccurrenceRef = React.createRef();
    this.deleteSeriesRef = React.createRef();
    this.editOccurrenceRef = React.createRef();
    this.editSeriesRef = React.createRef();
    this.editResponseRef = React.createRef();
    this.acceptRef = React.createRef();
    this.tentativeAcceptRef = React.createRef();
    this.declineRef = React.createRef();
  }

  render() {
    const {
      className,
      event,
      onEditReservation,
      isExchangeIntegrated,
      onSyncWithOutlook,
    } = this.props;
    const showEditResponse = !event.isOrganizer && !isEmpty(event.organizer);
    return (
      <div
        className={classnames(cssBase, className, {
          [`${cssBase}--editResponse`]: showEditResponse,
        })}
        ref={(e) => (this.anchorEl = e)}
      >
        <div className={`${cssBase}__container`}>
          {showEditResponse && (
            <Button
              className={`${cssBase}__button`}
              kind="primary"
              ref={(ref) => {
                this.editResponseRef = ref;
              }}
              size="small"
              aria-label={
                this.props.appMessages[AppMsg.BUTTON.BUTTON_EDIT_RESPONSE]
              }
              disabled={!!(event.instance && event.instance.actualEnd)}
              onKeyDown={(e) => {
                event.type === Exchange.EventType.SINGLE_INSTANCE
                  ? this.onEvent("BUTTON_EDIT_RESPONSE", e)
                  : this.setState({
                      showRecurrenceResponse: true,
                    });
              }}
              onClick={() => {
                event.type === Exchange.EventType.SINGLE_INSTANCE
                  ? this.setState({ showResponseList: true })
                  : this.setState({
                      showRecurrenceResponse: true,
                    });
              }}
            >
              {this.props.appMessages[AppMsg.BUTTON.BUTTON_EDIT_RESPONSE]}
            </Button>
          )}
          {!showEditResponse && (
            <>
              <Button
                className={`${cssBase}__deleteButton`}
                kind="danger"
                ref={(ref) => {
                  this.deleteRef = ref;
                }}
                size="small"
                id="eventDetailDelete"
                onKeyDown={(e) =>
                  this.onEvent("BUTTON_DELETE", e, event.isRecurringReservation)
                }
                tabIndex={0}
                aria-label={this.props.appMessages[AppMsg.BUTTON.BUTTON_DELETE]}
                onClick={() =>
                  event.isRecurringReservation
                    ? this.setState({ showDeleteOptions: true })
                    : this.handlePrepDeleteEvent(ReservationEditMode.OCCURRENCE)
                }
              >
                <label htmlFor="eventDetailDelete">
                  {this.props.appMessages[AppMsg.BUTTON.BUTTON_DELETE]}
                </label>
              </Button>
              {isExchangeIntegrated && event.isRoomOnly ? (
                <Button
                  className={`${cssBase}__editButton ${cssBase}__syncWithOutlookButton`}
                  kind="primary"
                  size="small"
                  tabIndex={0}
                  aria-label={
                    this.props.appMessages[AppMsg.BUTTON.BUTTON_SYNC_OUTLOOK]
                  }
                  onClick={() => onSyncWithOutlook()}
                >
                  {this.props.appMessages[AppMsg.BUTTON.BUTTON_SYNC_OUTLOOK]}
                </Button>
              ) : (
                <Button
                  className={`${cssBase}__editButton`}
                  kind="primary"
                  size="small"
                  ref={(ref) => {
                    this.editRef = ref;
                  }}
                  tabIndex={0}
                  aria-label={this.props.appMessages[AppMsg.BUTTON.BUTTON_EDIT]}
                  disabled={!!(event.instance && event.instance.actualEnd)}
                  onKeyDown={(e) =>
                    this.onEvent("BUTTON_EDIT", e, event.isRecurringReservation)
                  }
                  onClick={() => {
                    event.isRecurringReservation
                      ? this.setState({ showEditOptions: true })
                      : onEditReservation(
                          event,
                          ReservationEditMode.OCCURRENCE
                        );
                  }}
                >
                  {this.props.appMessages[AppMsg.BUTTON.BUTTON_EDIT]}
                </Button>
              )}
            </>
          )}
          {this.renderResponsePopper()}
          {this.renderDeleteOptions()}
          {this.renderConfirmDeleteEventModal()}
          {this.renderEditOptions()}
          {this.renderOverlay()}
          {this.renderRecurringResponseOptions()}
        </div>
      </div>
    );
  }

  renderOverlay() {
    const { showResponseList, showDeleteOptions, showEditOptions } = this.state;
    return (
      <div
        className={classnames(`${cssBase}__overlay`, {
          [`${cssBase}__overlay--visible`]:
            showResponseList || showDeleteOptions || showEditOptions,
        })}
      />
    );
  }

  renderEditOptions() {
    const { dir, event, isExchangeIntegrated } = this.props;
    const { showEditOptions } = this.state;
    return (
      <>
        <MediaQuery minWidth={LayoutTypesConstants.MIN_LARGE_SCREEN_WIDTH}>
          <Popper
            className={`${cssBase}__responseOptions`}
            open={showEditOptions}
            anchorEl={this.anchorEl}
            transition
            placement={dir === "ltr" ? "bottom-end" : "bottom-start"}
            dir={dir}
            modifiers={this.popperModifiersLargeScreen}
          >
            <ClickAwayListener onClickAway={this.handleClickAway}>
              <div className={`${cssBase}__responseList`}>
                <div
                  className={`${cssBase}__option`}
                  tabIndex={0}
                  ref={(ref) => {
                    this.editOccurrenceRef = ref;
                  }}
                  role="link"
                  onKeyDown={(e) => this.onEvent("EDIT_OCCURRENCE", e)}
                  onClick={() =>
                    this.props.onEditReservation(
                      event,
                      ReservationEditMode.SERIES_OCCURRENCE
                    )
                  }
                  disabled={
                    isExchangeIntegrated &&
                    event.locationType === ReservationTypes.MEETING &&
                    isEmpty(event.iCalUId)
                  }
                >
                  {
                    this.props.appMessages[
                      AppMsg.RESERVATION_MESSAGE.EDIT_OCCURRENCE
                    ]
                  }
                </div>
                <div
                  className={`${cssBase}__option`}
                  tabIndex={0}
                  role="link"
                  ref={(ref) => {
                    this.editSeriesRef = ref;
                  }}
                  onKeyDown={(e) => this.onEvent("EDIT_SERIES", e, event)}
                  onClick={() =>
                    this.props.onEditReservation(
                      event,
                      ReservationEditMode.SERIES
                    )
                  }
                  disabled={
                    isExchangeIntegrated &&
                    event.hasSomeButNotEveryResourceInSeriesOccurrences &&
                    (event.locationType === ReservationTypes.MEETING ||
                      isEmpty(event.rooms))
                  }
                >
                  {
                    this.props.appMessages[
                      AppMsg.RESERVATION_MESSAGE.EDIT_SERIES
                    ]
                  }
                </div>
              </div>
            </ClickAwayListener>
          </Popper>
        </MediaQuery>
        <MediaQuery maxWidth={LayoutTypesConstants.MAX_SMALL_SCREEN_WIDTH}>
          <Popper
            className={`${cssBase}__responseOptions`}
            open={showEditOptions}
            anchorEl={this.anchorEl}
            transition
            placement="top-start"
            dir={dir}
            modifiers={this.popperModifiers}
          >
            <ClickAwayListener onClickAway={this.handleClickAway}>
              <div className={`${cssBase}__responseList`}>
                <div className={`${cssBase}__responseHeader`}>
                  {
                    this.props.appMessages[
                      AppMsg.RESERVATION_MESSAGE.REPEATING_EVENT
                    ]
                  }
                </div>
                <div
                  className={`${cssBase}__option`}
                  tabIndex={0}
                  ref={(ref) => {
                    this.editOccurrenceRef = ref;
                  }}
                  role="link"
                  onKeyDown={(e) => this.onEvent("EDIT_OCCURRENCE", e)}
                  onClick={() =>
                    this.props.onEditReservation(
                      event,
                      ReservationEditMode.SERIES_OCCURRENCE
                    )
                  }
                  disabled={isExchangeIntegrated && isEmpty(event.iCalUId)}
                >
                  {
                    this.props.appMessages[
                      AppMsg.RESERVATION_MESSAGE.EDIT_OCCURRENCE
                    ]
                  }
                </div>
                <div
                  className={`${cssBase}__option`}
                  tabIndex={0}
                  role="link"
                  ref={(ref) => {
                    this.editSeriesRef = ref;
                  }}
                  onKeyDown={(e) => this.onEvent("EDIT_SERIES", e, event)}
                  onClick={() =>
                    this.props.onEditReservation(
                      event,
                      ReservationEditMode.SERIES
                    )
                  }
                >
                  {
                    this.props.appMessages[
                      AppMsg.RESERVATION_MESSAGE.EDIT_SERIES
                    ]
                  }
                </div>
                <div
                  className={`${cssBase}__cancelButton`}
                  onClick={() => this.setState({ showEditOptions: false })}
                >
                  {this.props.appMessages[AppMsg.BUTTON.CANCEL]}
                </div>
              </div>
            </ClickAwayListener>
          </Popper>
        </MediaQuery>
      </>
    );
  }

  renderDeleteOptions() {
    const { showDeleteOptions } = this.state;
    const { dir } = this.props;
    return (
      <>
        <MediaQuery minWidth={LayoutTypesConstants.MIN_LARGE_SCREEN_WIDTH}>
          <Popper
            className={`${cssBase}__responseOptions`}
            open={showDeleteOptions}
            anchorEl={this.anchorEl}
            transition
            placement={dir === "ltr" ? "left-end" : "left-start"}
            dir={dir}
            modifiers={this.popperModifiersLargeScreen}
          >
            <ClickAwayListener onClickAway={this.handleClickAway}>
              <div className={`${cssBase}__responseList`}>
                <div
                  className={`${cssBase}__option`}
                  tabIndex={0}
                  ref={(ref) => {
                    this.deleteOccurrenceRef = ref;
                  }}
                  role="link"
                  onKeyDown={(e) => this.onEvent("DELETE_OCCURRENCE", e)}
                  onClick={() =>
                    this.handlePrepDeleteEvent(
                      ReservationEditMode.SERIES_OCCURRENCE
                    )
                  }
                >
                  {
                    this.props.appMessages[
                      AppMsg.RESERVATION_MESSAGE.DELETE_OCCURRENCE
                    ]
                  }
                </div>
                <div
                  className={`${cssBase}__option`}
                  tabIndex={0}
                  role="link"
                  ref={(ref) => {
                    this.deleteSeriesRef = ref;
                  }}
                  onKeyDown={(e) => this.onEvent("DELETE_SERIES", e)}
                  onClick={() =>
                    this.handlePrepDeleteEvent(ReservationEditMode.SERIES)
                  }
                >
                  {
                    this.props.appMessages[
                      AppMsg.RESERVATION_MESSAGE.DELETE_SERIES
                    ]
                  }
                </div>
              </div>
            </ClickAwayListener>
          </Popper>
        </MediaQuery>
        <MediaQuery maxWidth={LayoutTypesConstants.MAX_SMALL_SCREEN_WIDTH}>
          <Popper
            className={`${cssBase}__responseOptions`}
            open={showDeleteOptions}
            anchorEl={this.anchorEl}
            transition
            placement="top-start"
            dir={dir}
            modifiers={this.popperModifiers}
          >
            <ClickAwayListener onClickAway={this.handleClickAway}>
              <div className={`${cssBase}__responseList`}>
                <div className={`${cssBase}__responseHeader`}>
                  {
                    this.props.appMessages[
                      AppMsg.RESERVATION_MESSAGE.REPEATING_EVENT
                    ]
                  }
                </div>
                <div
                  className={`${cssBase}__option`}
                  tabIndex={0}
                  ref={(ref) => {
                    this.deleteOccurrenceRef = ref;
                  }}
                  role="link"
                  onKeyDown={(e) => this.onEvent("DELETE_OCCURRENCE", e)}
                  onClick={() =>
                    this.handlePrepDeleteEvent(
                      ReservationEditMode.SERIES_OCCURRENCE
                    )
                  }
                >
                  {
                    this.props.appMessages[
                      AppMsg.RESERVATION_MESSAGE.DELETE_OCCURRENCE
                    ]
                  }
                </div>
                <div
                  className={`${cssBase}__option`}
                  tabIndex={0}
                  role="link"
                  ref={(ref) => {
                    this.deleteSeriesRef = ref;
                  }}
                  onKeyDown={(e) => this.onEvent("DELETE_SERIES", e)}
                  onClick={() =>
                    this.handlePrepDeleteEvent(ReservationEditMode.SERIES)
                  }
                >
                  {
                    this.props.appMessages[
                      AppMsg.RESERVATION_MESSAGE.DELETE_SERIES
                    ]
                  }
                </div>
                <div
                  className={`${cssBase}__cancelButton`}
                  onClick={() => this.setState({ showDeleteOptions: false })}
                >
                  {this.props.appMessages[AppMsg.BUTTON.CANCEL]}
                </div>
              </div>
            </ClickAwayListener>
          </Popper>
        </MediaQuery>
      </>
    );
  }

  onEvent(type, e, event = {}) {
    switch (type) {
      case "BUTTON_DELETE": {
        if (e.key === "Enter" && event !== false) {
          setTimeout(() => {
            if (this.deleteOccurrenceRef) this.deleteOccurrenceRef.focus();
          }, 1);
        }

        break;
      }
      case "DELETE_OCCURRENCE": {
        if (e.key === "Enter") {
          this.handlePrepDeleteEvent(ReservationEditMode.SERIES_OCCURRENCE);
        }

        if (e.shiftKey && e.keyCode === 9) {
          this.setState({ showDeleteOptions: false });
          setTimeout(() => {
            if (this.deleteRef) this.deleteRef.focus();
          }, 1);
        }

        break;
      }
      case "DELETE_SERIES": {
        if (e.key === "Enter") {
          this.handlePrepDeleteEvent(ReservationEditMode.SERIES);
        }

        if (e.shiftKey && e.keyCode === 9) {
          setTimeout(() => {
            if (this.deleteOccurrenceRef) this.deleteOccurrenceRef.focus();
          }, 1);
        }

        if (e.key === "Tab" && !e.shiftKey) {
          this.setState({ showDeleteOptions: false });
          setTimeout(() => {
            if (this.deleteRef) this.deleteRef.focus();
          }, 1);
        }

        break;
      }

      case "BUTTON_EDIT": {
        if (e.key === "Enter" && event !== false) {
          setTimeout(() => {
            if (this.editOccurrenceRef) this.editOccurrenceRef.focus();
          }, 1);
        }
        break;
      }
      case "EDIT_OCCURRENCE": {
        if (e.key === "Enter") {
          this.props.onEditReservation(
            event,
            ReservationEditMode.SERIES_OCCURRENCE
          );
        }

        if (e.shiftKey && e.keyCode === 9) {
          this.setState({ showEditOptions: false });
          setTimeout(() => {
            if (this.editRef) this.editRef.focus();
          }, 1);
        }

        break;
      }

      case "EDIT_SERIES": {
        if (e.key === "Enter") {
          this.props.onEditReservation(event, ReservationEditMode.SERIES);
        }

        if (e.key === "Tab" && !e.shiftKey) {
          this.setState({ showEditOptions: false });
          setTimeout(() => {
            if (this.editRef) this.editRef.focus();
          }, 1);
        }

        if (e.shiftKey && e.keyCode === 9) {
          setTimeout(() => {
            if (this.editOccurrenceRef) this.editOccurrenceRef.focus();
          }, 1);
        }
        break;
      }
      case "BUTTON_EDIT_RESPONSE": {
        if (e.key === "Enter") {
          setTimeout(() => {
            if (this.acceptRef) {
              this.acceptRef.focus();
            }
          }, 1);
        }

        break;
      }
      case "ACCEPT": {
        if (e.key === "Enter") {
          this.handleResponse("accept");
        }
        if (e.key === "Tab") {
          setTimeout(() => {
            if (this.tentativeAcceptRef) this.tentativeAcceptRef.focus();
          }, 1);
        }
        if (e.shiftKey && e.keyCode === 9) {
          setTimeout(() => {
            if (this.editResponseRef) this.editResponseRef.focus();
          }, 1);
          this.setState({ showResponseList: false });
        }
        break;
      }
      case "TENTATIVELT_ACCEPT": {
        if (e.key === "Enter") {
          this.handleResponse("tentativelyAccept");
        }
        if (e.key === "Tab" && !e.shiftKey) {
          setTimeout(() => {
            if (this.declineRef) this.declineRef.focus();
          }, 1);
        }
        if (e.shiftKey && e.keyCode === 9) {
          setTimeout(() => {
            if (this.acceptRef) this.acceptRef.focus();
          }, 1);
        }
        break;
      }
      case "DECLINE": {
        if (e.key === "Enter") {
          this.handleResponse("decline");
        }
        if (e.key === "Tab" && !e.shiftKey) {
          setTimeout(() => {
            if (this.editResponseRef) this.editResponseRef.focus();
          }, 1);
          this.setState({ showResponseList: false });
        }
        if (e.shiftKey && e.keyCode === 9) {
          setTimeout(() => {
            if (this.tentativeAcceptRef) this.tentativeAcceptRef.focus();
          }, 1);
        }
        break;
      }

      default: {
        break;
      }
    }
  }

  handlePrepDeleteEvent(mode) {
    this.setState({
      showDeleteOptions: false,
      openConfirmDeleteModal: true,
      reservationEditMode: mode,
    });
  }

  renderResponsePopper = () => {
    const { dir } = this.props;
    const { showResponseList } = this.state;
    return (
      <>
        <MediaQuery maxWidth={LayoutTypesConstants.MAX_SMALL_SCREEN_WIDTH}>
          <Popper
            open={showResponseList}
            anchorEl={this.anchorEl}
            transition
            placement="top-start"
            dir={dir}
            modifiers={this.popperModifiers}
          >
            <ClickAwayListener onClickAway={this.handleClickAway}>
              <div className={`${cssBase}__responseList`}>
                {showResponseList && this.renderResponseOptions()}
              </div>
            </ClickAwayListener>
          </Popper>
        </MediaQuery>
        <MediaQuery minWidth={LayoutTypesConstants.MIN_LARGE_SCREEN_WIDTH}>
          <Popper
            open={showResponseList}
            anchorEl={this.anchorEl}
            transition
            placement={dir === "ltr" ? "left-end" : "left-start"}
            dir={dir}
            modifiers={this.popperModifiersLargeScreen}
          >
            <ClickAwayListener onClickAway={this.handleClickAway}>
              <div className={`${cssBase}__responseList`}>
                {showResponseList && this.renderResponseOptionsLargeScreen()}
              </div>
            </ClickAwayListener>
          </Popper>
        </MediaQuery>
      </>
    );
  };

  renderResponseOptions = () => {
    return (
      <>
        <div className={`${cssBase}__responseHeader`}>
          {
            this.props.appMessages[
              AppMsg.RESERVATION_MESSAGE.EDIT_YOUR_RESPONSE
            ]
          }
        </div>
        <div
          className={`${cssBase}__option`}
          onClick={() => this.handleResponse("accept")}
          onKeyDown={(e) => this.onEvent("ACCEPT", e)}
          tabIndex={0}
          role="link"
          ref={(ref) => {
            this.acceptRef = ref;
          }}
        >
          {this.props.appMessages[AppMsg.RESERVATION_MESSAGE.ACCEPT]}
        </div>
        <div
          className={`${cssBase}__option`}
          onClick={() => this.handleResponse("tentativelyAccept")}
          onKeyDown={(e) => this.onEvent("TENTATIVELT_ACCEPT", e)}
          tabIndex={0}
          role="link"
          ref={(ref) => {
            this.tentativeAcceptRef = ref;
          }}
        >
          {
            this.props.appMessages[
              AppMsg.RESERVATION_MESSAGE.TENTATIVELT_ACCEPT
            ]
          }
        </div>
        <div
          className={`${cssBase}__option`}
          onClick={() => this.handleResponse("decline")}
          onKeyDown={(e) => this.onEvent("DECLINE", e)}
          tabIndex={0}
          role="link"
          ref={(ref) => {
            this.declineRef = ref;
          }}
        >
          {this.props.appMessages[AppMsg.RESERVATION_MESSAGE.DECLINE]}
        </div>
        <div
          className={`${cssBase}__cancelButton`}
          onClick={() => this.setState({ showResponseList: false })}
        >
          {this.props.appMessages[AppMsg.BUTTON.CANCEL]}
        </div>
      </>
    );
  };

  renderResponseOptionsLargeScreen = () => {
    return (
      <>
        <div
          className={`${cssBase}__option`}
          onClick={() => this.handleResponse("accept")}
          onKeyDown={(e) => this.onEvent("ACCEPT", e)}
          tabIndex={0}
          role="link"
          ref={(ref) => {
            this.acceptRef = ref;
          }}
        >
          {this.props.appMessages[AppMsg.RESERVATION_MESSAGE.ACCEPT]}
        </div>
        <div
          className={`${cssBase}__option`}
          onClick={() => this.handleResponse("tentativelyAccept")}
          onKeyDown={(e) => this.onEvent("TENTATIVELT_ACCEPT", e)}
          tabIndex={0}
          role="link"
          ref={(ref) => {
            this.tentativeAcceptRef = ref;
          }}
        >
          {
            this.props.appMessages[
              AppMsg.RESERVATION_MESSAGE.TENTATIVELT_ACCEPT
            ]
          }
        </div>
        <div
          className={`${cssBase}__option`}
          onClick={() => this.handleResponse("decline")}
          onKeyDown={(e) => this.onEvent("DECLINE", e)}
          tabIndex={0}
          role="link"
          ref={(ref) => {
            this.declineRef = ref;
          }}
        >
          {this.props.appMessages[AppMsg.RESERVATION_MESSAGE.DECLINE]}
        </div>
      </>
    );
  };

  renderRecurringResponseOptions = () => {
    const { showRecurrenceResponse } = this.state;
    return (
      <Modal
        size="sm"
        preventCloseOnClickOutside
        selectorPrimaryFocus=".bx--modal-close"
        modalHeading={
          this.props.appMessages[AppMsg.RESERVATION_MESSAGE.EDIT_YOUR_RESPONSE]
        }
        primaryButtonText={
          this.props.appMessages[AppMsg.RESERVATION_MESSAGE.UPDATE_OCCURENCE]
        }
        secondaryButtonText={
          this.props.appMessages[AppMsg.RESERVATION_MESSAGE.UPDATE_SERIES]
        }
        onRequestSubmit={() => this.handleOccurenceResponse(false)}
        onSecondarySubmit={() => this.handleOccurenceResponse(true)}
        onRequestClose={() => this.handleRecurringModalClose()}
        open={showRecurrenceResponse}
        iconDescription={this.props.appMessages[AppMsg.BUTTON.CLOSE]}
      >
        <RadioButtonGroup
          legendText={
            this.props.appMessages[AppMsg.RESERVATION_MESSAGE.REPEATING_EVENT]
          }
          orientation="vertical"
          name="recurrence-response-options-group"
          defaultSelected="accept"
          onChange={(selectedStatus) =>
            this.setState({
              responseStatus: selectedStatus,
            })
          }
        >
          <RadioButton
            id="radio-button-accept"
            key="radio-button-accept"
            labelText={
              this.props.appMessages[AppMsg.RESERVATION_MESSAGE.ACCEPT]
            }
            value="accept"
          />
          <RadioButton
            id="radio-button-tentativelyAccept"
            key="radio-button-tentativelyAccept"
            labelText={
              this.props.appMessages[
                AppMsg.RESERVATION_MESSAGE.TENTATIVELT_ACCEPT
              ]
            }
            value="tentativelyAccept"
          />
          <RadioButton
            id="radio-button-decline"
            key="radio-button-decline"
            labelText={
              this.props.appMessages[AppMsg.RESERVATION_MESSAGE.DECLINE]
            }
            value="decline"
          />
        </RadioButtonGroup>
      </Modal>
    );
  };

  handleRecurringModalClose = () => {
    this.setState({
      showRecurrenceResponse: false,
    });
    setTimeout(() => {
      if (this.editResponseRef) this.editResponseRef.focus();
    }, 1);
  };

  handleOccurenceResponse = (updateSeries) => {
    const { onUpdateResponse, event } = this.props;
    const eventId = updateSeries ? event.seriesMasterId : event.eventId;
    this.setState({ showRecurrenceResponse: false });
    onUpdateResponse(eventId, this.state.responseStatus);
  };

  handleResponse = (newResponseStatus) => {
    const { event, onUpdateResponse } = this.props;
    onUpdateResponse(event.eventId, newResponseStatus);
  };

  renderConfirmDeleteEventModal() {
    const label = AppMsg.getMessage(AppMsg.RESERVATION_MESSAGE.DELETE_MEETING);
    const { openConfirmDeleteModal } = this.state;
    return (
      <Modal
        danger
        size="xs"
        aria-label={label}
        modalHeading={label}
        modalAriaLabel={label}
        primaryButtonText={this.props.appMessages[AppMsg.BUTTON.BUTTON_DELETE]}
        secondaryButtonText={this.props.appMessages[AppMsg.BUTTON.CANCEL]}
        onRequestSubmit={() => this.handleDeleteEvent()}
        onSecondarySubmit={() => this.handleCancelDelete()}
        onRequestClose={() => this.handleCancelDelete()}
        open={openConfirmDeleteModal}
        iconDescription={this.props.appMessages[AppMsg.BUTTON.CLOSE]}
      >
        <p>
          {
            this.props.appMessages[
              AppMsg.RESERVATION_MESSAGE.DELETE_MEETING_DESCRIPTION
            ]
          }
        </p>
      </Modal>
    );
  }

  handleCancelDelete() {
    this.setState({
      showDeleteOptions: false,
      openConfirmDeleteModal: false,
      reservationEditMode: "",
    });

    setTimeout(() => {
      this.deleteRef.focus();
    }, 1);
  }

  async handleDeleteEvent() {
    const { event, onDeleteEvent } = this.props;
    await onDeleteEvent(event, this.state.reservationEditMode);
  }

  handleClickAway = () => {
    this.setState({
      showResponseList: false,
      showRecurrenceResponse: false,
      showDeleteOptions: false,
      showEditOptions: false,
    });
  };
}

export default withTriDictionary(EventFooterButtons);
