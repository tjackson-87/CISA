/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import isEmpty from "lodash/isEmpty";
import { StarFilled16, Star16 } from "@carbon/icons-react";
import { TooltipIcon } from "carbon-components-react";
import { AppMsg } from "../../utils";

const cssBase = "favoriteIconButton";

export default class FavoriteIconButton extends React.PureComponent {
  constructor(props) {
    super(props);
    this.favButton = React.createRef();
  }

  static propTypes = {
    className: PropTypes.string,
    dir: PropTypes.string,
    favorites: PropTypes.array,
    item: PropTypes.object,
    onHold: PropTypes.bool,
    addFavorite: PropTypes.func,
    removeFavorite: PropTypes.func,
  };

  static defaultProps = {
    onHold: false,
  };

  render() {
    const { className, item, dir, onHold } = this.props;
    return (
      <div
        onClick={(e) => this.handleIconClicked(e, item)}
        onKeyDown={(e) =>
          e.key === "Enter" ? this.handleIconClicked(e, item) : null
        }
        className={classNames(
          cssBase,
          className
        )}
        ref={this.favButton}
      >
        <TooltipIcon
          direction={onHold ? "top" : dir === "rtl" ? "right" : "left"}
          align={onHold ? "start" : "center"}
          aria-label={this.computeFavButtonDescription(item)}
          tooltipText={this.computeFavButtonDescription(item)}
        >
          {this.computeIsFavorite(item) ? (
            <StarFilled16 />
          ) : (
            <Star16 />
          )}
        </TooltipIcon>
      </div>
    );
  }

  computeIsFavorite = (item) => {
    const favorites = this.props.favorites;
    if (isEmpty(favorites)) return false;
    return (
      !isEmpty(favorites) &&
      favorites.findIndex((fav) => fav._id === item._id) > -1
    );
  };

  computeFavButtonDescription(item) {
    const isFav = this.computeIsFavorite(item);
    if (item.isMeetingSpace) {
      return isFav
        ? AppMsg.getMessage(AppMsg.BUTTON.REMOVE_FAVORITE_ROOM)
        : AppMsg.getMessage(AppMsg.BUTTON.ADD_FAVORITE_ROOM);
    } else {
      return isFav
        ? AppMsg.getMessage(AppMsg.BUTTON.REMOVE_FAVORITE_WORKSPACE)
        : AppMsg.getMessage(AppMsg.BUTTON.ADD_FAVORITE_WORKSPACE);
    }
  }

  handleIconClicked = (e, item) => {
    e.stopPropagation();
    this.favButton.current.blur();
    const isFav = this.computeIsFavorite(item);
    if (isFav) {
      this.props.removeFavorite(item);
    } else {
      this.props.addFavorite(item);
    }
  };
}
