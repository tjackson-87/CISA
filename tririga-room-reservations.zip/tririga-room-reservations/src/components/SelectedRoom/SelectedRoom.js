import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import { AppMsg, computeAddress } from "../../utils";
import { Location16 } from "@carbon/icons-react";
import classnames from "classnames";

const cssBase = "selectedRoom";

class SelectedRoom extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    room: PropTypes.object,
    nameAndAddressOnly: PropTypes.bool,
  };

  render() {
    const { room, appMessages, nameAndAddressOnly } = this.props;
    return (
      <div
        className={classnames({
          [`${cssBase}`]: true,
          [`${cssBase}__nameAndAddressOnly`]: nameAndAddressOnly,
        })}
      >
        {!nameAndAddressOnly && (
          <div className={`${cssBase}__label`}>
            {appMessages[AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SELECTED_ROOM]}:
          </div>
        )}
        <div className={classnames(`${cssBase}__location`)}>
          {!nameAndAddressOnly && (
            <Location16 className={`${cssBase}__locationIcon`} />
          )}
          <div
            className={classnames({
              [`${cssBase}__room`]: true,
              [`${cssBase}__nameAndAddressOnly`]: nameAndAddressOnly,
              [`${cssBase}__link`]: nameAndAddressOnly,
            })}
          >
            {room.name}
          </div>
        </div>
        <div
          className={classnames({
            [`${cssBase}__address`]: true,
            [`${cssBase}__nameAndAddressOnly`]: nameAndAddressOnly,
          })}
        >
          {computeAddress(room)}
        </div>
      </div>
    );
  }
}

export default withTriDictionary(SelectedRoom);
