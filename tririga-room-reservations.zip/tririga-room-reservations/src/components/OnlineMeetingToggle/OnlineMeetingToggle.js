/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import classNames from "classnames";
import { Toggle } from "carbon-components-react";
import { AppMsg } from "../../utils";

class OnlineMeetingToggle extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    id: PropTypes.string,
    onToggle: PropTypes.func,
    className: PropTypes.string,
    toggled: PropTypes.bool,
    disabled: PropTypes.bool,
  };

  static defaultProps = {
    toggled: false,
  };

  render() {
    const { onToggle, className, toggled, disabled, id } = this.props;
    return (
      <Toggle
        id={id}
        className={classNames(className)}
        onToggle={onToggle}
        labelA={this.props.appMessages[AppMsg.BUTTON.BUTTON_OFF]}
        labelB={this.props.appMessages[AppMsg.BUTTON.BUTTON_ON]}
        toggled={toggled}
        disabled={disabled}
      />
    );
  }
}

export default withTriDictionary(OnlineMeetingToggle);