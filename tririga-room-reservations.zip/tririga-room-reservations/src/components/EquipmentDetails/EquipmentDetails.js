/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import { ChevronRight16, ChevronLeft16 } from "@carbon/icons-react";
import { AppMsg } from "../../utils";
const cssBase = "equipmentDetails";

export default class EquipmentDetails extends React.PureComponent {
  static propTypes = {
    stepIcon: PropTypes.elementType,
    name: PropTypes.string,
    className: PropTypes.string,
    equipment: PropTypes.array,
    onEquipmentClick: PropTypes.func,
    dir: PropTypes.string,
  };

  render() {
    const {
      stepIcon: StepIcon,
      name,
      className,
      equipment,
      onEquipmentClick,
      dir,
    } = this.props;

    return (
      <div
        tabIndex={0}
        role="button"
        className={classNames(cssBase, className)}
        onClick={onEquipmentClick}
        onKeyDown={(e) => (e.key === "Enter" ? onEquipmentClick() : null)}
      >
        <div className={`${cssBase}__content`}>
          <div className={`${cssBase}__header`}>
            <StepIcon className={`${cssBase}__headerIcon`} />
            <div className={`${cssBase}__headerName`}>{name}</div>
          </div>
          <div className={`${cssBase}__children`}>
            {equipment.map((e, index) => (
              <span className={`${cssBase}__equipment`} key={e._id}>
                {`${e.equipment}${
                  e.quantity > 1 ? " (" + e.quantity + ")" : ""
                }${index < equipment.length - 1 ? "; " : ""}`}
              </span>
            ))}
          </div>
        </div>
        <span
          aria-label={AppMsg.getMessage(AppMsg.BUTTON.OPEN_EQUIPMENT_LIST)}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => (e.key === "Enter" ? onEquipmentClick() : null)}
        >
          {this.renderArrowIcon(dir)}
        </span>
      </div>
    );
  }

  renderArrowIcon = (dir) => {
    if (dir === "rtl") {
      return <ChevronLeft16 className={`${cssBase}__icon`} />;
    } else {
      return <ChevronRight16 className={`${cssBase}__icon`} />;
    }
  };
}
