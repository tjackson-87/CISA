/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import isEmpty from "lodash/isEmpty";
import { AppMsg } from "../../utils";
import { CheckmarkOutline16, WarningAlt16 } from "@carbon/icons-react";

const cssBase = "attendeesStatus";

class AttendeesStatus extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    isExchangeIntegrated: PropTypes.bool,
    exchangeAttendeesAvailable: PropTypes.number,
    exchangeAttendees: PropTypes.array,
    nonExchangeAttendees: PropTypes.array,
  };

  render() {
    const {
      isExchangeIntegrated,
      exchangeAttendeesAvailable,
      exchangeAttendees,
      nonExchangeAttendees,
    } = this.props;
    const total = exchangeAttendees.length + nonExchangeAttendees.length;
    const unavailableCount =
      exchangeAttendees.length - exchangeAttendeesAvailable;
    return (
      isExchangeIntegrated &&
      !isEmpty(exchangeAttendees) && (
        <div className={`${cssBase}__attendeesAvailability`}>
          {exchangeAttendeesAvailable === total ? (
            <CheckmarkOutline16 />
          ) : (
            <WarningAlt16 />
          )}
          <span className={`${cssBase}__attendeesAvailabilityLabel`}>
            {this.props.appMessages[
              AppMsg.RESERVATION_MESSAGE.STEP_TIME_ATTENDEES_AVAILABLE
            ]
              .replace("{1}", exchangeAttendeesAvailable)
              .replace("{2}", total)}

            {unavailableCount !== 0 &&
              ", " +
                AppMsg.getMessage(
                  AppMsg.RESERVATION_MESSAGE.STEP_TIME_ATTENDEES_UNAVAILABLE
                ).replace("{1}", unavailableCount)}

            {!isEmpty(nonExchangeAttendees) &&
              ", " +
                AppMsg.getMessage(
                  AppMsg.RESERVATION_MESSAGE.STEP_TIME_ATTENDEES_UNKNOWN
                ).replace("{1}", nonExchangeAttendees.length)}
          </span>
        </div>
      )
    );
  }
}

export default withTriDictionary(AttendeesStatus);
