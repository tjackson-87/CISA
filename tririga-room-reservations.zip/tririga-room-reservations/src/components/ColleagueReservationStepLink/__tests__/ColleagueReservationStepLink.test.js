/* IBM Confidential· - OCO Source Materials· - (C) COPYRIGHT IBM CORP. 2023 - The source code for this program is not published or otherwise· divested of its trade secrets, irrespective of what has been· deposited with the U.S. Copyright Office. */

import React from "react";
import ColleagueReservationStepLink from "../ColleagueReservationStepLink";
import { AppMsg } from "../../../utils";
import { renderWithTriDictionaryProvider } from "../../../testUtils";

afterEach(() => jest.clearAllMocks());
describe("ColleagueReservationStepLink", () => {
  const appMessages = AppMsg.getAppMessages();
  const props = {
    onClick: jest.fn(),
    stepLinkReference: jest.fn(),
    name: "Test-Name",
    dir: "LTR",
    className: "Test-class",
    ariaLabel: "Test Label",
    addIcon: "AddIcon",
  };

  it("renders correctly", () => {
    renderWithTriDictionaryProvider(
      <ColleagueReservationStepLink {...props} />,
      { appMessages }
    );
    const header = document.getElementsByClassName(
      "colleagueReservationStepLink__headerName"
    );
    expect(header).toBeDefined();
    expect(header).not.toBeNull();
  });
  
  it("Page renders correctly if web indentation given right to left in parameter", () => {
    const args = {
      ...props,
      dir: "RTL",
    };
    renderWithTriDictionaryProvider(
      <ColleagueReservationStepLink {...args} />,
      { appMessages }
    );
    const header = document.getElementsByClassName(
      "colleagueReservationStepLink__headerName"
    );
    expect(header).toBeDefined();
    expect(header).not.toBeNull();
  });
});
