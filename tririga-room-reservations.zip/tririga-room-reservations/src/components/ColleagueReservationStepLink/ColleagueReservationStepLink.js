/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import classNames from "classnames";
import { ChevronRight16, ChevronLeft16 } from "@carbon/icons-react";
import { isNil } from "lodash";

const cssBase = "colleagueReservationStepLink";

class ColleagueReservationStepLink extends React.PureComponent {
  static propTypes = {
    stepIcon: PropTypes.elementType,
    onClick: PropTypes.func,
    stepLinkReference: PropTypes.func,
    name: PropTypes.any,
    className: PropTypes.string,
    children: PropTypes.node,
    dir: PropTypes.string,
    addIcon: PropTypes.elementType,
    ariaLabel: PropTypes.string,
    id: PropTypes.string,
    onKeyDown: PropTypes.func,
  };

  constructor(props) {
    super(props);
    this.stepLinkRef = React.createRef();
  }

  componentDidMount() {
    if (this.props.stepLinkReference) {
      this.props.stepLinkReference(this.stepLinkRef);
    }
  }

  renderArrowIcon(dir, AddIcon) {
    if (AddIcon) return <AddIcon className={`${cssBase}__icon`} />;
    if (dir === "rtl") {
      return <ChevronLeft16 className={`${cssBase}__icon`} />;
    } else {
      return <ChevronRight16 className={`${cssBase}__icon`} />;
    }
  }

  render() {
    const {
      stepIcon: StepIcon,
      onClick,
      name,
      className,
      children,
      dir,
      addIcon: AddIcon,
      ariaLabel,
      id,
      onKeyDown,
    } = this.props;
    const label = !isNil(ariaLabel) ? ariaLabel : name;

    return (
      <div
        className={classNames(cssBase, className)}
        ref={this.stepLinkRef}
        onClick={() => onClick()}
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            e.preventDefault();
            e.stopPropagation();
            onClick();
          }
          if (e.key === "Escape") {
            onKeyDown(e);
          } 
        }}
        role="link"
        tabIndex={0}
        aria-label={ariaLabel ? label : null}
        id={id}
      >
        <div className={`${cssBase}__content ${cssBase}__pointer`}>
          <div className={`${cssBase}__header`}>
            {StepIcon && <StepIcon className={`${cssBase}__headerIcon`} />}
            <div
              className={`${cssBase}__headerName`}
              aria-label={!ariaLabel ? label : null}
            >
              {name}
            </div>
          </div>
          {children != null && (
            <div className={`${cssBase}__children`}>{children}</div>
          )}
        </div>
        {this.renderArrowIcon(dir, AddIcon)}
      </div>
    );
  }
}
export default withTriDictionary(ColleagueReservationStepLink);
