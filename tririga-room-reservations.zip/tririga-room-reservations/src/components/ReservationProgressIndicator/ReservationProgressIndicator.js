/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import { ProgressIndicator, ProgressStep } from "carbon-components-react";

const cssBase = "reservationProgressIndicator";

export default class ReservationProgressIndicator extends React.PureComponent {
  static propTypes = {
    onChange: PropTypes.func,
    steps: PropTypes.array.isRequired,
    currentIndex: PropTypes.number,
    className: PropTypes.string,
    stepClassName: PropTypes.string,
  };

  static defaultProps = {
    smallLayout: false,
  };

  render() {
    const {
      currentIndex,
      steps,
      className,
      stepClassName,
      onChange,
    } = this.props;
    if (!steps || steps.length === 0) return null;

    return (
      <ProgressIndicator
        currentIndex={currentIndex}
        className={classNames(cssBase, className)}
        onChange={onChange}
      >
        {steps.map((step) => (
          <ProgressStep
            label={step.label}
            key={step.key}
            secondaryLabel={step.secondaryLabel}
            className={classNames(`${cssBase}__progressStep`, stepClassName)}
          />
        ))}
      </ProgressIndicator>
    );
  }
}
