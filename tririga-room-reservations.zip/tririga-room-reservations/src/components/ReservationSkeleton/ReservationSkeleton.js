/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import { SkeletonPlaceholder, SkeletonText } from "carbon-components-react";

const cssBase = "reservationSkeleton";

export default class ReservationSkeleton extends React.PureComponent {
  render() {
    return (
      <div className={cssBase}>
        <SkeletonText className={`${cssBase}__header`} />
        <SkeletonPlaceholder className={`${cssBase}__section`} />
        <SkeletonPlaceholder className={`${cssBase}__section`} />
        <SkeletonPlaceholder className={`${cssBase}__section`} />
        <SkeletonPlaceholder className={`${cssBase}__section`} />
      </div>
    );
  }
}
