/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import { AppMsg, LayoutTypesConstants } from "../../utils";
import MediaQuery from "react-responsive";

const cssBase = "displayMeetingInfo";

class DisplayMeetingInfo extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    meetingInfo: PropTypes.object,
  };

  render() {
    const { meetingInfo } = this.props;
    if (meetingInfo == null) return null;
    return (
      <>
        <MediaQuery maxWidth={LayoutTypesConstants.MAX_SMALL_SCREEN_WIDTH}>
          <div className="page__section">
            <div className={`${cssBase}__onlineMeetingHeader`}>
              {this.props.appMessages[AppMsg.RESERVATION_MESSAGE.MEETING_NAME]}
            </div>
            <div className={`${cssBase}__onlineMeetingDetails`}>
              {meetingInfo.name}
            </div>
          </div>
        </MediaQuery>
        <div className="page__section">
          <div className={`${cssBase}__onlineMeetingHeader`}>
            {this.props.appMessages[AppMsg.RESERVATION_MESSAGE.MEETING_URL]}
          </div>
          <div className={`${cssBase}__onlineMeetingDetails`}>
            {meetingInfo.url}
          </div>
        </div>
        <div className="page__section">
          <div className={`${cssBase}__onlineMeetingHeader`}>
            {
              this.props.appMessages[
                AppMsg.RESERVATION_MESSAGE.MEETING_PASSWORD
              ]
            }
          </div>
          <div className={`${cssBase}__onlineMeetingDetails`}>
            {meetingInfo.password}
          </div>
        </div>
        <div className="page__section">
          <div className={`${cssBase}__onlineMeetingHeader`}>
            {
              this.props.appMessages[
                AppMsg.RESERVATION_MESSAGE.MEETING_CALL_IN_INFO
              ]
            }
          </div>
          <div className={`${cssBase}__onlineMeetingDetails`}>
            {meetingInfo.callInInformation}
          </div>
        </div>
      </>
    );
  }
}

export default withTriDictionary(DisplayMeetingInfo);
