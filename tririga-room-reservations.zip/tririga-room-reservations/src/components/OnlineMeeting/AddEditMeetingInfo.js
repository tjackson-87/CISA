/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import classnames from "classnames";
import defaultTo from "lodash/defaultTo";
import truncate from "lodash/truncate";
import { Checkbox, TextArea, TextInput } from "carbon-components-react";
import { AppMsg } from "../../utils";

const cssBase = "addEditMeetingInfo";

const CALL_IN_INFORMATION_MAX_LENGTH = 1000;
const NAME_MAX_LENGTH = 150;
const URL_MAX_LENGTH = 150;
const PASSWORD_MAX_LENGTH = 150;

class AddEditMeetingInfo extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    meetingInfo: PropTypes.object,
    onChange: PropTypes.func,
  };

  handleStringFieldChange = (e, key, maxLength) => {
    const value = e.target.value;
    this.props.onChange(
      key,
      truncate(value, { length: maxLength, omission: "" })
    );
  };

  render() {
    const { meetingInfo } = this.props;

    return (
      <div className={cssBase}>
        {meetingInfo && (
          <>
            <div
              className={classnames(
                `${cssBase}__defaultCheckbox`,
                "page__section"
              )}
            >
              <Checkbox
                id="defaultMeeting"
                labelText={
                  this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE.SET_DEFAULT_MEETING
                  ]
                }
                onChange={(value) =>
                  this.props.onChange("defaultMeeting", value)
                }
                checked={meetingInfo.defaultMeeting}
              />
            </div>
            <div className={classnames(`${cssBase}__name`, "page__section")}>
              <TextInput
                id="name"
                aria-required="true"
                labelText={
                  this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE.MEETING_NAME
                  ]
                }
                ref={(element) => {
                  this.textInputRef = element;
                }}
                onChange={(e) =>
                  this.handleStringFieldChange(e, "name", NAME_MAX_LENGTH)
                }
                placeholder={
                  this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE.ONLINE_MEETING_ROOM_NAME
                  ]
                }
                type="text"
                value={defaultTo(meetingInfo.name, "")}
                maxLength={NAME_MAX_LENGTH}
              />
            </div>
            <div className={classnames(`${cssBase}__name`, "page__section")}>
              <TextInput
                id="url"
                aria-required="true"
                labelText={
                  this.props.appMessages[AppMsg.RESERVATION_MESSAGE.MEETING_URL]
                }
                ref={(element) => {
                  this.textInputRef = element;
                }}
                onChange={(e) =>
                  this.handleStringFieldChange(e, "url", URL_MAX_LENGTH)
                }
                placeholder={
                  this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE.ONLINE_MEETING_URL_EXAMPLE
                  ]
                }
                type="text"
                value={defaultTo(meetingInfo.url, "")}
                maxLength={URL_MAX_LENGTH}
              />
            </div>
            <div className={classnames(`${cssBase}__name`, "page__section")}>
              <TextInput
                id="password"
                labelText={
                  this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE.MEETING_PASSWORD_OPTIONAL
                  ]
                }
                ref={(element) => {
                  this.textInputRef = element;
                }}
                onChange={(e) =>
                  this.handleStringFieldChange(
                    e,
                    "password",
                    PASSWORD_MAX_LENGTH
                  )
                }
                placeholder={
                  this.props.appMessages[AppMsg.RESERVATION_MESSAGE.NONE]
                }
                type="text"
                value={defaultTo(meetingInfo.password, "")}
                maxLength={PASSWORD_MAX_LENGTH}
              />
            </div>
            <div className={classnames(`${cssBase}__name`, "page__section")}>
              <TextArea
                id="callInInformation"
                className={`${cssBase}__callinInfo`}
                labelText={
                  this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE.MEETING_CALL_IN_INFO_OPTIONAL
                  ]
                }
                ref={(element) => {
                  this.textInputRef = element;
                }}
                onChange={(e) =>
                  this.handleStringFieldChange(
                    e,
                    "callInInformation",
                    CALL_IN_INFORMATION_MAX_LENGTH
                  )
                }
                type="text"
                value={defaultTo(meetingInfo.callInInformation, "")}
                maxLength={CALL_IN_INFORMATION_MAX_LENGTH}
              />
            </div>
          </>
        )}
      </div>
    );
  }
}

export default withTriDictionary(AddEditMeetingInfo);
