/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import defaultTo from "lodash/defaultTo";
import { AppMsg, OnlineMeetingConstants } from "../../utils";
import { Select, SelectItem } from "carbon-components-react";

class OnlineMeetingInput extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    onOnlineMeetingChange: PropTypes.func.isRequired,
    selectedId: PropTypes.string,
    onlineMeetings: PropTypes.array,
  };

  render() {
    const { selectedId, onlineMeetings } = this.props;
    const items = [
      ...onlineMeetings.map((onlineMeeting) => {
        return {
          text: onlineMeeting.defaultMeeting
            ? `${onlineMeeting.name} (${
                this.props.appMessages[AppMsg.RESERVATION_MESSAGE.DEFAULT]
              })`
            : onlineMeeting.name,
          value: onlineMeeting._id,
        };
      }),
      {
        text: AppMsg.getMessage(AppMsg.RESERVATION_MESSAGE.ADD_NEW),
        value: OnlineMeetingConstants.NEW_ONLINE_MEETING_KEY,
      },
      {
        text: AppMsg.getMessage(AppMsg.RESERVATION_MESSAGE.NONE),
        value: OnlineMeetingConstants.NO_SELECTED_MEETING_KEY,
      },
    ];

    return (
      <Select
        autoFocus="true"
        id="onlineMeeting-input"
        value={defaultTo(
          this.getSelectedItem(selectedId, items),
          items[items.length - 1].value
        )}
        onChange={this.handleOnlineMeetingChange}
        labelText={
          this.props.appMessages[
            AppMsg.RESERVATION_MESSAGE.STEP_MEETING_ONLINE_MEETING
          ]
        }
        hideLabel="true"
      >
        {items &&
          items.map((onlineMeeting, index) => {
            return (
              <SelectItem
                key={index}
                text={onlineMeeting.text}
                value={onlineMeeting.value}
              />
            );
          })}
      </Select>
    );
  }

  getSelectedItem(id, items) {
    for (let i = 0; i < items.length; i++) {
      if (items[i].value === id) {
        return items[i].value;
      }
    }
    return null;
  }

  handleOnlineMeetingChange = (e) => {
    this.props.onOnlineMeetingChange(e.target.value);
  };
}

export default withTriDictionary(OnlineMeetingInput);
