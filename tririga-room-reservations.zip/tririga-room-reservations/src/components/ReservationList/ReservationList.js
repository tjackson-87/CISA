/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import debounce from "debounce";
import { groupBy, isEmpty } from "lodash";
import moment from "moment-timezone";
import memo from "memoize-one";
import { Loading } from "carbon-components-react";
import { DefaultValues, MyCalendarUtils } from "../../utils";
import ReservationListSkeleton from "./ReservationListSkeleton";
import ReservationListGroup from "./ReservationListGroup";

const cssBase = "reservationList";

export default class ReservationList extends React.PureComponent {
  static propTypes = {
    className: PropTypes.string,
    date: PropTypes.instanceOf(Date),
    calendarEvents: PropTypes.array,
    timezone: PropTypes.string,
    locale: PropTypes.string,
    loadMore: PropTypes.func,
    loadingEvents: PropTypes.bool,
    loadingMoreEventsBefore: PropTypes.bool,
    loadingMoreEventsAfter: PropTypes.bool,
    onOpenEvent: PropTypes.func,
    onDateChange: PropTypes.func,
    releaseRoom: PropTypes.func,
    checkIn: PropTypes.func,
    releaseRoomEarly: PropTypes.func,
    recheckRoom: PropTypes.func,
    editReservation: PropTypes.func,
    preventTriggerScroll: PropTypes.bool,
    onResetPreventTriggerScroll: PropTypes.func,
    isExchangeIntegrated: PropTypes.bool,
    updateRoomsCanceled: PropTypes.func,
  };

  constructor() {
    super();
    this.prevDate = null;
    this.prevCalendarEvents = null;
  }

  getGroups = memo((calendarEvents, timezone) =>
    Object.entries(
      groupBy(calendarEvents, (event) => {
        const start = moment
          .tz(event.start, timezone)
          .format(DefaultValues.DATE_OBJECT_FORMAT);
        return start;
      })
    )
  );

  render() {
    const {
      className,
      timezone,
      locale,
      calendarEvents,
      loadingEvents,
      loadingMoreEventsBefore,
      loadingMoreEventsAfter,
      onOpenEvent,
      releaseRoom,
      checkIn,
      releaseRoomEarly,
      recheckRoom,
      editReservation,
      isExchangeIntegrated,
      updateRoomsCanceled,
      date,
    } = this.props;
    const groups = this.getGroups(calendarEvents, timezone);
    return (
      <div className={classNames(className, cssBase)}>
        {loadingMoreEventsBefore && (
          <Loading
            small
            className={`${cssBase}__loadingMore`}
            withOverlay={false}
          />
        )}
        <div
          className={`${cssBase}__list`}
          ref={(element) => {
            this.list = element;
          }}
          onScroll={this.handleScroll}
          onWheel={this.handleMove}
          onTouchMove={this.handleMove}
        >
          <div className={`${cssBase}__listContent`}>
            {loadingEvents && <ReservationListSkeleton />}

            {!loadingEvents &&
              !isEmpty(calendarEvents) &&
              groups.map(([group, events]) => (
                <ReservationListGroup
                  key={group}
                  group={group}
                  events={events}
                  timezone={timezone}
                  locale={locale}
                  onOpenEvent={onOpenEvent}
                  releaseRoom={releaseRoom}
                  checkIn={checkIn}
                  releaseRoomEarly={releaseRoomEarly}
                  recheckRoom={recheckRoom}
                  editReservation={editReservation}
                  isExchangeIntegrated={isExchangeIntegrated}
                  updateRoomsCanceled={updateRoomsCanceled}
                  date={date}
                />
              ))}
          </div>
        </div>
        {loadingMoreEventsAfter && (
          <Loading
            small
            className={`${cssBase}__loadingMore`}
            withOverlay={false}
          />
        )}
      </div>
    );
  }

  componentDidMount() {
    this.scrollGroupIfNeeded();
  }

  componentDidUpdate() {
    this.scrollGroupIfNeeded();
  }

  scrollGroupIfNeeded = debounce(() => {
    const {
      date,
      timezone,
      calendarEvents,
      loadingEvents,
      onResetPreventTriggerScroll,
    } = this.props;
    if (
      date != null &&
      this.list != null &&
      !isEmpty(calendarEvents) &&
      !loadingEvents &&
      (this.prevDate === null ||
        this.prevCalendarEvents !== calendarEvents ||
        !moment(date).isSame(this.prevDate, "day"))
    ) {
      const groupElement = this.getGroupElement(this.list, date, timezone);
      const firstGroup = this.getFirstVisibleGroup();
      if (
        groupElement != null &&
        groupElement.getAttribute("data-group") !==
          firstGroup.getAttribute("data-group")
      ) {
        this.prevDate = date;
        this.list.scrollTop =
          this.getGroupOffset(groupElement) +
          MyCalendarUtils.GROUP_HEADER_HEIGHT / 2 +
          1;
      }
      onResetPreventTriggerScroll();
    }
  }, 100);

  getGroupElement(list, date, timezone) {
    const group = moment.tz(date, timezone).format("YYYY-MM-DD");
    return list.querySelector(`div[data-group='${group}']`);
  }

  handleMove = () => {
    this.scrollGroupIfNeeded.clear();
  };

  handleScroll = () => {
    if (!this.props.preventTriggerScroll) {
      this.scrollGroupIfNeeded.clear();
      this.checkIfFirstVisibleGroupChanged();
      this.checkPagination();
    }
  };

  getGroupOffset(group) {
    if (!group) return 0;
    // Since the group header has position equals sticky, all groups before the one on the top has the same offsetTop.
    // The offset of a group is the offset of the next element minus height of the group header.
    // It subtract from the result half of the group header, so that it considers that
    // a group is on the top when it covers more than the half of the of the previous group header.
    return (
      group.nextElementSibling.offsetTop -
      MyCalendarUtils.GROUP_HEADER_HEIGHT -
      MyCalendarUtils.GROUP_HEADER_HEIGHT / 2
    );
  }

  getFirstVisibleGroup() {
    const allGroupElements = this.list.querySelectorAll("[data-group]");
    let first = null;
    for (let i = 0; i < allGroupElements.length && first === null; i++) {
      const group = allGroupElements[i];
      const groupOffset = this.getGroupOffset(group);
      const nextGroupOffset = this.getGroupOffset(allGroupElements[i + 1]);
      if (
        this.list.scrollTop >= groupOffset &&
        this.list.scrollTop < nextGroupOffset
      ) {
        first = group;
      }
    }

    return first;
  }

  checkIfFirstVisibleGroupChanged = debounce(() => {
    if (this.list != null) {
      const first = this.getFirstVisibleGroup();
      if (first != null) {
        const { date, timezone, onDateChange } = this.props;
        const currentDate = moment.tz(date, timezone).format("YYYY-MM-DD");
        const firstDate = first.getAttribute("data-group");
        if (firstDate !== currentDate) {
          onDateChange(moment(firstDate).toDate());
        }
      }
    }
  }, 50);

  checkPagination = debounce(() => {
    const {
      loadingEvents,
      loadingMoreEventsBefore,
      loadingMoreEventsAfter,
      loadMore,
    } = this.props;
    if (
      this.list != null &&
      !loadingEvents &&
      !loadingMoreEventsBefore &&
      !loadingMoreEventsAfter
    ) {
      const scrollTop = this.list.scrollTop;
      const scrollBottom = scrollTop + this.list.offsetHeight;
      const totalHeight = this.list.scrollHeight;
      if (
        totalHeight - scrollBottom <
        MyCalendarUtils.RESERVATION_LIST_PAGINATION_THRESHOLD
      ) {
        loadMore(true);
      } else if (
        scrollTop < MyCalendarUtils.RESERVATION_LIST_PAGINATION_THRESHOLD
      ) {
        loadMore(false);
      }
    }
  }, 50);
}
