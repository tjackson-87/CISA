/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import classNames from "classnames";
import { SkeletonText } from "carbon-components-react";
import PropTypes from "prop-types";

const cssBase = "reservationListSkeleton";

export default class ReservationListSkeleton extends React.PureComponent {
  static propTypes = {
    className: PropTypes.string,
  };

  render() {
    const { className } = this.props;
    return (
      <div className={classNames(className, cssBase)}>
        <div className={`${cssBase}__dateContainer`}>
          <SkeletonText className={`${cssBase}__dateHeader`} />
          {this.renderNoEventsPlaceholderSkeleton()}
        </div>
        <div className={`${cssBase}__dateContainer`}>
          <SkeletonText className={`${cssBase}__dateHeader`} />
          {this.renderReservationListItemSkeleton()}
        </div>
        <div className={`${cssBase}__dateContainer`}>
          <SkeletonText className={`${cssBase}__dateHeader`} />
          {this.renderNoEventsPlaceholderSkeleton()}
          {this.renderReservationListItemSkeleton()}
        </div>
        <div className={`${cssBase}__dateContainer`}>
          <SkeletonText className={`${cssBase}__dateHeader`} />
          {this.renderReservationListItemSkeleton()}
        </div>
        <div className={`${cssBase}__dateContainer`}>
          <SkeletonText className={`${cssBase}__dateHeader`} />
          {this.renderReservationListItemSkeleton()}
          {this.renderReservationListItemSkeleton()}
          {this.renderReservationListItemSkeleton()}
        </div>
        <div className={`${cssBase}__dateContainer`}>
          <SkeletonText className={`${cssBase}__dateHeader`} />
          {this.renderReservationListItemSkeleton()}
        </div>
      </div>
    );
  }

  renderNoEventsPlaceholderSkeleton() {
    return (
      <div className={`${cssBase}__eventContainer`}>
        <SkeletonText
          className={`${cssBase}__noEventsPlaceholder`}
          style={{ width: "100px" }}
        />
      </div>
    );
  }

  renderReservationListItemSkeleton() {
    return (
      <div className={`${cssBase}__eventContainer`}>
        <div className={`${cssBase}__timesContainer`}>
          <SkeletonText
            className={`${cssBase}__startTime`}
            style={{ width: "60px" }}
          />
          <SkeletonText
            className={`${cssBase}__time`}
            style={{ width: "60px" }}
          />
        </div>
        <div className={`${cssBase}__detailsContainer`}>
          <SkeletonText className={`${cssBase}__description`} />
          <SkeletonText
            className={`${cssBase}__rooms`}
            style={{ width: "75%" }}
          />
        </div>
      </div>
    );
  }
}
