/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import classnames from "classnames";
import isEmpty from "lodash/isEmpty";
import isNil from "lodash/isNil";
import moment from "moment-timezone";
import { Tag } from "carbon-components-react";
import {
  Misuse16,
  UserAvatarFilled16,
  CheckmarkOutline16,
  MisuseOutline16,
  Information16,
  UndefinedFilled16,
  UnknownFilled16,
  CheckmarkFilled16,
} from "@carbon/icons-react";
import {
  AppMsg,
  DateTimeConstants,
  isNow,
  isPast,
  ReservableSpacesConstants,
  Status,
  ReservationUtils,
  EventEmitter,
} from "../../utils";
import { Exchange } from "../../model";
import CheckInStatusButtons from "../CheckInStatusButtons/CheckInStatusButtons";
import {
  hasDeclinedRooms,
  hasPendingRooms,
  reservationDetailsLabel,
  roomAndBuildingDetailsLabel,
} from "../../utils/reservation/ReservationUtils";

const cssBase = "reservationListItem";

const { RESERVATION_CLASS_REQUESTABLE } = ReservableSpacesConstants;

class ReservationListItem extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    className: PropTypes.string,
    reservation: PropTypes.object,
    timezone: PropTypes.string,
    locale: PropTypes.string,
    onOpen: PropTypes.func,
    releaseRoom: PropTypes.func,
    checkIn: PropTypes.func,
    releaseRoomEarly: PropTypes.func,
    recheckRoom: PropTypes.func,
    editReservation: PropTypes.func,
    isExchangeIntegrated: PropTypes.bool,
    updateRoomsCanceled: PropTypes.func,
    date: PropTypes.instanceOf(Date),
  };

  state = {
    timerDuration: null,
    statusCheck: null,
    reservationLinkFocus: false,
  };

  constructor(props) {
    super(props);
    this.intervalId = null;
  }

  render() {
    const {
      className,
      reservation,
      timezone,
      onOpen,
      locale,
      releaseRoom,
      checkIn,
      releaseRoomEarly,
      recheckRoom,
      editReservation,
      isExchangeIntegrated,
      updateRoomsCanceled,
      date,
    } = this.props;
    const { timerDuration, statusCheck, reservationLinkFocus } = this.state;
    const classes = classnames(cssBase, className, {
      [`${cssBase}--disabled`]:
        reservation &&
        reservation.responseStatus &&
        reservation.responseStatus === Exchange.ResponseStatus.NOT_RESPONDED,
    });
    return (
      <>
        {reservation &&
          reservation.eventId &&
          this.renderReservation(
            classes,
            reservation,
            timezone,
            onOpen,
            locale,
            releaseRoom,
            checkIn,
            releaseRoomEarly,
            recheckRoom,
            editReservation,
            timerDuration,
            statusCheck,
            isExchangeIntegrated,
            updateRoomsCanceled,
            date,
            reservationLinkFocus
          )}
        {reservation && !reservation.eventId && (
          <div className={`${cssBase}__placeholder`} />
        )}
      </>
    );
  }

  displayMultiDayEventStartDate(eventStart, start) {
    const startDate = moment(eventStart).startOf("day");
    const endDate = moment(start).startOf("day");
    if (startDate.isSame(endDate)) {
      return null;
    } else if (startDate.isBefore(endDate)) {
      return (
        <div className={`${cssBase}__startMonthDay`}>
          {"(" +
            moment
              .tz(startDate, this.props.timezone)
              .locale(this.props.locale)
              .format(DateTimeConstants.TIME_FORMAT_MONTH_AND_DAY) +
            ")"}
        </div>
      );
    }
    return null;
  }

  displayMultiDayEventEndDate(start, end) {
    const startDate = moment(start).startOf("day");
    const endDate = moment(end).startOf("day");
    if (startDate.isSame(endDate)) {
      return null;
    } else if (startDate.isBefore(endDate)) {
      return (
        <div className={`${cssBase}__monthDay`}>
          {"(" +
            moment
              .tz(endDate, this.props.timezone)
              .locale(this.props.locale)
              .format(DateTimeConstants.TIME_FORMAT_MONTH_AND_DAY) +
            ")"}
        </div>
      );
    }
    return null;
  }

  renderReservation(
    classes,
    reservation,
    timezone,
    onOpen,
    locale,
    releaseRoom,
    checkIn,
    releaseRoomEarly,
    recheckRoom,
    editReservation,
    timerDuration,
    statusCheck,
    isExchangeIntegrated,
    updateRoomsCanceled,
    date,
    reservationLinkFocus
  ) {
    if (reservation) {
      if (isNow(reservation.start, reservation.end)) {
        this.setState({
          reservationLinkFocus: true,
        });
      } else {
        this.setState({
          reservationLinkFocus: new Date(reservation.start) >= new Date(date),
        });
      }

      return (
        <div
          className={classes}
          onClick={() =>
            onOpen(
              reservation.eventId,
              !isNil(reservation.multidayEvent)
                ? reservation.eventStart
                : reservation.start,
              reservation.end
            )
          }
        >
          <div className={this.computeIndicatorClassName(reservation)} />
          <div className={`${cssBase}__container`}>
            <div
              className={`${cssBase}__nowAndTimeAndDetailsIndicatorContainer`}
              onKeyUp={(e) =>
                e.key === "Enter"
                  ? onOpen(
                      reservation.eventId,
                      !isNil(reservation.multidayEvent)
                        ? reservation.eventStart
                        : reservation.start,
                      reservation.end
                    )
                  : null
              }
              tabIndex={reservationLinkFocus ? 0 : -1}
              role="link"
              aria-hidden={!reservationLinkFocus}
            >
              {isNow(reservation.start, reservation.end) && (
                <div className={`${cssBase}__now`}>
                  {this.props.appMessages[AppMsg.RESERVATION_MESSAGE.NOW]}
                </div>
              )}
              {reservation.isRoomOnly && isExchangeIntegrated && (
                <Tag
                  className={classnames(`${cssBase}__roomOnlyTag`, {
                    [`${cssBase}__pastText`]: isPast(reservation.end),
                  })}
                  key={reservation.eventId}
                  type="blue"
                  title={
                    this.props.appMessages[AppMsg.RESERVATION_MESSAGE.ROOM_ONLY]
                  }
                >
                  {this.props.appMessages[AppMsg.RESERVATION_MESSAGE.ROOM_ONLY]}
                </Tag>
              )}
              <div
                className={classnames(`${cssBase}__timeAndDetailsContainer`, {
                  [`${cssBase}__pastText`]: isPast(reservation.end),
                })}
              >
                <div className={`${cssBase}__timesContainer`}>
                  {reservation.isAllDay && (
                    <div className={`${cssBase}__start`}>
                      {
                        this.props.appMessages[
                          AppMsg.RESERVATION_MESSAGE.STEP_TIME_ALLDAY
                        ]
                      }
                    </div>
                  )}
                  {!reservation.isAllDay && !isNil(reservation.multidayEvent) && (
                    <div>
                      <div className={`${cssBase}__startMultiDayTime`}>
                        {moment
                          .tz(reservation.eventStart, timezone)
                          .locale(locale)
                          .format(
                            DateTimeConstants.TIME_FORMAT_12H_WITH_PERIOD
                          )}
                      </div>
                      {!!reservation.multidayEvent &&
                        this.displayMultiDayEventStartDate(
                          reservation.eventStart,
                          reservation.start
                        )}
                      <div>
                        {moment
                          .tz(reservation.eventEnd, timezone)
                          .locale(locale)
                          .format(
                            DateTimeConstants.TIME_FORMAT_12H_WITH_PERIOD
                          )}
                      </div>
                      {!!reservation.multidayEvent &&
                        this.displayMultiDayEventEndDate(
                          reservation.start,
                          reservation.end
                        )}
                    </div>
                  )}
                  {!reservation.isAllDay && isNil(reservation.multidayEvent) && (
                    <div
                      aria-label={reservationDetailsLabel(
                        reservation,
                        timezone,
                        locale
                      )}
                    >
                      <div className={`${cssBase}__start`}>
                        {moment
                          .tz(reservation.start, timezone)
                          .locale(locale)
                          .format(
                            DateTimeConstants.TIME_FORMAT_12H_WITH_PERIOD
                          )}
                      </div>
                      <div>
                        {moment
                          .tz(reservation.end, timezone)
                          .locale(locale)
                          .format(
                            DateTimeConstants.TIME_FORMAT_12H_WITH_PERIOD
                          )}
                      </div>
                    </div>
                  )}
                </div>
                <div className={`${cssBase}__detailsContainer`}>
                  <div
                    className={classnames(
                      `${cssBase}__title`,
                      this.computeTitleClassName(
                        reservation.end,
                        reservation.responseStatus,
                        timezone
                      )
                    )}
                  >
                    {reservation.subject}
                  </div>
                  {!isEmpty(reservation.rooms) &&
                    reservation.rooms.map((room, index) => {
                      return (
                        (room.resourceInstanceRecordId ||
                          room.statusENUS === Status.REVIEW_IN_PROGRESS ||
                          room.statusENUS === Status.DECLINED ||
                          room.statusENUS === Status.ACCEPTED) && (
                          <div
                            className={`${cssBase}__location`}
                            key={index}
                            aria-label={roomAndBuildingDetailsLabel(room)}
                          >
                            <span className={`${cssBase}__locationTextWrap`}>
                              <span
                                style={
                                  room.status === Status.CANCELED ||
                                  statusCheck === Status.COMPLETED ||
                                  (reservation.instance &&
                                    reservation.instance.actualEnd &&
                                    isNow(reservation.start, reservation.end))
                                    ? {
                                        textDecoration: "line-through",
                                      }
                                    : {}
                                }
                              >
                                {this.renderRoomAndBuildingName(room)}
                              </span>
                            </span>
                          </div>
                        )
                      );
                    })}
                </div>
                <div className={`${cssBase}__statusContainer`}>
                  <div className={`${cssBase}__reservationStatus`}>
                    {this.renderReservationResponseStatus(reservation)}
                  </div>
                  {!isEmpty(reservation.rooms) &&
                    this.renderEachRoomStatus(reservation)}
                </div>
              </div>
            </div>
            {!hasDeclinedRooms(reservation.rooms) &&
              !hasPendingRooms(reservation.rooms) &&
              reservation.instance &&
              reservation.rooms
                ?.filter((room) => room.statusENUS === Status.ACCEPTED)
                ?.every((room) => !isEmpty(room.resourceInstanceRecordId)) &&
              isNow(
                reservation.instance.checkInReminderDateTime ||
                  reservation.start,
                reservation.end
              ) && (
                <CheckInStatusButtons
                  reservation={reservation}
                  timezone={timezone}
                  releaseRoom={releaseRoom}
                  checkIn={checkIn}
                  releaseRoomEarly={releaseRoomEarly}
                  recheckRoom={recheckRoom}
                  editReservation={editReservation}
                  timerEndDuration={timerDuration}
                  updateRoomsCanceled={updateRoomsCanceled}
                />
              )}
          </div>
        </div>
      );
    }
  }

  componentDidMount() {
    const { reservation } = this.props;
    if (
      reservation.instance &&
      isNow(
        reservation.instance.checkInReminderDateTime || reservation.start,
        reservation.end
      )
    ) {
      this.runTimer(reservation.end);
    }

    setTimeout(() => {
      EventEmitter.dispatch("appMenuFocus", true);
    }, 1000);
  }

  componentDidUpdate() {
    this.reservationInstanceStatusCheck();
  }

  componentWillUnmount() {
    this.clearTimer();
  }

  clearTimer() {
    if (this.intervalId != null) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
  }

  reservationInstanceStatusCheck = () => {
    const { reservation } = this.props;
    if (reservation.instance) {
      const instanceStatusCheck = reservation.instance.statusENUS;
      this.setState({
        statusCheck: instanceStatusCheck,
      });
    }
  };

  runTimer(endTime) {
    this.clearTimer();
    if (endTime != null) {
      this.computeDurationToEnd(endTime);
      this.intervalId = setInterval(
        () => this.computeDurationToEnd(endTime),
        1000
      );
    }
  }

  computeDurationToEnd(endTime) {
    const timerDuration = ReservationUtils.computeTimeDifferenceDuration(
      endTime
    );
    this.setState({
      timerDuration,
    });
    if (timerDuration === 0) {
      this.clearTimer();
    }
  }

  computeIndicatorClassName = (reservation) => {
    if (isPast(reservation.end)) {
      return `${cssBase}__pastIndicator`;
    } else if (isNow(reservation.start, reservation.end)) {
      return `${cssBase}__nowIndicator`;
    } else {
      return `${cssBase}__defaultIndicator`;
    }
  };

  computeTitleClassName = (endTime, responseStatus, timezone) => {
    if (isPast(endTime)) {
      return `${cssBase}__titlePast`;
    } else if (responseStatus === Exchange.ResponseStatus.NOT_RESPONDED) {
      return `${cssBase}__titleNoResponse`;
    }
  };

  renderReservationResponseStatus = (reservation) => {
    if (reservation.isRoomOnly) {
      return (
        <>
          <UserAvatarFilled16
            className={
              isPast(reservation.end)
                ? `${cssBase}__iconPast`
                : `${cssBase}__organizerIcon`
            }
          />
          <span>
            {this.props.appMessages[AppMsg.RESERVATION_MESSAGE.ORGANIZER]}
          </span>
        </>
      );
    }
    switch (reservation.responseStatus) {
      case Exchange.ResponseStatus.ORGANIZER:
        return (
          <>
            <UserAvatarFilled16
              className={
                isPast(reservation.end)
                  ? `${cssBase}__iconPast`
                  : `${cssBase}__organizerIcon`
              }
            />
            <span>
              {this.props.appMessages[AppMsg.RESERVATION_MESSAGE.ORGANIZER]}
            </span>
          </>
        );
      case Exchange.ResponseStatus.NOT_RESPONDED:
        return (
          <>
            <UndefinedFilled16
              className={
                isPast(reservation.end)
                  ? `${cssBase}__iconPast`
                  : `${cssBase}__noReplyColor`
              }
            />
            <span>
              {this.props.appMessages[AppMsg.RESERVATION_MESSAGE.NO_REPLY]}
            </span>
          </>
        );
      case Exchange.ResponseStatus.TENTATIVELY_ACCEPTED:
        return (
          <>
            <UnknownFilled16
              className={
                isPast(reservation.end)
                  ? `${cssBase}__iconPast`
                  : `${cssBase}__reviewInProgressIcon`
              }
            />
            <span>
              {this.props.appMessages[AppMsg.RESERVATION_MESSAGE.TENTATIVE]}
            </span>
          </>
        );
      case Exchange.ResponseStatus.ACCEPTED:
        return (
          <>
            <CheckmarkFilled16
              className={
                isPast(reservation.end)
                  ? `${cssBase}__iconPast`
                  : `${cssBase}__approvedIcon`
              }
            />
            <span>
              {this.props.appMessages[AppMsg.RESERVATION_MESSAGE.ACCEPTED]}
            </span>
          </>
        );
      case Exchange.ResponseStatus.DECLINED:
        return (
          <>
            <Misuse16
              className={
                isPast(reservation.end)
                  ? `${cssBase}__iconPast`
                  : `${cssBase}__organizerIcon`
              }
            />
            <span>
              {this.props.appMessages[AppMsg.RESERVATION_MESSAGE.DECLINED]}
            </span>
          </>
        );
      default:
        return null;
    }
  };

  renderEachRoomStatus = (reservation) => {
    return reservation.rooms.map((room, index) => {
      switch (room.statusENUS) {
        case Status.ACCEPTED:
          return room.reservationClassNameENUS ===
            RESERVATION_CLASS_REQUESTABLE ? (
            <div key={index} className={`${cssBase}__reservationStatus`}>
              <CheckmarkOutline16
                className={
                  isPast(reservation.end)
                    ? `${cssBase}__iconPast`
                    : `${cssBase}__approvedIcon`
                }
              />
              <span>
                {
                  this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE.ROOM_APPROVED
                  ]
                }
              </span>
            </div>
          ) : (
            <div key={index} className={`${cssBase}__reservationStatusEmpty`} />
          );
        case Status.DECLINED:
          return (
            <div key={index} className={`${cssBase}__reservationStatus`}>
              <MisuseOutline16
                className={
                  isPast(reservation.end)
                    ? `${cssBase}__iconPast`
                    : `${cssBase}__declinedIcon`
                }
              />
              <span>
                {
                  this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE.ROOM_DECLINED
                  ]
                }
              </span>
            </div>
          );
        case Status.REVIEW_IN_PROGRESS:
          return room.reservationClassNameENUS ===
            RESERVATION_CLASS_REQUESTABLE ? (
            <div key={index} className={`${cssBase}__reservationStatus`}>
              <Information16
                className={
                  isPast(reservation.end)
                    ? `${cssBase}__iconPast`
                    : `${cssBase}__reviewInProgressIcon`
                }
              />
              <span>
                {
                  this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE.ROOM_PENDING
                  ]
                }
              </span>
            </div>
          ) : (
            <div key={index} className={`${cssBase}__reservationStatusEmpty`} />
          );
        default:
          return null;
      }
    });
  };

  renderRoomAndBuildingName(room) {
    const roomAndBuildingNames = [];
    if (room.name) roomAndBuildingNames.push(room.name);
    if (room.building) roomAndBuildingNames.push(room.building);
    return roomAndBuildingNames.join(", ");
  }
}

export default withTriDictionary(ReservationListItem);
