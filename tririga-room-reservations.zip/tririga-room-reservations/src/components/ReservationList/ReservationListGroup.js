/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2022 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import PropTypes from "prop-types";
import moment from "moment-timezone";
import { MyCalendarUtils } from "../../utils";
import ReservationListItem from "./ReservationListItem";

const cssBase = "reservationListGroup";

export default class ReservationListGroup extends React.PureComponent {
  static propTypes = {
    group: PropTypes.string,
    events: PropTypes.array,
    timezone: PropTypes.string,
    locale: PropTypes.string,
    onOpenEvent: PropTypes.func,
    releaseRoom: PropTypes.func,
    checkIn: PropTypes.func,
    releaseRoomEarly: PropTypes.func,
    recheckRoom: PropTypes.func,
    editReservation: PropTypes.func,
    isExchangeIntegrated: PropTypes.bool,
    updateRoomsCanceled: PropTypes.func,
    date: PropTypes.instanceOf(Date),
  };

  state = {
    isEventOnBeforeDate: false,
  };

  componentDidMount() {
    const { group, date } = this.props;
    const check = moment(group).isSameOrAfter(date);
    if (check) this.setState({ isEventOnBeforeDate: true });
  }

  render() {
    const {
      group,
      events,
      timezone,
      locale,
      onOpenEvent,
      releaseRoom,
      checkIn,
      releaseRoomEarly,
      recheckRoom,
      editReservation,
      isExchangeIntegrated,
      updateRoomsCanceled,
      date,
    } = this.props;
    return (
      <>
        <div
          className={`${cssBase}__header`}
          data-group={group}
          aria-hidden={!this.state.isEventOnBeforeDate}
          tabIndex={this.state.isEventOnBeforeDate ? 0 : -1}
        >
          {moment
            .tz(group, timezone)
            .locale(locale)
            .format(MyCalendarUtils.RESERVATION_LIST_DATE_HEADER_FORMAT)}
        </div>
        {events.map((evt, index) => (
          <ReservationListItem
            key={evt.eventId != null ? evt.eventId : `${group}-${index}`}
            reservation={evt}
            timezone={timezone}
            locale={locale}
            onOpen={onOpenEvent}
            releaseRoom={releaseRoom}
            checkIn={checkIn}
            releaseRoomEarly={releaseRoomEarly}
            recheckRoom={recheckRoom}
            editReservation={editReservation}
            isExchangeIntegrated={isExchangeIntegrated}
            updateRoomsCanceled={updateRoomsCanceled}
            date={date}
          />
        ))}
      </>
    );
  }
}
