/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import classNames from "classnames";
import { DateInput } from "..";
import { Button } from "carbon-components-react";
import { ChevronLeft32, ChevronRight32 } from "@carbon/icons-react";
import { AppMsg, addDay } from "../../utils";

const cssBase = "availabilityDate";

class AvailabilityDate extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    selectedDate: PropTypes.object,
    dir: PropTypes.string,
    onSelectedDateChange: PropTypes.func,
    className: PropTypes.string,
    carbonDateFormat: PropTypes.string,
    dateFormat: PropTypes.string,
    carbonLocale: PropTypes.string,
  };

  render() {
    const {
      selectedDate,
      dir,
      onSelectedDateChange,
      className,
      carbonDateFormat,
      dateFormat,
      carbonLocale,
    } = this.props;
    return (
      <div className={classNames(cssBase, className)}>
        <DateInput
          id="availabilityDateInput"
          className={`${cssBase}__dateInput`}
          carbonDateFormat={carbonDateFormat}
          dateFormat={dateFormat}
          carbonLocale={carbonLocale}
          onValueChange={onSelectedDateChange}
          label=""
          value={selectedDate}
        />
        <div className={`${cssBase}__buttons`}>
          <Button
            className={`${cssBase}__prevDayButton`}
            kind="ghost"
            hasIconOnly
            renderIcon={dir === "ltr" ? ChevronLeft32 : ChevronRight32}
            tooltipAlignment={dir === "ltr" ? "end" : "start"}
            tooltipPosition="bottom"
            iconDescription={this.props.appMessages[AppMsg.BUTTON.PREVIOUS]}
            onClick={this.handlePrevDay}
          />
          <Button
            className={`${cssBase}__nextDayButton`}
            kind="ghost"
            hasIconOnly
            renderIcon={dir === "ltr" ? ChevronRight32 : ChevronLeft32}
            tooltipAlignment={dir === "ltr" ? "end" : "start"}
            tooltipPosition="bottom"
            iconDescription={this.props.appMessages[AppMsg.BUTTON.NEXT]}
            onClick={this.handleNextDay}
          />
        </div>
      </div>
    );
  }

  handlePrevDay = () => {
    this.props.onSelectedDateChange(addDay(this.props.selectedDate, -1));
  };

  handleNextDay = () => {
    this.props.onSelectedDateChange(addDay(this.props.selectedDate, 1));
  };
}

export default withTriDictionary(AvailabilityDate);
