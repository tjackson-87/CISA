/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import PropTypes from "prop-types";
import moment from "moment-timezone";
import classNames from "classnames";
import { ORGANIZATION_USER } from "../../model/exchange/ExchangePeople";
import {
  AVAILABILITY_COL_WIDTH,
  AVAILABILITY_NUM_HOURS,
  MINS_IN_HOUR,
} from "./AvailabilityUtils";
import { TYPE } from "./Availability";

const cssBase = "availabilityItemRow";
const EVENT_STATUS_FREE = "free";
export default class AvailabilityItemRow extends React.PureComponent {
  static propTypes = {
    dir: PropTypes.string,
    className: PropTypes.string,
    item: PropTypes.object,
    rowIdx: PropTypes.number,
    listSize: PropTypes.number,
    selectedDate: PropTypes.object,
    timezone: PropTypes.string,
    type: PropTypes.string,
  };

  render() {
    const { item, className, rowIdx, listSize, type } = this.props;
    return (
      <div
        className={classNames(cssBase, className, {
          [`${cssBase}--last`]: rowIdx === listSize - 1,
          [`${cssBase}--nonExchange`]:
            type === TYPE.PERSON && item.type !== ORGANIZATION_USER,
        })}
      >
        {new Array(AVAILABILITY_NUM_HOURS).fill(0).map((slot, idx) => (
          <div
            key={idx}
            className={`${cssBase}__timeSlot`}
            style={this.computeSlotStyle(idx)}
          />
        ))}
        {item?.scheduleItems
          ?.filter((event) => event.status !== EVENT_STATUS_FREE)
          .map((event, index) => (
            <div
              key={`${index}-${event.subject}-${event.start}-${event.end}`}
              className={`${cssBase}__busyTime`}
              style={this.computeBusySlotStyle(event)}
            />
          ))}
      </div>
    );
  }

  computeSlotStyle = (i) => {
    return { gridColumn: `${i + 1} / ${i + 2}` };
  };

  computeBusySlotStyle = (event) => {
    const { dir, selectedDate, timezone } = this.props;

    const { start, end } = event;
    const startDateTimeMoment = moment.tz(start, timezone);
    const endDateTimeMoment = moment.tz(end, timezone);
    const selectedDateMoment = moment.tz(selectedDate, timezone).startOf("day");

    if (
      !timezone ||
      selectedDateMoment.isBefore(startDateTimeMoment, "day") ||
      selectedDateMoment.isAfter(endDateTimeMoment, "day")
    )
      return { display: "none" };

    let durationHours;
    let width = 0;
    let endHour = 0;
    let startHour = 0;
    let startOffset = 0;
    if (selectedDateMoment.isSame(startDateTimeMoment, "day")) {
      durationHours = moment
        .duration(endDateTimeMoment.diff(startDateTimeMoment))
        .asHours();

      startHour = parseInt(startDateTimeMoment.format("HH"));
      startOffset =
        (AVAILABILITY_COL_WIDTH * startDateTimeMoment.format("mm")) /
        MINS_IN_HOUR;
    } else if (selectedDateMoment.isAfter(startDateTimeMoment, "day")) {
      durationHours = moment
        .duration(endDateTimeMoment.diff(selectedDateMoment))
        .asHours();
    }

    if (durationHours + startHour >= AVAILABILITY_NUM_HOURS) {
      width = (AVAILABILITY_NUM_HOURS - startHour) * AVAILABILITY_COL_WIDTH;
      endHour = AVAILABILITY_NUM_HOURS + 1;
    } else {
      width = durationHours * AVAILABILITY_COL_WIDTH;
      endHour = parseInt(endDateTimeMoment.format("HH"));
      if (endHour === startHour) endHour++;
    }

    return {
      gridColumn: `${startHour + 1} / ${endHour + 1}`,
      width: `${width}px`,
      left: dir === "ltr" ? `${startOffset}px` : "0px",
      right: dir === "rtl" ? `${startOffset}px` : "0px",
    };
  };
}
