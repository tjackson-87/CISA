/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import Hammer from "hammerjs";
import printf from "printf";
import throttle from "lodash/throttle";
import isEmpty from "lodash/isEmpty";
import classnames from "classnames";
import defaultTo from "lodash/defaultTo";
import moment from "moment";
import {
  ArrowUp16,
  ArrowDown16,
  ArrowLeft16,
  ArrowRight16,
} from "@carbon/icons-react";
import { Button, Tooltip } from "carbon-components-react";
import PropTypes from "prop-types";
import AvailabilityItemRow from "./AvailabilityItemRow";
import { AppMsg, getMomentFrom, DefaultValues, Status } from "../../utils";
import AvailabilityItemName from "./AvailabilityItemName";
import TimeSelector from "./TimeSelector";
import {
  AVAILABILITY_COL_WIDTH,
  AVAILABILITY_ROW_HEIGHT,
} from "./AvailabilityUtils";

const cssBase = "availability";

const DIRECTIONS = {
  PANRIGHT: "panright",
  PANLEFT: "panleft",
  PANUP: "panup",
  PANDOWN: "pandown",
};

export const TYPE = {
  ROOM: "room",
  PERSON: "person",
};

const hourList = [];

for (let i = 0; i < 24; i++) {
  hourList.push(`${printf("%02d", ((i + 11) % 12) + 1)}`);
}

class Availability extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    dateAndTime: PropTypes.object,
    onDateAndTimeChange: PropTypes.func,
    dir: PropTypes.string,
    attendees: PropTypes.array,
    rooms: PropTypes.array,
    className: PropTypes.string,
    exchangeAttendees: PropTypes.array,
    exchangeAttendeesAvailable: PropTypes.number,
    resourcesAvailable: PropTypes.number,
  };

  state = {
    availabilityPanelButtonHeight: "0",
    availabilityPanelButtonTop: "0",
    availabilityPanelButtonsDisplay: false,
    availabilityPanelLeftButton: true,
    availabilityPanelRightButton: true,
    availabilityPanelUpButton: true,
    availabilityPanelDownButton: true,
  };

  constructor(props) {
    super(props);
    this.hammer = null;
    const userLocaleData = moment.localeData(
      defaultTo(props.dateAndTime.locale, DefaultValues.LOCALE)
    );
    this.amLabel = userLocaleData.meridiem(1, 0);
    this.pmLabel = userLocaleData.meridiem(13, 0);
  }

  createHammerManager(el) {
    this.hammer = new Hammer.Manager(el, {
      recognizers: [[Hammer.Pan, { threshold: 0 }]],
    });

    this.hammer.on("panstart", this.onPanStart.bind(this));
    this.hammer.on("panmove", this.onPanMove.bind(this));
    this.hammer.on("panend", this.onPanEnd.bind(this));
  }

  componentDidMount() {
    this.createHammerManager(this.availabilityPanel);
    this.createHammerManager(this.timesHeader);
    this.scrollToTime();
    this.availabilityPanelButton();
  }

  componentDidUpdate(prevProps) {
    if (prevProps.dateAndTime?.startDate == null) {
      this.scrollToTime();
    }
  }

  componentWillUnmount() {
    if (this.hammer != null) {
      this.hammer.destroy();
    }
  }

  render() {
    const {
      className,
      dateAndTime,
      onDateAndTimeChange,
      dir,
      attendees,
      rooms,
      exchangeAttendees,
      exchangeAttendeesAvailable,
      resourcesAvailable,
    } = this.props;
    const {
      availabilityPanelButtonsDisplay,
      availabilityPanelButtonHeight,
      availabilityPanelButtonTop,
      availabilityPanelLeftButton,
      availabilityPanelRightButton,
      availabilityPanelUpButton,
      availabilityPanelDownButton,
    } = this.state;
    const { startDate, timezone } = dateAndTime;
    const availablityStyle = { height: `${availabilityPanelButtonHeight}px` };
    availablityStyle.top = `${availabilityPanelButtonTop}px`;
    return (
      <div className={classnames(cssBase, className)}>
        <div className={`${cssBase}__header`}>
          <Tooltip
            direction={dir === "rtl" ? "left" : "right"}
            className={`${cssBase}__headerTooltip`}
            triggerClassName={`${cssBase}__tooltipTrigger`}
            triggerText={
              <div
                className={classnames(
                  `${cssBase}__namesHeaderTop`,
                  `${cssBase}__namesHeader`,
                  `${cssBase}__tooltipTriggerContent`
                )}
              >
                {this.computeDisplayLables(attendees)}
              </div>
            }
            showIcon={false}
          >
            {this.computeDisplayLables(attendees)}
          </Tooltip>
          <div
            ref={(el) => (this.timesHeader = el)}
            className={classnames(
              `${cssBase}__timesHeader`,
              `${cssBase}__availabilitySlotsHeader`
            )}
            onScroll={this.handleTimesHeaderScroll}
          >
            {hourList.map((item, idx) => (
              <div className={`${cssBase}__time`} key={idx}>
                {item}
                {idx < 12 ? this.amLabel : this.pmLabel}
              </div>
            ))}
          </div>
        </div>
        <div
          ref={(el) => (this.content = el)}
          className={`${cssBase}__content`}
          onScroll={this.handleContentScroll}
          onMouseEnter={this.handleContentMouseEnter}
          onMouseLeave={this.handleContentMouseLeave}
          onWheel={() => {
            this.content.click();
          }}
        >
          <div className={`${cssBase}__namesPanel`}>
            {!isEmpty(attendees) && (
              <>
                {attendees.map((item, rowIdx, arr) => (
                  <AvailabilityItemName
                    className={`${cssBase}__listItemName`}
                    item={item}
                    rowIdx={rowIdx}
                    listSize={arr.length}
                    key={item.email || item.name}
                    type={TYPE.PERSON}
                    tooltipDir={dir === "rtl" ? "left" : "right"}
                  />
                ))}
              </>
            )}
            {!isEmpty(rooms) && (
              <>
                {!isEmpty(attendees) && (
                  <div className={`${cssBase}__namesHeader`}>
                    {
                      this.props.appMessages[
                        AppMsg.RESERVATION_MESSAGE.STEP_TIME_AVAILABILITY_ROOMS
                      ]
                    }
                  </div>
                )}
                {rooms.map(
                  (item, rowIdx, arr) =>
                    item.data.statusENUS !== Status.CANCELED && (
                      <AvailabilityItemName
                        className={`${cssBase}__listItemName`}
                        item={item}
                        rowIdx={rowIdx}
                        listSize={arr.length}
                        key={item.data.roomId}
                        type={TYPE.ROOM}
                        tooltipDir={dir === "rtl" ? "left" : "right"}
                      />
                    )
                )}
              </>
            )}
          </div>
          {availabilityPanelButtonsDisplay && (
            <div
              className={`${cssBase}__availabilityPanelButtons`}
              style={availablityStyle}
            >
              {availabilityPanelUpButton && (
                <Button
                  className={classnames(
                    `${cssBase}__scrollButton`,
                    `${cssBase}__scrollUpButton`
                  )}
                  kind="ghost"
                  hasIconOnly
                  renderIcon={ArrowUp16}
                  tooltipAlignment="center"
                  tooltipPosition="bottom"
                  iconDescription={
                    this.props.appMessages[AppMsg.BUTTON.SCROLL_UP]
                  }
                  onClick={this.handleScrollUp}
                />
              )}
              {availabilityPanelDownButton && (
                <Button
                  className={classnames(
                    `${cssBase}__scrollButton`,
                    `${cssBase}__scrollDownButton`
                  )}
                  kind="ghost"
                  hasIconOnly
                  renderIcon={ArrowDown16}
                  tooltipAlignment="center"
                  tooltipPosition="top"
                  iconDescription={
                    this.props.appMessages[AppMsg.BUTTON.SCROLL_DOWN]
                  }
                  onClick={this.handleScrollDown}
                />
              )}
              {availabilityPanelLeftButton && (
                <Button
                  className={classnames(
                    `${cssBase}__scrollButton`,
                    `${cssBase}__scrollLeftButton`
                  )}
                  kind="ghost"
                  hasIconOnly
                  renderIcon={ArrowLeft16}
                  tooltipAlignment="center"
                  tooltipPosition={dir === "ltr" ? "right" : "left"}
                  iconDescription={
                    this.props.appMessages[AppMsg.BUTTON.SCROLL_LEFT]
                  }
                  onClick={this.handleScrollLeft}
                />
              )}
              {availabilityPanelRightButton && (
                <Button
                  className={classnames(
                    `${cssBase}__scrollButton`,
                    `${cssBase}__scrollRightButton`
                  )}
                  kind="ghost"
                  hasIconOnly
                  renderIcon={ArrowRight16}
                  tooltipAlignment="center"
                  tooltipPosition={dir === "ltr" ? "left" : "right"}
                  iconDescription={
                    this.props.appMessages[AppMsg.BUTTON.SCROLL_RIGHT]
                  }
                  onClick={this.handleScrollRight}
                />
              )}
            </div>
          )}
          <div
            ref={(el) => (this.availabilityPanel = el)}
            className={`${cssBase}__availabilityPanel`}
            onScroll={this.handleAvailabilityPanelScroll}
          >
            {!isEmpty(attendees) && (
              <>
                {attendees.map((item, rowIdx, arr) => (
                  <AvailabilityItemRow
                    dir={dir}
                    key={item.email}
                    item={item}
                    rowIdx={rowIdx}
                    listSize={arr.length}
                    selectedDate={startDate}
                    timezone={timezone}
                    type={TYPE.PERSON}
                  />
                ))}
              </>
            )}
            {!isEmpty(rooms) && (
              <>
                {!isEmpty(attendees) && (
                  <div className={`${cssBase}__availabilitySlotsHeader`} />
                )}
                {rooms.map(
                  (item, rowIdx, arr) =>
                    item.data.statusENUS !== Status.CANCELED && (
                      <AvailabilityItemRow
                        dir={dir}
                        key={item.data.roomId}
                        item={item}
                        rowIdx={rowIdx}
                        listSize={arr.length}
                        selectedDate={startDate}
                        timezone={timezone}
                        type={TYPE.ROOM}
                      />
                    )
                )}
              </>
            )}
          </div>
        </div>

        <TimeSelector
          onWheel={this.handleTimeSelectorWheel}
          dir={dir}
          ref={(el) => (this.timeSelector = el)}
          dateAndTime={dateAndTime}
          onChange={onDateAndTimeChange}
          onFitIntoView={this.handleFitTimeSelectorIntoView}
          onAvailabilityPanelButtonsDisplay={
            this.handleAvailabilityPanelButtonsDisplay
          }
          allAvailable={this.computeAllAvailable(
            exchangeAttendees,
            exchangeAttendeesAvailable,
            rooms,
            resourcesAvailable
          )}
        />
      </div>
    );
  }

  handleAvailabilityPanelButtonsDisplay = (display) => {
    if (
      this.content.clientHeight < this.availabilityPanel.scrollHeight ||
      this.availabilityPanel.children[0].offsetWidth >
        this.availabilityPanel.scrollLeft
    ) {
      this.setState({
        availabilityPanelButtonsDisplay: display,
      });
    }
  };

  handleContentMouseEnter = () => {
    this.handleAvailabilityPanelButtonsDisplay(true);
  };

  handleContentMouseLeave = () => {
    this.handleAvailabilityPanelButtonsDisplay(false);
  };

  handleContentScroll = () => {
    this.availabilityPanelButton(this.content.scrollTop);
  };

  availabilityPanelButton = (top = 0) => {
    this.setState({
      availabilityPanelButtonHeight: this.content.clientHeight,
      availabilityPanelButtonTop: top,
    });
    this.hideArrowUpOrDown(this.content.scrollTop);
    if (this.availabilityPanel.children[0]) {
      this.hideArrowLeftOrRight(this.availabilityPanel.scrollLeft);
    }
  };

  handleScrollUpOrDown = (scrollTop) => {
    window.requestAnimationFrame(() => {
      this.content.scrollTop = scrollTop;
      this.setState({
        availabilityPanelButtonTop: this.content.scrollTop,
      });
      this.hideArrowUpOrDown(this.content.scrollTop);
    });
  };

  handleScrollDown = () => {
    const scrollTop = this.content.scrollTop + AVAILABILITY_ROW_HEIGHT;
    this.handleScrollUpOrDown(scrollTop);
  };

  handleScrollUp = () => {
    const scrollTop = this.content.scrollTop - AVAILABILITY_ROW_HEIGHT;
    this.handleScrollUpOrDown(scrollTop);
  };

  handleScrollLeftOrRight = (scrollLeft) => {
    window.requestAnimationFrame(() => {
      this.timesHeader.scrollLeft = scrollLeft;
      this.availabilityPanel.scrollLeft = scrollLeft;
    });
    this.hideArrowLeftOrRight(scrollLeft);
  };

  handleScrollLeft = () => {
    const scrollLeft =
      this.availabilityPanel.scrollLeft - AVAILABILITY_COL_WIDTH;
    this.handleScrollLeftOrRight(scrollLeft);
  };

  handleScrollRight = () => {
    const scrollLeft =
      this.availabilityPanel.scrollLeft + AVAILABILITY_COL_WIDTH;
    this.handleScrollLeftOrRight(scrollLeft);
  };

  hideArrowUpOrDown = (scrollTop) => {
    if (scrollTop <= 0) {
      this.setState({ availabilityPanelUpButton: false });
    } else {
      this.setState({ availabilityPanelUpButton: true });
    }
    if (scrollTop >= this.content.scrollHeight - this.content.clientHeight) {
      this.setState({ availabilityPanelDownButton: false });
    } else {
      this.setState({ availabilityPanelDownButton: true });
    }
  };

  hideArrowLeftOrRight = (scrollLeft) => {
    if (scrollLeft <= 0) {
      this.setState({ availabilityPanelLeftButton: false });
    } else {
      this.setState({ availabilityPanelLeftButton: true });
    }
    if (
      this.availabilityPanel.children[0].offsetWidth -
        this.availabilityPanel.offsetWidth <=
      scrollLeft
    ) {
      this.setState({ availabilityPanelRightButton: false });
    } else {
      this.setState({ availabilityPanelRightButton: true });
    }
  };

  handleAvailabilityPanelScroll = () => {
    window.requestAnimationFrame(() => {
      this.timesHeader.scrollLeft = this.availabilityPanel.scrollLeft;
      this.timeSelector.setScrollLeft(this.availabilityPanel.scrollLeft);
    });
  };

  handleTimesHeaderScroll = () => {
    window.requestAnimationFrame(() => {
      this.availabilityPanel.scrollLeft = this.timesHeader.scrollLeft;
    });
  };

  onPanStart = (e) => {
    this.panStart = {
      scrollLeftStart: this.availabilityPanel.scrollLeft,
      scrollTopStart: this.content.scrollTop,
      direction: e.additionalEvent,
    };
    this.panMoveThrottler = throttle(this.doPanMove, 10);
  };

  onPanMove = (e) => {
    if (this.panMoveThrottler && this.panStart) {
      this.panMoveThrottler(e, this.panStart);
    }
  };

  doPanMove = (e, panStart) => {
    const { scrollLeftStart, scrollTopStart, direction } = panStart;
    const { deltaX, deltaY } = e;
    const { dir } = this.props;
    if (direction === DIRECTIONS.PANLEFT || direction === DIRECTIONS.PANRIGHT) {
      const newScrollLeft =
        dir === "ltr" ? scrollLeftStart - deltaX : scrollLeftStart + deltaX;
      window.requestAnimationFrame(() => {
        this.timesHeader.scrollLeft = newScrollLeft;
        this.availabilityPanel.scrollLeft = newScrollLeft;
      });
      this.hideArrowLeftOrRight(newScrollLeft);
    } else if (
      direction === DIRECTIONS.PANUP ||
      direction === DIRECTIONS.PANDOWN
    ) {
      window.requestAnimationFrame(() => {
        this.content.scrollTop = scrollTopStart - deltaY;
        this.availabilityPanelButton(this.content.scrollTop);
      });
      this.hideArrowUpOrDown(this.content.scrollTop);
    }
  };

  onPanEnd = () => {
    this.panStart = null;
    this.panMoveThrottler = null;
  };

  handleTimeSelectorWheel = (e) => {
    e.preventDefault();
    if (Math.abs(e.deltaY) > Math.abs(e.deltaX)) {
      window.requestAnimationFrame(() => {
        this.content.scrollTop += e.deltaY;
      });
    } else {
      window.requestAnimationFrame(() => {
        this.availabilityPanel.scrollLeft += e.deltaX;
      });
    }
  };

  handleFitTimeSelectorIntoView = (scrollLeft) => {
    this.availabilityPanel.scrollLeft = scrollLeft;
  };

  scrollToTime = () => {
    const {
      dateAndTime: { startDate, startTime, startTimePeriod, timezone },
      dir,
    } = this.props;
    if (!startDate || !startTime || !startTimePeriod || !timezone || !dir)
      return;
    const startDateTime = getMomentFrom(
      startDate,
      startTime,
      startTimePeriod,
      timezone
    );
    const startHour = Math.max(parseInt(startDateTime.format("HH")) - 1, 0);
    const offset = startHour * AVAILABILITY_COL_WIDTH;
    this.availabilityPanel.scrollLeft = dir === "ltr" ? offset : -1 * offset;
  };

  computeDisplayLables = (attendees) => {
    if (!isEmpty(attendees)) {
      return AppMsg.getMessage(
        AppMsg.RESERVATION_MESSAGE.STEP_MEETING_ATTENDEES
      );
    } else {
      return AppMsg.getMessage(
        AppMsg.RESERVATION_MESSAGE.STEP_TIME_AVAILABILITY_ROOMS
      );
    }
  };

  computeAllAvailable = (
    exchangeAttendees,
    exchangeAttendeesAvailable,
    rooms,
    resourcesAvailable
  ) => {
    const attendeesAvail = !isEmpty(exchangeAttendees)
      ? exchangeAttendeesAvailable / exchangeAttendees.length === 1
      : true;

    const resourcesAvail = !isEmpty(rooms)
      ? resourcesAvailable / rooms.length === 1
      : true;

    return attendeesAvail && resourcesAvail;
  };
}

export default withTriDictionary(Availability);
