/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import memo from "memoize-one";
import moment from "moment-timezone";
import Hammer from "hammerjs";
import { DateTimeConstants } from "../../utils";
import styles from "../../app/TririgaRoomReservationApp.scss";

export const MINS_IN_HOUR = 60;
export const AVAILABILITY_COL_WIDTH = parseInt(
  styles["availability-col-width"].replace("px", "")
);
export const AVAILABILITY_NUM_HOURS = parseInt(
  styles["availability-num-hours"]
);
export const AVAILABILITY_ROW_HEIGHT = parseInt(
  styles["availability-row-height"].replace("px", "")
);
export const MAX_WIDTH = AVAILABILITY_COL_WIDTH * AVAILABILITY_NUM_HOURS;
export const MINUTE_WIDTH = AVAILABILITY_COL_WIDTH / MINS_IN_HOUR;
export const FIT_INTO_VIEW_THRESHOLD = AVAILABILITY_COL_WIDTH / 4;

export const convertStartEndTimeToPixelPosition = memo(
  (startTime, startTimePeriod, endTime, endTimePeriod) => {
    const startMoment = moment(
      `${startTime} ${startTimePeriod}`,
      DateTimeConstants.TIME_FORMAT_12H_WITH_PERIOD
    );
    const endMoment = moment(
      `${endTime} ${endTimePeriod}`,
      DateTimeConstants.TIME_FORMAT_12H_WITH_PERIOD
    );
    if (endMoment.hours() === 0 && endMoment.minutes() === 0) {
      endMoment.add(1, "days");
    }
    const startInMinutes = startMoment.hour() * 60 + startMoment.minute();
    const durationInMinutes = moment
      .duration(endMoment.diff(startMoment))
      .asMinutes();
    const start = Math.trunc(MINUTE_WIDTH * startInMinutes);
    const width = Math.trunc(MINUTE_WIDTH * durationInMinutes);
    const end = start + width;
    return {
      start,
      end,
      width,
    };
  }
);

function convertPixelToMoment(value, direction) {
  const duration = moment.duration(Math.trunc(value / MINUTE_WIDTH), "minutes");
  let roundTo15 = duration.minutes();
  let hourTime = duration.hours();
  if (direction === Hammer.DIRECTION_LEFT) {
    roundTo15 = Math.floor(duration.minutes() / 15) * 15;
  } else {
    roundTo15 = Math.ceil(duration.minutes() / 15) * 15;
    if (roundTo15 === 60) {
      roundTo15 = 0;
      hourTime = hourTime + 1;
    }
  }

  return moment(`${hourTime}:${roundTo15}`, DateTimeConstants.TIME_FORMAT_24H);
}

export const convertPixelPositionToStartEndTime = memo(
  (left, right, direction) => {
    const startMoment = convertPixelToMoment(left, direction);
    const endMoment = convertPixelToMoment(right, direction);
    return {
      startTime: startMoment.format(DateTimeConstants.TIME_FORMAT),
      startTimePeriod: startMoment.format(DateTimeConstants.AM_PM_FORMAT),
      endTime: endMoment.format(DateTimeConstants.TIME_FORMAT),
      endTimePeriod: endMoment.format(DateTimeConstants.AM_PM_FORMAT),
    };
  }
);

export function adjustToNearestInterval(value, delta) {
  let adjustedValue = value + delta;
  const remainder = adjustedValue % DateTimeConstants.MINUTE_INTERVAL;
  if (remainder !== 0) {
    if (adjustedValue > 0) {
      adjustedValue =
        delta < 0
          ? adjustedValue - remainder
          : adjustedValue + DateTimeConstants.MINUTE_INTERVAL - remainder;
    } else {
      adjustedValue =
        delta < 0
          ? adjustedValue - DateTimeConstants.MINUTE_INTERVAL - remainder
          : adjustedValue - remainder;
    }
  }
  return adjustedValue;
}
