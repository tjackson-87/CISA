/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import isEmpty from "lodash/isEmpty";
import { Tooltip } from "carbon-components-react";
import { TYPE } from "./Availability";
import { ORGANIZATION_USER } from "../../model/exchange/ExchangePeople";

const cssBase = "availabilityItemName";

export default class AvailabilityItemName extends React.Component {
  static propTypes = {
    className: PropTypes.string,
    item: PropTypes.object,
    rowIdx: PropTypes.number,
    listSize: PropTypes.number,
    type: PropTypes.string,
    tooltipDir: PropTypes.string,
  };

  render() {
    const { className, item, rowIdx, listSize, type, tooltipDir } = this.props;
    return (
      <div
        className={classNames(cssBase, className, {
          [`${cssBase}--last`]: rowIdx === listSize - 1,
          [`${cssBase}--nonExchange`]:
            type === TYPE.PERSON && item.type !== ORGANIZATION_USER,
        })}
      >
        <Tooltip
          id={type === TYPE.ROOM ? item.data.roomId : item.email}
          direction={tooltipDir}
          className={`${cssBase}__tooltip`}
          triggerClassName={`${cssBase}__tooltipTrigger`}
          triggerText={
            <div className={`${cssBase}__tooltipTriggerContent`}>
              {this.computeDisplayName(type, item)}
            </div>
          }
          showIcon={false}
        >
          {this.computeDisplayName(type, item)}
        </Tooltip>
      </div>
    );
  }

  computeDisplayName = (type, item) => {
    switch (type) {
      case TYPE.ROOM:
        return item.room.name;
      default:
        return item.type !== ORGANIZATION_USER
          ? item.email
          : isEmpty(item.name)
          ? item.email
          : item.name;
    }
  };
}
