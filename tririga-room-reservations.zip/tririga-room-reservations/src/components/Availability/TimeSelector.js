/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import Hammer from "hammerjs";
import moment from "moment-timezone";
import throttle from "lodash/throttle";
import { OverflowMenuVertical16 } from "@carbon/icons-react";

import { DateTimeConstants } from "../../utils";
import {
  MAX_WIDTH,
  FIT_INTO_VIEW_THRESHOLD,
  convertStartEndTimeToPixelPosition,
  convertPixelPositionToStartEndTime,
  adjustToNearestInterval,
} from "./AvailabilityUtils";

const cssBase = "timeSelector";

export default class TimeSelector extends React.PureComponent {
  static propTypes = {
    dateAndTime: PropTypes.object,
    onChange: PropTypes.func,
    onFitIntoView: PropTypes.func,
    onWheel: PropTypes.func,
    className: PropTypes.string,
    dir: PropTypes.string,
    allAvailable: PropTypes.bool,
    onAvailabilityPanelButtonsDisplay: PropTypes.func,
  };

  constructor(props) {
    super(props);
    this.hammers = [];
    this.panStart = null;
    this.startHandle = null;
    this.endHandle = null;
  }

  static getDerivedStateFromProps({ dateAndTime }, { prevDateAndTime }) {
    if (dateAndTime !== prevDateAndTime) {
      return {
        prevDateAndTime: dateAndTime,
        ...convertStartEndTimeToPixelPosition(
          dateAndTime.startTime,
          dateAndTime.startTimePeriod,
          dateAndTime.endTime,
          dateAndTime.endTimePeriod
        ),
      };
    }
    return null;
  }

  state = {
    prevDateAndTime: null,
    draggingStartHandle: false,
    draggingEndHandle: false,
    draggingSelector: false,
  };

  render() {
    const { className, allAvailable } = this.props;
    const {
      start,
      width,
      draggingStartHandle,
      draggingEndHandle,
      draggingSelector,
    } = this.state;
    const timeStyle = { width: `${width}px` };
    if (this.isLTR) {
      timeStyle.left = `${start}px`;
    } else {
      timeStyle.right = `${start}px`;
    }
    return (
      <div className={cssBase} ref={(el) => (this.container = el)}>
        <div className={`${cssBase}__spacer`} />
        <div
          className={classNames(
            {
              [`${cssBase}__time`]: true,
              [`${cssBase}__dragging`]: draggingSelector,
              [`${cssBase}__allAvailable`]: allAvailable,
            },
            className
          )}
          style={timeStyle}
          ref={(el) => (this.timeOverlay = el)}
        >
          <div
            className={classNames({
              [`${cssBase}__startHandle`]: true,
              [`${cssBase}__dragging`]: draggingStartHandle,
            })}
            ref={(element) => {
              this.startHandle = element;
            }}
          >
            <OverflowMenuVertical16 className={`${cssBase}__handleIcon`} />
          </div>
          <div
            className={classNames({
              [`${cssBase}__endHandle`]: true,
              [`${cssBase}__dragging`]: draggingEndHandle,
            })}
            ref={(element) => {
              this.endHandle = element;
            }}
          >
            <OverflowMenuVertical16 className={`${cssBase}__handleIcon`} />
          </div>
        </div>
      </div>
    );
  }

  componentDidMount() {
    this.timeOverlay.addEventListener("wheel", this.props.onWheel);
    this.hammer = this.createHammerManager(this.timeOverlay);
  }

  componentWillUnmount() {
    this.timeOverlay.removeEventListener("wheel", this.props.onWheel);
    this.hammer.destroy();
  }

  setScrollLeft(scrollLeft) {
    if (this.container != null) {
      this.container.scrollLeft = scrollLeft;
    }
  }

  createHammerManager(handle) {
    const hammer = new Hammer.Manager(handle, {
      recognizers: [
        [Hammer.Pan, { direction: Hammer.DIRECTION_HORIZONTAL, threshold: 0 }],
      ],
    });
    hammer.on("panstart", this.onHandlePanStart);
    hammer.on("panmove", this.onHandlePanMove);
    hammer.on("panend", this.onHandlePanEnd);
    return hammer;
  }

  onHandlePanStart = ({ deltaX, target }) => {
    this.panStart = {
      ...this.state,
      target,
    };
    this.moveHandle(deltaX);
    if (target === this.startHandle) {
      this.setState({ draggingStartHandle: true });
    } else if (target === this.endHandle) {
      this.setState({ draggingEndHandle: true });
    } else {
      this.setState({ draggingSelector: true });
    }
  };

  onHandlePanMove = ({ deltaX }) => {
    this.moveHandle(deltaX);
  };

  onHandlePanEnd = ({ offsetDirection }) => {
    const { start, end } = this.state;
    const dateAndTime = this.props.dateAndTime;
    const newDateAndTime = convertPixelPositionToStartEndTime(
      start,
      end,
      offsetDirection
    );
    if (
      newDateAndTime.endTime === "12:00" &&
      newDateAndTime.endTimePeriod === "AM" &&
      (dateAndTime.endTime !== "12:00" || dateAndTime.endTimePeriod !== "AM")
    ) {
      newDateAndTime.endDate = moment(dateAndTime.endDate)
        .add(1, "days")
        .toDate();
    } else if (
      dateAndTime.endTime === "12:00" &&
      dateAndTime.endTimePeriod === "AM" &&
      (newDateAndTime.endTime !== "12:00" ||
        newDateAndTime.endTimePeriod !== "AM")
    ) {
      newDateAndTime.endDate = moment(dateAndTime.endDate)
        .subtract(1, "days")
        .toDate();
    }
    this.props.onChange(newDateAndTime);
    this.setState({
      draggingStartHandle: false,
      draggingEndHandle: false,
      draggingSelector: false,
    });
  };

  moveHandle = throttle((delta) => {
    this.props.onAvailabilityPanelButtonsDisplay(false);
    delta = this.isLTR ? delta : -delta;
    let { width, start, end, target } = this.panStart;
    requestAnimationFrame(() => {
      if (target === this.startHandle) {
        start = Math.min(
          Math.max(
            this.containerStartEdge,
            adjustToNearestInterval(start, delta)
          ),
          end - DateTimeConstants.MINUTE_INTERVAL
        );
        width = end - start;
      } else if (target === this.endHandle) {
        end = Math.max(
          Math.min(this.containerEndEdge, adjustToNearestInterval(end, delta)),
          start + DateTimeConstants.MINUTE_INTERVAL
        );
        width = end - start;
      } else {
        start = Math.min(
          Math.max(
            this.containerStartEdge,
            adjustToNearestInterval(start, delta)
          ),
          this.containerEndEdge - width
        );
      }
      end = start + width;
      this.setState({
        width,
        start,
        end,
      });
      this.fitTimeSelectorIntoView(start, end, target);
    });
  }, 10);

  get isLTR() {
    return this.props.dir === "ltr";
  }

  get containerScrollLeft() {
    return this.isLTR ? this.container.scrollLeft : -this.container.scrollLeft;
  }

  get containerStartEdge() {
    return this.containerScrollLeft > 0
      ? adjustToNearestInterval(
          this.containerScrollLeft,
          FIT_INTO_VIEW_THRESHOLD
        )
      : 0;
  }

  get containerEndEdge() {
    const endThreshold =
      this.containerScrollLeft >= MAX_WIDTH - this.container.offsetWidth
        ? 0
        : FIT_INTO_VIEW_THRESHOLD;
    return adjustToNearestInterval(
      this.containerScrollLeft,
      this.container.offsetWidth - endThreshold
    );
  }

  fitTimeSelectorIntoView = (start, end, target) => {
    if (target !== this.endHandle && start <= this.containerStartEdge) {
      this.fitIntoView(-1);
    } else if (target === this.startHandle && start >= this.containerEndEdge) {
      this.fitIntoView(1);
    } else if (target === this.endHandle && end <= this.containerStartEdge) {
      this.fitIntoView(-1);
    } else if (target !== this.startHandle && end >= this.containerEndEdge) {
      this.fitIntoView(1);
    }
  };

  fitIntoView(direction) {
    if (!this.isLTR) {
      direction *= -1;
    }
    this.props.onFitIntoView(
      adjustToNearestInterval(
        this.container.scrollLeft,
        FIT_INTO_VIEW_THRESHOLD * direction
      )
    );
  }
}
