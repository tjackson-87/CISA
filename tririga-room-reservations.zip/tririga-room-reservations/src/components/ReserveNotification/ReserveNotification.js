/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - 2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import PropTypes from "prop-types";
import { Information16 } from "@carbon/icons-react";
import classnames from "classnames";
import { isEmpty } from "lodash";

const cssBase = "reserveNotification";

class ReserveNotification extends React.PureComponent {
  static propTypes = {
    message: PropTypes.string,
    className: PropTypes.string,
    noInfoIcon: PropTypes.bool,
  };

  render() {
    const { message, className, noInfoIcon } = this.props;
    return (
      <div
        className={classnames(cssBase, { [className]: !isEmpty(className) })}
      >
        <Information16 className={`${cssBase}__icon`} hidden={noInfoIcon} />
        <div className={`${cssBase}__text`}>{message}</div>
      </div>
    );
  }
}

export default ReserveNotification;
