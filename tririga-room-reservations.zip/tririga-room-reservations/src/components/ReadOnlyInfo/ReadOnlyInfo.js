import { PropTypes } from "prop-types";
import React, { Component } from "react";
import { FormLabel, Tile } from "carbon-components-react";

const cssBase = "readOnlyInfo";

class ReadOnlyInfo extends Component {
  static propTypes = {
    label: PropTypes.string,
    value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  };

  render() {
    const { label, value } = this.props;
    return (
      <div className={cssBase}>
        <FormLabel className={`${cssBase}__label`}>{label}</FormLabel>
        <Tile className={`${cssBase}__text`}>{value}</Tile>
      </div>
    );
  }
}

export default ReadOnlyInfo;
