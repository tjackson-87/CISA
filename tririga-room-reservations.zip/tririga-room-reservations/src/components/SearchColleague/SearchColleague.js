/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import { ComposedModal, ModalHeader } from "carbon-components-react";
import { AppMsg } from "../../utils";
import debounce from 'lodash/debounce'
import ColleagueSearch from "../ColleagueSearch/ColleagueSearch";
import {
  ColleagueActions,
  ColleagueSelectors,
  LayoutSelectors,
  LoadingSelectors,
  RoomSearchActions,
  RouteActions,
} from "../../store";
const cssBase = "searchColleague";

class SearchColleague extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    isOpen: PropTypes.bool,
    onClose: PropTypes.func,
    searchColleagues: PropTypes.func,
    searchMoreColleagues: PropTypes.func,
    setSelectedColleague: PropTypes.func,
    setSearchColleagueModal: PropTypes.func,
    colleagues: PropTypes.array,
    loading: PropTypes.bool,
    loadingMore: PropTypes.bool,
    dir: PropTypes.string,
    navigateToColleagueReservation: PropTypes.func,
  };

  state = {
    searchText: "",
    debouncingSearch: false,
  };

  render() {
    const {
      isOpen,
      onClose,
      loading,
      loadingMore,
      dir,
      colleagues,
      searchMoreColleagues
    } = this.props;
    
    const { searchText, debouncingSearch } = this.state;

    return (
      <main aria-labelledby="searchColleagueModal">
        <ComposedModal
          id="searchColleagueModal"
          open={isOpen}
          onClose={onClose}
          aria-label={
            this.props.appMessages[AppMsg.RESERVATION_MESSAGE.SEARCH_COLLEAGUES_MODAL_TITLE]
          }
          selectorPrimaryFocus=".bx--modal-close"
        >
          <ModalHeader
            title={
              this.props.appMessages[
                AppMsg.RESERVATION_MESSAGE.SEARCH_COLLEAGUES_MODAL_TITLE
              ]
            }
            iconDescription={this.props.appMessages[AppMsg.BUTTON.CLOSE]}
          />
          <div className={cssBase}>
            <div className={`${cssBase}__content`}>
              <div className={`${cssBase}__description`}>
              {
                this.props.appMessages[
                  AppMsg.RESERVATION_MESSAGE.SEARCH_COLLEAGUES_MODAL_DESCRIPTION
                ]
              }
              </div>
              <ColleagueSearch
                searchText={searchText}
                onSearchTextChange={this.handleSearchTextChange}
                onSearchMore={searchMoreColleagues}
                onSelect={this.handleSelectBuilding}
                colleagues={colleagues}
                loading={loading || debouncingSearch}
                loadingMore={loadingMore}
                dir={dir}
                isModalOpen={isOpen}
              />
            </div>
          </div>
        </ComposedModal>
      </main>
    );
  }

  handleSearchTextChange = (searchText) => {
    this.setState({ searchText, debouncingSearch: true });
    this.debouncedSearch(searchText);
  };

  debouncedSearch = debounce((searchText) => {
    this.props.searchColleagues(searchText);
    setTimeout(() => this.setState({ debouncingSearch: false }), 50);
  }, 300);

  handleSelectBuilding = (colleague) => {
    const {
      setSelectedColleague,
      setSearchColleagueModal,
      navigateToColleagueReservation,
      onClose,
    } = this.props;
    setSearchColleagueModal(false);
    setSelectedColleague(colleague);
    this.setState({ searchText: "" });
    onClose(true);
    navigateToColleagueReservation();
  };
}

const mapStateToProps = (state) => {
  return {
    colleagues: ColleagueSelectors.colleaguesSelector(state),
    loading: LoadingSelectors.searchingColleaguesSelector(state),
    loadingMore: LoadingSelectors.searchingMoreColleaguesSelector(state),
    dir: LayoutSelectors.dirSelector(state),
  };
};

export default withTriDictionary(
  connect(mapStateToProps, {
    searchColleagues: ColleagueActions.searchColleagues,
    searchMoreColleagues: ColleagueActions.searchMoreColleagues,
    setSelectedColleague: ColleagueActions.setSelectedColleague,
    setSearchColleagueModal: RoomSearchActions.setSearchColleagueModal,
    navigateToColleagueReservation: RouteActions.navigateToColleagueReservation,
  })(SearchColleague)
);
