/* IBM Confidential· - OCO Source Materials· - (C) COPYRIGHT IBM CORP. 2023 - The source code for this program is not published or otherwise· divested of its trade secrets, irrespective of what has been· deposited with the U.S. Copyright Office. */

import React from "react";
import { screen, fireEvent } from "@testing-library/react";
import { AppMsg } from "../../../utils";
import SearchColleague from "../SearchColleague";
import {
  ColleagueActions,
  getAppStore,
  RouteActions
} from "../../../store";
import { renderWithReduxAndDictionaryProvider } from "../../../testUtils";
import { colleagueReducer } from "../../../store/reducers/ColleaguesReducer";
import { Button, TextInput } from "carbon-addons-iot-react";

afterEach(() => jest.clearAllMocks());

function mockedColleagueSearch({
  // eslint-disable-next-line react/prop-types
  onSearchTextChange,
  // eslint-disable-next-line react/prop-types
  onSelect,
}) {
  return (
    <div>
      <TextInput
        id="search"
        onChange={(e) => {
          onSearchTextChange({ val: e.target.value });
        }}
        labelText="search"
      />

      <Button onClick={() => onSelect({ id: "shiva" })} aria-label="onselect" />
    </div>
  );
}

jest.mock("../../../components/ColleagueSearch/ColleagueSearch", () => {
  return mockedColleagueSearch;
});

ColleagueActions.searchColleagues.mockImplementation(() => jest.fn());

ColleagueActions.setSelectedColleague.mockImplementation(() => jest.fn());

RouteActions.navigateToColleagueReservation.mockImplementation(() => 
  jest.fn()
)

jest.mock("../../../store/actions/ColleagueActions");
jest.mock("../../../store/actions/ReservationActions");
jest.mock("../../../store/actions/RouteActions");
jest.mock('lodash/debounce', () => jest.fn(fn => fn));
describe("SearchColleague", () => { 
  let appMessages, props;
  beforeEach(() => {
    appMessages = AppMsg.getAppMessages();
    props = {
      isOpen: true,
      onClose: jest.fn(),
    };

    const initialColleagueState = {
      ...getAppStore().getState.colleague,
    };
    const initialLoadingState = {
      ...getAppStore().getState.loading,
    };
    const initialState = {
      ...getAppStore().getState(),
      colleague: initialColleagueState,
      loading: initialLoadingState,
      layout: { ...getAppStore().getState.layout },
    };

    renderWithReduxAndDictionaryProvider(
      <SearchColleague {...props} />,
      {
        initialState,
        reducer: colleagueReducer,
      },
      appMessages
    );
  });

  it("Should render correctly", () => {
    const modal = screen.getByRole("dialog");
    expect(modal).toBeInTheDocument();
  });

  it("Should call searchcolleague function when text is searched", () => {
    const tb = screen.getByRole("textbox");
    jest.useFakeTimers();
    fireEvent.change(tb, { target: { value: "sh" } });
    jest.runAllTimers();
    expect(ColleagueActions.searchColleagues).toHaveBeenCalledWith({
      val: "sh",
    });
    jest.useRealTimers();
  });

  it("Should call setSelectedColleague function when colleague is selected", () => {
    const onselect = screen.getByRole("button", { name: /onselect/i });
    fireEvent.click(onselect);
    expect(ColleagueActions.setSelectedColleague).toHaveBeenCalledWith({
      id: "shiva",
    });
    expect(props.onClose).toBeCalled();
    expect(RouteActions.navigateToColleagueReservation).toBeCalled();
  });
});