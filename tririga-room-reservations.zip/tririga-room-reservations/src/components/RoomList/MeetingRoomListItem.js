/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import classNames from "classnames";
import isEmpty from "lodash/isEmpty";
import { Button, TooltipIcon } from "carbon-components-react";
import {
  Location16,
  Close20,
  ChevronDown32,
  ChevronUp32,
  Printer16,
  Cafe16,
  ErrorFilled16,
} from "@carbon/icons-react";
import {
  ReservationStepLink,
  FavoriteIconButton,
  RoomRequestableInlineNotification,
  TimezoneStatus,
} from "..";
import { AppMsg, ReservableSpacesConstants } from "../../utils";
import { isStartDateInvalid } from "../../utils/reservation/ReservationUtils";
import RecurrenceLabel from "./RecurrenceLabel";

const cssBase = "meetingRoomListItem";

const { RESERVATION_CLASS_REQUESTABLE } = ReservableSpacesConstants;

class MeetingRoomListItem extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    resource: PropTypes.object.isRequired,
    className: PropTypes.string,
    disabled: PropTypes.bool,
    onRemove: PropTypes.func,
    dir: PropTypes.string,
    onClick: PropTypes.func,
    onEquipmentClick: PropTypes.func,
    onMoreOptionsClick: PropTypes.func,
    onCateringClick: PropTypes.func,
    favorites: PropTypes.array,
    addFavoriteRoom: PropTypes.func,
    removeFavoriteRoom: PropTypes.func,
    navigateToOccurrenceExceptionsPage: PropTypes.func,
    isRecurring: PropTypes.bool,
    defaultTimezone: PropTypes.string,
    forceIgnoreRecurrenceLabel: PropTypes.bool,
    dateAndTime: PropTypes.object,
    stepLinkReference: PropTypes.func,
    isReservationExchangeOnly: PropTypes.bool,
  };

  constructor(props) {
    super(props);
    this.meetingRoomItemRef = React.createRef();
  }

  render() {
    const {
      resource,
      className,
      dir,
      disabled,
      defaultTimezone,
      favorites,
      navigateToOccurrenceExceptionsPage,
      isRecurring,
      forceIgnoreRecurrenceLabel,
      isReservationExchangeOnly,
    } = this.props;
    const { isUnavailable } = resource;
    const displayMoreOptions = this.hasMoreOptions(resource);
    const {
      room: {
        timezone,
        reservationClassNameENUS,
        _availCount: availCount,
        _maxOccurrenceCount: maxCount,
      },
    } = resource;
    const classes = classNames({
      [cssBase]: true,
      [`${cssBase}--unavailable`]: disabled,
      [className]: true,
    });
    const unavailableMessage = isEmpty(resource.data.userMessage)
      ? AppMsg.getMessage(AppMsg.RESERVATION_MESSAGE.ROOM_UNAVAILABLE)
      : resource.data.userMessage;
    return (
      <div className={classes}>
        <div className={`${cssBase}__roomDetails`}>
          {this.renderRemoveButton()}
          <div className={`${cssBase}__unavailableRemoveContent`}>
            {isUnavailable &&
              this.displayUnavailableMessage(dir, unavailableMessage)}
          </div>
          {reservationClassNameENUS === RESERVATION_CLASS_REQUESTABLE ? (
            <div className={`${cssBase}__roomClassStatus`}>
              <RoomRequestableInlineNotification
                message={AppMsg.RESERVATION_MESSAGE.REQUIRE_OWNERS_APPROVAL}
              />
            </div>
          ) : null}
          <TimezoneStatus
            timezone={timezone}
            defaultTimezone={defaultTimezone}
            cssBase={cssBase}
          />
          <div
            className={classNames(`${cssBase}__room`, {
              [`${cssBase}__noMoreOptions`]:
                disabled || (!displayMoreOptions && !isRecurring),
            })}
          >
            <div className={`${cssBase}__name-favoriteIcon`}>
              <div
                className={`${cssBase}__name`}
                role="link"
                tabIndex={0}
                ref={this.meetingRoomItemRef}
                onClick={() => this.handleonClick(resource)}
                onKeyDown={(e) =>
                  e.key === "Enter" ? this.handleonClick(resource) : null
                }
              >
                {resource.room.roomId}
                {", "}
                {resource.room.name}
              </div>
              <FavoriteIconButton
                dir={dir}
                onHold={true}
                addFavorite={this.props.addFavoriteRoom}
                removeFavorite={this.props.removeFavoriteRoom}
                favorites={favorites}
                item={resource.room}
              />
            </div>
            <div className={`${cssBase}__location`}>
              <div className={`${cssBase}__floor`}>{resource.room.floor}</div>
              <div className={`${cssBase}__buildingLocation`}>
                <Location16 className={`${cssBase}__locationIcon`} />
                <span className={`${cssBase}__building`}>
                  {resource.room.building}
                </span>
              </div>
            </div>
          </div>
          {!disabled &&
            isRecurring &&
            !forceIgnoreRecurrenceLabel &&
            resource.exceptions && (
              <RecurrenceLabel
                onClick={() => {
                  navigateToOccurrenceExceptionsPage(resource.data._id);
                }}
                availCount={availCount}
                maxCount={maxCount}
                exceptions={resource.exceptions}
              />
            )}
          {!disabled && !isReservationExchangeOnly && (
            <>
              {this.renderMoreOptions(resource, displayMoreOptions)}
              {this.renderEquipmentLink(resource)}
              {this.renderCateringLink(resource)}
            </>
          )}
        </div>
      </div>
    );
  }

  renderMoreOptions = (resource, displayMoreOptions) => {
    return (
      displayMoreOptions && (
        <div className={`${cssBase}__moreOptionsContent`}>
          <Button
            className={`${cssBase}__moreOptions`}
            kind="ghost"
            onClick={this.handleTapOptions}
            renderIcon={resource.showMoreOptions ? ChevronUp32 : ChevronDown32}
            size="small"
          >
            {
              this.props.appMessages[
                resource.showMoreOptions
                  ? AppMsg.RESERVATION_MESSAGE.STEP_LOCATION_LESS_OPTIONS
                  : AppMsg.RESERVATION_MESSAGE.STEP_LOCATION_MORE_OPTIONS
              ]
            }
          </Button>
        </div>
      )
    );
  };

  renderEquipmentLink = (resource) => {
    const { onEquipmentClick, dir } = this.props;
    return (
      this.hasAvailableOrSelectedEquipment(resource) &&
      resource.showMoreOptions && (
        <ReservationStepLink
          dir={dir}
          stepIcon={Printer16}
          name={
            this.props.appMessages[
              AppMsg.RESERVATION_MESSAGE.STEP_MEETING_EQUIPMENT
            ]
          }
          className={`${cssBase}__equipment`}
          children={this.computeSelectedEquipment(resource, dir)}
          onClick={() => onEquipmentClick(resource.data.roomId)}
          onKeyDown={(e) =>
            e.key === "Enter" ? onEquipmentClick(resource.data.roomId) : null
          }
        />
      )
    );
  };

  renderCateringLink = (resource) => {
    const { onCateringClick, dir, dateAndTime, stepLinkReference } = this.props;
    const invalidStartDate = isStartDateInvalid(dateAndTime);
    return (
      !isEmpty(resource.availableCatering) &&
      resource.showMoreOptions && (
        <ReservationStepLink
          dir={dir}
          className={`${cssBase}__catering`}
          stepIcon={Cafe16}
          name={
            this.props.appMessages[
              AppMsg.RESERVATION_MESSAGE.STEP_MEETING_CATERING
            ]
          }
          onClick={() => onCateringClick(resource.data.roomId)}
          invalidStartDate={invalidStartDate}
          onKeyDown={(e) =>
            e.key === "Enter" ? onCateringClick(resource.data.roomId) : null
          }
          children={this.computeSelectedCaterings(resource)}
          stepLinkReference={stepLinkReference}
        />
      )
    );
  };

  renderRemoveButton() {
    const { dir } = this.props;
    return (
      <div
        onClick={(e) => this.handleOnRemove(e)}
        onKeyDown={(e) => (e.key === "Enter" ? this.handleOnRemove(e) : null)}
        className={`${cssBase}__removeButton`}
      >
        <TooltipIcon
          direction="left"
          align={dir === "ltr" ? "start" : "end"}
          tooltipText={this.props.appMessages[AppMsg.BUTTON.REMOVE_ROOM]}
          aria-label={this.props.appMessages[AppMsg.BUTTON.REMOVE_ROOM]}
        >
          <Close20 />
        </TooltipIcon>
      </div>
    );
  }

  handleonClick = (resource) => {
    const { onClick, disabled } = this.props;
    if (!disabled) onClick(resource, this.meetingRoomItemRef);
  };

  handleOnRemove = (e) => {
    e.stopPropagation();
    const { onRemove, resource } = this.props;
    if (onRemove) {
      onRemove(resource);
    }
  };

  handleTapOptions = () => {
    const { onMoreOptionsClick, resource } = this.props;
    onMoreOptionsClick(resource.data.roomId, !resource.showMoreOptions);
  };

  computeSelectedEquipment = (resource, dir) => {
    if (!isEmpty(resource.selectedEquipment)) {
      const equipment = resource.selectedEquipment.filter(
        (e) => e.roomId === resource.data.roomId
      );
      return (
        <div className={`${cssBase}__equipmentLinkText`}>
          {resource.hasUnavailableSelectedEquipment &&
            this.displayUnavailableMessage(dir, "")}
          {this.getEquipmentNames(equipment)}
        </div>
      );
    } else return null;
  };

  displayUnavailableMessage = (dir, tooltipText) => {
    return (
      <div className={`${cssBase}__unavailableEquipment`}>
        {tooltipText !== "" && (
          <TooltipIcon
            direction="top"
            align={dir === "ltr" ? "start" : "end"}
            tooltipText={tooltipText}
          >
            <ErrorFilled16 className={`${cssBase}__unavailableIcon`} />
          </TooltipIcon>
        )}
        {tooltipText === "" && (
          <ErrorFilled16 className={`${cssBase}__unavailableIcon`} />
        )}
        <div className={`${cssBase}__unavailableText`}>
          {this.props.appMessages[AppMsg.RESERVATION_MESSAGE.UNAVAILABLE]}
        </div>
      </div>
    );
  };

  getEquipmentNames = (equipment) => {
    return (
      <>
        {equipment.map(
          (item, index) =>
            item.actionType !== "delete" && (
              <span
                key={`item-${index}`}
                className={`${cssBase}__equipmentName`}
              >{`${item.name}${
                item.quantity > 1 ? " (" + item.quantity + ")" : ""
              }${index < equipment.length - 1 ? "; " : ""}`}</span>
            )
        )}
      </>
    );
  };

  hasAvailableOrSelectedEquipment = (resource) => {
    return (
      !isEmpty(resource.availableEquipment) ||
      !isEmpty(resource.selectedEquipment)
    );
  };

  hasMoreOptions = (resource) => {
    return (
      this.hasAvailableOrSelectedEquipment(resource) ||
      !isEmpty(resource.availableCatering)
    );
  };

  getCateringNames = (caterings) => {
    return (
      <>
        {caterings.map(({ additionalInformation }, index) => (
          <span key={`item-${index}`} className={`${cssBase}__cateringName`}>
            {`${
              additionalInformation.orderName ||
              AppMsg.getMessage(AppMsg.RESERVATION_MESSAGE.FOOD_ORDER)
            } ${additionalInformation.deliveryTime} ${
              additionalInformation.deliveryTimePeriod
            }`}
          </span>
        ))}
      </>
    );
  };

  computeSelectedCaterings = (resource) => {
    if (!isEmpty(resource.selectedCatering)) {
      const caterings = resource.selectedCatering;
      return (
        <div className={`${cssBase}__cateringLinkText`}>
          {this.getCateringNames(caterings)}
        </div>
      );
    } else return null;
  };
}

export default withTriDictionary(MeetingRoomListItem);
