/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import { isEmpty, isEqual } from "lodash";
import MeetingRoomListItem from "./MeetingRoomListItem";
import WorkspaceListItem from "./WorkspaceListItem";
import { ReservationTypes } from "../../utils";

const cssBase = "reservationRoomList";

export default class ReservationRoomList extends React.PureComponent {
  static propTypes = {
    resources: PropTypes.array,
    dateAndTime: PropTypes.object,
    className: PropTypes.string,
    holdTimeExpired: PropTypes.bool,
    onRemove: PropTypes.func,
    onItemClick: PropTypes.func,
    dir: PropTypes.string,
    favorites: PropTypes.array,
    addFavoriteRoom: PropTypes.func,
    defaultTimezone: PropTypes.string,
    removeFavoriteRoom: PropTypes.func,
    reservationType: PropTypes.string,
    onEquipmentClick: PropTypes.func,
    onMoreOptionsClick: PropTypes.func,
    onCateringClick: PropTypes.func,
    stepLinkReference: PropTypes.func,
    navigateToOccurrenceExceptionsPage: PropTypes.func,
    isRecurring: PropTypes.bool,
    recurrence: PropTypes.object,
    initUpdatedData: PropTypes.object,
    setRef: PropTypes.func,
    isReservationExchangeOnly: PropTypes.bool,
  };

  render() {
    const { resources, className } = this.props;
    if (isEmpty(resources)) return null;
    return (
      <div className={classNames(cssBase, className)}>
        {resources.map(this.renderResource)}
      </div>
    );
  }

  renderResource = (resource) => {
    const {
      onRemove,
      onItemClick,
      dir,
      favorites,
      reservationType,
      addFavoriteRoom,
      removeFavoriteRoom,
      holdTimeExpired,
      onEquipmentClick,
      onMoreOptionsClick,
      onCateringClick,
      navigateToOccurrenceExceptionsPage,
      isRecurring,
      defaultTimezone,
      initUpdatedData,
      recurrence,
      setRef,
      stepLinkReference,
      isReservationExchangeOnly,
    } = this.props;
    let hasNewResource = false;
    if (initUpdatedData && initUpdatedData.resources) {
      hasNewResource = !initUpdatedData.resources.some(
        (r) => r.data._id === resource.data._id
      );
    }
    const forceIgnoreRecurrenceLabel =
      initUpdatedData &&
      initUpdatedData.recurrence &&
      recurrence &&
      isEqual(initUpdatedData.recurrence, recurrence) &&
      !hasNewResource;

    const { dateAndTime } = this.props;
    return reservationType === ReservationTypes.MEETING ? (
      <MeetingRoomListItem
        className={`${cssBase}__meetingRoomListItem`}
        disabled={holdTimeExpired || resource?.isUnavailable}
        key={resource.data._id}
        resource={resource}
        dateAndTime={dateAndTime}
        dir={dir}
        favorites={favorites}
        onRemove={onRemove}
        onClick={onItemClick}
        onEquipmentClick={onEquipmentClick}
        onMoreOptionsClick={onMoreOptionsClick}
        onCateringClick={onCateringClick}
        addFavoriteRoom={addFavoriteRoom}
        removeFavoriteRoom={removeFavoriteRoom}
        navigateToOccurrenceExceptionsPage={navigateToOccurrenceExceptionsPage}
        isRecurring={isRecurring}
        defaultTimezone={defaultTimezone}
        forceIgnoreRecurrenceLabel={forceIgnoreRecurrenceLabel}
        stepLinkReference={stepLinkReference}
        isReservationExchangeOnly={isReservationExchangeOnly}
      />
    ) : (
      <WorkspaceListItem
        key={resource.data._id}
        dir={dir}
        disabled={holdTimeExpired || resource?.isUnavailable}
        resource={resource}
        favorites={favorites}
        onRemove={onRemove}
        onClick={onItemClick}
        addFavoriteRoom={addFavoriteRoom}
        removeFavoriteRoom={removeFavoriteRoom}
        navigateToOccurrenceExceptionsPage={navigateToOccurrenceExceptionsPage}
        isRecurring={isRecurring}
        defaultTimezone={defaultTimezone}
        forceIgnoreRecurrenceLabel={forceIgnoreRecurrenceLabel}
        reservationType={reservationType}
        setRef={setRef}
      />
    );
  };
}
