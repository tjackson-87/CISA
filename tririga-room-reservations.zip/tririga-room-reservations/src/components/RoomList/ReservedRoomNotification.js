/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2023 The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React, { useState, useRef } from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import { ErrorFilled16, Information16 } from "@carbon/icons-react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import { AppMsg } from "../../utils";
import { ColleagueSelectors, ReservationSelectors } from "../../store";
import { Modal } from "carbon-components-react";

const cssBase = "reservedRoomNotification";

function ReservedRoomNotification(props) {
  const { colleagueReservedRoom, colleagueDetails, formattedDate } = props;
  const [reservedRoomDetailsModal, setReservedRoomDetailsModal] = useState(
    false
  );
  const modalEl = useRef(null);
  return (
    <div className={cssBase}>
      <ErrorFilled16 className={`${cssBase}__icon`} />
      <div className={`${cssBase}__text`}>
        {props.appMessages[AppMsg.RESERVATION_MESSAGE.COLLEAGUE_RESERVED_BY] +
          " " +
          colleagueDetails?.name}
      </div>
      <div
        onClick={(e) => setReservedRoomDetailsModal(true)}
        tabIndex={0}
        role="button"
        ref={modalEl}
      >
        <Information16 className={`${cssBase}__iconInfo`} tabIndex={-1} />
      </div>
      <Modal
        passiveModal
        size="xs"
        aria-label={colleagueReservedRoom?.name}
        modalHeading={colleagueReservedRoom?.name}
        modalAriaLabel={colleagueReservedRoom?.name}
        onRequestClose={() => {
          if (modalEl && modalEl.current) {
            setTimeout(modalEl.current.focus(), 100);
          }
          setReservedRoomDetailsModal(false);
        }}
        open={reservedRoomDetailsModal}
        iconDescription={props.appMessages[AppMsg.BUTTON.CLOSE]}
      >
        {colleagueDetails && colleagueDetails.shareWorkspace ? (
          <div
            tabIndex={0}
            aria-label={`${
              props.appMessages[
                AppMsg.RESERVATION_MESSAGE.COLLEAGUE_RESERVED_BY
              ]
            } ${formattedDate} ${colleagueDetails?.email}`}
          >
            <span>
              {`${
                props.appMessages[
                  AppMsg.RESERVATION_MESSAGE.COLLEAGUE_RESERVED_BY
                ]
              }  ${colleagueDetails?.name}`}
              <p className={`${cssBase}__reservationDetails`}>
                {formattedDate}
              </p>
            </span>
            <a tabIndex={-1} href={`mailto:${colleagueDetails?.email}`}>
              {colleagueDetails?.email}
            </a>
          </div>
        ) : (
          props.appMessages[
            AppMsg.RESERVATION_MESSAGE.NO_COLLEAGUE_RESERVATION_CONTENT_LINE
          ]
        )}
      </Modal>
    </div>
  );
}

ReservedRoomNotification.propTypes = {
  appMessages: PropTypes.object,
  colleagueReservedRoom: PropTypes.object,
  colleagueDetails: PropTypes.object,
  formattedDate: PropTypes.string,
};

const mapStateToProps = (state) => {
  return {
    colleagueReservedRoom: ColleagueSelectors.colleagueReservedRoomSelector(
      state
    ),
    colleagueDetails: ColleagueSelectors.colleagueDetailsSelector(state),
    formattedDate: ReservationSelectors.formattedStartEndDatesSelector(state),
  };
};

export default withTriDictionary(
  connect(mapStateToProps, {})(ReservedRoomNotification)
);
