/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import PropTypes from "prop-types";
import { InformationFilled16 } from "@carbon/icons-react";
import { withTriDictionary } from "@tririga/tririga-react-components";

const cssBase = "roomRequestableInlineNotification";

function RoomRequestableInlineNotification(props) {
  return (
    <div className={cssBase}>
      <InformationFilled16 className={`${cssBase}__icon`} />
      <div className={`${cssBase}__text`}>
        {props.appMessages[props.message]}
      </div>
    </div>
  );
}

RoomRequestableInlineNotification.propTypes = {
  appMessages: PropTypes.object,
  message: PropTypes.string,
};

export default withTriDictionary(RoomRequestableInlineNotification);
