/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2022 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import PropTypes from "prop-types";
import debounce from "debounce";
import classNames from "classnames";
import { Virtuoso } from "react-virtuoso";
import { SkeletonPlaceholder } from "carbon-components-react";
import isEmpty from "lodash/isEmpty";
import RoomListItem from "./RoomListItem";
import { RoomsUtils } from "../../utils";
import { isEqual, isNil } from "lodash";

const cssBase = "roomList";

export default class RoomList extends React.PureComponent {
  static propTypes = {
    rooms: PropTypes.array.isRequired,
    selected: PropTypes.array,
    favorites: PropTypes.array,
    className: PropTypes.string,
    onChange: PropTypes.func,
    onItemClick: PropTypes.func,
    onRecurrenceClick: PropTypes.func,
    isRecurring: PropTypes.bool,
    loadingMore: PropTypes.bool,
    addFavoriteRoom: PropTypes.func.isRequired,
    removeFavoriteRoom: PropTypes.func.isRequired,
    dir: PropTypes.string,
    reservationType: PropTypes.string,
    isException: PropTypes.bool,
  };

  static defaultProps = {
    selected: [],
    isRecurring: false,
  };

  constructor(props) {
    super(props);
    this.handleResizeDebounced = debounce(this.handleResize, 300);
  }

  componentDidMount() {
    window.addEventListener("resize", this.handleResizeDebounced);
    if (!isEmpty(this.props.rooms)) {
      this.addFocusableElementListener();
    }
  }

  componentWillUnmount() {
    window.removeEventListener("resize", this.handleResizeDebounced);
    if (!isEmpty(this.roomListEl)) {
      this.roomListEl = null;
    }
    if (!isEmpty(this.state.lastFocusableElement)) {
      this.state.lastFocusableElement.removeEventListener(
        "focus",
        this.handleLastElementFocused
      );
    }
    if (!isEmpty(this.state.firstFocusableElement)) {
      this.state.firstFocusableElement.removeEventListener(
        "focus",
        this.handleLastElementFocused
      );
    }
  }

  state = {
    maxVisibleAmenities: RoomsUtils.computeMaxVisibleAmenities(),
    firstFocusableElement: null,
    lastFocusableElement: null,
  };

  render() {
    const {
      className,
      rooms,
      onChange,
      onItemClick,
      isRecurring,
      onRecurrenceClick,
      favorites,
      addFavoriteRoom,
      removeFavoriteRoom,
      dir,
      reservationType,
      loadingMore,
      isException,
    } = this.props;
    const { maxVisibleAmenities } = this.state;
    return (
      <Virtuoso
        id="roomList"
        tabIndex={-1}
        totalCount={rooms.length}
        components={{
          Footer: () =>
            loadingMore ? (
              <SkeletonPlaceholder className={`${cssBase}__loadingMore`} />
            ) : null,
        }}
        className={classNames(cssBase, className)}
        ref={(virtuoso) => {
          this.virtuoso = virtuoso;
        }}
        itemContent={(index) => (
          <RoomListItem
            room={rooms[index]}
            selected={this.isSelected(rooms[index])}
            favorites={favorites}
            onChange={onChange}
            maxVisibleAmenities={maxVisibleAmenities}
            onClick={onItemClick}
            isRecurring={isRecurring}
            onRecurrenceClick={onRecurrenceClick}
            addFavoriteRoom={addFavoriteRoom}
            removeFavoriteRoom={removeFavoriteRoom}
            dir={dir}
            reservationType={reservationType}
            isException={isException}
          />
        )}
      />
    );
  }

  handleResize = () => {
    const maxVisibleAmenities = RoomsUtils.computeMaxVisibleAmenities();
    this.setState({ maxVisibleAmenities });
  };

  addFocusableElementListener = () => {
    setTimeout(() => {
      if (isEmpty(this.roomListEl)) {
        this.roomListEl = document.getElementById("roomList");
      }
      if(!isNil(this.roomListEl)) {
        const allFocusableElements = this.roomListEl.querySelectorAll(
          'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
        );
        const firstFocusableElement = allFocusableElements[0];
        if (!isEqual(this.state.firstFocusableElement, firstFocusableElement)) {
          firstFocusableElement.addEventListener(
            "focus",
            this.handleFirstElementFocused
          );
          this.setState({ firstFocusableElement });
        }
        const lastFocusableElement =
          allFocusableElements[allFocusableElements.length - 1];
        if (!isEqual(this.state.lastFocusableElement, lastFocusableElement)) {
          lastFocusableElement.addEventListener(
            "focus",
            this.handleLastElementFocused
          );
          this.setState({ lastFocusableElement });
        } 
      }
    }, 300);
  };

  handleFirstElementFocused = (e) => {
    if (!isEmpty(this.state.firstFocusableElement)) {
      this.state.firstFocusableElement.removeEventListener(
        "focus",
        this.handleFirstElementFocused
      );
      this.roomListEl.scrollBy(0, this.roomListEl.clientHeight * -1);
      this.addFocusableElementListener();
    }
  };

  handleLastElementFocused = (e) => {
    e.currentTarget.scrollIntoView(true);
    if (!isEmpty(this.state.lastFocusableElement)) {
      this.state.lastFocusableElement.removeEventListener(
        "focus",
        this.handleLastElementFocused
      );
    }
    this.addFocusableElementListener();
  };

  isSelected = (room) => {
    const { selected } = this.props;
    if (isEmpty(selected)) {
      return false;
    }
    return (
      selected.findIndex(
        (selected) =>
          selected._id === room._id &&
          selected.layoutTypeInternal === room.layoutTypeInternal
      ) >= 0
    );
  };
}
