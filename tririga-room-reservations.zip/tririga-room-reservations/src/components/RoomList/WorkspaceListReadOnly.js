/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2022 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import classNames from "classnames";
import isEmpty from "lodash/isEmpty";
import defaultTo from "lodash/defaultTo";
import memo from "memoize-one";
import { Subject, from } from "rxjs";
import { switchMap } from "rxjs/operators";
import { Button, Accordion, AccordionItem } from "carbon-components-react";
import {
  TriFloorPlan,
  TriHighlightPlugin,
  withTriDictionary,
  TriLabelsPlugin,
  TriPanPlugin,
  TriZoomPlugin,
} from "@tririga/tririga-react-components";
import {
  Location16,
  ChevronUp32,
  ChevronDown32,
  MisuseOutline16,
  CheckmarkOutline16,
  Information16,
} from "@carbon/icons-react";
import {
  AppMsg,
  RoomsUtils,
  Status,
  ReservableSpacesConstants,
  ContactRolesConstants,
} from "../../utils";
import { TimezoneStatus, RoomAmenities } from "..";
import { LabelStylesSelectors } from "../../store";

const cssBase = "workspaceListReadOnly";
const { RESERVATION_CLASS_REQUESTABLE } = ReservableSpacesConstants;
const { RESOURCE_OWNER } = ContactRolesConstants;
class WorkspaceListReadOnly extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    resource: PropTypes.object.isRequired,
    onClick: PropTypes.func,
    defaultTimezone: PropTypes.string,
    reservationType: PropTypes.string,
    labelStyles: PropTypes.array,
    roomDetailModal: PropTypes.bool,
  };

  state = {
    viewFloorplan: false,
  };

  constructor(props) {
    super(props);
    this.resource$ = new Subject();
    this.floorPlanId$ = this.resource$.pipe(
      switchMap((resource) =>
        from(RoomsUtils.getFloorplanId(resource.floorSystemRecordID))
      )
    );
    this.floorPlanIdSubscription = this.floorPlanId$.subscribe(
      (floorPlanId) => {
        this.setState({ floorPlanId });
      }
    );
    this.workspaceRef = React.createRef();
  }

  componentDidMount() {
    const { resource } = this.props;
    if (resource?._id != null) {
      this.resource$.next(resource);
    }
  }

  componentDidUpdate(prevProps) {
    const { resource } = this.props;
    if (resource?._id !== prevProps.resource?._id) {
      this.resource$.next(resource);
    }
  }

  componentWillUnmount() {
    this.floorPlanIdSubscription.unsubscribe();
    this.resource$ = null;
    this.floorPlanId$ = null;
    this.floorPlanIdSubscription = null;
  }

  render() {
    const {
      resource,
      onClick,
      defaultTimezone,
      reservationType,
      labelStyles,
      roomDetailModal,
    } = this.props;
    if (roomDetailModal) {
      this.setFocusOnRoomTitle();
    }
    const classes = classNames({
      [cssBase]: true,
    });
    const { timezone } = resource;
    const { viewFloorplan, floorPlanId } = this.state;
    return (
      <div
        className={classNames(
          classes,
          this.computeIndicatorColor(resource.statusENUS)
        )}
      >
        <div
          className={classNames(`${cssBase}__roomDetails`, {
            [`${cssBase}__noFloorPlan`]: !floorPlanId,
          })}
        >
          <TimezoneStatus
            timezone={timezone}
            defaultTimezone={defaultTimezone}
            cssBase={cssBase}
          />
          <div className={`${cssBase}__title`} onClick={onClick}>
            <div className={`${cssBase}__name-favoriteIcon`}>
              <div
                className={`${cssBase}__name`}
                tabIndex={0}
                role="link"
                onKeyDown={(e) => (e.key === "Enter" ? onClick() : false)}
                ref={(ref) => {
                  this.workspaceRef = ref;
                }}
              >
                {resource.roomId}
                {", "}
                {resource.name}
              </div>
            </div>
          </div>

          <div className={`${cssBase}__location`}>
            <Location16 className={`${cssBase}__locationIcon`} />
            {this.computeAddress(resource)}
          </div>
          {resource.spaceclassname && (
            <div className={`${cssBase}__workspaceType`}>
              {`${this.props.appMessages[AppMsg.RECURRENCE.TYPE_HEADING]}: ${
                resource.spaceclassname
              }`}
            </div>
          )}
          {this.handleAmenities(resource, reservationType)}
          {this.renderWorkspaceStatus(resource)}
          {floorPlanId && (
            <div className={`${cssBase}__viewFloorplanContent`}>
              <Button
                className={`${cssBase}__viewFloorplan`}
                kind="ghost"
                onClick={this.handleFloorplanView}
                renderIcon={viewFloorplan ? ChevronUp32 : ChevronDown32}
                size="small"
              >
                {
                  this.props.appMessages[
                    viewFloorplan
                      ? AppMsg.RESERVATION_MESSAGE.WORKSPACE_HIDE_FLOORPLAN
                      : AppMsg.RESERVATION_MESSAGE.WORKSPACE_VIEW_FLOORPLAN
                  ]
                }
              </Button>
            </div>
          )}
          {viewFloorplan && (
            <div className={`${cssBase}__floorPlan`}>
              <TriFloorPlan
                floorPlanId={defaultTo(floorPlanId, null)}
                plugins={[
                  {
                    type: TriHighlightPlugin.type,
                    id: "highlightPlugin",
                    highlighted: this.getHighligthedRoom(resource),
                    className: `${cssBase}__roomHighlighted`,
                    useInteractiveLayer: false,
                  },
                  {
                    type: TriLabelsPlugin.type,
                    id: "labelsPlugin",
                    labelId: labelStyles ? labelStyles[0]._id : "",
                  },
                  { type: TriZoomPlugin.type, id: "zoomPlugin" },
                  { type: TriPanPlugin.type, id: "panPlugin" },
                ]}
              />
            </div>
          )}
        </div>
      </div>
    );
  }

  setFocusOnRoomTitle() {
    if (this.workspaceRef) {
      setTimeout(() => {
        this.workspaceRef.focus();
      }, 1);
    }
  }

  computeIndicatorColor(resourceStatus) {
    if (resourceStatus === Status.DECLINED) {
      return `${cssBase}__workspaceStatusColor_declined`;
    } else if (resourceStatus === Status.REVIEW_IN_PROGRESS) {
      return `${cssBase}__workspaceStatusColor_reviewInProgress`;
    } else {
      return null;
    }
  }

  renderWorkspaceStatus = (resource) => {
    const ownerDetails =
      resource.contactRoles !== undefined
        ? resource.contactRoles.find(
            (contactRole) => contactRole.roleENUS === RESOURCE_OWNER
          )
        : null;
    switch (resource.statusENUS) {
      case Status.ACCEPTED:
        return resource.reservationClassNameENUS ===
          RESERVATION_CLASS_REQUESTABLE ? (
          <div className={`${cssBase}__workspaceStatus`}>
            <CheckmarkOutline16 className={`${cssBase}__approvedIcon`} />
            <span>
              {this.props.appMessages[AppMsg.RESERVATION_MESSAGE.ROOM_APPROVED]}
            </span>
          </div>
        ) : null;
      case Status.DECLINED:
        return (
          <div className={`${cssBase}__workspaceStatus`}>
            <MisuseOutline16 className={`${cssBase}__declinedIcon`} />
            <span>
              {this.props.appMessages[AppMsg.RESERVATION_MESSAGE.ROOM_DECLINED]}
            </span>
          </div>
        );
      case Status.REVIEW_IN_PROGRESS:
        return resource.reservationClassNameENUS ===
          RESERVATION_CLASS_REQUESTABLE ? (
          <Accordion className={`${cssBase}__pending`}>
            <AccordionItem
              title={
                <div className={`${cssBase}__workspaceStatus`}>
                  <Information16 className={`${cssBase}__pendingIcon`} />
                  <span>
                    {
                      this.props.appMessages[
                        AppMsg.RESERVATION_MESSAGE.ROOM_PENDING
                      ]
                    }
                  </span>
                </div>
              }
            >
              {!isEmpty(ownerDetails) ? (
                <div className={`${cssBase}__ownersDetails`}>
                  {!isEmpty(ownerDetails.name) && (
                    <>
                      <span>
                        <span className={`${cssBase}__ownersLabel`}>
                          {
                            this.props.appMessages[
                              AppMsg.RESERVATION_MESSAGE.OWNERS_LABEL
                            ]
                          }
                        </span>
                        {ownerDetails.name}
                      </span>
                      <br />
                    </>
                  )}
                  {!isEmpty(ownerDetails.workPhone) && (
                    <>
                      <span>{ownerDetails.workPhone}</span>
                      <br />
                    </>
                  )}
                  {!isEmpty(ownerDetails.email) && (
                    <>
                      <span>{ownerDetails.email}</span>
                      <br />
                    </>
                  )}
                </div>
              ) : (
                <span>
                  {
                    this.props.appMessages[
                      AppMsg.RESERVATION_MESSAGE.OWNERS_LABEL
                    ]
                  }
                </span>
              )}
            </AccordionItem>
          </Accordion>
        ) : null;
      default:
        return null;
    }
  };

  computeAddress = (room) => {
    const { floor, building, city, state, country } = room;
    const addressArr = [city, state, country];
    let ariaLabel = `${floor} ${building} ${addressArr
      .filter((e) => e !== null)
      .join(" ")}`;
    const BuildingFloor = `${floor}, ${building}`;
    if (ariaLabel) {
      ariaLabel = ariaLabel.replace(/,/g, " ");
    }
    return (
      <div className={`${cssBase}__address`} aria-label={ariaLabel}>
        {BuildingFloor}
        <div>{addressArr.filter((e) => e !== null).join(", ")}</div>
      </div>
    );
  };

  handleAmenities = (resource, reservationType) => {
    const amenities = RoomsUtils.getAmenitiesByRoom(resource, reservationType);
    if (isEmpty(amenities)) {
      return null;
    }
    return (
      <RoomAmenities
        className={`${cssBase}__amenities`}
        displayAllAmenities={false}
        amenities={amenities}
        displayCount={RoomsUtils.computeMaxVisibleAmenities()}
      />
    );
  };

  handleFloorplanView = (e) => {
    e.stopPropagation();
    const { viewFloorplan } = this.state;
    this.setState({ viewFloorplan: !viewFloorplan });
  };

  getHighligthedRoom = memo((room) => ({
    [TriHighlightPlugin.SPACE_ID]: room.spaceRecordId,
  }));
}

const mapStateToProps = (state) => {
  return {
    labelStyles: LabelStylesSelectors.labelStylesSelector(state),
  };
};

export default withTriDictionary(
  connect(mapStateToProps, {})(WorkspaceListReadOnly)
);
