/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2022 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import classNames from "classnames";
import isEmpty from "lodash/isEmpty";
import defaultTo from "lodash/defaultTo";
import memo from "memoize-one";
import { Subject, from } from "rxjs";
import { switchMap } from "rxjs/operators";
import { Button, TooltipIcon } from "carbon-components-react";
import {
  TriFloorPlan,
  TriHighlightPlugin,
  withTriDictionary,
  TriLabelsPlugin,
  TriPanPlugin,
  TriZoomPlugin,
} from "@tririga/tririga-react-components";
import {
  Location16,
  ChevronUp32,
  ChevronDown32,
  Close16,
} from "@carbon/icons-react";
import { AppMsg, RoomsUtils, ReservableSpacesConstants } from "../../utils";
import {
  FavoriteIconButton,
  RoomRequestableInlineNotification,
  TimezoneStatus,
  RoomAmenities,
} from "..";
import RecurrenceLabel from "./RecurrenceLabel";
import { LabelStylesSelectors } from "../../store";

const cssBase = "workspaceListItem";

const { RESERVATION_CLASS_REQUESTABLE } = ReservableSpacesConstants;

class WorkspaceListItem extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    resource: PropTypes.object.isRequired,
    className: PropTypes.string,
    dir: PropTypes.string,
    onRemove: PropTypes.func,
    onClick: PropTypes.func,
    favorites: PropTypes.array,
    addFavoriteRoom: PropTypes.func,
    removeFavoriteRoom: PropTypes.func,
    isRecurring: PropTypes.bool,
    disabled: PropTypes.bool,
    navigateToOccurrenceExceptionsPage: PropTypes.func,
    defaultTimezone: PropTypes.string,
    forceIgnoreRecurrenceLabel: PropTypes.bool,
    reservationType: PropTypes.string,
    labelStyles: PropTypes.array,
    setRef: PropTypes.func,
  };

  state = {
    viewFloorplan: false,
  };

  constructor(props) {
    super(props);
    this.workspaceDetailsRef = React.createRef();
    this.resource$ = new Subject();
    this.floorPlanId$ = this.resource$.pipe(
      switchMap((resource) =>
        from(RoomsUtils.getFloorplanId(resource.room.floorSystemRecordID))
      )
    );
    this.floorPlanIdSubscription = this.floorPlanId$.subscribe(
      (floorPlanId) => {
        this.setState({ floorPlanId });
      }
    );
  }

  componentDidMount() {
    const { resource } = this.props;
    if (resource.room?._id != null) {
      this.resource$.next(resource);
    }
  }

  componentDidUpdate(prevProps) {
    const { resource } = this.props;
    if (resource.room?._id !== prevProps.resource.room?._id) {
      this.resource$.next(resource);
    }
  }

  componentWillUnmount() {
    this.floorPlanIdSubscription.unsubscribe();
    this.resource$ = null;
    this.floorPlanId$ = null;
    this.floorPlanIdSubscription = null;
  }

  render() {
    const {
      resource,
      className,
      dir,
      onClick,
      favorites,
      isRecurring,
      navigateToOccurrenceExceptionsPage,
      disabled,
      defaultTimezone,
      forceIgnoreRecurrenceLabel,
      reservationType,
      labelStyles,
      setRef,
    } = this.props;
    const classes = classNames({
      [cssBase]: true,
      [`${cssBase}--unavailable`]: disabled,
      [className]: true,
    });
    const {
      room: {
        timezone,
        reservationClassNameENUS,
        _availCount: availCount,
        _maxOccurrenceCount: maxCount,
      },
    } = resource;
    const { viewFloorplan, floorPlanId } = this.state;
    return (
      <div className={classes}>
        <div
          className={classNames(`${cssBase}__roomDetails`, {
            [`${cssBase}__noFloorPlan`]:
              disabled || (!floorPlanId && !isRecurring),
          })}
        >
          {reservationClassNameENUS === RESERVATION_CLASS_REQUESTABLE ? (
            <div className={`${cssBase}__roomClassStatus`}>
              <>
                <RoomRequestableInlineNotification
                  message={AppMsg.RESERVATION_MESSAGE.REQUIRE_OWNERS_APPROVAL}
                />
              </>
            </div>
          ) : null}
          {this.renderRemoveButton()}
          <TimezoneStatus
            timezone={timezone}
            defaultTimezone={defaultTimezone}
            cssBase={cssBase}
          />
          <div
            className={`${cssBase}__title`}
            onClick={() => this.handleOnClick(resource)}
          >
            <div className={`${cssBase}__name-favoriteIcon`}>
              <div
                className={`${cssBase}__name`}
                tabIndex={0}
                role="link"
                onKeyDown={(e) =>
                  e.key === "Enter"
                    ? setTimeout(() => this.handleOnClick(resource), 1)
                    : null
                }
                ref={(ref) => {
                  setRef(ref, resource.data._id);
                }}
              >
                {resource.room.roomId}
                {", "}
                {resource.room.name}
              </div>
              <FavoriteIconButton
                dir={dir}
                onHold={true}
                addFavorite={this.props.addFavoriteRoom}
                removeFavorite={this.props.removeFavoriteRoom}
                favorites={favorites}
                item={resource.room}
              />
            </div>
          </div>

          <div
            className={`${cssBase}__location`}
            onClick={() => onClick(resource)}
          >
            <Location16 className={`${cssBase}__locationIcon`} />
            {this.computeAddress(resource.room)}
          </div>
          {!disabled && isRecurring && !forceIgnoreRecurrenceLabel && (
            <RecurrenceLabel
              onClick={() => {
                navigateToOccurrenceExceptionsPage(resource.data._id);
              }}
              availCount={availCount}
              maxCount={maxCount}
              exceptions={resource.exceptions}
            />
          )}
          <div className={`${cssBase}__workspaceType`}>
            {`${this.props.appMessages[AppMsg.RECURRENCE.TYPE_HEADING]}: ${
              resource.room.spaceclassname
            }`}
          </div>
          {this.handleAmenities(resource, reservationType)}

          {!disabled && floorPlanId && (
            <div className={`${cssBase}__viewFloorplanContent`}>
              <Button
                className={`${cssBase}__viewFloorplan`}
                kind="ghost"
                onClick={this.handleFloorplanView}
                renderIcon={viewFloorplan ? ChevronUp32 : ChevronDown32}
                size="small"
              >
                {
                  this.props.appMessages[
                    viewFloorplan
                      ? AppMsg.RESERVATION_MESSAGE.WORKSPACE_HIDE_FLOORPLAN
                      : AppMsg.RESERVATION_MESSAGE.WORKSPACE_VIEW_FLOORPLAN
                  ]
                }
              </Button>
            </div>
          )}
          {!disabled && viewFloorplan && (
            <div className={`${cssBase}__floorPlan`}>
              <TriFloorPlan
                floorPlanId={defaultTo(floorPlanId, null)}
                plugins={[
                  {
                    type: TriHighlightPlugin.type,
                    id: "highlightPlugin",
                    highlighted: this.getHighligthedRoom(resource.room),
                    className: `${cssBase}__roomHighlighted`,
                    useInteractiveLayer: false,
                  },
                  {
                    type: TriLabelsPlugin.type,
                    id: "labelsPlugin",
                    labelId: labelStyles ? labelStyles[0]._id : "",
                  },
                  { type: TriZoomPlugin.type, id: "zoomPlugin" },
                  { type: TriPanPlugin.type, id: "panPlugin" },
                ]}
              />
            </div>
          )}
        </div>
      </div>
    );
  }

  handleOnClick = (resource) => {
    const { onClick, disabled } = this.props;
    if (!disabled) onClick(resource);
  };

  renderRemoveButton() {
    const { resource, dir } = this.props;
    return (
      <div
        onClick={(e) => this.handleOnRemove(e)}
        onKeyDown={(e) => (e.key === "Enter" ? this.handleOnRemove(e) : null)}
        className={`${cssBase}__removeButton`}
      >
        <TooltipIcon
          direction="left"
          align={dir === "ltr" ? "start" : "end"}
          tooltipText={
            this.props.appMessages[
              resource.room.isMeetingSpace
                ? AppMsg.BUTTON.REMOVE_ROOM
                : AppMsg.BUTTON.REMOVE_WORKSPACE
            ]
          }
          aria-label={
            this.props.appMessages[
              resource.room.isMeetingSpace
                ? AppMsg.BUTTON.REMOVE_ROOM
                : AppMsg.BUTTON.REMOVE_WORKSPACE
            ]
          }
        >
          <Close16 />
        </TooltipIcon>
      </div>
    );
  }

  handleOnRemove = (e) => {
    e.stopPropagation();
    const { onRemove, resource } = this.props;
    if (onRemove) {
      onRemove(resource);
    }
  };

  computeAddress = (room) => {
    const { floor, building, city, state, country } = room;
    const addressArr = [city, state, country];
    return (
      <div className={`${cssBase}__address`}>
        {floor}, {building},
        <div>{addressArr.filter((e) => e !== null).join(", ")}</div>
      </div>
    );
  };

  handleAmenities = (resource, reservationType) => {
    const amenities = RoomsUtils.getAmenitiesByRoom(
      resource.room,
      reservationType
    );
    if (isEmpty(amenities)) {
      return null;
    }
    return (
      <RoomAmenities
        className={`${cssBase}__amenities`}
        displayAllAmenities={false}
        amenities={amenities}
        displayCount={RoomsUtils.computeMaxVisibleAmenities()}
      />
    );
  };

  handleFloorplanView = (e) => {
    e.stopPropagation();
    const { viewFloorplan } = this.state;
    this.setState({ viewFloorplan: !viewFloorplan });
  };

  getHighligthedRoom = memo((room) => ({
    [TriHighlightPlugin.SPACE_ID]: room._id,
  }));
}

const mapStateToProps = (state) => {
  return {
    labelStyles: LabelStylesSelectors.labelStylesSelector(state),
  };
};

export default withTriDictionary(
  connect(mapStateToProps, {})(WorkspaceListItem)
);
