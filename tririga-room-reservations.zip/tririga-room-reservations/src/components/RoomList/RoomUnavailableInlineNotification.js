/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import PropTypes from "prop-types";
import { ErrorFilled16 } from "@carbon/icons-react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import { AppMsg } from "../../utils";

const cssBase = "roomUnavailableInlineNotification";

function RoomUnavailableInlineNotification(props) {
  return (
    <div className={cssBase}>
      <ErrorFilled16 className={`${cssBase}__icon`} />
      <div
        className={`${cssBase}__text`}
        tabIndex={0}
        aria-label={props.appMessages[AppMsg.RESERVATION_MESSAGE.UNAVAILABLE]}
      >
        {props.appMessages[AppMsg.RESERVATION_MESSAGE.UNAVAILABLE]}
      </div>
    </div>
  );
}

RoomUnavailableInlineNotification.propTypes = {
  appMessages: PropTypes.object,
};

export default withTriDictionary(RoomUnavailableInlineNotification);
