/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import classNames from "classnames";
import isEmpty from "lodash/isEmpty";
import {
  Button,
  Checkbox,
  RadioButton,
  RadioButtonGroup,
} from "carbon-components-react";
import { User16, Time16 } from "@carbon/icons-react";
import { AppMsg, RoomsUtils, ReservableSpacesConstants } from "../../utils";
import {
  RoomAmenities,
  RoomUnavailableInlineNotification,
  RoomRequestableInlineNotification,
  RoomPrivateInlineNotification,
  FavoriteIconButton,
  ReservedRoomNotification,
} from "..";

const cssBase = "roomListItem";

const {
  RESERVATION_CLASS_PRIVATE,
  RESERVATION_CLASS_REQUESTABLE,
} = ReservableSpacesConstants;

class RoomListItem extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    room: PropTypes.object.isRequired,
    selected: PropTypes.bool,
    favorites: PropTypes.array,
    className: PropTypes.string,
    onChange: PropTypes.func,
    onClick: PropTypes.func,
    onRecurrenceClick: PropTypes.func,
    maxVisibleAmenities: PropTypes.number,
    isRecurring: PropTypes.bool,
    addFavoriteRoom: PropTypes.func.isRequired,
    removeFavoriteRoom: PropTypes.func.isRequired,
    disableOnTap: PropTypes.bool,
    dir: PropTypes.string,
    reservationType: PropTypes.string,
    isException: PropTypes.bool,
  };

  static defaultProps = {
    selected: false,
    isRecurring: false,
    disableOnTap: false,
  };

  constructor(props) {
    super(props);
    this.btnRef = React.createRef();
  }

  render() {
    const {
      room,
      selected,
      className,
      maxVisibleAmenities,
      onClick,
      isRecurring,
      disableOnTap,
      dir,
      reservationType,
      favorites,
      addFavoriteRoom,
      removeFavoriteRoom,
      isException,
    } = this.props;

    return (
      <div
        className={classNames(
          cssBase,
          className,
          {
            [`${cssBase}--disabled`]: !room.isAvailable || !room.isReservable,
          },
          { [`${cssBase}--reserved`]: room.reservedRoom === true }
        )}
      >
        {room.reservedRoom === true ? (
          <ReservedRoomNotification />
        ) : (
          !room.isAvailable && <RoomUnavailableInlineNotification />
        )}
        {room.reservationClassNameENUS === RESERVATION_CLASS_REQUESTABLE && (
          <RoomRequestableInlineNotification
          message={AppMsg.RESERVATION_MESSAGE.REQUESTABLE}
        />
        )}
        {room.reservationClassNameENUS === RESERVATION_CLASS_PRIVATE && (
          <RoomPrivateInlineNotification />
        )}
        <div className={`${cssBase}__mainContainer`}>
          {this.handleSelectionButton(room, selected, isException)}
          <div
            className={classNames({
              [`${cssBase}__content`]: true,
              [`${cssBase}__enableClick`]: !disableOnTap,
            })}
            onClick={disableOnTap ? () => onClick(room) : null}
          >
            <div className={`${cssBase}__header`}>
              <span
                className={classNames({
                  [`${cssBase}__name`]: true,
                  [`${cssBase}__reservedRoomName`]: room.reservedRoom === true,
                })}
                ref={(ref) => {
                  this.setRef(ref, room._id);
                }}
                onClick={
                  !disableOnTap ? () => onClick(room, this[room._id]) : null
                }
                onKeyDown={(e) =>
                  e.key === "Enter"
                    ? !disableOnTap
                      ? onClick(room, this[room._id])
                      : null
                    : null
                }
                tabIndex={0}
                role="link"
              >
                {`${room.name}`}
              </span>
              <FavoriteIconButton
                dir={dir}
                addFavorite={addFavoriteRoom}
                removeFavorite={removeFavoriteRoom}
                favorites={favorites}
                item={room}
              />
            </div>
            {room.isWorkSpace && (
              <>
                <span className={`${cssBase}__workspaceType`}>
                  {`${
                    this.props.appMessages[AppMsg.RECURRENCE.TYPE_HEADING]
                  }: ${room.spaceclassname}`}
                </span>
                {room.collateralType != null && (
                  <span className={`${cssBase}__collateral`}>
                    {`${
                      this.props.appMessages[
                        AppMsg.RESERVATION_MESSAGE
                          .STEP_ROOM_SEARCH_FILTER_COLLATERAL_LABEL
                      ]
                    }: ${room.collateralType}`}
                  </span>
                )}
              </>
            )}
            {room.isOfficeSpace && (
              <>
                <span className={`${cssBase}__workspaceType`}>
                  {`${
                    this.props.appMessages[AppMsg.RECURRENCE.TYPE_HEADING]
                  }: ${room.spaceclassname}`}
                </span>
                {room.collateralType != null && (
                  <span className={`${cssBase}__collateral`}>
                    {`${
                      this.props.appMessages[
                        AppMsg.RESERVATION_MESSAGE
                          .STEP_ROOM_SEARCH_FILTER_COLLATERAL_LABEL
                      ]
                    }: ${room.collateralType}`}
                  </span>
                )}
              </>
            )}
            {room.isMeetingSpace && (
              <>
                <div className={`${cssBase}__floorCapacity`}>
                  <div className={`${cssBase}__floor`}>{room.floor}</div>
                  <div className={`${cssBase}__capacity`}>
                    <User16 />
                    {`${this.props.appMessages[AppMsg.CAPACITY]}: ${
                      room.capacity
                    }`}
                  </div>
                </div>
                {room.collateralType != null && (
                  <span className={`${cssBase}__collateral`}>
                    {`${
                      this.props.appMessages[
                        AppMsg.RESERVATION_MESSAGE
                          .STEP_ROOM_SEARCH_FILTER_COLLATERAL_LABEL
                      ]
                    }: ${room.collateralType}`}
                  </span>
                )}
              </>
            )}
            {this.handleAmenities(room, maxVisibleAmenities, reservationType)}
            {isRecurring && this.computeOccurrencesLabel(room)}
          </div>
        </div>
      </div>
    );
  }

  setRef(ref, roomId) {
    if (ref && roomId) {
      this[roomId] = React.createRef();
      this[roomId] = ref;
    }
  }

  handleSelectionButton = (room, selected, isException) => {
    return !isException ? (
      <Checkbox
        id={`checkbox-${room._id}`}
        checked={selected}
        onChange={(e) => this.handleOnChange(e)}
        wrapperClassName={`${cssBase}__checkbox`}
        labelText={`${room.roomId}, ${room.name}`}
        hideLabel
        disabled={!room.isReservable && !selected}
      />
    ) : (
      <RadioButtonGroup
        className={`${cssBase}__radiobutton`}
        orientation="vertical"
        name="recurrence-daily-options-group"
        valueSelected={selected ? room.name : null}
        onChange={(e) => this.handleOnChange(e)}
      >
        <RadioButton
          id={`radio-button-${room._id}`}
          key={`radio-button-${room._id}`}
          labelText=""
          value={room.name}
          disabled={!room.isReservable && !selected}
        />
      </RadioButtonGroup>
    );
  };

  handleAmenities = (room, displayCount, reservationType) => {
    const amenities = RoomsUtils.getAmenitiesByRoom(room, reservationType);
    if (isEmpty(amenities)) {
      return null;
    }
    return (
      <RoomAmenities
        className={`${cssBase}__amenities`}
        displayAllAmenities={false}
        amenities={amenities}
        displayCount={displayCount}
      />
    );
  };

  handleOnChange = (selected) => {
    const { onChange, room } = this.props;
    if (onChange) {
      onChange(room, selected);
    }
  };

  computeOccurrencesLabel = (room) => {
    const { _availCount: availCount, _maxOccurrenceCount: maxCount } = room;
    return (
      <div className={`${cssBase}__occurrences`}>
        <Time16 />
        <Button
          ref={this.btnRef}
          className={`${cssBase}__occurrencesButton`}
          kind="ghost"
          size="small"
          onClick={(event) => {
            event.stopPropagation();
            this.props.onRecurrenceClick(room, this.btnRef);
          }}
        >
          {RoomsUtils.computeOccurrencesLabel(availCount, maxCount)}
        </Button>
      </div>
    );
  };
}

export default withTriDictionary(RoomListItem);
