/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import isEmpty from "lodash/isEmpty";
import { Repeat16 } from "@carbon/icons-react";
import { RoomsUtils } from "../../utils";

const cssBase = "recurrenceLabel";

export default class RecurrenceLabel extends React.PureComponent {
  static propTypes = {
    className: PropTypes.string,
    exceptions: PropTypes.array,
    availCount: PropTypes.number,
    maxCount: PropTypes.number,
    onClick: PropTypes.func,
  };

  render() {
    const { className, onClick, exceptions, availCount, maxCount } = this.props;
    const showExceptions = !isEmpty(exceptions);
    return (
      <div
        tabIndex={0}
        className={classNames(`${cssBase}`, className, {
          [`${cssBase}--hasExceptions`]: showExceptions,
        })}
        onClick={showExceptions ? onClick : null}
        onKeyDown={(e) => {
          if (e.key === "Enter" && showExceptions) {
            e.preventDefault();
            onClick();
          }
        }}
      >
        <Repeat16 className={`${cssBase}__icon`} />
        <span className={`${cssBase}__occurrences`}>
          {RoomsUtils.computeOccurrencesLabel(availCount, maxCount)}
        </span>
        {showExceptions && (
          <span className={`${cssBase}__exceptions`}>
            {RoomsUtils.computeExceptionLabel(exceptions)}
          </span>
        )}
      </div>
    );
  }
}
