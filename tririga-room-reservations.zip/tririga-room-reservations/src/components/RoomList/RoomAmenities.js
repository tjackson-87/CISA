/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2022 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import classNames from "classnames";
import isEmpty from "lodash/isEmpty";

const cssBase = "roomAmenities";

class RoomAmenities extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    className: PropTypes.string,
    amenities: PropTypes.array.isRequired,
    displayCount: PropTypes.number,
    displayAllAmenities: PropTypes.bool,
  };

  static defaultProps = {
    displayAllAmenities: true,
  };

  render() {
    const {
      className,
      amenities,
      displayCount,
      displayAllAmenities,
    } = this.props;
    return (
      <div className={classNames(`${cssBase}`, className)}>
        <div className={`${cssBase}__amenities`}>
          {!displayAllAmenities &&
            displayCount &&
            this.handleAmenitiesDisplayWithCount(amenities, displayCount)}
          {displayAllAmenities && (
            <ul>
              {amenities.map((amenity, index) => {
                const Icon = amenity.icon;
                const title = amenity.label;
                return (
                  <li key={index} className={`${cssBase}__amenititesDetail`}>
                    <Icon />
                    {this.props.appMessages[`${title}`]}
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      </div>
    );
  }

  handleAmenitiesDisplayWithCount = (amenities, displayCount) => {
    if (isEmpty(amenities)) {
      return null;
    }
    let amenitiesCount = 0;
    return (
      <>
        {amenities.map((amenity, index) => {
          const Icon = amenity.icon;
          amenitiesCount++;
          return displayCount >= amenitiesCount ? (
            <Icon
              key={index}
              aria-label={this.props.appMessages[`${amenity.label}`]}
              tabIndex="-1"
            />
          ) : null;
        })}

        {amenitiesCount - displayCount > 0 ? (
          <span className={`${cssBase}__amenititesMoreCount`}>
            + {amenitiesCount - displayCount} more
          </span>
        ) : null}
      </>
    );
  };
}

export default withTriDictionary(RoomAmenities);
