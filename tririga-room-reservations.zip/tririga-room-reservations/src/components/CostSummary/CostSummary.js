/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import PropTypes from "prop-types";
import { withTriDictionary } from "@tririga/tririga-react-components";
import { connect } from "react-redux";
import {
  DataTable,
  Table,
  TableContainer,
  TableHeader,
  TableHead,
  TableRow,
  TableBody,
  TableCell,
  TextInput,
  TooltipIcon,
} from "carbon-components-react";
import { Warning16 } from "@carbon/icons-react";
import { ReservationSelectors } from "../../store";
import { CateringUtils, AppMsg } from "../../utils";
import defaultTo from "lodash/defaultTo";
import isEmpty from "lodash/isEmpty";
import isNil from "lodash/isNil";
const cssBase = "costSummary";
class CostSummary extends React.PureComponent {
  static propTypes = {
    onCostCodeValueChanged: PropTypes.func,
    appMessages: PropTypes.object,
    data: PropTypes.object,
    currentUserLocale: PropTypes.string,
    currencies: PropTypes.array,
    editMode: PropTypes.bool,
    isCateringCostsSameCurrencySelector: PropTypes.bool,
    isEquipmentCostsSameCurrencySelector: PropTypes.bool,
  };

  render() {
    const { data } = this.props;

    if (data != null) {
      const estimatedCostResource = this.getCostForResource(
        data.estimatedCostResource
      );
      const estimatedCostFood = this.getCostForResource(data.estimatedCostFood);
      const estimatedCostEquipment = this.getCostForResource(
        data.estimatedCostEquipment
      );
      const accountCodeRoom = data.accountCodeRoom;
      const accountCodeFood = data.accountCodeFood;
      const accountCodeEquipment = data.accountCodeEquipment;
      const total = this.getTotalEstimatedCost(
        data.estimatedCostResource,
        data.estimatedCostFood,
        data.estimatedCostEquipment
      );

      if (isNil(total)) return null;

      const costSummaryDisplayData = this.createDisplayData(
        accountCodeRoom,
        accountCodeFood,
        accountCodeEquipment,
        estimatedCostResource,
        estimatedCostFood,
        estimatedCostEquipment,
        total
      );
      const { table, card } = costSummaryDisplayData;
      return (
        <>
          <div className={`${cssBase}__tableView`}>
            <DataTable rows={table.rows} headers={table.header} size="xl">
              {({ rows, headers, getHeaderProps, getTableProps }) => (
                <TableContainer>
                  <Table {...getTableProps()}>
                    <TableHead>
                      <TableRow>
                        {headers.map((header, i) => (
                          <TableHeader
                            className={
                              header.type === "currency"
                                ? `${cssBase}__alignRight`
                                : ""
                            }
                            key={header.header}
                            {...getHeaderProps({ header })}
                            tabIndex={0}
                            aria-label={this.props.appMessages[
                              AppMsg.RESERVATION_MESSAGE
                                .COST_SUMMARY_HEADER_COLUMN
                            ]
                              .replace("{1}", i + 1)
                              .replace("{2}", header.header)}
                          >
                            {header.header}
                          </TableHeader>
                        ))}
                      </TableRow>
                    </TableHead>
                    <TableBody className={`${cssBase}__totalRow`}>
                      {rows.map((row, i) => (
                        <TableRow key={row.id}>
                          {row.cells.map((cell, j) => (
                            <TableCell
                              className={
                                this.getHeaderType(
                                  cell.info.header,
                                  table.header
                                ) === "currency"
                                  ? `${cssBase}__alignRight`
                                  : ""
                              }
                              key={cell.id}
                              aria-label={this.props.appMessages[
                                AppMsg.RESERVATION_MESSAGE
                                  .COST_SUMMARY_HEADER_ROW
                              ]
                                .replace("{1}", i + 1)
                                .replace("{2}", j + 1)}
                              tabIndex={0}
                            >
                              {this.getCellValue(cell, table.header)}
                            </TableCell>
                          ))}
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TableContainer>
              )}
            </DataTable>
          </div>
          <div className={`${cssBase}__cardView`}>
            {card.resourceCost && (
              <div className={`${cssBase}__reservationService`}>
                <div className={`${cssBase}__costSummaryContent`}>
                  <div className={`${cssBase}__costSummaryTitle`}>
                    {
                      this.props.appMessages[
                        AppMsg.RESERVATION_MESSAGE.RESERVATION_SERVICE_HEADER
                      ]
                    }
                  </div>
                  <div>
                    <div className={`${cssBase}__costSummaryValue`}>
                      {
                        this.props.appMessages[
                          AppMsg.RESERVATION_MESSAGE.RESERVATION_CHARGES_TITLE
                        ]
                      }
                    </div>
                    <div className={`${cssBase}__costSummarySubValue`}>
                      {
                        this.props.appMessages[
                          AppMsg.RESERVATION_MESSAGE.RESERVATION_USAGE_FEE
                        ]
                      }{" "}
                      +{" "}
                      {
                        this.props.appMessages[
                          AppMsg.RESERVATION_MESSAGE.RESERVATION_LAYOUT_FEE
                        ]
                      }
                    </div>
                  </div>
                </div>
                <div className={`${cssBase}__costSummaryContent`}>
                  <div className={`${cssBase}__costSummaryTitle`}>
                    {
                      this.props.appMessages[
                        AppMsg.RESERVATION_MESSAGE.ESTIMATED_COST_HEADER
                      ]
                    }
                  </div>
                  <div className={`${cssBase}__costSummaryValue`}>
                    {this.renderCostField(card.resourceCost)}
                  </div>
                </div>
                <div>
                  <div className={`${cssBase}__costSummaryTitle`}>
                    {
                      this.props.appMessages[
                        AppMsg.RESERVATION_MESSAGE.ACCOUNT_CODE_HEADER
                      ]
                    }
                  </div>
                  <div className={`${cssBase}__costSummaryValue`}>
                    {this.renderAccountCodeField(
                      "accountCodeRoom",
                      accountCodeRoom
                    )}
                  </div>
                </div>
              </div>
            )}
            {card.equipmentCost && (
              <div className={`${cssBase}__reservationService`}>
                <div className={`${cssBase}__costSummaryContent`}>
                  <div className={`${cssBase}__costSummaryTitle`}>
                    {
                      this.props.appMessages[
                        AppMsg.RESERVATION_MESSAGE.RESERVATION_SERVICE_HEADER
                      ]
                    }
                  </div>
                  <div className={`${cssBase}__costSummaryValue`}>
                    {
                      this.props.appMessages[
                        AppMsg.RESERVATION_MESSAGE.EQUIPMENT_TITLE
                      ]
                    }
                  </div>
                </div>
                <div className={`${cssBase}__costSummaryContent`}>
                  <div className={`${cssBase}__costSummaryTitle`}>
                    {
                      this.props.appMessages[
                        AppMsg.RESERVATION_MESSAGE.ESTIMATED_COST_HEADER
                      ]
                    }
                  </div>
                  <div className={`${cssBase}__costSummaryValue`}>
                    {this.renderCostField(card.equipmentCost)}
                  </div>
                </div>
                <div>
                  <div className={`${cssBase}__costSummaryTitle`}>
                    {
                      this.props.appMessages[
                        AppMsg.RESERVATION_MESSAGE.ACCOUNT_CODE_HEADER
                      ]
                    }
                  </div>
                  <div className={`${cssBase}__costSummaryValue`}>
                    {this.renderAccountCodeField(
                      "accountCodeEquipment",
                      accountCodeEquipment
                    )}
                  </div>
                </div>
              </div>
            )}
            {card.cateringCost && (
              <div className={`${cssBase}__reservationService`}>
                <div className={`${cssBase}__costSummaryContent`}>
                  <div className={`${cssBase}__costSummaryTitle`}>
                    {
                      this.props.appMessages[
                        AppMsg.RESERVATION_MESSAGE.RESERVATION_SERVICE_HEADER
                      ]
                    }
                  </div>
                  <div className={`${cssBase}__costSummaryValue`}>
                    {
                      this.props.appMessages[
                        AppMsg.RESERVATION_MESSAGE.FOOD_SERVICES
                      ]
                    }
                  </div>
                </div>
                <div className={`${cssBase}__costSummaryContent`}>
                  <div className={`${cssBase}__costSummaryTitle`}>
                    {
                      this.props.appMessages[
                        AppMsg.RESERVATION_MESSAGE.ESTIMATED_COST_HEADER
                      ]
                    }
                  </div>
                  <div className={`${cssBase}__costSummaryValue`}>
                    {this.renderCostField(card.cateringCost)}
                  </div>
                </div>
                <div>
                  <div className={`${cssBase}__costSummaryTitle`}>
                    {
                      this.props.appMessages[
                        AppMsg.RESERVATION_MESSAGE.ACCOUNT_CODE_HEADER
                      ]
                    }
                  </div>
                  <div className={`${cssBase}__costSummaryValue`}>
                    {this.renderAccountCodeField(
                      "accountCodeFood",
                      accountCodeFood
                    )}
                  </div>
                </div>
              </div>
            )}
            <div className={`${cssBase}__reservationCostTotal`}>
              {
                this.props.appMessages[
                  AppMsg.RESERVATION_MESSAGE.COST_SUMMARY_TOTAL_TITLE
                ]
              }{" "}
              {this.renderCostField(card.totalCost)}
            </div>
          </div>
        </>
      );
    }

    return "";
  }

  renderCostField(estimatedCost) {
    if (estimatedCost && estimatedCost.showIcon) {
      return (
        <span className={`${cssBase}__tooltipAlign`}>
          <TooltipIcon
            direction="right"
            className={`${cssBase}__tooltipContainer`}
            align="center"
            tooltipText={
              this.props.appMessages[
                AppMsg.RESERVATION_MESSAGE.NO_SUMMARY_VALUE_CALCULATED
              ]
            }
          >
            <Warning16 className={`${cssBase}__unavailableIcon`} />
          </TooltipIcon>
        </span>
      );
    }
    return <span>{estimatedCost.costValue}</span>;
  }

  renderAccountCodeField(accountCodeName, accountCodeValue) {
    if (this.props.editMode) {
      return (
        <div>
          <TextInput
            className={`${cssBase}__backgroundColor`}
            id={accountCodeName}
            hideLabel={true}
            onChange={(e) =>
              this.props.onCostCodeValueChanged(accountCodeName, e.target.value)
            }
            placeholder={
              this.props.appMessages[
                AppMsg.RESERVATION_MESSAGE.ACCOUNT_CODE_PLACEHOLDER
              ]
            }
            title=""
            type="text"
            value={defaultTo(accountCodeValue, "")}
            maxLength="150"
          />
        </div>
      );
    }
    return <div className={`${cssBase}__accountCode`}>{accountCodeValue}</div>;
  }

  getCellValue(cell, header) {
    const isEditable = this.isEditable(cell.info.header, header);
    const value = cell.value;
    if (!isEditable) {
      if (!isNil(value) && cell.info.header === "label") {
        return (
          <div tabIndex={0}>
            <span>{value.labelHeader}</span>
            <br />
            {value.description && (
              <span className={`${cssBase}__subValue`}>
                {value.description}
              </span>
            )}
          </div>
        );
      } else if (!isNil(value) && cell.info.header === "cost") {
        if (value.showIcon && this.props.editMode) {
          return (
            <div>
              <TooltipIcon
                direction="top"
                className={`${cssBase}__tooltipContainer`}
                align="center"
                tooltipText={
                  this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE.NO_SUMMARY_VALUE_CALCULATED
                  ]
                }
              >
                <Warning16 className={`${cssBase}__unavailableIcon`} />
              </TooltipIcon>
            </div>
          );
        }
        return <span tabIndex={0}>{value.costValue}</span>;
      } else if (!isNil(value) && cell.info.header === "code") {
        return (
          value.accountCodeValue && (
            <span tabIndex={0}>{value.accountCodeValue}</span>
          )
        );
      }
      return <span tabIndex={0}>{value}</span>;
    } else {
      if (!isNil(value) && cell.info.header === "code") {
        if (value.accountCodeName === "accountCodeTotal") return;
        return (
          <TextInput
            id={value.accountCodeName}
            aria-label={
              this.props.appMessages[
                AppMsg.RESERVATION_MESSAGE.ACCOUNT_CODE_ENTER
              ]
            }
            hideLabel={true}
            labelText={
              this.props.appMessages[
                AppMsg.RESERVATION_MESSAGE.ACCOUNT_CODE_HEADER
              ]
            }
            onChange={(e) =>
              this.props.onCostCodeValueChanged(
                value.accountCodeName,
                e.target.value
              )
            }
            type="text"
            value={defaultTo(value.accountCodeValue, "")}
            placeholder={
              this.props.appMessages[
                AppMsg.RESERVATION_MESSAGE.ACCOUNT_CODE_PLACEHOLDER
              ]
            }
            maxLength="150"
          />
        );
      }
    }
  }

  getHeaderType(label, headerData) {
    const result = headerData.filter((obj) => {
      return obj.key === label;
    });
    if (result.length > 0) {
      return result[0].type;
    }
    return "";
  }

  isEditable(label, headerData) {
    const result = headerData.filter((obj) => {
      return obj.key === label;
    });
    if (result.length > 0) {
      return result[0].editable;
    }
    return false;
  }

  getCostForResource(resource) {
    const { currentUserLocale, currencies } = this.props;
    if (isNil(resource) || parseFloat(resource.value) === 0) return null;
    if (!isEmpty(resource.uom)) {
      return CateringUtils.getFoodCost(
        currentUserLocale,
        CateringUtils.getCurrency(currencies, { currency: resource.uom }),
        resource.value.toFixed(2)
      );
    }
  }

  getTotalEstimatedCost(resourceCost, cateringCost, equipmentCost) {
    const resourceCurrency = resourceCost?.uom || null;
    const cateringCurrency = cateringCost?.uom || null;
    const equipmentCurrency = equipmentCost?.uom || null;
    const totalCurrency =
      resourceCurrency || cateringCurrency || equipmentCurrency;

    const sum =
      (resourceCost ? resourceCost.value : 0) +
      (cateringCost ? cateringCost.value : 0) +
      (equipmentCost ? equipmentCost.value : 0);

    if (parseFloat(sum) === 0) return null;
    return this.getCostForResource({ uom: totalCurrency, value: sum });
  }

  createDisplayData(
    accountCodeRoom,
    accountCodeFood,
    accountCodeEquipment,
    estimatedCostResource,
    estimatedCostFood,
    estimatedCostEquipment,
    total
  ) {
    const headerData = [
      {
        key: "label",
        header: this.props.appMessages[
          AppMsg.RESERVATION_MESSAGE.RESERVATION_SERVICE_HEADER
        ],
        type: "text",
        editable: false,
      },
      {
        key: "cost",
        header: this.props.appMessages[
          AppMsg.RESERVATION_MESSAGE.ESTIMATED_COST_HEADER
        ],
        type: "currency",
        editable: false,
      },
      {
        key: "code",
        header: this.props.appMessages[
          AppMsg.RESERVATION_MESSAGE.ACCOUNT_CODE_HEADER
        ],
        type: "code",
        editable: this.props.editMode,
      },
    ];
    const rowData = [];
    let resourceCost = null;
    let cateringCost = null;
    let equipmentCost = null;
    let totalCost = null;
    if (!isNil(estimatedCostResource)) {
      const resourceDescription = {
        labelHeader: this.props.appMessages[
          AppMsg.RESERVATION_MESSAGE.RESERVATION_CHARGES_TITLE
        ],
        description: `${
          this.props.appMessages[
            AppMsg.RESERVATION_MESSAGE.RESERVATION_USAGE_FEE
          ]
        } + ${
          this.props.appMessages[
            AppMsg.RESERVATION_MESSAGE.RESERVATION_LAYOUT_FEE
          ]
        }`,
      };
      const costDescription = {
        showIcon: false,
        costValue: estimatedCostResource,
      };
      const accountCodeDescription = {
        accountCodeName: "accountCodeRoom",
        accountCodeValue: accountCodeRoom,
      };
      resourceCost = costDescription;
      rowData.push({
        id: "accountCodeRoom",
        label: resourceDescription,
        cost: costDescription,
        code: accountCodeDescription,
      });
    }
    if (!isNil(estimatedCostFood)) {
      const resourceDescription = {
        labelHeader: this.props.appMessages[
          AppMsg.RESERVATION_MESSAGE.CATERING_TITLE
        ],
      };
      const costDescription = {
        showIcon: false,
        costValue: estimatedCostFood,
      };
      const accountCodeDescription = {
        accountCodeName: "accountCodeFood",
        accountCodeValue: accountCodeFood,
      };
      cateringCost = costDescription;
      rowData.push({
        id: "accountCodeFood",
        label: resourceDescription,
        cost: costDescription,
        code: accountCodeDescription,
      });
    }
    if (!isNil(estimatedCostEquipment)) {
      const resourceDescription = {
        labelHeader: this.props.appMessages[
          AppMsg.RESERVATION_MESSAGE.EQUIPMENT_TITLE
        ],
      };
      const costDescription = {
        showIcon: false,
        costValue: estimatedCostEquipment,
      };
      const accountCodeDescription = {
        accountCodeName: "accountCodeEquipment",
        accountCodeValue: accountCodeEquipment,
      };
      equipmentCost = costDescription;
      rowData.push({
        id: "accountCodeEquipment",
        label: resourceDescription,
        cost: costDescription,
        code: accountCodeDescription,
      });
    }
    const totalCostDescription = {
      showIcon: false,
      costValue: total,
    };
    const accountCodeDescription = {
      accountCodeName: "accountCodeTotal",
    };
    totalCost = totalCostDescription;
    rowData.push({
      id: "accountCodeTotal",
      label: {
        labelHeader: this.props.appMessages[
          AppMsg.RESERVATION_MESSAGE.COST_SUMMARY_TOTAL_TITLE
        ],
      },
      cost: totalCostDescription,
      code: accountCodeDescription,
    });
    return {
      table: {
        header: headerData,
        rows: rowData,
      },
      card: {
        resourceCost,
        cateringCost,
        equipmentCost,
        totalCost,
      },
    };
  }
}

const mapStateToProps = (state) => {
  return {
    isCateringCostsSameCurrencySelector: ReservationSelectors.isCateringCostsSameCurrencySelector(
      state
    ),
    isEquipmentCostsSameCurrencySelector: ReservationSelectors.isEquipmentCostsSameCurrencySelector(
      state
    ),
  };
};

export default withTriDictionary(connect(mapStateToProps, {})(CostSummary));
