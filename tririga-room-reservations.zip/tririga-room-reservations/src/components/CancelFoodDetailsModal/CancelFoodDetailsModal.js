/* IBM Confidential· - OCO Source Materials· - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise· divested of its trade secrets, irrespective of what has been· deposited with the U.S. Copyright Office. */

import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import { PropTypes } from "prop-types";
import {
  Button,
  ComposedModal,
  ModalHeader,
  ModalFooter,
} from "carbon-components-react";
import { AppMsg } from "../../utils";

class CancelFoodDetailsModel extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    header: PropTypes.string,
    viewCancelOrderModal: PropTypes.bool,
    handleModalCancelClick: PropTypes.func,
    onClose: PropTypes.func,
    cssBase: PropTypes.string,
  };

  render() {
    const {
      header,
      viewCancelOrderModal,
      handleModalCancelClick,
      onClose,
      cssBase,
    } = this.props;
    return (
      viewCancelOrderModal && (
        <ComposedModal
          aria-label={header}
          preventCloseOnClickOutside
          open={viewCancelOrderModal}
          size="xs"
          selectorPrimaryFocus=".bx--modal-close"
          onClose={() => onClose()}
        >
          <ModalHeader
            iconDescription={this.props.appMessages[AppMsg.BUTTON.CLOSE]}
          >
            <h4 className={`${cssBase}__modalRemoveCateringHeader`}>
              {header}
            </h4>
          </ModalHeader>
          <ModalFooter>
            <Button kind="secondary" onClick={() => onClose()}>
              {this.props.appMessages[AppMsg.BUTTON.CANCEL]}
            </Button>
            <Button kind="danger" onClick={() => handleModalCancelClick()}>
              {this.props.appMessages[AppMsg.BUTTON.BUTTON_DELETE]}
            </Button>
          </ModalFooter>
        </ComposedModal>
      )
    );
  }
}

export default withTriDictionary(CancelFoodDetailsModel);
