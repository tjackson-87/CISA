/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2022 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
   Reviewed for upgrade 7/29/2024
   Name: Mike Tremblay
*/
import React from "react";
import PropTypes from "prop-types";
import classnames from "classnames";
import { Button, Modal } from "carbon-components-react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import { AppMsg } from "../../utils";
const cssBase = "reservationCostSummaryFooterButtons";

class ReservationCostSummaryFooterButtons extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    className: PropTypes.string,
    tertiaryLabel: PropTypes.string.isRequired,
    tertiaryClickedHandler: PropTypes.func,
    secondaryLabel: PropTypes.string.isRequired,
    secondaryClickedHandler: PropTypes.func,
    primaryLabel: PropTypes.string.isRequired,
    primaryClickedHandler: PropTypes.func,
    primaryDisabled: PropTypes.bool,
  };

  state = {
    openConfirmDeleteModal: false,
  };

  render() {
    const {
      className,
      tertiaryLabel,
      secondaryLabel,
      secondaryClickedHandler,
      primaryLabel,
      primaryClickedHandler,
      primaryDisabled,
    } = this.props;

    return (
      <div className={classnames(cssBase, className)}>
        <div className={`${cssBase}__container`}>
          <span hidden id="tertiaryBtnHiddenLabel">
            {tertiaryLabel}
          </span>
          <Button
            className={`${cssBase}__button`}
            kind="danger"
            size="small"
            onClick={() => {
              this.setState({ openConfirmDeleteModal: true });
            }}
            aria-label={tertiaryLabel}
            aria-labelledby="tertiaryBtnHiddenLabel"
          >
            {tertiaryLabel}
          </Button>
          <div className={`${cssBase}__divider`} />
          <Button
            className={`${cssBase}__button`}
            kind="tertiary"
            size="small"
            onClick={secondaryClickedHandler}
            aria-label={secondaryLabel}
          >
            {secondaryLabel}
          </Button>
          <div className={`${cssBase}__divider`} />
          <Button
            className={`${cssBase}__button`}
            kind="primary"
            size="small"
            disabled={primaryDisabled}
            onClick={primaryClickedHandler}
            aria-label={primaryLabel}
          >
            {primaryLabel}
          </Button>
        </div>
        {this.renderConfirmDeleteEventModal()}
      </div>
    );
  }

  renderConfirmDeleteEventModal() {
    const label = AppMsg.getMessage(AppMsg.RESERVATION_MESSAGE.DELETE_MEETING);
    const { openConfirmDeleteModal } = this.state;
    return (
      <Modal
        danger
        size="xs"
        aria-label={label}
        modalHeading={label}
        modalAriaLabel={label}
        primaryButtonText={this.props.appMessages[AppMsg.BUTTON.BUTTON_DELETE]}
        secondaryButtonText={this.props.appMessages[AppMsg.BUTTON.CANCEL]}
        onRequestSubmit={() => this.handleDeleteEvent()}
        onSecondarySubmit={() => this.handleCancelDelete()}
        onRequestClose={() => this.handleCancelDelete()}
        open={openConfirmDeleteModal}
        iconDescription={this.props.appMessages[AppMsg.BUTTON.CLOSE]}
      >
        <p>
          {
            this.props.appMessages[
              AppMsg.RESERVATION_MESSAGE.DELETE_MEETING_DESCRIPTION
            ]
          }
        </p>
      </Modal>
    );
  }

  handleDeleteEvent() {
    this.props.tertiaryClickedHandler();
  }

  handleCancelDelete() {
    this.setState({
      openConfirmDeleteModal: false,
    });
  }
}
export default withTriDictionary(ReservationCostSummaryFooterButtons);
