/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import { AppMsg } from "../../utils";
import { ChevronRight16, ChevronLeft16 } from "@carbon/icons-react";

const cssBase = "cateringSummary";

export default class CateringSummary extends React.PureComponent {
  static propTypes = {
    name: PropTypes.string,
    className: PropTypes.string,
    items: PropTypes.array,
    icon: PropTypes.elementType,
    onCateringClick: PropTypes.func,
    dir: PropTypes.string,
  };

  render() {
    const {
      icon: Icon,
      name,
      className,
      items,
      onCateringClick,
      dir,
    } = this.props;
    return (
      <div
        className={classNames(cssBase, className)}
        onClick={onCateringClick}
        tabIndex={0}
        onKeyDown={(e) => (e.key === "Enter" ? onCateringClick() : null)}
        role="button"
      >
        <div className={`${cssBase}__content`}>
          <div className={`${cssBase}__header`}>
            <Icon className={`${cssBase}__headerIcon`} />
            <div className={`${cssBase}__headerName`}>{name}</div>
          </div>
          <div className={`${cssBase}__children`}>
            {items.map((e) => (
              <span key={e.items[0]._id}>
                {`
                  ${
                    e.additionalInformation.orderName ||
                    AppMsg.getMessage(AppMsg.RESERVATION_MESSAGE.FOOD_ORDER)
                  } 
                  ${e.additionalInformation.deliveryTime} 
                  ${e.additionalInformation.deliveryTimePeriod}
                `}
              </span>
            ))}
          </div>
        </div>
        <span
          aria-label={AppMsg.getMessage(AppMsg.BUTTON.OPEN_CATERING_LIST)}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => (e.key === "Enter" ? onCateringClick() : null)}
        >
          {this.renderArrowIcon(dir)}
        </span>
      </div>
    );
  }

  renderArrowIcon = (dir) => {
    if (dir === "rtl") {
      return <ChevronLeft16 className={`${cssBase}__icon`} />;
    } else {
      return <ChevronRight16 className={`${cssBase}__icon`} />;
    }
  };
}
