/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2022 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import classNames from "classnames";
import { Button } from "carbon-components-react";
import { Filter24 } from "@carbon/icons-react";
import { AppMsg } from "../../utils";

const cssBase = "filterButtons";

class FilterButton extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    count: PropTypes.number,
    onClick: PropTypes.func,
    className: PropTypes.string,
    disabled: PropTypes.bool,
    filterRef: PropTypes.any,
  };

  static defaultProps = {
    count: 0,
    disabled: false,
  };

  render() {
    const { count, onClick, className, disabled, filterRef } = this.props;

    const filterQtyLabel =
      count > 0
        ? ` (${count} ${this.props.appMessages[AppMsg.BUTTON.APPLIED]})`
        : "";
    return (
      <Button
        className={classNames(cssBase, className)}
        kind="ghost"
        size="small"
        onClick={onClick}
        renderIcon={Filter24}
        disabled={disabled}
        ref={filterRef}
      >
        {`${this.props.appMessages[AppMsg.BUTTON.FILTER]}${filterQtyLabel}`}
      </Button>
    );
  }
}

export default withTriDictionary(FilterButton);
