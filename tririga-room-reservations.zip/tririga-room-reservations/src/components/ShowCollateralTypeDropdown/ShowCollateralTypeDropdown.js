/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import classNames from "classnames";
import { Dropdown } from "carbon-components-react";
import { AppMsg } from "../../utils";
import { COLLATERAL_TYPE_DROPDOWN } from "../../utils/constants/DropdownValues";

class ShowCollateralTypeDropdown extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    id: PropTypes.string,
    onChange: PropTypes.func,
    className: PropTypes.string,
    disabled: PropTypes.bool,
    selected: PropTypes.object
  };

  static defaultProps = {
    toggled: false,
    collateralItems: COLLATERAL_TYPE_DROPDOWN
  };

  render() {
    const { onChange, collateralItems, selected, className, disabled, id } = this.props;
    
    return (
      <Dropdown
        id={id}
        items={collateralItems}
        className={classNames(className)}
        selectedItem={selected}
        onChange={onChange}
        itemToString={(item) => (item ? item.text : '')}
        label={this.props.appMessages[AppMsg.BUTTON.DROPDOWN_COLLATERAL_TYPE]}
        aria-label={this.props.appMessages[AppMsg.BUTTON.DROPDOWN_COLLATERAL_TYPE]}
        disabled={disabled}

      />
     
    );
  }
}

export default withTriDictionary(ShowCollateralTypeDropdown);
