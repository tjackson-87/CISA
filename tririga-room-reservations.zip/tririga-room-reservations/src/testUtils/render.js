/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import { Provider } from "react-redux";
import { render } from "@testing-library/react";
import { createStore, applyMiddleware } from "redux";
import thunk from "redux-thunk";

import { TriDictionaryProvider } from "@tririga/tririga-react-components";

export const renderWithTriDictionaryProvider = (
  ui,
  { appMessages, ...renderOptions }
) => {
  return {
    ...render(
      <TriDictionaryProvider appMessages={appMessages}>
        {ui}
      </TriDictionaryProvider>,
      renderOptions
    ),
  };
};

export function renderWithReduxAndDictionaryProvider(
  ui,
  {
    initialState,
    reducer,
    store = createStore(reducer, initialState, applyMiddleware(thunk)),
  } = {},
  appMessages,
  ...renderOptions
) {
  return {
    store,
    ...render(
      <Provider store={store}>
        <TriDictionaryProvider appMessages={appMessages}>
          {ui}
        </TriDictionaryProvider>
      </Provider>,
      ...renderOptions
    ),
  };
}
