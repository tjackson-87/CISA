/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import moment from "moment-timezone";

export const MOCK_ACTIVE_USERS = {
  data: [
    {
      name: "Jane Warren",
      personId: "143879536",
      _id: "143879536",
      email: "jane@tririga100.onmicrosoft.com",
    },
    {
      name: "John Smith",
      personId: "143879566",
      _id: "143879566",
      email: "john@tririga100.onmicrosoft.com",
    },
    {
      name: "Leanne Graham",
      personId: "143879506",
      _id: "143879506",
      email: "leanne@tririga100.onmicrosoft.com",
    },
    {
      name: "Ervin Howell",
      personId: "143879503",
      _id: "143879503",
      email: "ervin@tririga100.onmicrosoft.com",
    },
  ],
};
export const MOCK_ATTENDEE = {
  type: "OrganizationUser",
  email: "armalene@Tririga01.onmicrosoft.com",
  displayName: "Armalene",
  firstName: "Armalene",
};

export const MOCK_FOOD_ORDER = {
  foodOrderId: "0",
  deliveryDate: "2022-11-03T09:00:00-07:00",
  instructions: "",
  name: "test 2",
  resourceId: "144015717",
  actionType: "Add",
};

export const MOCK_FOOD_ITEM = {
  foodOrderId: "0",
  productId: "12028620",
  quantity: 3,
  instructions: "",
  actionType: "Add",
  purchaseLineItemId: "",
};

export const MOCK_EQUIPMENT = {
  image: null,
  usageCost: {
    uom: "US Dollars",
    value: 30,
  },
  name: "agtest-Building Equipment Spec test",
  description: "ARMALENE TEST",
  currency: "US Dollars",
  _id: "10946347",
  totalCost: {
    uom: "US Dollars",
    value: 555.5,
  },
  quantity: 2,
  instructions: "",
  roomId: "12384572",
  actionType: "create",
  orderId: null,
  resourceId: "144015717",
};

export const MOCK_ONLINE_MEETING = {
  callInInformation: "test",
  defaultMeeting: false,
  meetingRecordId: "143835189",
  name: "test",
  password: null,
  url: "test.com",
  _id: "143835189",
};

export const MOCK_COLLEAGUE = {
  name: "Sudhir kumar",
  designation: "Facility assistant Manager",
  email: "sudhir@Tririga01.onmicrosoft.com",
  seat: "ws04-ws22",
  address: "Bangalore, India",
  image: null,
};

export const MOCK_BRAZIL_TIMEZONE = "America/Sao_Paulo";

export function generateNumsInStrings(idDigits = 10) {
  return Math.floor(Math.random() * Math.pow(10, idDigits).toString());
}

export function createReservableRoom(name, building, spaceId) {
  const roomId = generateNumsInStrings(7);
  return {
    country: null,
    floorSystemRecordID: generateNumsInStrings(),
    networkConnection: null,
    reservationClassDescription: "No Approval Required",
    building,
    roomId,
    exchangeIntegration: true,
    reserveAdvanceLimit: 0,
    usageCost: null,
    layoutDefault: true,
    cateringAvailable: null,
    property: null,
    spaceclassname: "Alternative Workplace",
    state: null,
    barcode: roomId,
    isMeetingSpace: true,
    image: "//Company-1/file1665394146998.jpg",
    exchangeMailbox: "Cinepolis@Tririga01.onmicrosoft.com",
    ipPhone: null,
    _maxOccurrenceCount: 1,
    floorLevel: generateNumsInStrings(5),
    inRoomProjector: null,
    doNotAllowSeriesReservations: false,
    noiseBarrier: null,
    setupCost: 0,
    name,
    citySystemRecordID: null,
    _id: spaceId || generateNumsInStrings(),
    city: null,
    timezone:
      "(GMT +5:30) Bombay, Kolkata, Madras, New Delhi, Colombo [Asia/Kolkata]",
    reservationClassNameENUS: "Reservable",
    systemRecordId: "143877486",
    whiteboard: null,
    capacity: 111,
    _availCount: 1,
    naturalLight: null,
    layoutType: "Conference",
    currency: "US Dollars",
    floor: "Floor2",
    buildingSystemRecordID: "143877433",
    propertySystemRecordID: null,
    usageUnit: "Hour",
    telephoneConference: null,
    videoConferenceRoom: null,
    adaAvailable: null,
    _isAvailable: true,
    adjustableHeightDesk: null,
    layoutTypeInternal: "Conference",
    isWorkSpace: false,
    reserveCutOffDuration: 1100000000000000,
    layoutImage: "//Company-1/file1665394146998.jpg",
    isAvailable: true,
    isReservable: true,
  };
}

export function createResource(
  room,
  exceptions = [],
  selectedCatering = [],
  selectedEquipment = [],
  availableEquipment = []
) {
  const resourceID = generateNumsInStrings(10);
  return {
    showMoreOptions: true,
    removed: false,
    onHold: true,
    data: {
      userMessage: null,
      resourceId: resourceID,
      layoutTypeInternal: "Conference",
      statusENUS: "Accepted",
      layoutType: "Conference",
      _id: resourceID,
      roomId: room._id,
      status: "Accepted",
    },
    room,
    exceptions,
    availableCatering: [],
    availableEquipment,
    selectedCatering,
    addedEquipment: [],
    addedEquipmentSaved: true,
    selectedEquipment,
  };
}

export function createTririgaActionResponse(actionName, wfParametersMap = {}) {
  return {
    actionGroupName: "actions",
    actionName,
    wfParametersMap,
  };
}

export function createReservationParam() {
  const randomNumber = Math.trunc(Math.random() * 9999999);
  const startDate = moment()
    .tz("America/Sao_Paulo")
    .add(Math.trunc(Math.random() * 3) + 1, "weeks")
    .day(Math.trunc(Math.random() * 4) + 1)
    .hour(Math.trunc(Math.random() * 4) + 9)
    .minute(0)
    .second(0)
    .millisecond(0);
  const endDate = startDate
    .clone()
    .add(Math.trunc(Math.random() * 3) + 1, "hours");
  return {
    allDay: false,
    description: `Reservation ${randomNumber} created when running a unit test.`,
    subject: `Unit Testing Reservation ${randomNumber}`,
    start: startDate.toISOString(),
    end: endDate.toISOString(),
  };
}

export function createDateParams(startDateTime = "2020-12-01 12:00:00") {
  const startDate = moment.tz(startDateTime, MOCK_BRAZIL_TIMEZONE);
  const endDate = startDate.clone().add(1, "hours");
  return {
    start: startDate.toISOString(),
    end: endDate.toISOString(),
    timezone: {
      id: generateNumsInStrings(9),
      value: MOCK_BRAZIL_TIMEZONE,
    },
  };
}

export function createRecurrence(
  type = "DAILY",
  numberOfOccurrencesBeforeEnd = 2,
  details
) {
  const dateParam = createDateParams();
  details = details || {
    ruleLabel: "some recurrence label",
    endDate: dateParam.end,
    rule: "some rule",
    startDate: dateParam.start,
  };
  return {
    type,
    numberOfOccurrencesBeforeEnd,
    details,
    ...dateParam,
  };
}

export function createException(start, end, resource, exceptionId) {
  return {
    exceptionStartDT: start || moment().format(),
    resource: {
      id: resource?.data?._id || generateNumsInStrings(9),
      value: generateNumsInStrings(9),
    },
    _id: exceptionId || generateNumsInStrings(9),
    exceptionEndDT: end || moment().add(1, "h").format(),
    start: start || moment().format(),
    end: end || moment().add(1, "h").format(),
  };
}
