/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import moment from "moment-timezone";
import { ReservableSpacesDS, MyPrimaryBuildingDS, CurrentUserDS } from "..";
import { setupTests } from "../../setupTests";
import { ReservationTypes } from "../../utils";

let currentUser = null;
let userPrimaryBuiding = null;

beforeAll(async () => {
  await setupTests;
  currentUser = await CurrentUserDS.getCurrentUser();
  userPrimaryBuiding = await MyPrimaryBuildingDS.getMyPrimaryBuilding();
}, 60000);

function createRandomMeetingTime() {
  const startDate = moment()
    .add(Math.trunc(Math.random() * 3) + 1, "weeks")
    .day(Math.trunc(Math.random() * 4) + 1)
    .hour(Math.trunc(Math.random() * 5) + 9)
    .minute(0)
    .second(0)
    .millisecond(0);
  return {
    startDate: startDate.toISOString(),
    endDate: startDate
      .clone()
      .add((Math.trunc(Math.random() * 6) + 1) * 30, "minutes")
      .toISOString(),
  };
}

test("Search meeting rooms from User Primary Building", async () => {
  expect(userPrimaryBuiding).toBeTruthy();
  expect(currentUser).toBeTruthy();
  expect(currentUser._TimeZoneId).toBeTruthy();
  const { startDate, endDate } = createRandomMeetingTime();

  const { data: spaces } = await ReservableSpacesDS.queryReservableSpaces(
    ReservationTypes.MEETING,
    {
      locationFilters: [userPrimaryBuiding],
      roomFilters: {},
      startDate,
      endDate,
    },
    false
  );

  expect(spaces).toBeTruthy();
  expect(spaces.length).toBeGreaterThan(0);
}, 30000);

test("Unavailable meeting rooms from User Primary Building", async () => {
  expect(userPrimaryBuiding).toBeTruthy();
  expect(currentUser).toBeTruthy();
  expect(currentUser._TimeZoneId).toBeTruthy();
  const { data: spaces } = await ReservableSpacesDS.queryReservableSpaces(
    ReservationTypes.MEETING,
    {
      locationFilters: [userPrimaryBuiding],
      roomFilters: {},
      startDate: "2020-05-20T22:00:00.000-0300",
      endDate: "2020-05-20T23:00:00.000-0300",
    },
    false
  );
  expect(spaces).toBeTruthy();
  expect(spaces.filter((item) => item._availCount > 0).length).toBe(0);
}, 30000);
