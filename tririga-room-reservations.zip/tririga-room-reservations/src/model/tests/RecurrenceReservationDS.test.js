/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import moment from "moment-timezone";
import { ReservationDS } from "..";
import { setupTests } from "../../setupTests";

const DEC_FIRST_2020 = "2020-12-01 12:00:00";
const DEC_THIRD_2020 = "2020-12-03 12:00:00";
const DEC_FIFTH_2020 = "2020-12-05 12:00:00";
const DEC_FIFTHTEENTH_2020 = "2020-12-15 12:00:00";
const BRAZIL_TIMEZONE_ID = "1598943";
const BRAZIL_TIMEZONE = "America/Sao_Paulo";

beforeAll(async () => {
  await setupTests;
}, 60000);

function createDateParams(startDateTime) {
  const startDate = moment.tz(startDateTime, BRAZIL_TIMEZONE);
  const endDate = startDate.clone().add(1, "hours");
  return {
    start: startDate.toISOString(),
    end: endDate.toISOString(),
    timezone: {
      id: BRAZIL_TIMEZONE_ID,
    },
  };
}

test("Daily every 2 days end after 5 occurrences", async () => {
  const dateParams = createDateParams(DEC_FIRST_2020);
  const recurrenceParams = {
    dailyOption: "Every [x] day(s)",
    dailyRecurWeekDay: false,
    dailyRecurWeekEndDay: false,
    dailyRecurrenceDays: 2,
    endOption: "End After",
    noEndDate: false,
    numberOfOccurrencesBeforeEnd: 5,
    type: "DAILY",
  };
  const recurrenceResult = await ReservationDS.processRecurrence({
    ...dateParams,
    ...recurrenceParams,
  });

  expect(recurrenceResult).toBeTruthy();
  expect(recurrenceResult.result).toBeTruthy();
  expect(recurrenceResult.result.success).toBeTruthy();
  expect(recurrenceResult.result.endDate).toBe("2020-12-09T08:00:00.000-08:00");
  expect(recurrenceResult.result.rule).toBe(
    "RRULE:FREQ=DAILY;COUNT=5;INTERVAL=2;BYDAY=SU,MO,TU,WE,TH,FR,SA"
  );
  expect(recurrenceResult.result.ruleLabel).toBe(
    "Daily, every 2 days, ending after 5 occurrences."
  );
}, 30000);

test("Daily every weekday no end date", async () => {
  const dateParams = createDateParams(DEC_FIRST_2020);
  const recurrenceParams = {
    dailyOption: "Every weekday",
    dailyRecurWeekDay: true,
    dailyRecurWeekEndDay: false,
    dailyRecurrenceDays: 1,
    endOption: "No End Date",
    noEndDate: true,
    numberOfOccurrencesBeforeEnd: 0,
    type: "DAILY",
  };
  const recurrenceResult = await ReservationDS.processRecurrence({
    ...dateParams,
    ...recurrenceParams,
  });

  expect(recurrenceResult).toBeTruthy();
  expect(recurrenceResult.result).toBeTruthy();
  expect(recurrenceResult.result.endDate).toBeNull();
  expect(recurrenceResult.result.success).toBeTruthy();
  expect(recurrenceResult.result.rule).toBe(
    "RRULE:FREQ=DAILY;BYDAY=MO,TU,WE,TH,FR"
  );
  expect(recurrenceResult.result.ruleLabel).toBe(
    "Daily, every weekday, with no end date."
  );
}, 30000);

test("Daily every weekend day end date 01/26/2030", async () => {
  const dateParams = createDateParams(DEC_FIFTH_2020);
  const recurrenceParams = {
    dailyOption: "Every weekend day",
    dailyRecurWeekDay: false,
    dailyRecurWeekEndDay: true,
    dailyRecurrenceDays: 1,
    endDate: "2030-01-26T12:00:00.000-03:00",
    endOption: "End Date",
    noEndDate: false,
    numberOfOccurrencesBeforeEnd: 0,
    type: "DAILY",
  };
  const recurrenceResult = await ReservationDS.processRecurrence({
    ...dateParams,
    ...recurrenceParams,
  });

  expect(recurrenceResult).toBeTruthy();
  expect(recurrenceResult.result).toBeTruthy();
  expect(recurrenceResult.result.success).toBeTruthy();
  expect(recurrenceResult.result.endDate).toBe("2030-01-26T08:00:00.000-08:00");
  expect(recurrenceResult.result.rule).toBe(
    "RRULE:FREQ=DAILY;UNTIL=20300126T160000Z;BYDAY=SU,SA"
  );
  expect(recurrenceResult.result.ruleLabel).toBe(
    "Daily, every weekend day, ending on 01/26/2030."
  );
}, 30000);

test("Weekly every 3 weeks Tu Th end after 6", async () => {
  const dateParams = createDateParams(DEC_FIRST_2020);
  const recurrenceParams = {
    endOption: "End After",
    noEndDate: false,
    numberOfOccurrencesBeforeEnd: 6,
    type: "WEEKLY",
    weeklyFriday: false,
    weeklyMonday: false,
    weeklyRecurrenceWeeks: 3,
    weeklySaturday: false,
    weeklySunday: false,
    weeklyThursday: true,
    weeklyTuesday: true,
    weeklyWednesday: false,
  };
  const recurrenceResult = await ReservationDS.processRecurrence({
    ...dateParams,
    ...recurrenceParams,
  });

  expect(recurrenceResult).toBeTruthy();
  expect(recurrenceResult.result).toBeTruthy();
  expect(recurrenceResult.result.success).toBeTruthy();
  expect(recurrenceResult.result.endDate).toBe("2021-01-14T08:00:00.000-08:00");

  expect(recurrenceResult.result.rule).toBe(
    "RRULE:FREQ=WEEKLY;COUNT=6;INTERVAL=3;BYDAY=TU,TH"
  );
  expect(recurrenceResult.result.ruleLabel).toBe(
    "Every 3 weeks, on Tuesday, Thursday, ending after 6 occurrences."
  );
}, 30000);

test("Monthly day 15 every 2 months end after 3", async () => {
  const dateParams = createDateParams(DEC_FIFTHTEENTH_2020);
  const recurrenceParams = {
    endOption: "End After",
    monthlyDayOfMonth: 15,
    monthlyOption: "Day [x] of every [x] month(s)",
    monthlyRecurrenceMonths: 3,
    noEndDate: false,
    numberOfOccurrencesBeforeEnd: 2,
    type: "MONTHLY",
  };
  const recurrenceResult = await ReservationDS.processRecurrence({
    ...dateParams,
    ...recurrenceParams,
  });

  expect(recurrenceResult).toBeTruthy();
  expect(recurrenceResult.result).toBeTruthy();
  expect(recurrenceResult.result.success).toBeTruthy();
  expect(recurrenceResult.result.endDate).toBe("2021-03-15T10:00:00.000-07:00");
  expect(recurrenceResult.result.rule).toBe(
    "RRULE:FREQ=MONTHLY;COUNT=2;INTERVAL=3;BYMONTHDAY=15"
  );
  expect(recurrenceResult.result.ruleLabel).toBe(
    "Monthly, day 15 of every 3 months, ending after 2 occurrences."
  );
}, 30000);

test("Monthly third tuesday every 2 month end date 1/14/2031", async () => {
  const dateParams = createDateParams(DEC_FIFTHTEENTH_2020);
  const recurrenceParams = {
    endDate: "2030-12-17T12:00:00.000-03:00",
    endOption: "End Date",
    monthlyDayOfMonth: 0,
    monthlyDayOfWeek: "Tuesday",
    monthlyOption: "The [First] [Monday] of every [x] month(s)",
    monthlyRecurrenceMonths: 2,
    monthlyWeekOfMonth: "Third",
    noEndDate: false,
    numberOfOccurrencesBeforeEnd: 0,
    type: "MONTHLY",
  };
  const recurrenceResult = await ReservationDS.processRecurrence({
    ...dateParams,
    ...recurrenceParams,
  });

  expect(recurrenceResult).toBeTruthy();
  expect(recurrenceResult.result).toBeTruthy();
  expect(recurrenceResult.result.success).toBeTruthy();
  expect(recurrenceResult.result.endDate).toBe("2030-12-17T08:00:00.000-08:00");
  expect(recurrenceResult.result.rule).toBe(
    "RRULE:FREQ=MONTHLY;UNTIL=20301217T160000Z;INTERVAL=2;BYDAY=TU;BYSETPOS=3"
  );
  expect(recurrenceResult.result.ruleLabel).toBe(
    "Monthly, on the third Tuesday of every 2 months, ending on 12/17/2030."
  );
}, 30000);

test("Yearly Dec 15 every year end date 12/15/2031", async () => {
  const dateParams = createDateParams(DEC_FIFTHTEENTH_2020);
  const recurrenceParams = {
    endDate: "2031-12-15T12:00:00.000-03:00",
    endOption: "End Date",
    noEndDate: false,
    numberOfOccurrencesBeforeEnd: 0,
    type: "YEARLY",
    yearlyDayOfMonth: 15,
    yearlyMonth: "December",
    yearlyOption: "Every [May] [1]",
  };
  const recurrenceResult = await ReservationDS.processRecurrence({
    ...dateParams,
    ...recurrenceParams,
  });

  expect(recurrenceResult).toBeTruthy();
  expect(recurrenceResult.result).toBeTruthy();
  expect(recurrenceResult.result.success).toBeTruthy();
  expect(recurrenceResult.result.endDate).toBe("2031-12-15T08:00:00.000-08:00");
  expect(recurrenceResult.result.rule).toBe(
    "RRULE:FREQ=YEARLY;UNTIL=20311215T160000Z;BYMONTH=12;BYMONTHDAY=15"
  );
  expect(recurrenceResult.result.ruleLabel).toBe(
    "Yearly, on December 15, ending on 12/15/2031."
  );
}, 30000);

test("Yearly Dec third weekday every year end after 5", async () => {
  const dateParams = createDateParams(DEC_THIRD_2020);
  const recurrenceParams = {
    endOption: "End After",
    noEndDate: false,
    numberOfOccurrencesBeforeEnd: 5,
    type: "YEARLY",
    yearlyDayOfMonth: 0,
    yearlyDayOfWeek: "weekday",
    yearlyMonth: "December",
    yearlyOption: "The [First] [Monday] of [May]",
    yearlyWeekOfMonth: "Third",
  };
  const recurrenceResult = await ReservationDS.processRecurrence({
    ...dateParams,
    ...recurrenceParams,
  });

  expect(recurrenceResult).toBeTruthy();
  expect(recurrenceResult.result).toBeTruthy();
  expect(recurrenceResult.result.success).toBeTruthy();
  expect(recurrenceResult.result.endDate).toBe("2024-12-04T08:00:00.000-08:00");
  expect(recurrenceResult.result.rule).toBe(
    "RRULE:FREQ=YEARLY;COUNT=5;BYMONTH=12;BYDAY=MO,TU,WE,TH,FR;BYSETPOS=3"
  );
  expect(recurrenceResult.result.ruleLabel).toBe(
    "Yearly, on the third weekday of December, ending after 5 occurrences."
  );
}, 30000);

test("No params params", async () => {
  const recurrenceResult = await ReservationDS.processRecurrence();

  expect(recurrenceResult).toBeTruthy();
  expect(recurrenceResult.result).toBeTruthy();
  expect(recurrenceResult.result.success).toBeFalsy();
}, 30000);
