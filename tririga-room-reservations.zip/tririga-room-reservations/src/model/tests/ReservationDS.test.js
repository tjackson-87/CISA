/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import moment from "moment-timezone";
import { ReservationDS } from "..";
import { setupTests } from "../../setupTests";
import { Status } from "../../utils";

beforeAll(async () => {
  await setupTests;
}, 60000);

test("Unhold rooms From User", async () => {
  const removeResult = await ReservationDS.unholdRoomsFromUser();
  expect(removeResult).toBeTruthy();
}, 30000);

function createReservationParam() {
  const randomNumber = Math.trunc(Math.random() * 9999999);
  const startDate = moment()
    .tz("America/Sao_Paulo")
    .add(Math.trunc(Math.random() * 3) + 1, "weeks")
    .day(Math.trunc(Math.random() * 4) + 1)
    .hour(Math.trunc(Math.random() * 4) + 9)
    .minute(0)
    .second(0)
    .millisecond(0);
  const endDate = startDate
    .clone()
    .add(Math.trunc(Math.random() * 3) + 1, "hours");
  return {
    allDay: false,
    description: `Reservation ${randomNumber} created when running a unit test.`,
    subject: `Unit Testing Reservation ${randomNumber}`,
    start: startDate.toISOString(),
    end: endDate.toISOString(),
  };
}

test("Hold Group and Dependent Rooms", async () => {
  const reservationParam = createReservationParam();
  const holdResult = await ReservationDS.holdRooms(reservationParam, [
    {
      spaceId: "132734337",
      layoutTypeInternal: "Class Room",
    },
    {
      spaceId: "132734369",
      layoutTypeInternal: "Class Room",
    },
  ]);

  expect(holdResult).toBeTruthy();
  expect(holdResult.result).toBeTruthy();
  expect(holdResult.result.success).not.toBeTruthy();
  expect(holdResult.result.error).toBe(
    "Some of the rooms selected are part of the same grouped-room configuration and cannot be combined within the same Reservation."
  );
}, 30000);

test("Create New Meeting", async () => {
  const reservationParam = createReservationParam();
  const holdResult = await ReservationDS.holdRooms(reservationParam, [
    {
      spaceId: "132657179",
      layoutTypeInternal: "Conference",
    },
    {
      spaceId: "132657169",
      layoutTypeInternal: "Conference",
    },
    {
      spaceId: "132657190",
      layoutTypeInternal: "Conference",
    },
  ]);

  expect(holdResult).toBeTruthy();
  expect(holdResult.result).toBeTruthy();
  expect(holdResult.result.success).toBeTruthy();
  expect(new Date(holdResult.result.holdTimeEnd).getTime()).toBeGreaterThan(
    new Date().getTime()
  );
  expect(holdResult.resources.length).toBe(3);

  const reservation = await ReservationDS.createNewReservation(
    reservationParam,
    holdResult.resources
  );
  expect(reservation).toBeTruthy();
  expect(reservation._id).not.toBeNaN();
  expect(reservation.status).toBe(Status.ACTIVE);
}, 30000);

test("Unhold room and Create New Meeting", async () => {
  const reservationParam = createReservationParam();
  const holdResult = await ReservationDS.holdRooms(reservationParam, [
    {
      spaceId: "132657179",
      layoutTypeInternal: "Conference",
    },
    {
      spaceId: "132657169",
      layoutTypeInternal: "Conference",
    },
    {
      spaceId: "132657190",
      layoutTypeInternal: "Conference",
    },
  ]);

  expect(holdResult).toBeTruthy();
  expect(holdResult.result).toBeTruthy();
  expect(holdResult.result.success).toBeTruthy();
  expect(new Date(holdResult.result.holdTimeEnd).getTime()).toBeGreaterThan(
    new Date().getTime()
  );
  expect(holdResult.resources.length).toBe(3);

  const resultUnhold = await ReservationDS.unholdRoom(holdResult.resources[2]);
  expect(resultUnhold).toBeTruthy();

  const reservation = await ReservationDS.createNewReservation(
    reservationParam,
    holdResult.resources
  );
  expect(reservation).toBeTruthy();
  expect(reservation._id).not.toBeNaN();
  expect(reservation.status).toBe(Status.ACTIVE);
}, 30000);

test("Hold Alternate Layout", async () => {
  const reservationParam = createReservationParam();
  const holdResult = await ReservationDS.holdRooms(reservationParam, [
    {
      spaceId: "132734337",
      layoutTypeInternal: "Conference",
    },
  ]);

  expect(holdResult).toBeTruthy();
  expect(holdResult.result).toBeTruthy();
  expect(holdResult.result.success).toBeTruthy();
  expect(holdResult.resources.length).toBe(1);
  expect(holdResult.resources[0].status).toBe(Status.TENTATIVE);
  expect(holdResult.resources[0].layoutTypeInternal).toBe("Conference");
}, 30000);
