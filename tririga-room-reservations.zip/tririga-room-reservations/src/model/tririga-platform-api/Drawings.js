/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import { getTriAppConfig } from "@tririga/tririga-react-components";

const DRAWING_SEARCH_BOX_API = "api/p/v1/drawing/search-box";
const DRAWING_SEARCH_NEARBY_API = "api/p/v1/drawing/search-nearby";

export async function searchBox(drawingId, x, y, width, height) {
  const tririgaUrl = getTriAppConfig().tririgaUrl;
  const requestOptions = {
    method: "GET",
    headers: {
      Accept: "application/json",
    },
  };
  const request = new Request(
    `${tririgaUrl}/${DRAWING_SEARCH_BOX_API}?drawingId=${drawingId}&x=${x}&y=${y}&width=${width}&height=${height}`,
    requestOptions
  );
  const response = await fetch(request);
  if (!response.ok) {
    const { error } = await response.json();
    throw error;
  }
  const parsedResponse = await response.json();
  return parsedResponse;
}

export async function searchNearby(
  drawingId,
  spaceId,
  radius = 100,
  increment = 10,
  skip = 0,
  count = 1000
) {
  const tririgaUrl = getTriAppConfig().tririgaUrl;
  const sameLayer = false;
  const request = new Request(
    `${tririgaUrl}/${DRAWING_SEARCH_NEARBY_API}?drawingId=${drawingId}&recordId=${spaceId}&radius=${radius}&count=${count}&increment=${increment}&skip=${skip}&sameLayer=${sameLayer}`
  );
  const response = await fetch(request);
  if (!response.ok) {
    const { error } = await response.json();
    throw error;
  }
  const parsedResponse = await response.json();
  return parsedResponse;
}
