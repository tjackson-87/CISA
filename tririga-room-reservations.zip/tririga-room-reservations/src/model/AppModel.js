/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import { TriModel, getTriAppConfig } from "@tririga/tririga-react-components";

let appModel = null;

export function createAppModel(onError) {
  const { modelAndView, instanceId } = getTriAppConfig();
  return (appModel = new TriModel(modelAndView, instanceId, onError));
}

export function getAppModel() {
  return appModel;
}
