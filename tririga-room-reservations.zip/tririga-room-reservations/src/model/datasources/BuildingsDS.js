/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import { getAppModel } from "../AppModel";
import memo from "memoize-one";
import {
  DatasourceNames,
  lastRequestDebouncer,
  LocationConstants,
} from "../../utils";

const LOCATION_SEARCH_QUERY_PAGE_SIZE =
  LocationConstants.LOCATION_SEARCH_QUERY_PAGE_SIZE;

export const SELECTED_BUILDING_ID = "selectedBuildingId";

export const queryBuildings = lastRequestDebouncer(doQueryBuildings);
const createBuildingsQueryFiltersMemo = memo(createBuildingsQueryFilters);

async function doQueryBuildings(searchText, from = 0) {
  const filters = createBuildingsQueryFiltersMemo(searchText);
  const page = { from, size: LOCATION_SEARCH_QUERY_PAGE_SIZE };
  const sorts = [{ name: "gsaRegion", desc: false }, { name: "name", desc: false}]; // CISA
  const query = { filters, page, sorts };
  const result = await getAppModel().getRecord(
    DatasourceNames.BUILDINGS_DS_NAME,
    query,
    null,
    false,
    false
  );
  return result;
}

export function queryMoreBuildings(searchText, from) {
  return doQueryBuildings(searchText, from);
}

function createBuildingsQueryFilters(searchText) {
  const filters = [];
  filters.push({
    ignoreIfBlank: true,
    name: "name",
    operator: "contains",
    value: searchText,
  });
  filters.push({ operator: "or" });
  filters.push({
    ignoreIfBlank: true,
    name: "city",
    operator: "contains",
    value: searchText,
  });
  filters.push({ operator: "or" });
  filters.push({
    ignoreIfBlank: true,
    name: "property",
    operator: "contains",
    value: searchText,
  });
  filters.push({ operator: "or" });
  filters.push({
    ignoreIfBlank: true,
    name: "state",
    operator: "contains",
    value: searchText,
  });
  // CISA
  filters.push({ operator: "or" });
  filters.push({
    ignoreIfBlank: true,
    name: "gsaRegion",
    operator: "contains",
    value: searchText,
  });
 // CISA
  filters.push({ operator: "or" });
  filters.push({
    ignoreIfBlank: true,
    name: "akaName",
    operator: "contains",
    value: searchText,
  });
  
  return filters;
}

export async function getBuildingsWithGeoLocation() {
  const page = { from: 0, size: 10000 };
  const filters = [
    {
      name: "latitude",
      operator: "not equals",
      value: 0,
    },
    { operator: "and" },
    {
      name: "longitude",
      operator: "not equals",
      value: 0,
    },
  ];
  const query = { filters, page };
  const response = await getAppModel().getRecord(
    DatasourceNames.BUILDINGS_DS_NAME,
    query
  );
  return response.data;
}

export async function getBuildingByID(recordID) {
  const page = { from: 0, size: 10000 };
  const filters = [
    {
      name: "systemRecordID",
      operator: "equals",
      value: recordID,
    },
  ];
  const query = { filters, page };
  const response = await getAppModel().getRecord(
    DatasourceNames.BUILDINGS_DS_NAME,
    query
  );
  return response.data[0];
}
