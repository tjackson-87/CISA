import { getAppModel } from "../AppModel";
import { DatasourceNames } from "../../utils";

export async function getLabelStyles() {
  const response = await getAppModel().getRecord(
    DatasourceNames.LABELSTYLES_DS_NAME
  );
  const labelStyles = response.data;
  return labelStyles && labelStyles.length ? labelStyles : null;
}
