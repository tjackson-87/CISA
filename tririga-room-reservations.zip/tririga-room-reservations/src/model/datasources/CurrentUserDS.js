/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import { getAppModel } from "../AppModel";
import { DatasourceNames } from "../../utils";
import {
  CURRENT_USER_DS_NAME,
  FAVORITE_ROOMS_DS_NAME,
  PRIVATE_ROOMS_DS_NAME,
  DELEGATE_FOR_DS_NAME,
  DELEGATE_USER_CALENDAR,
} from "../../utils/constants/DatasourceNames";

let currentUserId;

export async function getCurrentUser() {
  const response = await getAppModel().getRecord(
    DatasourceNames.CURRENT_USER_DS_NAME
  );
  const currentUser = response.data;
  if (currentUser?._id != null) {
    currentUserId = currentUser._id;
    const personResponse = await getAppModel().getRecord(
      `${DatasourceNames.CURRENT_USER_DS_NAME}/${currentUserId}/${DatasourceNames.CURRENT_PERSON_DS_NAME}`
    );
    const currentPerson = personResponse.data;
    if (currentPerson?._id != null) {
      currentUser.personId = currentPerson._id;
    }
    return currentUser;
  }
  return null;
}

export async function getFavoriteRooms() {
  let favoriteRooms;
  if (currentUserId) {
    const response = await getAppModel().getRecord(
      `${CURRENT_USER_DS_NAME}/${currentUserId}/${FAVORITE_ROOMS_DS_NAME}`
    );
    favoriteRooms = response.data;
  }
  return favoriteRooms;
}

export async function removeFavoriteRoom(roomId) {
  if (currentUserId) {
    const response = await getAppModel().removeRecord(
      `${CURRENT_USER_DS_NAME}/${currentUserId}/${FAVORITE_ROOMS_DS_NAME}`,
      [roomId]
    );
    return response;
  }
}

export async function addFavoriteRoom(roomId) {
  if (currentUserId) {
    const response = await getAppModel().addRecord(
      `${CURRENT_USER_DS_NAME}/${currentUserId}/${FAVORITE_ROOMS_DS_NAME}`,
      [roomId]
    );
    return response;
  }
}

export async function getCurrentUserRole() {
  const response = await getAppModel().getRecord(
    DatasourceNames.MY_FUNCTIONAL_ROLE_DS_NAME
  );
  const role = response.data;
  return role && role._id ? role : null;
}

export async function getPrivateRooms() {
  let privateRooms;
  if (currentUserId) {
    const response = await getAppModel().getRecord(
      `${CURRENT_USER_DS_NAME}/${currentUserId}/${PRIVATE_ROOMS_DS_NAME}`
    );
    privateRooms = response.data;
  }
  return privateRooms;
}

/* Below method is to get list of people I am delegated for in TRIRIGA.
    Not used in this story but will be used in future stories */
export async function getReservationDelegateFor() {
  let delegateFor;
  if (currentUserId) {
    const response = await getAppModel().getRecord(
      `${CURRENT_USER_DS_NAME}/${currentUserId}/${DELEGATE_FOR_DS_NAME}`
    );
    delegateFor = response.data;
  }
  return delegateFor;
}

export async function getDelegateCalendar(reservationID, delegateUsers) {
  const delegatePersonIDS = [];
  delegateUsers.forEach((user) => delegatePersonIDS.push(user.personId));
  const filters = [
    {
      name: "reservationId",
      operator: "equals",
      value: reservationID,
    },
    {
      name: "delegatePersonID",
      operator: "IN",
      value: delegatePersonIDS,
    },
  ];

  const query = { filters };
  const response = await getAppModel().getRecord(
    DELEGATE_USER_CALENDAR,
    query,
    null,
    false,
    false
  );

  return response?.data[0];
}
