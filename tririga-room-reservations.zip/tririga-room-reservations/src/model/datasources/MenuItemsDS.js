/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import { getAppModel } from "../AppModel";
import { DatasourceNames } from "../../utils";

const { MENU_ITEMS_DS_NAME, RESERVABLE_SPACES_DS_NAME } = DatasourceNames;

export async function getMenuItems(roomId) {
  const response = await getAppModel().getRecord(
    `${RESERVABLE_SPACES_DS_NAME}/${roomId}/${MENU_ITEMS_DS_NAME}`
  );
  const menuItems = response.data;
  return menuItems && menuItems.length ? menuItems : null;
}
