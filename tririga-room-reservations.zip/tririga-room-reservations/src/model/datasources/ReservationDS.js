/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2022 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import defaultTo from "lodash/defaultTo";
import { getAppModel } from "../AppModel";
import {
  DatasourceNames,
  getEventEndDate,
  getTimezoneCode,
  ReservationEditMode,
} from "../../utils";

export async function holdRooms(
  reservationParam,
  rooms,
  reservationId,
  removedResources,
  exceptions
) {
  const response = await getAppModel().performAction(
    DatasourceNames.RESERVATION_DS_NAME,
    null,
    null,
    false,
    "actions",
    "holdRooms",
    {
      reservationParam,
      rooms,
      reservation: reservationId,
      removedResources: defaultTo(removedResources, []).map(
        (item) => item.data._id
      ),
      exceptions: exceptions
        .filter((e) => e.room)
        .map((e) => ({
          start: e.start,
          end: e.end,
          exceptionRoomId: e.room._id,
          roomId: e.holdRoomId,
          resourceId: e.resourceId,
        })),
    }
  );

  if (
    response &&
    response.wfParametersMap &&
    response.wfParametersMap.result &&
    response.wfParametersMap.result.length > 0
  ) {
    const { resources, result } = response.wfParametersMap;
    if (resources != null) {
      resources.forEach((item) => {
        item._id = item.resourceId;
      });
    }
    if(response.wfParametersMap.reservationPolicyMessage &&
      response.wfParametersMap.reservationPolicyMessage.length > 0){
      const { userMessage } = response.wfParametersMap.reservationPolicyMessage[0];
      return { resources, result: result[0], message: userMessage};
    }
    return { resources, result: result[0], message: ""};
  } else {
    return {
      result: {
        success: false,
      },
    };
  }
}

export async function unholdRoomsFromUser() {
  const response = await getAppModel().performAction(
    DatasourceNames.RESERVATION_DS_NAME,
    null,
    null,
    false,
    "actions",
    "removeResoucesFromUser"
  );
  return response;
}

export async function createNewReservation(
  reservationParam,
  resources,
  attendees,
  foodOrders,
  foodItems,
  selectedEquipment,
  selectedOnlineMeeting
) {
  const equipment = selectedEquipment?.map((e) => {
    const { resourceId, quantity, instructions } = e;
    return { equipmentId: e._id, resourceId, quantity, instructions };
  });

  const response = await getAppModel().performAction(
    DatasourceNames.RESERVATION_DS_NAME,
    null,
    null,
    false,
    "actions",
    "createNewReservation",
    {
      reservationParam,
      resources: resources?.map((item) => item.data._id),
      attendees: defaultTo(attendees, []),
      foodOrders: defaultTo(foodOrders, []),
      foodItems: defaultTo(foodItems, []),
      equipment: equipment,
      onlineMeeting: defaultTo(selectedOnlineMeeting, null),
    }
  );
  if (
    response &&
    response.wfParametersMap &&
    response.wfParametersMap.reservation &&
    response.wfParametersMap.reservation.length > 0 &&
    response.wfParametersMap.reservationPolicyMessage &&
    response.wfParametersMap.reservationPolicyMessage.length === 0
  ) {
    return response.wfParametersMap.reservation[0];
  } else {
    if (
      response &&
      response.wfParametersMap &&
      response.wfParametersMap.reservationPolicyMessage &&
      response.wfParametersMap.reservationPolicyMessage.length > 0
    ) {
        throw new Error(response.wfParametersMap.reservationPolicyMessage[0].userMessage);
    } else {
      throw new Error("Create new reservation Failed.");
    }
  }
}

export async function updateReservation(
  reservationParam,
  resources,
  removedResources,
  attendees,
  foodOrders,
  foodItems,
  reservationId,
  onlineMeeting,
  selectedEquipment
) {
  const response = await getAppModel().performAction(
    DatasourceNames.RESERVATION_DS_NAME,
    null,
    null,
    false,
    "actions",
    "updateReservation",
    {
      reservationParam,
      resources: defaultTo(resources, []).map((item) => item.data._id),
      removedResources: defaultTo(removedResources, []).map(
        (item) => item.data._id
      ),
      attendees: defaultTo(attendees, []),
      foodOrders: defaultTo(foodOrders, []),
      foodItems: defaultTo(foodItems, []),
      reservation: reservationId,
      onlineMeeting: defaultTo(onlineMeeting, null),
      equipment: selectedEquipment.map((e) => {
        const { resourceId, quantity, instructions, orderId, actionType } = e;
        return {
          equipmentId: e._id,
          resourceId,
          quantity,
          instructions,
          orderId,
          actionType,
        };
      }),
    }
  );
  if (
    response &&
    response.wfParametersMap &&
    response.wfParametersMap.updatedReservation &&
    response.wfParametersMap.updatedReservation.length > 0 &&
    response.wfParametersMap.reservationPolicyMessage &&
    response.wfParametersMap.reservationPolicyMessage.length === 0
  ) {
    return response.wfParametersMap.updatedReservation[0];
  } else {
    if (
      response &&
      response.wfParametersMap &&
      response.wfParametersMap.reservationPolicyMessage &&
      response.wfParametersMap.reservationPolicyMessage.length > 0
    ) {
        throw new Error(response.wfParametersMap.reservationPolicyMessage[0].userMessage);
    } else {
      throw new Error("Update reservation Failed.");
    }
  }
}

export async function unholdRoom(resource) {
  const response = await getAppModel().performAction(
    DatasourceNames.RESERVATION_DS_NAME,
    resource.data._id,
    null,
    false,
    "actions",
    "unholdRooms"
  );
  return response;
}

export async function processRecurrence(recurrenceParams) {
  const response = await getAppModel().performAction(
    DatasourceNames.RESERVATION_DS_NAME,
    null,
    null,
    false,
    "actions",
    "processRecurrence",
    {
      recurrence: recurrenceParams,
    }
  );

  if (
    response &&
    response.wfParametersMap &&
    response.wfParametersMap.result &&
    response.wfParametersMap.result.length > 0
  ) {
    const { result } = response.wfParametersMap;
    return {
      result: { ...result[0], success: true },
    };
  } else {
    return {
      result: {
        success: false,
      },
    };
  }
}

export async function getRecurrenceInfo(
  recurrenceRule,
  timezoneId,
  start,
  end
) {
  const response = await getAppModel().performAction(
    DatasourceNames.RESERVATION_DS_NAME,
    null,
    null,
    false,
    "actions",
    "getRecurrenceInfo",
    {
      recurrenceParam: {
        recurrenceRule,
        timezone: { id: timezoneId },
        start,
        end,
      },
    }
  );

  if (
    response &&
    response.wfParametersMap &&
    response.wfParametersMap.result &&
    response.wfParametersMap.result.length > 0
  ) {
    const { result, recurrenceInfo } = response.wfParametersMap;
    return {
      result: result[0],
      recurrenceId: recurrenceInfo[0]?._id,
    };
  } else {
    return null;
  }
}

export async function getReservation(reservationId, editMode, start, end) {
  const response = await getAppModel().getRecord(
    `${DatasourceNames.RESERVATION_DS_NAME}/${reservationId}`
  );
  const reservation = response.data;
  if (reservation.timezone != null) {
    reservation.timezone = getTimezoneCode(reservation.timezone.value);
  }
  if (editMode === ReservationEditMode.SERIES_OCCURRENCE) {
    reservation.start = start;
    reservation.end = end;
    reservation.recurrenceRule = null;
  }
  reservation.end = getEventEndDate(
    reservation.allDay,
    reservation.end,
    reservation.timezone
  );
  return reservation;
}

export async function getReservationDescriptionAndAttendees(reservationId) {
  const response = await getAppModel().getRecord(
    `${DatasourceNames.RESERVATION_DS_NAME}/${reservationId}`
  );
  const attendees = response.data.attendees.data.map((a) => {
    const name =
      a.firstName && a.firstName === a.lastName ? a.firstName : a.displayName;
    return { ...a, emailAddress: { name } };
  });

  return {
    attendees,
    description: response.data.description,
  };
}

export async function deleteReservation(reservation, reservationDeleteParam) {
  const response = await getAppModel().performAction(
    DatasourceNames.RESERVATION_DS_NAME,
    null,
    null,
    false,
    "actions",
    "deleteReservation",
    {
      reservationDeleteParam,
      reservation,
    }
  );
  return response;
}

export async function recheckRooms(reservationId, rooms) {
  const response = await getAppModel().performAction(
    DatasourceNames.RESERVATION_DS_NAME,
    null,
    null,
    false,
    "actions",
    "recheckRooms",
    {
      reservation: reservationId,
      rooms,
    }
  );
  return response;
}

export async function getOccurrenceExceptions(recurrence, resources) {
  const response = await getAppModel().performAction(
    DatasourceNames.RESERVATION_DS_NAME,
    null,
    null,
    false,
    "actions",
    "getOccurrenceExceptions",
    {
      recurrence,
      resources,
    }
  );
  if (
    response &&
    response.wfParametersMap &&
    response.wfParametersMap.result &&
    response.wfParametersMap.result.length > 0
  ) {
    const { result } = response.wfParametersMap;
    return result;
  } else {
    return [];
  }
}

export async function unholdResources(resources) {
  const response = await getAppModel().performAction(
    DatasourceNames.RESERVATION_DS_NAME,
    null,
    null,
    false,
    "actions",
    "unholdResources",
    { resources }
  );
  return response;
}

export async function getReservationExceptions(reservationDefinitionId) {
  if (reservationDefinitionId) {
    const filters = [
      {
        ignoreIfBlank: true,
        name: "reservationDefinitionId",
        operator: "equals",
        value: reservationDefinitionId,
      },
    ];
    const query = { filters };
    const response = await getAppModel().getRecord(
      DatasourceNames.RESERVATION_EXCEPTIONS,
      query,
      null,
      false,
      false
    );
    return response.data;
  }
  return [];
}
