/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2022 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import { getAppModel } from "../AppModel";
import { DatasourceNames } from "../../utils";

export async function getFoodOrderItems(reservationId) {
  const page = { from: 0, size: 10000 };
  const sorts = [
    { name: "reservationDefinitionRecordID", desc: false },
    { name: "name", desc: false },
  ];
  const query = { page, sorts };
  const response = await getAppModel().getRecord(
    `${DatasourceNames.RESERVATION_DS_NAME}/${reservationId}/${DatasourceNames.FOOD_ORDER_ITEMS_DS_NAME}`,
    query,
    null,
    false,
    false
  );
  return response.data;
}

export async function getPurchaseOrder(reservationId, foodOrderId) {
  const page = { from: 0, size: 10000 };
  const sorts = [
    { name: "reservationDefinitionRecordID", desc: false },
    { name: "name", desc: false },
  ];
  const query = { page, sorts };
  const response = await getAppModel().getRecord(
    `${DatasourceNames.RESERVATION_DS_NAME}/${reservationId}/${DatasourceNames.FOOD_ORDER_ITEMS_DS_NAME}/${foodOrderId}/${DatasourceNames.PURCHASE_ORDERS_DS_NAME}`,
    query,
    null,
    false,
    false
  );
  return response.data;
}
