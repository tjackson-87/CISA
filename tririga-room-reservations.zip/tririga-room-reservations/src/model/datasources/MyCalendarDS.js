/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2022 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import moment from "moment-timezone";
import { getAppModel } from "../AppModel";
import { DatasourceNames } from "../../utils";

export async function getMyCalendar(startDate, endDate, personId) {
  const page = { from: 0, size: 10000 };
  const calendar = {
    startDate,
    endDate,
    id: personId,
  };
  const query = { page, calendar };
  const response = await getAppModel().getRecord(
    DatasourceNames.MY_CALENDAR_DS_NAME,
    query,
    null,
    false,
    false
  );
  return response.data.map(
    ({
      additionalLocationInfo,
      iCalUId,
      locationType,
      subject,
      requestedBy,
      requestedFor,
      reservationId,
      reservationTimezone,
      _All_Day: isAllDay,
      _Start_Datetime: start,
      _End_Datetime: end,
      _Part_of_Recurring_Event: isRecurringReservation,
      _Recurring_Event_Exception: isRecurringException,
      _Master_Recurring_Event_Id: seriesReservationId,
    }) => ({
      additionalLocationInfo,
      iCalUId,
      translatedLocationType: locationType,
      subject,
      requestedBy,
      requestedFor,
      reservationId,
      reservationTimezone,
      isAllDay,
      start,
      end,
      isRecurringReservation,
      isRecurringException,
      seriesReservationId,
    })
  );
}

export async function getMyCalendarEventByReservationId(
  startDate,
  endDate,
  personId,
  reservationId
) {
  const events = await getMyCalendar(startDate, endDate, personId);
  const momentStart = moment(startDate);
  const momentEnd = moment(endDate);
  return events.find(
    (event) =>
      event.reservationId === reservationId &&
      momentStart.isSame(event.start, "minutes") &&
      momentEnd.isSame(event.end, "minutes")
  );
}

export async function getMyCalendarEventByICalUId(
  startDate,
  endDate,
  personId,
  iCalUId,
  seriesICalUId
) {
  const events = await getMyCalendar(startDate, endDate, personId);
  const momentStart = moment(startDate);
  const momentEnd = moment(endDate);
  return events.find(
    (event) =>
      (event.iCalUId === iCalUId || event.iCalUId === seriesICalUId) &&
      momentStart.isSame(event.start, "minutes") &&
      momentEnd.isSame(event.end, "minutes")
  );
}

export async function getMyCalendarEventBySeriesReservationId(
  startDate,
  endDate,
  personId,
  seriesReservationId
) {
  const events = await getMyCalendar(startDate, endDate, personId);
  const momentStart = moment(startDate);
  const momentEnd = moment(endDate);
  return events.find(
    (event) =>
      event.seriesReservationId === seriesReservationId &&
      momentStart.isSame(event.start, "minutes") &&
      momentEnd.isSame(event.end, "minutes")
  );
}

export async function getReservationSeriesByICalUID(iCalUId) {
  const filters = [
    {
      name: "iCalUID",
      operator: "equals",
      value: iCalUId,
    },
    {
      name: "recurrenceRule",
      operator: "not equals",
      value: "",
    },
  ];

  const query = { filters };
  const response = await getAppModel().getRecord(
    DatasourceNames.DELEGATE_USER_CALENDAR,
    query,
    null,
    false,
    false
  );

  return response?.data[0];
}
