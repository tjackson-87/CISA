import { getAppModel } from "../AppModel";
import { DatasourceNames } from "../../utils";

export async function getTimezones() {
  const response = await getAppModel().getRecord(
    DatasourceNames.TIMEZONES_DS_NAME
  );
  const timezones = response.data;
  return timezones && timezones.length ? timezones : null;
}
