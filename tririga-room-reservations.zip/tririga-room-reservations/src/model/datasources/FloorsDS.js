/* IBM Confidential· - OCO Source Materials· - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise· divested of its trade secrets, irrespective of what has been· deposited with the U.S. Copyright Office. */

import { getAppModel } from "../AppModel";
import { DatasourceNames, ReservationTypes } from "../../utils";

export async function getBuildingFloors(
  buildingId,
  reservationType,
  isExchangeIntegrated
) {
  const filters = [
    {
      name: "buildingSystemRecordID",
      operator: "equals",
      value: buildingId,
    },
  ];
  const response = await getAppModel().getRecord(
    reservationType === ReservationTypes.WORKSPACE
      ? DatasourceNames.FLOORS_WORKSPACES_DS_NAME
      : isExchangeIntegrated
      ? DatasourceNames.FLOORS_EXCHANGE_MEETING_SPACES_DS_NAME
      : DatasourceNames.FLOORS_MEETING_SPACES_DS_NAME,
    { filters },
    null,
    false,
    false
  );
  return response.data;
}
