import { getAppModel } from "../AppModel";
import { DatasourceNames } from "../../utils";

export async function geRecurrence(recurrenceId) {
  const response = await getAppModel().getRecord(
    `${DatasourceNames.RECURRENCE_DS_NAME}/${recurrenceId}`
  );
  const recurrence = response.data;
  return recurrence?._id != null ? recurrence : null;
}
