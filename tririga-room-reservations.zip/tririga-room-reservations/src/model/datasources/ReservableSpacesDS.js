/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import isEmpty from "lodash/isEmpty";
import { getAppModel } from "../AppModel";
import {
  DatasourceNames,
  DefaultValues,
  ReservationTypes,
  ContactRolesConstants,
  ReservableSpacesConstants,
} from "../../utils";

// const DEFAULT_PAGE_SIZE = 20; // OOB
const DEFAULT_PAGE_SIZE = 500; // CISA
const {
  RESERVATION_CLASS_PRIVATE,
  RESERVATION_CLASS_REQUESTABLE,
  RESERVATION_CLASS_RESERVABLE,
} = ReservableSpacesConstants;
const { RESOURCE_OWNER, RESERVATION_COORDINATOR } = ContactRolesConstants;
const {
  RESERVABLE_SPACES_DS_NAME,
  RESERVABLE_SPACES_WITHOUT_ROLES_DS_NAME,
  RESERVABLE_SPACES_CONTACT_ROLES_DS_NAME,
} = DatasourceNames;

export async function queryReservableSpaces(
  reservationType,
  { filters, startDate, endDate },
  isExchangeIntegrated,
  pageFrom = 0,
  pageSize,
  recurrence,
  occurrenceMatch,
  favoriteRooms,
  currentUserRole,
  filterWorkspaceByRole = false,
  code = null,
  rooms = null,
  excludeRooms = null,
  searchText,
  buildingId,
  oauthProfileDomain
) {
  if (
    isEmpty(favoriteRooms) &&
    (filters.showFavoritesOnly ||
      (filters.floor == null &&
        isEmpty(code) &&
        isEmpty(rooms) &&
        isEmpty(searchText)))
  ) {
    return { data: [], hasMoreResults: false, totalSize: 0, pageFrom: 0 };
  }
  const queryFilters = createReservableSpacesQueryFilters(
    reservationType,
    filters,
    isExchangeIntegrated,
    recurrence,
    favoriteRooms,
    currentUserRole,
    filterWorkspaceByRole,
    code,
    rooms,
    excludeRooms,
    searchText,
    buildingId,
    oauthProfileDomain
  );
  const page = {
    from: pageFrom,
    size: pageSize > 0 ? pageSize : DEFAULT_PAGE_SIZE,
  };

  const reserveContext = createReservableSpacesQueryReserveContext({
    startDate,
    endDate,
    recurrence,
    occurrenceMatch,
  });
  const sorts = [
    { name: "building", desc: false },
    { name: "floorLevel", desc: false },
    { name: "name", desc: false },
  ];
  const query = { filters: queryFilters, page, reserveContext, sorts };
  const { data, hasMoreResults, totalSize } = await getAppModel().getRecord(
    reservationType === ReservationTypes.WORKSPACE && filterWorkspaceByRole
      ? RESERVABLE_SPACES_DS_NAME
      : RESERVABLE_SPACES_WITHOUT_ROLES_DS_NAME,
    query,
    null,
    false,
    true
  );
  return { data, hasMoreResults, pageFrom: page.from + page.size, totalSize };
}

export async function getContactRoles(roomId, roomSpaceIdList = []) {
  let contactRoles = [];
  const query = {
    filters: [
      {
        name: "roleENUS",
        operator: "in",
        value: roomId
          ? [RESOURCE_OWNER, RESERVATION_COORDINATOR]
          : [RESOURCE_OWNER],
      },
    ],
  };
  let response = [];
  if (roomId) {
    response = await getAppModel().getRecord(
      `${RESERVABLE_SPACES_DS_NAME}/${roomId}/${RESERVABLE_SPACES_CONTACT_ROLES_DS_NAME}`,
      query
    );
    contactRoles = response.data;
  } else {
    response = await getAppModel().getRecord(
      `${RESERVABLE_SPACES_DS_NAME}/-1/${RESERVABLE_SPACES_CONTACT_ROLES_DS_NAME}`,
      query,
      roomSpaceIdList
    );
    contactRoles = response.data;
  }
  return contactRoles;
}

function createReservableSpacesQueryFilters(
  reservationType,
  filters,
  isExchangeIntegrated,
  recurrence,
  favoriteRooms,
  currentUserRole,
  filterWorkspaceByRole,
  code,
  rooms,
  excludeRooms,
  searchText,
  buildingId,
  oauthProfileDomain
) {
  const queryFilters = [];

  queryFilters.push({
    name:
      reservationType === ReservationTypes.MEETING ? "isMeetingSpace"
      : reservationType === ReservationTypes.OFFICE ? "isOfficeSpace"
      : "isWorkSpace",
    operator: "equals",
    value: true,
  });

  if (!isEmpty(searchText)) {
    queryFilters.push({ operator: "and" });
    queryFilters.push({ operator: "open parenthesis" });
    queryFilters.push({
      ignoreIfBlank: true,
      name: "name",
      operator: "contains",
      value: searchText,
    });
    queryFilters.push({ operator: "or" });
    queryFilters.push({
      ignoreIfBlank: true,
      name: "roomId",
      operator: "contains",
      value: searchText,
    });
    queryFilters.push({ operator: "close parenthesis" });
  }

  if (!isEmpty(buildingId)) {
    queryFilters.push({ operator: "and" });
    queryFilters.push({
      ignoreIfBlank: true,
      name: "buildingSystemRecordID",
      operator: "equals",
      value: buildingId,
    });
  }

  if (!isEmpty(rooms)) {
    queryFilters.push({ operator: "and" });
    queryFilters.push({
      name: "systemRecordId",
      operator: "in",
      value: rooms.map((space) => space._id),
    });
  } else if (filters.floor != null) {
    queryFilters.push({ operator: "and" });
    queryFilters.push({
      name: "floorSystemRecordID",
      operator: "equals",
      value: filters.floor._id,
    });
  } else if (!isEmpty(code)) {
    queryFilters.push({ operator: "and" });
    queryFilters.push({
      name: "barcode",
      operator: "equals",
      value: code,
    });
  } else if (!isEmpty(excludeRooms)) {
    queryFilters.push({ operator: "and" });
    queryFilters.push({ operator: "open parenthesis" });
    excludeRooms.forEach((er, i) => {
      queryFilters.push({
        name: "systemRecordId",
        operator: "not equals",
        value: er._id,
      });
      if (i < excludeRooms.length - 1) queryFilters.push({ operator: "and" });
    });
    queryFilters.push({ operator: "close parenthesis" });
  }

  if (reservationType === ReservationTypes.MEETING && isExchangeIntegrated) {
    queryFilters.push({ operator: "and" });
    queryFilters.push({
      name: "exchangeIntegration",
      operator: "equals",
      value: true,
    });
    queryFilters.push({ operator: "and" });
    queryFilters.push(
      oauthProfileDomain
        ? {
            name: "exchangeMailbox",
            operator: "contains",
            value: `@${oauthProfileDomain}`,
          }
        : {
            name: "exchangeMailbox",
            operator: "not equals",
            value: "",
          });
        }
  if (
    filters.showCollateralTypeOnly
  ) {
    const collateralTypeFilter = filters.showCollateralTypeOnly.text;
    queryFilters.push({ operator: "and" });
    queryFilters.push({
      name: "collateralType",
      operator: "equals",
      value: collateralTypeFilter,
    });
  }

  if (reservationType === ReservationTypes.MEETING && filters.capacity > 1) {
    queryFilters.push({ operator: "and" });
    queryFilters.push({
      name: "capacity",
      operator: "greater than or equals",
      value: filters.capacity,
    });
  }

  if (
    filters.showFavoritesOnly ||
    (filters.floor == null &&
      isEmpty(code) &&
      isEmpty(rooms) &&
      isEmpty(searchText))
  ) {
    queryFilters.push({ operator: "and" });
    queryFilters.push({ operator: "open parenthesis" });
    favoriteRooms.forEach((room, index) => {
      if (index > 0) queryFilters.push({ operator: "or" });
      queryFilters.push({
        name: "systemRecordId",
        operator: "equals",
        value: room._id,
      });
    });
    queryFilters.push({ operator: "close parenthesis" });
  }

  queryFilters.push({ operator: "and" });
  const reservationClassFilters = [RESERVATION_CLASS_RESERVABLE];
  if (filters.showRequestableRooms) {
    reservationClassFilters.push(RESERVATION_CLASS_REQUESTABLE);
  }
  if (filters.showPrivateRooms) {
    reservationClassFilters.push(RESERVATION_CLASS_PRIVATE);
  }
  queryFilters.push({
    name: "reservationClassNameENUS",
    operator: "in",
    value: reservationClassFilters,
  });

  if (
    reservationType === ReservationTypes.MEETING &&
    filters.layoutType != null &&
    filters.layoutType.internalValue !== DefaultValues.LAYOUT_TYPE.internalValue
  ) {
    queryFilters.push({ operator: "and" });
    queryFilters.push({
      name: "layoutTypeInternal",
      operator: "equals",
      value: filters.layoutType.internalValue,
    });
  } else {
    queryFilters.push({ operator: "and" });
    queryFilters.push({
      name: "layoutDefault",
      operator: "equals",
      value: true,
    });
  }

  if (reservationType === ReservationTypes.WORKSPACE && filterWorkspaceByRole) {
    queryFilters.push({ operator: "and" });
    queryFilters.push({ operator: "open parenthesis" });
    if (currentUserRole != null) {
      queryFilters.push({
        name: "roleSystemRecordID",
        operator: "equals",
        value: currentUserRole._id,
      });
      queryFilters.push({ operator: "or" });
    }
    queryFilters.push({
      name: "roleSystemRecordID",
      operator: "equals",
      value: null,
    });
    queryFilters.push({ operator: "close parenthesis" });
  }

  const amenities =
    filters.amenities != null ? Object.entries(filters.amenities) : null;
  if (amenities != null) {
    for (const [key, value] of amenities) {
      if (value) {
        queryFilters.push({ operator: "and" });
        queryFilters.push({
          name: key,
          operator: "equals",
          value: "Yes",
        });
      }
    }
  }

  if (recurrence) {
    queryFilters.push({ operator: "and" });
    queryFilters.push({
      name: "doNotAllowSeriesReservations",
      operator: "equals",
      value: false,
    });
  }

  return queryFilters;
}

function createReservableSpacesQueryReserveContext({
  startDate,
  endDate,
  recurrence,
  occurrenceMatch,
}) {
  return {
    startDate,
    endDate,
    resultsLimit: 0,
    recurrence,
    availabilityThreshold: occurrenceMatch ? occurrenceMatch / 100 : 0.01,
    returnOccurrenceList: recurrence != null,
  };
}

export async function getResourcesEvents({ startDate, endDate }, resources) {
  if (isEmpty(resources)) return [];
  const page = { from: 0, size: 10000 };
  const calendar = {
    startDate,
    endDate,
  };
  const query = { page, calendar };
  const { data } = await getAppModel().getRecord(
    `${DatasourceNames.SPACE_DS_NAME}/${
      resources.length > 1 ? -1 : resources[0]
    }/${DatasourceNames.EVENTS_DS_NAME}`,
    query,
    resources,
    false,
    false
  );
  return { data };
}
