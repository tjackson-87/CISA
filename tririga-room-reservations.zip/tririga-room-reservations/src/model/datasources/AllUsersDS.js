/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2022 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import { getAppModel } from "../AppModel";
import { DatasourceNames } from "../../utils";

export async function getAllUserByEmails(emails) {
  if (emails && emails.length) {
    const filters = [];
    emails.forEach( (email, index )=> {
        filters.push({
          ignoreIfBlank: true,
          name: "email",
          operator: "contains",
          value: email,  
        });
        if (index < emails.length - 1)
          filters.push({ operator: "or" });
    });
    const query = { filters };
    const response = await getAppModel().getRecord(
      DatasourceNames.ALL_USERS_DS_NAME,
      query,
      null,
      false,
      false
    );
    return response.data;
  }
  return [];
}
