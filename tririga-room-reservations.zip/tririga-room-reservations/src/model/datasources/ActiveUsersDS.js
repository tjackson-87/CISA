/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import { getAppModel } from "../AppModel";
import { DatasourceNames } from "../../utils";

export async function getUserByEmail(email) {
  const filters = [
    {
      name: "email",
      operator: "equals",
      value: email,
    },
  ];
  const query = { filters };
  const response = await getAppModel().getRecord(
    DatasourceNames.ACTIVE_USERS_DS_NAME,
    query,
    null,
    false,
    false
  );
  return response.data[0];
}
