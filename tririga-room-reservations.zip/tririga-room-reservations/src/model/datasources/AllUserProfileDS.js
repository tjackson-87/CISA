/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - 2023 The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import { getAppModel } from "../AppModel";
import { DatasourceNames, lastRequestDebouncer } from "../../utils";

export async function getallUserProfileByEmails(emails) {
  if (emails && emails.length) {
    const filters = [];
    emails.forEach((email, index) => {
      filters.push({
        ignoreIfBlank: true,
        name: "email",
        operator: "contains",
        value: email,
      });
      if (index < emails.length - 1) filters.push({ operator: "or" });
    });
    const query = { filters };
    const response = await getAppModel().getRecord(
      DatasourceNames.ALL_PROFILE_DS_NAME,
      query,
      null,
      false,
      false
    );
    return response.data;
  }
  return [];
}

export const queryColleagues = lastRequestDebouncer(doQueryColleagues);

async function doQueryColleagues(searchText, from = 0) {
  const filters = [];
  filters.push({
    ignoreIfBlank: true,
    name: "name",
    operator: "Starts With",
    value: searchText,
  });
  filters.push({ operator: "and" })
  filters.push({
    ignoreIfBlank: true,
    name: "email",
    operator: "contains",
    value: "@",
  });
  const page = { from, size: 10 };
  const sorts = [{ name: "name", desc: false }];
  const query = { filters, page, sorts };
  const response = await getAppModel().getRecord(
    DatasourceNames.ALL_PROFILE_DS_NAME,
    query,
    null,
    false,
    false
  );
  return response;
}

export function queryMoreColleagues(searchText, from) {
  return doQueryColleagues(searchText, from);
}

export async function getUserByPersonID(personId) {
  if (!personId) {
    return null;
  }

  const filters = [
    {
      name: "personId",
      operator: "equals",
      value: personId,
    },
  ];
  const query = { filters };
  const response = await getAppModel().getRecord(
    DatasourceNames.ACTIVE_USERS_DS_NAME,
    query,
    null,
    false,
    false
  );
  if (response.data[0]) {
    return response.data[0];
  }
  return {};
}