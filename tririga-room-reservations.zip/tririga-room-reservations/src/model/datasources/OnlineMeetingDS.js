/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2022 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import isEmpty from "lodash/isEmpty";
import { getAppModel } from "../AppModel";
import { DatasourceNames } from "../../utils";

export async function getOnlineMeetings(userProfileId) {
  /*
  const filters = [
    {
      name: "userProfileId",
      operator: "equals",
      value: userProfileId,
    },
  ];*/
  const response = await getAppModel().getRecord(
    DatasourceNames.ONLINE_MEETING_DS_NAME
  );
  const onlineMeetings = response.data;
  return onlineMeetings && onlineMeetings.length ? onlineMeetings : [];
}
// CISA
//TODO Remove the full dataset refresh
export async function createNewTeamsMeeting(meetingData) {
  let tririgaMeetingData = formatTeamsMeetingToTririga(meetingData);
  const response = await getAppModel().createRecord(
    DatasourceNames.TEAMS_MEETING_DS_NAME,
    tririgaMeetingData,
    null,
    false,
    "onlineMeetingActions",
    "createNewTeamsMeeting"
  );
  if (isEmpty(response.createdRecordId))
    throw new Error("Teams meeting record could not be created.");
  return {
    createdRecordId: response.createdRecordId,
  };
}
/**
 * @param {*} meetingData 
 * @returns 
 */
function formatTeamsMeetingToTririga(meetingData) {
  let formattedCallInInformation = "Call information is not available.";
  if(meetingData.audioConferencing != null){
    let meetingid, passcode, dialinUrl, tollNumbers, tollFreeNumbers, conferenceId = "";
    meetingid = (meetingData.meetingCode && meetingData.meetingCode != null) ? meetingData.meetingCode : "";
    passcode = (meetingData.passcode && meetingData.passcode != null )? meetingData.passcode : "";
    dialinUrl = (meetingData.audioConferencing.dialinUrl && meetingData.audioConferencing.dialinUrl != null )? meetingData.audioConferencing.dialinUrl : "";
    tollNumbers = (meetingData.audioConferencing.tollNumbers && meetingData.audioConferencing.tollNumbers != null )? meetingData.audioConferencing.tollNumbers : "";
    tollFreeNumbers = (meetingData.audioConferencing.tollFreeNumbers && meetingData.audioConferencing.tollFreeNumbers != null )? meetingData.audioConferencing.tollFreeNumbers : "";
    conferenceId = (meetingData.audioConferencing.conferenceId && meetingData.audioConferencing.conferenceId != null )? meetingData.audioConferencing.conferenceId : "";
    formattedCallInInformation = `Meeting ID: ${meetingid}\n Passcode: ${passcode}\n Dail in Url: ${dialinUrl}\n Or call in (audio only)\n Toll Number: ${tollNumbers}\n Toll Free Number: ${tollFreeNumbers}\n Phone Conference ID: ${conferenceId}`;
  }
  return {
    teamsMeetingId: meetingData.id,
    url: meetingData.joinWebUrl,
    defaultMeeting: false,
    password: meetingData.passcode,
    name: meetingData.subject,
    callInInformation: formattedCallInInformation
  };
}

export async function createNewOnlineMeeting(meetingData) {
  const filters = [
    {
      name: "userProfileId",
      operator: "equals",
      value: meetingData.ownerId,
    },
  ];
  const response = await getAppModel().createRecord(
    DatasourceNames.ONLINE_MEETING_DS_NAME,
    meetingData,
    { filters },
    true,
    "onlineMeetingActions",
    "createNewOnlineMeeting"
  );
  if (isEmpty(response.createdRecordId))
    throw new Error("Online meeting record could not be created.");

  const onlineMeetings = response.refresh.data;
  return {
    onlineMeetings: !isEmpty(onlineMeetings) ? onlineMeetings : [],
    createdRecordId: response.createdRecordId,
  };
}

export async function updateOnlineMeeting(meetingData) {
  const filters = [
    {
      name: "userProfileId",
      operator: "equals",
      value: meetingData.ownerId,
    },
  ];
  const response = await getAppModel().updateRecord(
    DatasourceNames.ONLINE_MEETING_DS_NAME,
    meetingData,
    { filters },
    true,
    "onlineMeetingActions",
    "updateOnlineMeeting"
  );
  const onlineMeetings = response.refresh.data;
  return onlineMeetings && onlineMeetings.length ? onlineMeetings : [];
}

export async function deleteOnlineMeeting(meetingData, ownerId) {
  const filters = [
    {
      name: "userProfileId",
      operator: "equals",
      value: ownerId,
    },
  ];
  const response = await getAppModel().deleteRecord(
    DatasourceNames.ONLINE_MEETING_DS_NAME,
    meetingData,
    { filters },
    true,
    null,
    null
  );
  const onlineMeetings = response.refresh.data;
  return onlineMeetings && onlineMeetings.length ? onlineMeetings : [];
}

export async function getOnlineMeetingByID(meetingRecordId) {
  const filters = [];
  filters.push({
    name: "meetingRecordId",
    operator: "equals",
    value: meetingRecordId,
  });
  const response = await getAppModel().getRecord(
    DatasourceNames.ONLINE_MEETING_DS_NAME,
    { filters }
  );
  return response.data[0];
}
// CISA
export async function getTeamsMeetingByID(meetingRecordId) {
  const filters = [];
  filters.push({
    name: "meetingRecordId",
    operator: "equals",
    value: meetingRecordId,
  });
  const response = await getAppModel().getRecord(
    DatasourceNames.TEAMS_MEETING_DS_NAME,
    { filters }
  );
  return response.data[0];
}
