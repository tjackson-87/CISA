/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import { getAppModel } from "../AppModel";
import { DatasourceNames, LocationConstants } from "../../utils";

export async function getReservationSpaces(reservationIds) {
  const page = { from: 0, size: 10000 };
  const filters = [];
  filters.push({
    name: "reservationDefinitionRecordID",
    operator: "in",
    value: reservationIds,
  });
  const sorts = [
    { name: "reservationDefinitionRecordID", desc: false },
    { name: "building", desc: false },
    { name: "floor", desc: false },
    { name: "name", desc: false },
  ];
  const query = { filters, page, sorts };
  const response = await getAppModel().getRecord(
    `${DatasourceNames.RESERVATION_DS_NAME}/-1/${DatasourceNames.RESERVATION_SPACES_DS_NAME}`,
    query,
    null,
    false,
    false
  );
  return response.data;
}

export async function getReservableSpaces(code) {
  const page = { from: 0, size: 10 };
  const filters = [
    {
      name: "barcode",
      operator: "equals",
      value: code,
    },
  ];

  const sorts = [
    { name: "reservationDefinitionRecordID", desc: false },
    { name: "name", desc: false },
  ];
  const query = { filters, page, sorts };
  const response = await getAppModel().getRecord(
    DatasourceNames.RESERVATION_SPACES_DS_NAME,
    query,
    null,
    false,
    false
  );
  return response.data;
}

export async function getReservationSpacesByRoomExchange(roomExchangeIds) {
  const page = {
    from: 0,
    size: LocationConstants.LOCATION_SEARCH_QUERY_PAGE_SIZE,
  };
  const filters = [];
  filters.push({
    ignoreIfBlank: true,
    name: "exchangeMailbox",
    operator: "in",
    value: roomExchangeIds,
  });
  const query = { filters, page };
  const response = await getAppModel().getRecord(
    DatasourceNames.RESERVED_SPACES_BY_EXCHANGE_MAILBOX,
    query,
    null,
    false,
    false
  );
  return response.data;
}
