/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import { getAppModel } from "../AppModel";
import { DatasourceNames } from "../../utils";
import { isEmpty } from "lodash";

export async function getReservationInstances() {
  const response = await getAppModel().getRecord(
    DatasourceNames.RESERVATION_INSTANCES_DS_NAME,
    null,
    null,
    false,
    false
  );
  return response.data;
}

export async function getReservationInstance(instanceId) {
  const response = await getAppModel().getRecord(
    `${DatasourceNames.RESERVATION_INSTANCES_DS_NAME}/${instanceId}`,
    null,
    null,
    false,
    false
  );
  return response.data;
}

export async function getLatestReservationInstanceByReservation(
  reservationId,
  start
) {
  const response = await getAppModel().getRecord(
    DatasourceNames.RESERVATION_INSTANCES_DS_NAME,
    {
      filters: [
        {
          name: "reservationId",
          operator: "equals",
          value: reservationId,
        },
        {
          name: "plannedStart",
          operator: "equals",
          value: start,
        },
      ],
    },
    null,
    false,
    false
  );
  return !isEmpty(response.data) ? response.data[0] : null;
}

export async function checkIn(instanceId) {
  const response = await getAppModel().performAction(
    DatasourceNames.RESERVATION_INSTANCES_DS_NAME,
    instanceId,
    null,
    false,
    "reservationLifecycleActions",
    "checkIn"
  );
  return response;
}

export async function checkOut(instanceId) {
  const response = await getAppModel().performAction(
    DatasourceNames.RESERVATION_INSTANCES_DS_NAME,
    instanceId,
    null,
    false,
    "reservationLifecycleActions",
    "checkOut"
  );
  return response;
}

export async function endEarly(instanceId) {
  const response = await getAppModel().performAction(
    DatasourceNames.RESERVATION_INSTANCES_DS_NAME,
    instanceId,
    null,
    false,
    "reservationLifecycleActions",
    "endEarly"
  );
  return response;
}
