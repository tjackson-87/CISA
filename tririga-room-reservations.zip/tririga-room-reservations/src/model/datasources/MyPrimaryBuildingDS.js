/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import { getAppModel } from "../AppModel";
import { DatasourceNames } from "../../utils";

export async function getMyPrimaryBuilding() {
  const response = await getAppModel().getRecord(
    DatasourceNames.MY_PRIMARY_BUILDING_DS_NAME
  );
  const primaryBuilding = response.data;
  return primaryBuilding && primaryBuilding._id ? primaryBuilding : null;
}
