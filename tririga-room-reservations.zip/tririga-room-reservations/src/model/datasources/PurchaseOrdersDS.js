/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2022 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import { getAppModel } from "../AppModel";
import { DatasourceNames } from "../../utils";

export async function getPurchaseOrders(foodOrderIds) {
  const page = { from: 0, size: 10000 };
  const filters = [
    {
      name: "foodOrderRecordId",
      operator: "in",
      value: foodOrderIds,
    },
  ];
  const sorts = [
    { name: "reservationDefinitionRecordID", desc: false },
    { name: "name", desc: false },
  ];
  const query = { page, sorts, filters };
  const response = await getAppModel().getRecord(
    `${DatasourceNames.PURCHASE_ORDERS_DS_NAME}`,
    query,
    null,
    false,
    false
  );
  return response.data;
}
