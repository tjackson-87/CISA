/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2022 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import { getAppModel } from "../AppModel";
import { DatasourceNames } from "../../utils";

export async function getOAuthProfile(oauthProfileDomain) {
  const filters = [
    {
      name: "oauthProfileDomain",
      operator: "equals",
      value: oauthProfileDomain,
    },
    {
      name: "useWithExchange",
      operator: "equals",
      value: "false",
    },
  ];
  const response = await getAppModel().getRecord(
    DatasourceNames.OAUTH_PROFILE_DS_NAME,
    { filters },
    null,
    false,
    false
  );

  const oauthProfile = response.data;
  return oauthProfile && oauthProfile.length ? oauthProfile[0] : [];
}
