/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import { getAppModel } from "../AppModel";
import { DatasourceNames } from "../../utils";

export async function getReservableSpaceType(spaceId, exchangeIntegration) {
  const filters = createQueryFilters(spaceId, exchangeIntegration);
  const response = await getAppModel().getRecord(
    DatasourceNames.RESERVABLE_SPACE_TYPE_DS_NAME,
    { filters }
  );
  const result = response.data;
  let space = result && result.length > 0 ? result[0] : null;
  if (
    space != null &&
    exchangeIntegration &&
    space.isMeetingSpace &&
    !space.exchangeIntegration
  ) {
    space = null;
  }
  return space;
}

function createQueryFilters(spaceId) {
  const filters = [];
  filters.push({
    name: "spaceId",
    operator: "equals",
    value: spaceId,
  });
  return filters;
}
