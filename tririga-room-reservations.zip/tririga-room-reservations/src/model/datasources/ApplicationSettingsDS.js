/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import { getAppModel } from "../AppModel";
import { DatasourceNames } from "../../utils";

export async function getApplicationSettings() {
  const response = await getAppModel().getRecord(
    DatasourceNames.APPLICATION_SETTINGS_DS_NAME
  );
  const applicationSettings = response.data;
  return applicationSettings && applicationSettings._id
    ? applicationSettings
    : null;
}
