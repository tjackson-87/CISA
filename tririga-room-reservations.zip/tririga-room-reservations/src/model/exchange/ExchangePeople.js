/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import isEmpty from "lodash/isEmpty";

const PAGE_SIZE = 20;

const LIST_PEOPLE_GRAPH_URL = "https://graph.microsoft.com/v1.0/me/people";

export const ORGANIZATION_USER = "OrganizationUser";
export const IMPLICIT_CONTACT_TYPE = "ImplicitContact";
export const PERSONAL_CONTACT_TYPE = "PersonalContact";
export const NON_EXCHANGE_TYPE = "NonExchange";

export async function getPeople(accessToken, search, nextLink) {
  let getPeopleUrl;
  if (isEmpty(nextLink)) {
    getPeopleUrl = new URL(LIST_PEOPLE_GRAPH_URL);
    if (!isEmpty(search)) {
      getPeopleUrl.searchParams.set("$search", `"${search}"`);
      getPeopleUrl.searchParams.set("$orderby", "displayName");
    }
    getPeopleUrl.searchParams.set(
      "$select",
      "scoredEmailAddresses,displayName,givenName,surname,personType"
    );
    getPeopleUrl.searchParams.set("$top", PAGE_SIZE);
    getPeopleUrl.searchParams.set("$filter", "personType/class eq 'Person'");
  } else {
    getPeopleUrl = new URL(nextLink);
  }
  const requestOptions = {
    method: "GET",
    headers: {
      Accept: "application/json",
      Authorization: `Bearer ${accessToken}`,
      "X-PeopleQuery-QuerySources": "Mailbox,Directory",
    },
  };
  const request = new Request(getPeopleUrl, requestOptions);
  const response = await fetch(request);
  if (!response.ok) {
    const { error } = await response.json();
    throw error;
  }
  const parsedResponse = await response.json();
  return {
    hasMore: parsedResponse["@odata.nextLink"] != null,
    data: filterPeopleWithoutEmail(
      parsedResponse.value.map(
        ({
          scoredEmailAddresses,
          displayName,
          givenName,
          surname,
          personType,
        }) => ({
          type: personType?.subclass,
          email: scoredEmailAddresses?.[0]?.address,
          displayName,
          firstName: givenName,
          lastName: surname,
        })
      )
    ),
    nextLink: parsedResponse["@odata.nextLink"],
    search,
  };
}

function filterPeopleWithoutEmail(peopleList) {
  return peopleList.filter((item) => !isEmpty(item.email));
}

export async function getPeopleByEmail(accessToken, email) {
  try {
    const getPeopleUrl = new URL(LIST_PEOPLE_GRAPH_URL);
    getPeopleUrl.searchParams.set("$search", `"${email}"`);
    getPeopleUrl.searchParams.set(
      "$select",
      "scoredEmailAddresses,displayName,givenName,surname,personType"
    );
    const requestOptions = {
      method: "GET",
      headers: {
        Accept: "application/json",
        Authorization: `Bearer ${accessToken}`,
        "X-PeopleQuery-QuerySources": "Mailbox,Directory",
      },
    };
    const request = new Request(getPeopleUrl, requestOptions);
    const response = await fetch(request);
    if (!response.ok) {
      const { error } = await response.json();
      console.warn(error);
      return null;
    }
    const parsedResponse = await response.json();
    if (isEmpty(parsedResponse.value)) {
      return null;
    }
    return parsedResponse.value.map(
      ({
        scoredEmailAddresses,
        displayName,
        givenName,
        surname,
        personType,
      }) => ({
        type: personType?.subclass,
        email: scoredEmailAddresses?.[0]?.address,
        name: displayName,
        firstName: givenName,
        lastName: surname,
      })
    )[0];
  } catch (error) {
    return null;
  }
}
