/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

const GET_PHOTO_GRAPH_URL =
  "https://graph.microsoft.com/v1.0/users/{userPrincipalName}/photos/48x48/$value";
const GET_CONTACT_GRAPH_URL = "https://graph.microsoft.com/v1.0/me/contacts";
const GET_CONTACT_PHOTO_GRAPH_URL =
  "https://graph.microsoft.com/v1.0/me/contacts/{contactId}/photo/$value";

const userPhotoMap = new Map();
const contactPhotoMap = new Map();

async function getContactId(accessToken, email) {
  const getContactUrl = new URL(GET_CONTACT_GRAPH_URL);
  getContactUrl.searchParams.set("$select", "id");
  getContactUrl.searchParams.set(
    "$filter",
    `emailAddresses/any(a:a/address eq '${email}')`
  );
  const requestOptions = {
    method: "GET",
    headers: {
      Accept: "application/json",
      Authorization: `Bearer ${accessToken}`,
    },
  };
  const request = new Request(getContactUrl, requestOptions);
  const response = await fetch(request);
  if (!response.ok) {
    const { error } = await response.json();
    throw error;
  }
  const parsedResponse = await response.json();
  return parsedResponse.value[0]?.id;
}

export async function getUserPhoto(accessToken, email) {
  if (email == null) {
    return null;
  }
  if (userPhotoMap.has(email)) {
    return userPhotoMap.get(email);
  }
  const getPhotoUrl = new URL(
    GET_PHOTO_GRAPH_URL.replace("{userPrincipalName}", email)
  );
  const requestOptions = {
    method: "GET",
    headers: {
      Accept: "application/json",
      Authorization: `Bearer ${accessToken}`,
    },
  };
  const request = new Request(getPhotoUrl, requestOptions);
  try {
    const response = await fetch(request);
    if (!response.ok) {
      userPhotoMap.set(email, null);
      return null;
    }
    const imageBlob = await response.blob();
    const imageURL = URL.createObjectURL(imageBlob);
    userPhotoMap.set(email, imageURL);
    return imageURL;
  } catch (error) {
    userPhotoMap.set(email, null);
    return null;
  }
}

export async function getContactPhoto(accessToken, email) {
  if (email == null) {
    return null;
  }
  if (contactPhotoMap.has(email)) {
    return contactPhotoMap.get(email);
  }

  try {
    let imageURL = null;
    const contactId = await getContactId(accessToken, email);
    if (contactId != null) {
      const getPhotoUrl = new URL(
        GET_CONTACT_PHOTO_GRAPH_URL.replace("{contactId}", contactId)
      );
      const requestOptions = {
        method: "GET",
        headers: {
          Accept: "application/json",
          Authorization: `Bearer ${accessToken}`,
        },
      };
      const request = new Request(getPhotoUrl, requestOptions);
      const response = await fetch(request);
      if (response.ok) {
        const imageBlob = await response.blob();
        imageURL = URL.createObjectURL(imageBlob);
      }
    }
    contactPhotoMap.set(email, imageURL);
    return imageURL;
  } catch (error) {
    contactPhotoMap.set(email, null);
    return null;
  }
}
