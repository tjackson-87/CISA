/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import {
  getAzureAccessToken,
  receiveAuthorizationCodeOnPopup,
  PopupBlockedException,
  getAccessTokenUsingRefreshToken,
} from "./ExchangeAccessToken";
import {
  getPeople,
  getPeopleByEmail,
  ORGANIZATION_USER,
  IMPLICIT_CONTACT_TYPE,
  PERSONAL_CONTACT_TYPE,
  NON_EXCHANGE_TYPE,
} from "./ExchangePeople";
import { getUserPhoto, getContactPhoto } from "./ExchangePhoto";
import {
  createEvent,
  updateEventAttendees,
  updateEvent,
  deleteEvent,
  getSchedule,
  getMe,
  updateResponse,
  createTeamsMeeting, // CISA
  deleteTeamsMeeting, // CISA
  getEventByiCalUId,
  removeRoomDetails,
  updateEventExtension,
  createEventExtension,
  updateEventEndTime,
} from "./ExchangeEvent";
import {
  getUserCalendarView,
  ResponseStatus,
  EventType,
  getEventDescriptionAndAttendees,
  getCalendarEventByICalUId,
  getCalendarEventById,
  getAllCalendars,
  getEventExtension,
} from "./ExchangeCalendar";

export default {
  getAzureAccessToken,
  receiveAuthorizationCodeOnPopup,
  getAccessTokenUsingRefreshToken,
  PopupBlockedException,
  getPeople,
  getPeopleByEmail,
  ORGANIZATION_USER,
  IMPLICIT_CONTACT_TYPE,
  PERSONAL_CONTACT_TYPE,
  NON_EXCHANGE_TYPE,
  getUserPhoto,
  getContactPhoto,
  createEvent,
  updateEventAttendees,
  updateEvent,
  deleteEvent,
  getSchedule,
  getMe,
  getUserCalendarView,
  getCalendarEventByICalUId,
  getCalendarEventById,
  ResponseStatus,
  EventType,
  getEventDescriptionAndAttendees,
  updateResponse,
  createTeamsMeeting, // CISA
  deleteTeamsMeeting, // CISA
  getEventByiCalUId,
  removeRoomDetails,
  getAllCalendars,
  getEventExtension,
  updateEventExtension,
  createEventExtension,
  updateEventEndTime,
};
