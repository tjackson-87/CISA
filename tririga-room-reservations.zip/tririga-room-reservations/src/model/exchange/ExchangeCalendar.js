/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import moment from "moment-timezone";
import isEmpty from "lodash/isEmpty";
import { WindowsZones, EventUtils, getEventEndDate } from "../../utils";
import { getUserPhoto } from "./ExchangePhoto";
import { EXTENSION_NAME, EXTENSION_URL } from "./ExchangeEvent";

export const ResponseStatus = {
  TENTATIVELY_ACCEPTED: "tentativelyAccepted",
  ACCEPTED: "accepted",
  DECLINED: "declined",
  NOT_RESPONDED: "notResponded",
  ORGANIZER: "organizer",
};

export const EventType = {
  SINGLE_INSTANCE: "singleInstance",
  OCCURRENCE: "occurrence",
  EXCEPTION: "exception",
};

const CALENDAR_VIEW_URL = "https://graph.microsoft.com/v1.0/me/calendarview";
const GET_EVENT_DETAIL = "https://graph.microsoft.com/v1.0/me/events";
const GET_ALL_CALENDARS = "https://graph.microsoft.com/v1.0/me/calendars";
const USER_CALENDAR_VIEW_URL =
  "https://graph.microsoft.com/v1.0/me/calendars/{calendarId}/calendarview";
const USER_EVENT_LIST_URL =
  "https://graph.microsoft.com/v1.0/me/calendars/{calendarId}/events";

export async function getUserCalendarView(
  accessToken,
  calendar,
  start,
  end,
  timezone,
  fields
) {
  const windowsTimezone = WindowsZones.ianaToWindows(timezone);

  const getUserCalendarViewUrl = isEmpty(calendar)
    ? new URL(CALENDAR_VIEW_URL)
    : new URL(USER_CALENDAR_VIEW_URL.replace("{calendarId}", calendar.id));
  getUserCalendarViewUrl.searchParams.set(
    "$select",
    fields != null
      ? fields
      : "subject,location,start,end,iCalUId,isAllDay,isOrganizer,organizer,seriesMasterId,type,responseStatus,attendees,responseRequested,isOnlineMeeting"
  );
  getUserCalendarViewUrl.searchParams.set("startdatetime", start);
  getUserCalendarViewUrl.searchParams.set("enddatetime", end);
  getUserCalendarViewUrl.searchParams.set("$top", 1000);
  getUserCalendarViewUrl.searchParams.set("$filter", "isCancelled eq false");

  const requestOptions = {
    method: "GET",
    headers: {
      Accept: "application/json",
      Authorization: `Bearer ${accessToken}`,
      Prefer: `outlook.timezone="${windowsTimezone}"`,
    },
  };
  const request = new Request(getUserCalendarViewUrl, requestOptions);
  const response = await fetch(request);
  if (!response.ok) {
    const { error } = await response.json();
    throw error;
  }
  const parsedResponse = await response.json();
  return normalizeExchangeCalendarEvents(
    accessToken,
    parsedResponse.value,
    timezone,
    calendar,
    start,
    end
  );
}

export async function getCalendarEventById(accessToken, timezone, eventId) {
  const windowsTimezone = WindowsZones.ianaToWindows(timezone);
  const getEventUrl = new URL(`${GET_EVENT_DETAIL}/${eventId}`);
  getEventUrl.searchParams.set(
    "$select",
    "subject,location,start,end,iCalUId,isAllDay,isOrganizer,organizer,seriesMasterId,type,responseStatus,responseRequested,isOnlineMeeting"
  );
  const requestOptions = {
    method: "GET",
    headers: {
      Accept: "application/json",
      Authorization: `Bearer ${accessToken}`,
      Prefer: `outlook.timezone="${windowsTimezone}"`,
    },
  };
  const request = new Request(getEventUrl, requestOptions);
  const response = await fetch(request);
  if (!response.ok) {
    const { error } = await response.json();
    throw error;
  }
  const parsedResponse = await response.json();
  const normalizedEvents = await normalizeExchangeCalendarEvents(
    accessToken,
    [parsedResponse],
    timezone
  );
  return normalizedEvents[0];
}

export async function getCalendarEventByICalUId(
  accessToken,
  start,
  end,
  timezone,
  iCalUId,
  edit,
  calendar
) {
  const events = await getUserCalendarView(
    accessToken,
    calendar,
    start,
    end,
    timezone,
    edit
      ? "subject,location,start,end,iCalUId,isAllDay,isOrganizer,organizer,seriesMasterId,type,body,attendees,responseRequested,isOnlineMeeting"
      : null
  );
  const momentStart = moment(start);
  const momentEnd = moment(end);
  const event = events.find(
    (event) =>
      (event.iCalUId === iCalUId || event.seriesICalUId === iCalUId) &&
      momentStart.isSame(event.start, "minutes") &&
      momentEnd.isSame(event.end, "minutes")
  );
  return event;
}

export async function getEventDescriptionAndAttendees(
  accessToken,
  eventId,
  reservationId
) {
  const getEventUrl = new URL(`${GET_EVENT_DETAIL}/${eventId}`);
  getEventUrl.searchParams.set("$select", "body,attendees,isOrganizer");

  const requestOptions = {
    method: "GET",
    headers: {
      Accept: "application/json",
      Authorization: `Bearer ${accessToken}`,
    },
  };
  const request = new Request(getEventUrl, requestOptions);
  const response = await fetch(request);
  if (!response.ok) {
    const { error } = await response.json();
    throw error;
  }
  const parsedResponse = await response.json();
  return {
    description: parsedResponse?.isOrganizer
      ? EventUtils.removeAutoGeneratedTextFromBody(
          parsedResponse?.body?.content,
          reservationId
        )
      : parsedResponse?.body?.content,
    attendees: parsedResponse?.attendees,
  };
}

export async function getEventExtension(accessToken, eventId) {
  const getEventUrl = new URL(
    `${GET_EVENT_DETAIL}/${eventId}/${EXTENSION_URL}/${EXTENSION_NAME}`
  );

  const requestOptions = {
    method: "GET",
    headers: {
      Accept: "application/json",
      Authorization: `Bearer ${accessToken}`,
    },
  };
  const request = new Request(getEventUrl, requestOptions);
  const response = await fetch(request);
  if (!response.ok) {
    return null;
  } else {
    const parsedResponse = await response.json();
    return {
      additionalLocationInfo: parsedResponse.additionalLocationInfo,
      onlineMeetingID: parsedResponse.onlineMeetingID,
    };
  }
}

async function getSeriesICalUId(accessToken, events, calendar, start, end) {
  if (!isEmpty(start) && !isEmpty(end)) {
    const eventList = await getEventList(
      accessToken,
      calendar,
      calendar,
      start,
      end
    );
    events.forEach((event) => {
      if (
        eventList &&
        event.seriesMasterId &&
        event.isOrganizer &&
        (event.type === EventType.EXCEPTION ||
          event.type === EventType.OCCURRENCE)
      ) {
        const seriesMasterEvent = eventList.find(
          (ev) => ev.id === event.seriesMasterId
        );
        event.seriesICalUId = seriesMasterEvent?.iCalUId;
      }
    });
  } else {
    const seriesMasterIdIterator = new Set(
      events
        .filter(
          (evt) =>
            !isEmpty(evt.seriesMasterId) &&
            evt.isOrganizer &&
            (evt.type === EventType.EXCEPTION ||
              evt.type === EventType.OCCURRENCE)
        )
        .map((evt) => evt.seriesMasterId)
    ).values();
    for (const seriesMasterId of seriesMasterIdIterator) {
      const seriesICalUId = await getEventICalUId(accessToken, seriesMasterId);
      if (seriesICalUId != null) {
        events.forEach((evt) => {
          if (evt.seriesMasterId === seriesMasterId) {
            evt.seriesICalUId = seriesICalUId;
          }
        });
      }
    }
  }
  return events;
}

async function getEventICalUId(accessToken, eventId) {
  try {
    const getEventUrl = new URL(`${GET_EVENT_DETAIL}/${eventId}`);
    getEventUrl.searchParams.set("$select", "iCalUId");
    const requestOptions = {
      method: "GET",
      headers: {
        Accept: "application/json",
        Authorization: `Bearer ${accessToken}`,
      },
    };
    const request = new Request(getEventUrl, requestOptions);
    const response = await fetch(request);
    if (!response.ok) {
      const { error } = await response.json();
      throw error;
    }
    const parsedResponse = await response.json();
    return parsedResponse?.iCalUId;
  } catch (error) {
    return null;
  }
}

async function getEventList(accessToken, calendar, start, end) {
  try {
    const getEventListUrl = isEmpty(calendar)
      ? new URL(GET_EVENT_DETAIL)
      : new URL(USER_EVENT_LIST_URL.replace("{calendarId}", calendar.id));
    getEventListUrl.searchParams.set("$select", "iCalUId");
    getEventListUrl.searchParams.set("startdatetime", start);
    getEventListUrl.searchParams.set("enddatetime", end);
    getEventListUrl.searchParams.set("$top", 1000);
    getEventListUrl.searchParams.set("$filter", "isCancelled eq false");
    const requestOptions = {
      method: "GET",
      headers: {
        Accept: "application/json",
        Authorization: `Bearer ${accessToken}`,
      },
    };
    const request = new Request(getEventListUrl, requestOptions);
    const response = await fetch(request);
    if (!response.ok) {
      const { error } = await response.json();
      throw error;
    }
    const parsedResponse = await response.json();
    return parsedResponse.value;
  } catch (error) {
    return null;
  }
}

export async function normalizeExchangeCalendarEvents(
  accessToken,
  events,
  timezone,
  calendar,
  start,
  end
) {
  if (isEmpty(events)) {
    return [];
  }

  const normalizedEvents = events
    .filter((event) => event.responseRequested)
    .map(
      ({
        id,
        iCalUId,
        subject,
        isAllDay,
        isOrganizer,
        organizer,
        seriesMasterId,
        type,
        responseStatus,
        start,
        end,
        location,
        body,
        attendees,
        isOnlineMeeting
      }) => ({
        id,
        iCalUId,
        subject,
        isAllDay,
        isOrganizer,
        organizer,
        seriesMasterId,
        type,
        responseStatus:
          responseStatus?.time === "0001-01-01T00:00:00Z" &&
          responseStatus?.response !== ResponseStatus.ORGANIZER
            ? ResponseStatus.NOT_RESPONDED
            : responseStatus?.response,
        start: moment.tz(start.dateTime, timezone).toISOString(true),
        end: getEventEndDate(isAllDay, end.dateTime, timezone),
        location: location?.displayName,
        description: EventUtils.removeAutoGeneratedTextFromBody(body?.content),
        attendees: attendees,
        reservationTimezone: WindowsZones.windowsToIana(start.timeZone),
        isOnlineMeeting: isOnlineMeeting
      })
    );
  return await getSeriesICalUId(
    accessToken,
    normalizedEvents,
    calendar,
    start,
    end
  );
}

export async function getAllCalendars(accessToken) {
  const getAllCalendarsUrl = new URL(GET_ALL_CALENDARS);

  const requestOptions = {
    method: "GET",
    headers: {
      Accept: "application/json",
      Authorization: `Bearer ${accessToken}`,
    },
  };

  const request = new Request(getAllCalendarsUrl, requestOptions);
  const response = await fetch(request);
  if (!response.ok) {
    const { error } = await response.json();
    throw error;
  }
  const parsedResponse = await response.json();
  let result = parsedResponse.value
    .filter((calendar) => calendar.canEdit)
    .map(async (calendar) => ({
      ...EventUtils.refineCalendar(calendar),
      image: await getUserPhoto(accessToken, calendar.owner?.address),
    }));
  result = await Promise.all(result);
  return {
    result: result,
    success: true,
  };
}
