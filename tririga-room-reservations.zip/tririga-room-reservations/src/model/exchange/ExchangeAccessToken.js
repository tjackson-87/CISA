/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import { TriAzureOauth2 } from "@tririga/tririga-react-components";
import Timeout from "await-timeout";
import { isPopupBlocked } from "../../utils";

const ACCESS_TOKEN_MESSAGE_FROM_POPUP = "ACCESS_TOKEN";
const ACCESS_TOKEN_POPUP_OPEN_WAIT = 1000;
const ACCESS_TOKEN_POPUP_HEARTBEAT_INTERVAL = 2000;

let azureAuthenticationPopup = null;

export async function getAzureAccessToken(oauthProfile) {
  const popup = await openAzureAuthenticationPopup();
  if (isPopupBlocked(popup)) {
    throw new PopupBlockedException();
  }
  const requestAuthorizationCodeURL = await TriAzureOauth2.getRequestAuthorizationCodeURL(
    oauthProfile
  );
  popup.location = requestAuthorizationCodeURL;
  return receiveAccessTokenFromPopup();
}

export async function getAccessTokenUsingRefreshToken(oauthProfile) {
  try {
    return await TriAzureOauth2.getAccessToken("", oauthProfile);
  } catch (error) {
    return null;
  }
}

export async function receiveAuthorizationCodeOnPopup() {
  try {
    const {
      code: authCode,
      profileName: oauthProfile,
    } = TriAzureOauth2.receiveAuthorizationCode();
    const accessToken = await TriAzureOauth2.getAccessToken(
      authCode,
      oauthProfile
    );
    window.opener.postMessage(
      { type: ACCESS_TOKEN_MESSAGE_FROM_POPUP, token: accessToken },
      window.location.origin
    );
  } catch (error) {
    window.opener.postMessage(
      { type: ACCESS_TOKEN_MESSAGE_FROM_POPUP, error },
      window.location.origin
    );
  }
}

async function openAzureAuthenticationPopup() {
  if (azureAuthenticationPopup != null && !azureAuthenticationPopup.closed) {
    azureAuthenticationPopup.close();
  }
  const width = Math.max(500, Math.trunc(window.screen.width * 0.3));
  const height = Math.max(500, Math.trunc(window.screen.height * 0.3));
  const left = (window.screen.width - width) / 2;
  const top = (window.screen.height - height) / 4;
  azureAuthenticationPopup = window.open(
    "",
    "AZURE_AUTH_POPUP",
    `left=${left},top=${top},width=${width},height=${height},menubar=no,toolbar=no,location=no,status=no,resizable=yes,scrollbars=no`
  );
  await Timeout.set(ACCESS_TOKEN_POPUP_OPEN_WAIT);
  return azureAuthenticationPopup;
}

let tokenMessageListenerBound = null;
let checkPopupInterval = null;

function receiveAccessTokenFromPopup() {
  return new Promise((resolve, reject) => {
    addTokenMessageListener(resolve, reject);
    startCheckPopupHeartBeat(reject);
  });
}

function addTokenMessageListener(resolve, reject) {
  removeTokenMessageListener();
  tokenMessageListenerBound = tokenMessageListener.bind(null, resolve, reject);
  window.addEventListener("message", tokenMessageListenerBound);
}

function removeTokenMessageListener() {
  if (tokenMessageListenerBound != null) {
    window.removeEventListener("message", tokenMessageListenerBound);
    tokenMessageListenerBound = null;
  }
}

function tokenMessageListener(resolve, reject, { data }) {
  if (data != null && data.type === ACCESS_TOKEN_MESSAGE_FROM_POPUP) {
    clearAzureAuthenticationPopup();
    if (data.token != null && data.errorCode == null) {
      resolve(data.token);
    } else {
      reject(data.error);
    }
  }
}

function startCheckPopupHeartBeat(reject) {
  stopCheckPopupHeartBeat();
  checkPopupInterval = setInterval(() => {
    if (azureAuthenticationPopup == null || azureAuthenticationPopup.closed) {
      clearAzureAuthenticationPopup();
      reject(new PopupClosedException());
    }
  }, ACCESS_TOKEN_POPUP_HEARTBEAT_INTERVAL);
}

function stopCheckPopupHeartBeat() {
  if (checkPopupInterval != null) {
    clearInterval(checkPopupInterval);
    checkPopupInterval = null;
  }
}

function clearAzureAuthenticationPopup() {
  stopCheckPopupHeartBeat();
  removeTokenMessageListener();
  if (azureAuthenticationPopup != null) {
    azureAuthenticationPopup.close();
    azureAuthenticationPopup = null;
  }
}

export function PopupBlockedException() {}
export function PopupClosedException() {}
