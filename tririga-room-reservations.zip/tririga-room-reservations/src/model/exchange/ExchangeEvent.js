/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import moment from "moment-timezone";
import isEmpty from "lodash/isEmpty";
import { WindowsZones, EventUtils, getEventEndDate } from "../../utils";

const EVENT_GRAPH_URL = "https://graph.microsoft.com/v1.0/me/events";
const UPDATE_EVENT_GRAPH_URL =
  "https://graph.microsoft.com/v1.0/me/events/{eventId}";
const CREATE_TEAMS_MEETING_GRAPH_URL = "https://graph.microsoft.com/v1.0/me/onlineMeetings"; // CISA
const DELETE_TEAMS_MEETING_GRAPH_URL = "https://graph.microsoft.com/v1.0/me/onlineMeetings/{meetingId}"; // CISA
const UPDATE_TEAMS_MEETING_GRAPH_URL = "https://graph.microsoft.com/v1.0/me/onlineMeetings/{meetingId}"; // CISA
const GET_SCHEDULE_GRAPH_URL =
  "https://graph.microsoft.com/v1.0/me/calendar/getschedule";
const GET_ME_URL = "https://graph.microsoft.com/v1.0/me";
const DELEGATE_EVENT_GRAPH_URL =
  "https://graph.microsoft.com/v1.0/me/calendars/{calendarId}/events";
const UPDATE_DELEGATE_EVENT_GRAPH_URL =
  "https://graph.microsoft.com/v1.0/me/calendars/{calendarId}/events/{eventId}";
const OPEN_TYPE_EXTENSION = "microsoft.graph.openTypeExtension";
export const EXTENSION_NAME = "eventsExtension";
export const EXTENSION_URL = "extensions";

export async function createEvent(accessToken, eventParams, calendarId) {
  const url = !calendarId
    ? EVENT_GRAPH_URL
    : DELEGATE_EVENT_GRAPH_URL.replace("{calendarId}", calendarId);
  const createEventUrl = new URL(url);

  const requestOptions = {
    method: "POST",
    headers: {
      Accept: "application/json",
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(computeBaseEventBody(eventParams)),
  };
  const request = new Request(createEventUrl, requestOptions);
  const response = await fetch(request);
  if (!response.ok) {
    const { error } = await response.json();
    throw error;
  }
  const parsedResponse = await response.json();
  return {
    id: parsedResponse.id,
    iCalUId: parsedResponse.iCalUId,
  };
}

export async function updateEvent(
  accessToken,
  eventId,
  eventParams,
  attendees,
  resources,
  calendarId
) {
  const url = !calendarId
    ? UPDATE_EVENT_GRAPH_URL.replace("{eventId}", eventId)
    : UPDATE_DELEGATE_EVENT_GRAPH_URL.replace(
        "{calendarId}",
        calendarId
      ).replace("{eventId}", eventId);
  const updateEventUrl = new URL(url);

  const requestOptions = {
    method: "PATCH",
    headers: {
      Accept: "application/json",
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(
      computeUpdateEventBody(eventParams, attendees, resources)
    ),
  };
  const request = new Request(updateEventUrl, requestOptions);
  const response = await fetch(request);
  if (!response.ok) {
    const { error } = await response.json();
    throw error;
  }
  const parsedResponse = await response.json();
  return {
    id: parsedResponse.id,
  };
}

export async function updateEventExtension(accessToken, eventId, eventParams) {
  const updateEventUrl = new URL(
    `${EVENT_GRAPH_URL}/${eventId}/${EXTENSION_URL}/${EXTENSION_NAME}`
  );

  const requestOptions = {
    method: "PATCH",
    headers: {
      Accept: "application/json",
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(computeEventExtension(eventParams)),
  };
  const request = new Request(updateEventUrl, requestOptions);
  await fetch(request);
}

export async function updateEventAttendees(
  accessToken,
  eventId,
  attendees,
  resources
) {
  const updateEventUrl = new URL(
    UPDATE_EVENT_GRAPH_URL.replace("{eventId}", eventId)
  );

  const requestOptions = {
    method: "PATCH",
    headers: {
      Accept: "application/json",
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(computeEventAttendees(attendees, resources)),
  };
  const request = new Request(updateEventUrl, requestOptions);
  const response = await fetch(request);
  if (!response.ok) {
    const { error } = await response.json();
    throw error;
  }
  const parsedResponse = await response.json();
  return {
    id: parsedResponse.id,
  };
}

export async function getEventByiCalUId(
  accessToken,
  timezone,
  iCalUId,
  start,
  end,
  calendarId
) {
  const windowsTimezone = WindowsZones.ianaToWindows(timezone);
  const url = !calendarId
    ? EVENT_GRAPH_URL
    : DELEGATE_EVENT_GRAPH_URL.replace("{calendarId}", calendarId);
  const getEventUrl = new URL(url);
  getEventUrl.searchParams.set(
    "$select",
    "subject,location,start,end,iCalUId,isAllDay,seriesMasterId,type,recurrence,body,attendees,isOnlineMeeting"
  );
  getEventUrl.searchParams.set("$filter", `iCalUid eq '${iCalUId}'`);
  const requestOptions = {
    method: "GET",
    headers: {
      Accept: "application/json",
      Authorization: `Bearer ${accessToken}`,
      Prefer: `outlook.timezone="${windowsTimezone}"`,
    },
  };
  const request = new Request(getEventUrl, requestOptions);
  const response = await fetch(request);
  if (!response.ok) {
    const { error } = await response.json();
    throw error;
  }
  const parsedResponse = await response.json();
  if (isEmpty(parsedResponse.value)) {
    return null;
  }
  return parsedResponse.value.map(
    ({
      id,
      iCalUId,
      subject,
      isAllDay,
      seriesMasterId,
      type,
      start,
      end,
      location,
      recurrence,
      body,
      attendees,
      isOnlineMeeting,
    }) => ({
      id,
      iCalUId,
      subject,
      isAllDay,
      seriesMasterId,
      type,
      start: moment.tz(start.dateTime, timezone).toISOString(true),
      end: getEventEndDate(isAllDay, end.dateTime, timezone),
      location: location?.displayName,
      recurrence,
      description: EventUtils.removeAutoGeneratedTextFromBody(body?.content),
      attendees: attendees,
      isOnlineMeeting: isOnlineMeeting
    })
  )[0];
}

export async function deleteEvent(accessToken, eventId) {
  const deleteEventUrl = new URL(
    UPDATE_EVENT_GRAPH_URL.replace("{eventId}", eventId)
  );

  const requestOptions = {
    method: "DELETE",
    headers: {
      Accept: "application/json",
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
    },
  };
  const request = new Request(deleteEventUrl, requestOptions);
  const response = await fetch(request);
  if (!response.ok) {
    const { error } = await response.json();
    throw error;
  }
  return eventId;
}

export async function updateResponse(accessToken, eventId, newStatus) {
  const updateResponseEventUrl = new URL(
    UPDATE_EVENT_GRAPH_URL.replace("{eventId}", eventId) + "/" + newStatus
  );

  const requestOptions = {
    method: "POST",
    headers: {
      Accept: "application/json",
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      sendResponse: true,
    }),
  };
  const request = new Request(updateResponseEventUrl, requestOptions);
  const response = await fetch(request);
  if (!response.ok) {
    const { error } = await response.json();
    throw error;
  }
  return { id: eventId };
}
// CISA
export async function createTeamsMeeting(accessToken, startDateTime, endDateTime, subject) {
  const createTeamsMeetingUrl = CREATE_TEAMS_MEETING_GRAPH_URL;

  const requestOptions = {
    method: "POST",
    headers: {
      Accept: "application/json",
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      sendResponse: true,
      subject: subject,
      startDateTime: startDateTime,
      endDateTime: endDateTime,
      joinMeetingIdSettings: {
        isPasscodeRequired: true
      }
    }),
  };
  const request = new Request(createTeamsMeetingUrl, requestOptions);
  const response = await fetch(request);
  if (!response.ok) {
    const { error } = await response.json();
    throw error;
  }
  const parsedResponse = await response.json();

  //TODO: add a action to save the joinInformation
  return {
    id: parsedResponse.id,
    audioConferencing: parsedResponse.audioConferencing,
    joinInformation: parsedResponse.joinInformation,
    meetingCode: parsedResponse.joinMeetingIdSettings.joinMeetingId,
    passcode: parsedResponse.joinMeetingIdSettings.passcode,
    joinWebUrl: parsedResponse.joinWebUrl,
    subject: parsedResponse.subject,
  };
}

export async function updateTeamsMeeting(accessToken, startDateTime, endDateTime, subject, id) {
  const updateTeamsMeetingUrl = new URL(
    UPDATE_TEAMS_MEETING_GRAPH_URL.replace("{meetingId}", id)
  );

  const requestOptions = {
    method: "PATCH",
    headers: {
      Accept: "application/json",
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      sendResponse: true,
      subject: subject,
      startDateTime: startDateTime,
      endDateTime: endDateTime
    }),
  };
  const request = new Request(updateTeamsMeetingUrl, requestOptions);
  const response = await fetch(request);
  if (!response.ok) {
    const { error } = await response.json();
    throw error;
  }
  const parsedResponse = await response.json();
  return {
    id: parsedResponse.id,
    audioConferencing: parsedResponse.audioConferencing,
    joinInformation: parsedResponse.joinInformation,
    meetingCode: parsedResponse.joinMeetingIdSettings.joinMeetingId,
    passcode: parsedResponse.joinMeetingIdSettings.passcode,
    joinWebUrl: parsedResponse.joinWebUrl,
    subject: parsedResponse.subject,
  };
}

export async function deleteTeamsMeeting(accessToken, id) {
  const deleteTeamsMeetingUrl = new URL(
    DELETE_TEAMS_MEETING_GRAPH_URL.replace("{meetingId}", id)
  );

  const requestOptions = {
    method: "DELETE",
    headers: {
      Accept: "application/json",
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
    }
  };
  const request = new Request(deleteTeamsMeetingUrl, requestOptions);
  const response = await fetch(request);
  if (!response.ok) {
    const { error } = await response.json();
    throw error;
  }
  return {response};
}

function computeBaseEventBody({
  allDay,
  description,
  subject,
  start,
  end,
  timezone,
  recurrence,
  location,
}) {
  const windowsTimezone = WindowsZones.ianaToWindows(timezone);
  const body = {
    subject,
    body: {
      contentType: "HTML",
      content: description,
    },
    isAllDay: allDay,
    start: {
      dateTime: moment.parseZone(start).format("YYYY-MM-DDTHH:mm:ss"),
      timeZone: windowsTimezone,
    },
    end: {
      dateTime: moment.parseZone(end).format("YYYY-MM-DDTHH:mm:ss"),
      timeZone: windowsTimezone,
    },
    recurrence,
    location: { displayName: location },
  };
  return body;
}

function computeUpdateEventBody(eventParams, attendees, resources) {
  return {
    ...computeBaseEventBody(eventParams),
    ...computeEventAttendees(attendees, resources),
  };
}

function computeEventAttendees(attendees, resources) {
  const eventAttendees = [];
  attendees.forEach((item) =>
    eventAttendees.push({
      emailAddress: {
        address: item.email,
        name: item.name,
      },
      type: "required",
    })
  );
  // eslint-disable-next-line no-unused-expressions
  resources?.forEach((item) =>
    eventAttendees.push({
      emailAddress: {
        address: item.room.exchangeMailbox,
        name: item.room.name,
      },
      type: "resource",
    })
  );
  return {
    attendees: eventAttendees,
  };
}

export async function getSchedule(accessToken, eventParams, attendees) {
  const getScheduleUrl = new URL(GET_SCHEDULE_GRAPH_URL);
  const windowsTimezone = WindowsZones.ianaToWindows(eventParams.timezone);

  const requestOptions = {
    method: "POST",
    headers: {
      Accept: "application/json",
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
      Prefer: `outlook.timezone="${windowsTimezone}"`,
    },
    body: JSON.stringify(
      computeGetScheduleBody(eventParams, attendees, windowsTimezone)
    ),
  };
  const request = new Request(getScheduleUrl, requestOptions);
  const response = await fetch(request);
  if (!response.ok) {
    const { error } = await response.json();
    throw error;
  }
  const parsedResponse = await response.json();
  return {
    result: parsedResponse.value,
  };
}

function computeGetScheduleBody(
  { startDate, endDate },
  attendees,
  windowsTimezone
) {
  return {
    startTime: {
      dateTime: moment.parseZone(startDate).format("YYYY-MM-DDTHH:mm:ss"),
      timeZone: windowsTimezone,
    },
    endTime: {
      dateTime: moment.parseZone(endDate).format("YYYY-MM-DDTHH:mm:ss"),
      timeZone: windowsTimezone,
    },
    schedules: attendees,
    availabilityViewInterval: 5,
  };
}

export async function getMe(accessToken) {
  const getMeUrl = new URL(GET_ME_URL);

  const requestOptions = {
    method: "GET",
    headers: {
      Accept: "application/json",
      Authorization: `Bearer ${accessToken}`,
    },
  };

  const request = new Request(getMeUrl, requestOptions);
  const response = await fetch(request);
  if (!response.ok) {
    const { error } = await response.json();
    throw error;
  }
  const parsedResponse = await response.json();
  return {
    result: parsedResponse,
    success: true,
  };
}

export async function removeRoomDetails(
  accessToken,
  eventId,
  attendees,
  description
) {
  const updateEventUrl = new URL(
    UPDATE_EVENT_GRAPH_URL.replace("{eventId}", eventId)
  );

  const requestOptions = {
    method: "PATCH",
    headers: {
      Accept: "application/json",
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(computeEventBodyToBeUpdated(attendees, description)),
  };
  const request = new Request(updateEventUrl, requestOptions);
  const response = await fetch(request);
  if (!response.ok) {
    const { error } = await response.json();
    throw error;
  }
  const parsedResponse = await response.json();
  return {
    id: parsedResponse.id,
  };
}

function computeEventBodyToBeUpdated(attendees, description) {
  const body = {
    body: {
      contentType: "HTML",
      content: description,
    },
    location: { displayName: "" },
    attendees,
  };
  return body;
}

function computeEventExtension({ additionalLocationInfo, onlineMeetingID }) {
  return {
    "@odata.type": OPEN_TYPE_EXTENSION,
    extensionName: EXTENSION_NAME,
    additionalLocationInfo: isEmpty(additionalLocationInfo)
      ? ""
      : additionalLocationInfo,
    onlineMeetingID: isEmpty(onlineMeetingID) ? "" : onlineMeetingID,
  };
}

export async function createEventExtension(accessToken, eventId, eventParams) {
  const createEventUrl = new URL(
    `${EVENT_GRAPH_URL}/${eventId}/${EXTENSION_URL}`
  );

  const requestOptions = {
    method: "POST",
    headers: {
      Accept: "application/json",
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(computeEventExtension(eventParams)),
  };
  const request = new Request(createEventUrl, requestOptions);
  await fetch(request);
}

export async function updateEventEndTime(
  accessToken,
  eventId,
  start,
  end,
  timezone,
  calendarId
) {
  const url = !calendarId
    ? UPDATE_EVENT_GRAPH_URL.replace("{eventId}", eventId)
    : UPDATE_DELEGATE_EVENT_GRAPH_URL.replace(
        "{calendarId}",
        calendarId
      ).replace("{eventId}", eventId);
  const updateEventUrl = new URL(url);

  const requestOptions = {
    method: "PATCH",
    headers: {
      Accept: "application/json",
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(computeStartEndEventBody(start, end, timezone)),
  };
  const request = new Request(updateEventUrl, requestOptions);
  const response = await fetch(request);
  if (!response.ok) {
    const { error } = await response.json();
    throw error;
  }
  const parsedResponse = await response.json();
  return {
    id: parsedResponse.id,
  };
}

function computeStartEndEventBody(start, end, timezone) {
  const windowsTimezone = WindowsZones.ianaToWindows(timezone);
  const body = {
    start: {
      dateTime: moment.parseZone(start).format("YYYY-MM-DDTHH:mm:ss"),
      timeZone: windowsTimezone,
    },
    end: {
      dateTime: moment.parseZone(end).format("YYYY-MM-DDTHH:mm:ss"),
      timeZone: windowsTimezone,
    },
  };
  return body;
}
