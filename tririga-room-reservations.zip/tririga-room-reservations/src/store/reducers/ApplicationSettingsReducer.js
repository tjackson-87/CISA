/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2022 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/

import { applicationSettingsActionTypes } from "../../utils";

const INITIAL_STATE = null;

export const applicationSettingsReducer = (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case applicationSettingsActionTypes.SET_APPLICATION_SETTINGS:
      return action.applicationSettings;
    default:
      return state;
  }
};

const isExchangeIntegratedSelector = ({ applicationSettings }) =>
  applicationSettings == null ? null : applicationSettings.exchangeIntegrated;

const oauthProfileSelector = ({ applicationSettings }) =>
  applicationSettings == null ? null : applicationSettings.oauthProfile;

const occurrenceMatchSelector = ({ applicationSettings }) =>
  applicationSettings == null ? null : applicationSettings.occurrenceMatch;

const roomSearchPageSizeSelector = ({ applicationSettings }) =>
  applicationSettings == null ? 0 : applicationSettings.resultsLimit;

const filterWorkspaceByRoleSelector = ({ applicationSettings }) =>
  applicationSettings == null
    ? false
    : applicationSettings.filterWorkspaceByRole;

const serviceWakeUpDurationSelector = ({ applicationSettings }) =>
  applicationSettings == null
    ? null
    : applicationSettings.serviceWakeUpDuration;

const oauthProfileDomainSelector = ({ applicationSettings }) =>
  applicationSettings == null ? null : applicationSettings.oauthProfileDomain;

export const ApplicationSettingsSelectors = {
  isExchangeIntegratedSelector,
  occurrenceMatchSelector,
  oauthProfileSelector,
  roomSearchPageSizeSelector,
  filterWorkspaceByRoleSelector,
  serviceWakeUpDurationSelector,
  oauthProfileDomainSelector,
};
