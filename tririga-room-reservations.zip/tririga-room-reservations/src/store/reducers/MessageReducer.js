/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import { messageActionTypes, MessageTypes } from "../../utils";

const INITIAL_STATE = null;

export const messageReducer = (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case messageActionTypes.SET_MESSAGE: {
      if (state?.type === MessageTypes.SESSION_EXPIRED) {
        return state;
      }
      return action.message;
    }

    case messageActionTypes.CLEAR_MESSAGE:
      return null;
    default:
      return state;
  }
};

const messageSelector = (state) => state.message;

export const MessageSelectors = {
  messageSelector,
};
