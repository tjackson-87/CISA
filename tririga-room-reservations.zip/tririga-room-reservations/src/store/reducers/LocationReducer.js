/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/


import { locationActionTypes } from "../../utils";

const INITIAL_STATE = {
  buildings: [],
  from: 0,
  totalSize: 0,
  searchText: "",
  selectedBuilding: undefined,
  prevSelectedBuilding: undefined,
  lastMeetingSearchFilters: undefined,
  floors: [],
};

export const locationReducer = (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case locationActionTypes.SET_BUILDINGS: {
      return {
        ...state,
        searchText: action.searchText,
        buildings: action.buildings,
        from: action.from,
        totalSize: action.totalSize,
      };
    }

    case locationActionTypes.CLEAR_SEARCH_LOCATION_SEARCH: {
      return {
        ...state,
        buildings: [],
        from: 0,
        totalSize: 0,
        searchText: "",
      };
    }

    case locationActionTypes.SET_SELECTED_BUILDING: {
      return {
        ...state,
        selectedBuilding: action.selectedBuilding,
      };
    }

    case locationActionTypes.SET_PREVSELECTED_BUILDING: {
      return {
        ...state,
        prevSelectedBuilding: action.prevSelectedBuilding,
      };
    }

    case locationActionTypes.SET_LAST_SEARCH_FILTERS: {
      return {
        ...state,
        lastMeetingSearchFilters: action.lastMeetingSearchFilters,
      };
    }

    case locationActionTypes.SET_FLOORS: {
      return {
        ...state,
        floors: action.floors,
      };
    }

    default:
      return state;
  }
};

const buildingsSelector = ({ location }) => location.buildings;
const totalSizeSelector = ({ location }) => location.totalSize;
const floorsSelector = ({ location }) => location.floors;
const selectedBuildingSelector = ({ location }) => location.selectedBuilding;
const prevSelectedBuildingSelector = ({ location }) =>
  location.prevSelectedBuilding;
const lastMeetingSearchFilters = ({ location }) =>
  location.lastMeetingSearchFilters;
const isSelectedBuildingInitializedSelector = ({ location }) =>
  location.selectedBuilding !== undefined;

export const LocationSelectors = {
  buildingsSelector,
  totalSizeSelector,
  floorsSelector,
  selectedBuildingSelector,
  prevSelectedBuildingSelector,
  isSelectedBuildingInitializedSelector,
  lastMeetingSearchFilters,
};
