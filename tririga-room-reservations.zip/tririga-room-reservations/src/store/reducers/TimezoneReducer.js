/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import { timezoneActionTypes } from "../../utils";

const INITIAL_STATE = null;

export const timezonesReducer = (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case timezoneActionTypes.SET_TIME_ZONES:
      return action.timezones;
    default:
      return state;
  }
};

const timezonesSelector = (state) => state.timezones;

export const TimezonesSelectors = {
  timezonesSelector,
};
