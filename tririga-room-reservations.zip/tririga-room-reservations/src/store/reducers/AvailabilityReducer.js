/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import { availabilityActionTypes, reservationActionTypes } from "../../utils";

const INITIAL_STATE = {
  attendeesExchangeSchedule: null,
  attendeesExchangeScheduleForDay: null,
  resourcesEventsForDay: null,
  resourcesAvailability: null,
};

export const availabilityReducer = (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case reservationActionTypes.INITIALIZE_NEW_RESERVATION:
    case reservationActionTypes.CLEAR_RESERVATION:
      return INITIAL_STATE;

    case availabilityActionTypes.SET_ATTENDEES_EXCHANGE_SCHEDULE: {
      return {
        ...state,
        attendeesExchangeSchedule: action.attendeesExchangeSchedule,
      };
    }

    case availabilityActionTypes.CLEAR_ATTENDEES_EXCHANGE_SCHEDULE: {
      return {
        ...state,
        attendeesExchangeSchedule: null,
      };
    }

    case availabilityActionTypes.SET_ATTENDEES_EXCHANGE_SCHEDULE_FOR_DAY: {
      return {
        ...state,
        attendeesExchangeScheduleForDay: action.attendeesExchangeSchedule,
      };
    }

    case availabilityActionTypes.CLEAR_ATTENDEES_EXCHANGE_SCHEDULE_FOR_DAY: {
      return {
        ...state,
        attendeesExchangeScheduleForDay: null,
      };
    }

    case availabilityActionTypes.SET_RESOURCES_EVENTS_FOR_DAY: {
      return {
        ...state,
        resourcesEventsForDay: action.resourcesEvents,
      };
    }

    case availabilityActionTypes.SET_RESOURCES_AVAILABILITY: {
      return {
        ...state,
        resourcesAvailability: action.resourcesAvailability,
      };
    }

    default:
      return state;
  }
};
