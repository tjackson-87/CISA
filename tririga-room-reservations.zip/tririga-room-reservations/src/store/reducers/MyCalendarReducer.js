/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/

import { isEmpty, isEqual, sortBy } from "lodash";
import { createSelector } from "reselect";
import { getDatesBetween, myCalendarActionTypes } from "../../utils";
import moment from "moment-timezone";
import { getTimeZoneName } from "../../utils/timezones/TimezoneUtils";

const INITIAL_STATE = {
  date: null,
  timezone: null,
  events: null,
  start: null,
  end: null,
};

function checkForMultiDayEvents(events) {
  const eventsAll = [];

  const filteredEvents = events
    .map((e) => {
      const timezone = getTimeZoneName(e.reservationTimezone);
      const startDate = moment.tz(e.start, timezone).startOf("day");
      const endDate = moment.tz(e.end, timezone).startOf("day");
      if (!startDate.isSame(endDate)) {
        return {
          ...e,
          multidayEvent: true,
          eventStart: e.start,
          eventEnd: e.end,
        };
      } else {
        return e;
      }
    })
    .filter(function (e) {
      return (
        e.ignoreEvent === undefined ||
        !e.ignoreEvent ||
        e.multidayEvent === false
      );
    });

  filteredEvents.forEach((e) => {
    if (e.multidayEvent !== undefined) {
      const timezone = getTimeZoneName(e.reservationTimezone);
      const startDate = moment.tz(e.start, timezone).startOf("day");
      const endDate = moment.tz(e.end, timezone).startOf("day");

      while (startDate.add(1, "days").diff(endDate) <= 0) {
        eventsAll.push({
          ...e,
          start: startDate.clone().format(),
          ignoreEvent: true,
          multidayEvent: true,
          eventStart: e.start,
          eventEnd: e.end,
        });
      }
    }
  });

  return filteredEvents.concat(eventsAll);
}

export const myCalendarReducer = (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case myCalendarActionTypes.SET_MY_CALENDAR_DATE:
      return {
        ...state,
        date: action.date,
      };
    case myCalendarActionTypes.SET_MY_CALENDAR_TIMEZONE:
      return {
        ...state,
        timezone: action.timezone,
      };
    case myCalendarActionTypes.SET_MY_CALENDAR_EVENTS:
      return {
        ...state,
        events: checkForMultiDayEvents(action.events),
        start: action.start,
        end: action.end,
      };
    case myCalendarActionTypes.DELETE_MY_CALENDAR_EVENT:
      return {
        ...state,
        events: state.events?.filter(
          (e) => e.eventId !== action.eventId || e.start !== action.start
        ),
      };
    case myCalendarActionTypes.UPDATE_EVENTS_RESERVATION_ID: {
      return {
        ...state,
        events: state.events.map((event) => {
          const matchingUpdatedEvent = action.events.find(
            (updatedEvent) =>
              (event.eventId === updatedEvent.eventId ||
                event.reservationId === updatedEvent.reservationId) &&
              event.start === updatedEvent.start
          );
          return !isEmpty(matchingUpdatedEvent)
            ? {
                ...event,
                ...matchingUpdatedEvent,
                reservationId: action.updatedReservationId,
              }
            : event;
        }),
      };
    }
    case myCalendarActionTypes.UPDATE_EVENTS: {
      return {
        ...state,
        events: state.events.map((event) => {
          const matchingUpdatedEvent = action.events.find(
            (updatedEvent) =>
              (event.eventId === updatedEvent.eventId ||
                event.reservationId === updatedEvent.reservationId) &&
              event.start === updatedEvent.start
          );
          return !isEmpty(matchingUpdatedEvent)
            ? { ...event, ...matchingUpdatedEvent }
            : event;
        }),
      };
    }
    default:
      return state;
  }
};

const dateSelector = ({ myCalendar }) => myCalendar.date;
const timezoneSelector = ({ myCalendar }) => myCalendar.timezone;
const eventsStartAndEndSelector = ({ myCalendar }) => ({
  start: myCalendar.start,
  end: myCalendar.end,
});
const eventsSelector = ({ myCalendar }) => myCalendar.events;

const eventsWithInstances = createSelector([eventsSelector], (events) =>
  events != null
    ? events.map((e) => {
        if (isEmpty(e.instance)) return e;
        return { ...e };
      })
    : events
);

let prevCalendarEvents;

const calendarEventsSelector = createSelector(
  [
    dateSelector,
    eventsWithInstances,
    eventsStartAndEndSelector,
    timezoneSelector,
  ],
  (date, events, startAndEndDates, timezone) => {
    if (
      date &&
      events &&
      startAndEndDates &&
      timezone &&
      !isEqual(prevCalendarEvents, events)
    ) {
      const datesBetween = getDatesBetween(
        startAndEndDates.start,
        events,
        startAndEndDates.end,
        timezone
      );

      const eventsBetween = datesBetween.map((date) => {
        return { start: date };
      });
      const combined = [...eventsBetween, ...events];
      const sortedEvents = sortBy(combined, (event) => {
        return moment(moment.tz(event.start, timezone)).valueOf();
      });

      const calendarEvents = sortedEvents;
      prevCalendarEvents = calendarEvents;
      return calendarEvents;
    }
    return prevCalendarEvents;
  }
);

const eventSelector = (state, eventId, start, end) => {
  if (eventId == null) return null;
  const events = eventsSelector(state);
  const momentStart = moment(start);
  const momentEnd = moment(end);
  const event = events?.find(
    (item) =>
      item.eventId === eventId &&
      momentStart.isSame(item.start, "minutes") &&
      momentEnd.isSame(item.end, "minutes")
  );
  return event === undefined ? null : event;
};

const eventSelectorWithId = (state, eventId, reservationId) => {
  if (eventId == null) return null;
  const events = eventsSelector(state);
  const event = events?.find(
    (item) => item.eventId === eventId && item.reservationId === reservationId
  );
  return event === undefined ? null : event;
};

const eventByReservationIdSelector = (state, reservationId, start) => {
  if (reservationId == null) return null;
  const events = eventsSelector(state);
  const momentStart = moment(start);
  const event = events?.find(
    (item) =>
      item.reservationId === reservationId &&
      momentStart.isSame(item.start, "minutes")
  );
  return event === undefined ? null : event;
};

const seriesOccurrencesSelector = (state, iCalUId) => {
  if (iCalUId === null) return null;
  const events = eventsSelector(state);
  const event = events?.filter((item) => item.seriesICalUId === iCalUId);
  return event === undefined ? null : event;
};

export const MyCalendarSelectors = {
  eventsSelector,
  dateSelector,
  eventsStartAndEndSelector,
  timezoneSelector,
  calendarEventsSelector,
  eventSelector,
  eventSelectorWithId,
  eventByReservationIdSelector,
  seriesOccurrencesSelector,
};
