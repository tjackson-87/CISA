/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/

import { currentUserActionTypes, CodeScannerConstants } from "../../utils";

const { BAR } = CodeScannerConstants;

const INITIAL_STATE = {
  data: null,
  carbonDateFormat: null,
  carbonLocale: null,
  role: null,
  defaultTimezone: null,
  privateRooms: [],
  scanType: BAR,
};

export const currentUserReducer = (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case currentUserActionTypes.SET_CURRENT_USER:
      return {
        ...state,
        data: action.data,
        carbonDateFormat: action.carbonDateFormat,
        carbonLocale: action.carbonLocale,
      };
    case currentUserActionTypes.SET_FAVORITE_ROOMS:
      return { ...state, favoriteRooms: action.favoriteRooms };
    case currentUserActionTypes.UPDATE_FAVORITE_ROOMS:
      return { ...state, favoriteRooms: action.favoriteRooms };
    case currentUserActionTypes.SET_CURRENT_USER_ROLE:
      return { ...state, role: action.role };
    case currentUserActionTypes.SET_PRIVATE_ROOMS:
      return { ...state, privateRooms: action.privateRooms };
    case currentUserActionTypes.SET_DEFAULT_TIMEZONE:
      return { ...state, defaultTimezone: action.timezone };
    case currentUserActionTypes.SET_SCAN_TYPE:
      return { ...state, scanType: action.scanType };
    default:
      return state;
  }
};

const carbonDateFormatSelector = (state) =>
  state.currentUser == null || state.currentUser.data == null
    ? null
    : state.currentUser.carbonDateFormat;

const carbonLocaleSelector = (state) =>
  state.currentUser == null ? null : state.currentUser.carbonLocale;

const dateFormatSelector = (state) =>
  state.currentUser == null || state.currentUser.data == null
    ? null
    : state.currentUser.data._DateFormat;

const localeSelector = (state) =>
  state.currentUser == null || state.currentUser.data == null
    ? null
    : state.currentUser.data._Locale;

const languageSelector = (state) =>
  state.currentUser == null || state.currentUser.data == null
    ? null
    : state.currentUser.data._Language;

const idSelector = (state) =>
  state.currentUser == null || state.currentUser.data == null
    ? null
    : state.currentUser.data._id;

const personIdSelector = (state) =>
  state.currentUser == null || state.currentUser.data == null
    ? null
    : state.currentUser.data.personId;

const favoriteRoomsSelector = (state) =>
  state.currentUser == null ? null : state.currentUser.favoriteRooms;

const currentUserRoleSelector = (state) =>
  state.currentUser == null ? null : state.currentUser.role;

const privateRoomsSelector = (state) =>
  state.currentUser == null ? null : state.currentUser.privateRooms;
const defaultTimezoneSelector = (state) =>
  state.currentUser == null ? null : state.currentUser.defaultTimezone;

const currentUserEmailSelector = (state) =>
  state.currentUser == null || state.currentUser.data == null
    ? null
    : state.currentUser.data.email;

const accountCodeEquipmentSelector = (state) =>
  state.currentUser == null || state.currentUser.data == null
    ? null
    : state.currentUser.data.accountCodeEquipment;

const accountCodeFoodSelector = (state) =>
  state.currentUser == null || state.currentUser.data == null
    ? null
    : state.currentUser.data.accountCodeFood;

const accountCodeRoomSelector = (state) =>
  state.currentUser == null || state.currentUser.data == null
    ? null
    : state.currentUser.data.accountCodeRoom;

const scanTypeSelector = (state) =>
  state.currentUser == null || state.currentUser.data == null
    ? null
    : state.currentUser.scanType;

export const CurrentUserSelectors = {
  carbonDateFormatSelector,
  carbonLocaleSelector,
  dateFormatSelector,
  localeSelector,
  idSelector,
  favoriteRoomsSelector,
  currentUserRoleSelector,
  personIdSelector,
  languageSelector,
  privateRoomsSelector,
  defaultTimezoneSelector,
  currentUserEmailSelector,
  accountCodeEquipmentSelector,
  accountCodeFoodSelector,
  accountCodeRoomSelector,
  scanTypeSelector,
};
