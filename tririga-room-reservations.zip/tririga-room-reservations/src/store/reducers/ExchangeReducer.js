/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2022 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/

import isEmpty from "lodash/isEmpty";
import moment from "moment-timezone";
import { createSelector } from "reselect";
import { exchangeActionTypes } from "../../utils";
import { ORGANIZATION_USER } from "../../model/exchange/ExchangePeople";
import { CurrentUserSelectors } from "./CurrentUserReducer";

const INITIAL_STATE = {
  accessToken: null,
  accessTokenExpireDate: null,
  peopleList: null,
  loadingPeople: false,
  loadingMorePeople: false,
  profile: null,
};

export const exchangeReducer = (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case exchangeActionTypes.SET_ACCESS_TOKEN:
      return {
        ...state,
        accessToken: action.accessToken,
        accessTokenExpireDate: action.accessTokenExpireDate,
      };

    case exchangeActionTypes.SET_PEOPLE_LIST: {
      const peopleList = action.append
        ? {
            ...action.peopleList,
            data: [...state.peopleList.data, ...action.peopleList.data],
          }
        : action.peopleList;
      return {
        ...state,
        peopleList,
      };
    }

    case exchangeActionTypes.CLEAR_PEOPLE_LIST:
      return {
        ...state,
        peopleList: null,
      };

    case exchangeActionTypes.SET_USER_EXCHANGE_PROFILE: {
      return {
        ...state,
        profile: action.exchangeProfile,
      };
    }

    case exchangeActionTypes.SET_DELEGATE_CALENDARS: {
      return {
        ...state,
        calendars: action.delegateCalendars,
      };
    }

    case exchangeActionTypes.SET_CURRENT_CALENDAR: {
      return {
        ...state,
        currentCalendar: action.calendar,
      };
    }

    default:
      return state;
  }
};

const hasAccessTokenSelector = ({ exchange }) => {
  if (isEmpty(exchange.accessToken) || !exchange.accessTokenExpireDate) {
    return false;
  }
  return moment().isBefore(exchange.accessTokenExpireDate);
};
const accessTokenSelector = ({ exchange }) => exchange.accessToken;
const peopleListSelector = ({ exchange }) =>
  exchange.peopleList != null
    ? exchange.peopleList
    : { data: null, hasMore: false };

const userProfileSelector = ({ exchange }) => exchange.profile;

const userExchangeProfileSelector = createSelector(
  [userProfileSelector],
  (userProfile) => {
    if (!userProfile) return null;
    return {
      type: ORGANIZATION_USER,
      email: userProfile.mail,
      name: userProfile.displayName,
      firstName: userProfile.givenName,
      lastName: userProfile.surname,
    };
  }
);

const delegateCalendarsSelector = ({ exchange }) => exchange.calendars;

const currentCalendarSelector = ({ exchange }) => exchange.currentCalendar;

const currentCalenderProfileSelector = createSelector(
  [currentCalendarSelector],
  (userProfile) => {
    if (!userProfile) return null;
    return {
      type: ORGANIZATION_USER,
      email: userProfile.email,
      name: userProfile.name,
      firstName: userProfile.givenName,
      lastName: userProfile.surname,
    };
  }
);

const userProfileIdSelector = createSelector(
  [currentCalendarSelector, CurrentUserSelectors.idSelector],
  (userProfile, currentUserProfileId) => {
    if (!userProfile) return `${currentUserProfileId}`;
    return userProfile.userProfileId;
  }
);

export const ExchangeSelectors = {
  accessTokenSelector,
  peopleListSelector,
  hasAccessTokenSelector,
  userExchangeProfileSelector,
  currentCalenderProfileSelector,
  currentCalendarSelector,
  delegateCalendarsSelector,
  userProfileIdSelector,
};
