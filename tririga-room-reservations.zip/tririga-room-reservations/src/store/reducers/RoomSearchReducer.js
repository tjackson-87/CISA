/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021, 2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import { roomSearchActionTypes, DefaultValues } from "../../utils";
import { RoomViewMode } from "../../components";
import { uniqBy } from "lodash";

const INITIAL_STATE = {
  filters: {
    capacity: DefaultValues.CAPACITY,
    layoutType: DefaultValues.LAYOUT_TYPE,
    amenities: DefaultValues.AMENITIES,
    showCollateralTypeOnly: DefaultValues.SHOW_COLLATERAL_TYPE_ROOMS, // CISA
    showUnavailable: DefaultValues.SHOW_UNAVAILABLE_ROOMS,
    showFavoritesOnly: DefaultValues.SHOW_FAVORITES_ONLY,
    showRequestableRooms: DefaultValues.SHOW_REQUESTABLE_ROOMS,
    showPrivateRooms: DefaultValues.SHOW_PRIVATE_ROOMS,
    floor: null,
    rooms: null,
  },
  result: [],
  hasMoreResults: false,
  pageFrom: 0,
  totalSize: 0,
  type: null,
  selectedRoom: null,
  roomViewMode: RoomViewMode.LIST,
  scannedResult: null,
  scannerType: "",
  searchByNameResult: [],
  searchText: "",
  selectedRoomByName: null,
  moreResults: false,
  total: 0,
  isLocationModalOpen: false,
  isSearchColleagueModalOpen: false,
  isFilterModalOpen: false,
  isRoomModalOpen: false,
  isRoomRecurrenceModalOpen: false,
  isRecurrenceModalOpen: false,
  rememberFloorplanLastPosition: false,
};

export const roomSearchReducer = (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case roomSearchActionTypes.INIT_ROOM_SEARCH:
      return {
        ...INITIAL_STATE,
      };

    case roomSearchActionTypes.SET_FLOOR_FILTER: {
      return {
        ...state,
        filters: { ...state.filters, floor: action.floor },
        selectedRoom: null,
        roomViewMode:
          action.floor == null ? RoomViewMode.LIST : state.roomViewMode,
      };
    }

    case roomSearchActionTypes.SET_ROOMS_FILTER: {
      return {
        ...state,
        filters: { ...state.filters, rooms: action.rooms },
      };
    }

    case roomSearchActionTypes.UPDATE_FILTERS: {
      return {
        ...state,
        filters: { ...state.filters, ...action.filters },
      };
    }

    case roomSearchActionTypes.UPDATE_CAPACITY_FILTERS: {
      return {
        ...state,
        filters: { ...state.filters, capacity: action.capacity },
      };
    }

    case roomSearchActionTypes.SET_ROOM_SEARCH_RESULT: {
      const newResult = uniqBy(
        [...state.result, ...action.roomSearchResult],
        "_id"
      );
      return {
        ...state,
        result:
          action.checkMore || action.cache
            ? newResult
            : action.roomSearchResult,
        hasMoreResults: action.hasMoreResults,
        pageFrom: action.pageFrom,
        totalSize: action.totalSize,
      };
    }

    case roomSearchActionTypes.SET_ROOM_VIEW_MODE: {
      return {
        ...state,
        roomViewMode: action.mode,
      };
    }

    case roomSearchActionTypes.SET_SELECTED_ROOM_ON_FLOORPLAN: {
      return {
        ...state,
        selectedRoom: action.selectedRoom,
      };
    }

    case roomSearchActionTypes.SET_SELECTED_ROOM: {
      return {
        ...state,
        checkedRooms: action.checkedRooms,
      };
    }

    case roomSearchActionTypes.REMOVE_CHECKED_ROOMS: {
      return {
        ...state,
        checkedRooms: [],
      };
    }

    case roomSearchActionTypes.SET_SCANNED_ROOM_SEARCH_RESULT: {
      return {
        ...state,
        scannedResult: action.scannedResult,
      };
    }

    case roomSearchActionTypes.SET_SCANNER_TYPE: {
      return {
        ...state,
        scannerType: action.scannerType,
      };
    }

    case roomSearchActionTypes.SET_ROOM_SEARCH_BY_NAME_RESULT: {
      return {
        ...state,
        searchByNameResult: action.checkMore
          ? [...state.searchByNameResult, ...action.roomSearchResult]
          : action.roomSearchResult,
        moreResults: action.hasMoreResults,
        pageFrom: action.pageFrom,
        total: action.totalSize,
        searchText: action.searchText,
      };
    }

    case roomSearchActionTypes.SET_SELECTED_ROOMS: {
      return {
        ...state,
        selectedRoomByName: action.selectedRoom,
      };
    }

    case roomSearchActionTypes.SET_LOCATION_MODAL: {
      return {
        ...state,
        isLocationModalOpen: action.isOpen,
      };
    }

    case roomSearchActionTypes.SET_SEARCH_COLLEAGUE_MODAL: {
      return {
        ...state,
        isSearchColleagueModalOpen: action.isOpen,
      };
    }

    case roomSearchActionTypes.SET_FILTER_MODAL: {
      return {
        ...state,
        isFilterModalOpen: action.isOpen,
      };
    }

    case roomSearchActionTypes.SET_ROOM_DETAILS_MODAL: {
      return {
        ...state,
        isRoomModalOpen: action.isOpen,
      };
    }

    case roomSearchActionTypes.SET_ROOM_RECURRENCE_DETAILS_MODAL: {
      return {
        ...state,
        isRoomRecurrenceModalOpen: action.isOpen,
      };
    }

    case roomSearchActionTypes.SET_RECURRENCE_MODAL: {
      return {
        ...state,
        isRecurrenceModalOpen: action.isOpen,
      };
    }

    case roomSearchActionTypes.SET_REMEMBER_FLOORPLAN_LAST_POSITION: {
      return {
        ...state,
        rememberFloorplanLastPosition: action.remember,
      };
    }

    default:
      return state;
  }
};
