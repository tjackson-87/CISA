/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2022 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/

import { onlineMeetingActionTypes, OnlineMeetingConstants } from "../../utils";

const INITIAL_STATE = {
  list: [],
  selectedId: OnlineMeetingConstants.NO_SELECTED_MEETING_KEY,
  record: null,
  edit: false,
};

export const onlineMeetingReducer = (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case onlineMeetingActionTypes.SET_ONLINE_MEETINGS:
      return {
        ...state,
        list: action.data,
        edit: false,
      };
    // CISA
    case onlineMeetingActionTypes.TEAMS_MEETING_KEY: {
      let edit = false
      return {
        ...state,
        selectedId: action.selectedId,
        record: action.data,
        edit
      }
    }

    case onlineMeetingActionTypes.SET_SELECTED_ONLINE_MEETING: {
      let edit = false;
      let record = null;
      if (action.selectedId === OnlineMeetingConstants.NEW_ONLINE_MEETING_KEY) {
        record = {
          name: "",
          url: "",
          callInInformation: "",
          _id: "",
          password: "",
          defaultMeeting: false,
          ownerId: action.userProfileId,
        };
        edit = true;
      } else if (
        action.selectedId === OnlineMeetingConstants.NO_SELECTED_MEETING_KEY
      ) {
        record = null;
      } else {
        const onlineMeetings = state.list;
        record = onlineMeetings.find((d) => d._id === action.selectedId);
      }
      return {
        ...state,
        selectedId: action.selectedId,
        record,
        edit,
      };
    }

    case onlineMeetingActionTypes.SET_ONLINE_MEETING_EDIT_FLAG: {
      return {
        ...state,
        edit: action.edit,
      };
    }

    case onlineMeetingActionTypes.UPDATE_ONLINE_MEETING_RECORD: {
      return {
        ...state,
        record: {
          ...state.record,
          [action.key]: action.value,
        },
      };
    }
    default:
      return state;
  }
};

const onlineMeetingsSelector = (state) => {
  return state.onlineMeetings.list;
};

const selectedRecordSelector = (state) => {
  return state.onlineMeetings.record;
};

const editRecordSelector = (state) => {
  return state.onlineMeetings.edit;
};

const selectedIdSelector = (state) => {
  return state.onlineMeetings.selectedId;
};

export const OnlineMeetingSelectors = {
  onlineMeetingsSelector,
  selectedRecordSelector,
  editRecordSelector,
  selectedIdSelector,
};
