/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import { layoutActionTypes } from "../../utils";

const INITIAL_STATE = { small: false };

export const layoutReducer = (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case layoutActionTypes.SET_LAYOUT:
      return { ...state, ...action.layout };
    case layoutActionTypes.SET_USER_DIR:
      return {
        ...state,
        dir: action.dir,
      };
    default:
      return state;
  }
};

const dirSelector = (state) => {
  return state?.layout?.dir == null ? "ltr" : state.layout.dir;
};

export const LayoutSelectors = { dirSelector };
