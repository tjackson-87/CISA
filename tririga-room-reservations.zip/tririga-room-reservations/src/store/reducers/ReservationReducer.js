/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2022 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/

import defaultTo from "lodash/defaultTo";
import isEmpty from "lodash/isEmpty";
import {
  reservationActionTypes,
  DateTimeConstants,
  ReservationUtils,
} from "../../utils";

const { DateTimeViewMode } = DateTimeConstants;

const INITIAL_STATE = {
  create: false,
  data: null,
  timeStepTempData: null,
  type: null,
  exchangeEventId: null,
  editMode: null,
  selectedResource: null,
};

export const reservationReducer = (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case reservationActionTypes.INITIALIZE_NEW_RESERVATION:
      return {
        ...INITIAL_STATE,
        create: true,
        data: {
          subject: action.subject,
          description: "",
          onlineMeeting: null,
          info: action.info,
          startDate: action.startDate,
          startTime: action.startTime,
          startTimePeriod: action.startTimePeriod,
          endDate: action.endDate,
          endTime: action.endTime,
          endTimePeriod: action.endTimePeriod,
          timezone: action.timezone,
          allDayEvent: false,
          resources: [],
          holdTimeEnd: null,
          holdTimeExpired: false,
          attendees: [],
          recurrence: null,
          accountCodeRoom: action.accountCodeRoom,
          accountCodeFood: action.accountCodeFood,
          accountCodeEquipment: action.accountCodeEquipment,
          estimatedCostEquipment: action.estimatedCostEquipment,
          estimatedCostFood: action.estimatedCostFood,
          estimatedCostResource: action.estimatedCostResource,
        },
        timeStepTempData: {
          startDate: action.startDate,
          startTime: action.startTime,
          startTimePeriod: action.startTimePeriod,
          endDate: action.endDate,
          endTime: action.endTime,
          endTimePeriod: action.endTimePeriod,
          timezone: action.timezone,
          allDayEvent: false,
          recurrence: null,
          dateTimeViewMode: DateTimeViewMode.SIMPLE,
        },
        type: action.reservationType,
      };

    case reservationActionTypes.UPDATE_RESERVATION_DATA: {
      return {
        ...state,
        data: {
          ...state.data,
          ...action.value,
        },
      };
    }

    case reservationActionTypes.SET_RESOURCES_ON_HOLD: {
      const newResources = [];
      action.resources.forEach((resource) => {
        const resourceOld = state.data.resources.find(
          (r) => r.data.roomId === resource.data.roomId
        );
        const isRecurring = state.data.recurrence != null;
        newResources.push({
          showMoreOptions: false,
          removed: false,
          ...resourceOld,
          onHold: ReservationUtils.isAvailable(resource.data.statusENUS),
          data: resource.data,
          room: resource.room != null ? resource.room : resourceOld.room,
          ...(isRecurring && isEmpty(resource.exceptions)
            ? {
                exceptions: setRoomExceptions(resource.room?._occurrenceList),
              }
            : { exceptions: resource.exceptions }),
        });
      });
      state.data.resources.forEach((resource) => {
        if (
          resource.reserved &&
          !newResources.some(
            (newResource) => newResource.data.roomId === resource.data.roomId
          )
        ) {
          newResources.push({ ...resource, onHold: false });
        }
      });
      return setResources(state, newResources);
    }

    case reservationActionTypes.SET_RESERVED_RESOURCES: {
      const newResources = action.resources.map((resource) => ({
        showMoreOptions: false,
        data: resource.data,
        room: resource.room,
        reserved: true,
      }));
      return setResources(state, newResources);
    }
    case reservationActionTypes.REMOVE_RESOURCE_UNHOLD_ROOM_SERIES_EXCEPTION: {
      const newResources = [];
      state.data.resources.forEach((resource) => {
        if (resource.data._id !== action.resourceId) {
          newResources.push(resource);
        }
      });
      return setResources(state, newResources);
    }

    case reservationActionTypes.REMOVE_RESOURCE: {
      const newResources = [];
      state.data.resources.forEach((resource) => {
        if (resource.data._id === action.resourceId) {
          if (resource.reserved) {
            newResources.push({ ...resource, removed: true, onHold: false });
          }
        } else {
          newResources.push(resource);
        }
      });
      return setResources(state, newResources);
    }

    case reservationActionTypes.UNDO_REMOVE_RESOURCE: {
      const newResources = [];
      state.data.resources.forEach((resource) => {
        if (resource.data._id === action.resourceId) {
          newResources.push({ ...resource, removed: false, onHold: false });
        } else {
          newResources.push(resource);
        }
      });
      return setResources(state, newResources);
    }

    case reservationActionTypes.SET_RESOURCE_SHOW_MORE_FLAG: {
      const newResources = [];
      state.data.resources.forEach((resource) => {
        if (action.roomId === resource.data.roomId) {
          newResources.push({
            ...resource,
            showMoreOptions: action.showMoreOptions,
          });
        } else {
          newResources.push(resource);
        }
      });
      return setResources(state, newResources);
    }

    case reservationActionTypes.SET_RESOURCES_AVAILABLE_EQUIPMENT: {
      const newResources = [];
      if (state.data.resources) {
        state.data.resources.forEach((resource) => {
          const resourceAvailableEquipment = action.availableEquipmentForAllResources.find(
            (r) => r.roomId === resource.data.roomId
          );
          newResources.push({
            ...resource,
            availableEquipment: defaultTo(
              resourceAvailableEquipment?.availableEquipment,
              []
            ),
          });
        });
      }
      return setResources(state, newResources);
    }

    case reservationActionTypes.SET_RESOURCE_SELECTED_EQUIPMENT: {
      const newResources = [];
      state.data.resources.forEach((resource) => {
        if (action.roomId === resource.data.roomId) {
          newResources.push({
            ...resource,
            selectedEquipment: action.selectedEquipment,
            addedEquipment: [],
            addedEquipmentSaved: true, // tells whether the updated equipments are saved or not
          });
        } else {
          newResources.push(resource);
        }
      });
      return setResources(state, newResources);
    }

    case reservationActionTypes.SET_RESOURCE_ADDED_EQUIPMENT: {
      const newResources = [];
      state.data.resources.forEach((resource) => {
        if (action.roomId === resource.data.roomId) {
          newResources.push({
            ...resource,
            addedEquipment: action.addedEquipment,
            addedEquipmentSaved: false, // tells whether the updated equipments are saved or not
          });
        } else {
          newResources.push(resource);
        }
      });
      return setResources(state, newResources);
    }

    case reservationActionTypes.SET_RESOURCES_AVAILABLE_CATERING_ITEMS: {
      const newResources = [];
      state.data.resources.forEach((resource) => {
        const resourceAvailableCatering = action.menuItemsForAllResources.find(
          (r) => r.roomId === resource.data.roomId
        );
        newResources.push({
          ...resource,
          availableCatering: defaultTo(
            resourceAvailableCatering?.availableCatering,
            []
          ),
        });
      });
      return setResources(state, newResources);
    }

    case reservationActionTypes.SET_RESOURCE_SELECTED_CATERING: {
      const newResources = [];
      state.data.resources.forEach((resource) => {
        if (action.roomId === resource.data.roomId) {
          newResources.push({
            ...resource,
            selectedCatering: action.selectedCatering,
          });
        } else {
          newResources.push(resource);
        }
      });
      return setResources(state, newResources);
    }

    case reservationActionTypes.SET_RESOURCES_SELECTED_CATERING_DELIVERY_TIME: {
      const newResources = [];
      state.data.resources.forEach((resource) => {
        if (resource && resource.selectedCatering) {
          resource.selectedCatering.forEach((catering) => {
            catering.additionalInformation.deliveryTime = action.startTime;
            catering.additionalInformation.deliveryTimePeriod =
              action.startTimePeriod;
          });
        }

        newResources.push({
          ...resource,
          selectedCatering: resource.selectedCatering,
        });
      });
      return setResources(state, newResources);
    }

    case reservationActionTypes.UPDATE_TIME_STEP_TEMP_DATA: {
      return {
        ...state,
        timeStepTempData: {
          ...state.timeStepTempData,
          ...action.value,
        },
      };
    }
    case reservationActionTypes.IS_RESERVATION_SERIES_WITH_EXCEPTIONS_DATA: {
      return {
        ...state,
        isReservationSeriesWithException:
          action.value.isReservationSeriesWithException,
        seriesMasterId: action.value.seriesMasterId,
        seriesReservationId: action.value.seriesReservationId,
      };
    }

    case reservationActionTypes.UPDATE_HOLD_TIME_END: {
      return {
        ...state,
        data: {
          ...state.data,
          holdTimeEnd: action.holdTimeEnd,
          holdTimeExpired: false,
        },
      };
    }

    case reservationActionTypes.SET_HOLD_TIME_EXPIRED: {
      return {
        ...state,
        data: {
          ...state.data,
          holdTimeExpired: true,
        },
      };
    }

    case reservationActionTypes.CLEAR_RESERVATION: {
      return INITIAL_STATE;
    }

    case reservationActionTypes.SET_ATTENDEES: {
      return {
        ...state,
        data: {
          ...state.data,
          attendees: action.attendees,
        },
      };
    }

    case reservationActionTypes.SET_MEETING_RECURRENCE_DETAILS: {
      return {
        ...state,
        data: {
          ...state.data,
          recurrence: {
            ...state.data.recurrence,
            details: action.details,
          },
        },
      };
    }

    case reservationActionTypes.SET_TEMP_RECURRENCE_DETAILS: {
      return {
        ...state,
        timeStepTempData: {
          ...state.timeStepTempData,
          recurrence: {
            ...state.timeStepTempData.recurrence,
            details: action.details,
          },
        },
      };
    }

    case reservationActionTypes.LOAD_RESERVATION:
      return {
        ...INITIAL_STATE,
        create: false,
        data: {
          subject: action.subject,
          description: action.description,
          additionalLocationInfo: action.additionalLocationInfo,
          startDate: action.startDate,
          startTime: action.startTime,
          startTimePeriod: action.startTimePeriod,
          eventStart: action.start,
          endDate: action.endDate,
          endTime: action.endTime,
          endTimePeriod: action.endTimePeriod,
          eventEnd: action.end,
          timezone: action.timezone,
          allDayEvent: action.allDayEvent,
          resources: [],
          holdTimeEnd: null,
          holdTimeExpired: false,
          attendees: [],
          recurrence: action.recurrence,
          reservationId: action.reservationId,
          iCalUId: action.iCalUId,
          isReservationExchangeOnly: action.isReservationExchangeOnly,
          accountCodeRoom: action.accountCodeRoom,
          accountCodeFood: action.accountCodeFood,
          accountCodeEquipment: action.accountCodeEquipment,
          estimatedCostEquipment: action.estimatedCostEquipment,
          estimatedCostFood: action.estimatedCostFood,
          estimatedCostResource: action.estimatedCostResource,
          seriesICalUId: action.seriesICalUId,
        },
        timeStepTempData: {
          startDate: action.startDate,
          startTime: action.startTime,
          startTimePeriod: action.startTimePeriod,
          endDate: action.endDate,
          endTime: action.endTime,
          endTimePeriod: action.endTimePeriod,
          timezone: action.timezone,
          allDayEvent: action.allDayEvent,
          recurrence: action.recurrence,
          dateTimeViewMode: action.dateTimeViewMode,
        },
        exchangeEventId: action.exchangeEventId,
        editMode: action.editMode,
        type: action.reservationType,
      };

    case reservationActionTypes.SET_RESERVATION_ONLINE_MEETING: {
      return {
        ...state,
        data: {
          ...state.data,
          onlineMeeting: isEmpty(action.onlineMeeting)
            ? null
            : { ...action.onlineMeeting },
        },
      };
    }
    // CISA
    case reservationActionTypes.SET_GENERATE_ONLINE_MEETING: {
      return {
        ...state,
        data: {
          ...state.data,
          generateOnlineMeeting: action.generateOnlineMeeting,
        },
      };
    }

    case reservationActionTypes.SET_RESOURCE_ORDERED_CATERING: {
      const newResources = [];
      state.data.resources.forEach((resource) => {
        if (action.roomId === resource.data.roomId) {
          newResources.push({
            ...resource,
            orderedCatering: action.orderedCatering,
          });
        } else {
          newResources.push(resource);
        }
      });
      return setResources(state, newResources);
    }

    case reservationActionTypes.SET_RESOURCE_TO_BE_UPDATED_CATERING: {
      const newResources = [];
      state.data.resources.forEach((resource) => {
        if (action.roomId === resource.data.roomId) {
          newResources.push({
            ...resource,
            toBeUpdatedCatering: action.toBeUpdatedCatering,
          });
        } else {
          newResources.push(resource);
        }
      });
      return setResources(state, newResources);
    }

    case reservationActionTypes.SET_SELECTED_RESOURCE: {
      return {
        ...state,
        selectedResource: { ...action.resource },
      };
    }

    case reservationActionTypes.SET_SELECTED_EXCEPTION: {
      const newExceptions = state.selectedResource.exceptions.filter(
        (e) => e.start !== action.exception.start
      );
      return {
        ...state,
        selectedResource: {
          ...state.selectedResource,
          exceptions: [...newExceptions, { ...action.exception }],
          selectedException: action.exception,
        },
      };
    }

    case reservationActionTypes.SET_INIT_UPDATED_DATA: {
      return {
        ...state,
        initUpdatedData: { ...action.data },
      };
    }

    case reservationActionTypes.SET_RESOURCES: {
      return setResources(state, action.resources);
    }

    case reservationActionTypes.SET_RESERVATION_TYPE: {
      return {
        ...state,
        type: action.reservationType,
      };
    }

    default:
      return state;
  }
};

function setRoomExceptions(occurrences) {
  if (occurrences === null || occurrences === undefined) return null;
  if (occurrences.every((occurrence) => !occurrence.isAvailable)) return null;
  const result = occurrences
    .filter((occurrence) => !occurrence.isAvailable)
    .map((occurrence) => {
      return {
        start: occurrence.start,
        end: occurrence.end,
        room: null,
        isAvailable: occurrence.isAvailable,
      };
    });

  return result;
}

function setResources(state, resources) {
  return {
    ...state,
    data: {
      ...state.data,
      resources,
    },
  };
}
