/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import { layoutTypesActionTypes, LayoutTypesConstants } from "../../utils";
import { groupBy } from "lodash";

const INITIAL_STATE = { meeting: [], workspace: [] };

export const layoutTypesReducer = (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case layoutTypesActionTypes.SET_LAYOUT_TYPES: {
      const layoutTypes = action.layoutTypes;
      const layoutTypesGroupedByParent = groupBy(layoutTypes, (type) => {
        if (
          type.internalParentValue ===
          LayoutTypesConstants.MEETING_PARENT_LIST_INTERNAL_VALUE
        ) {
          return "meeting";
        } else if (
          type.internalParentValue ===
          LayoutTypesConstants.WORKSPACE_PARENT_LIST_INTERNAL_VALUE
        ) {
          return "workspace";
        }
      });
      return {
        ...state,
        meeting: layoutTypesGroupedByParent.meeting,
        workspace: layoutTypesGroupedByParent.workspace,
      };
    }
    default:
      return state;
  }
};

const meetingLayoutTypesSelector = ({ layoutTypes }) =>
  !layoutTypes || !layoutTypes.meeting ? [] : layoutTypes.meeting;

const workspaceLayoutTypesSelector = ({ layoutTypes }) =>
  !layoutTypes || !layoutTypes.workspace ? [] : layoutTypes.workspace;

export const LayoutTypesSelectors = {
  meetingLayoutTypesSelector,
  workspaceLayoutTypesSelector,
};
