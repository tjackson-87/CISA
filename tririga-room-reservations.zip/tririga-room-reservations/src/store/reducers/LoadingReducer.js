/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/

import { loadingActionTypes } from "../../utils";

const INITIAL_STATE = {
  main: false,
  searchMeetingRooms: false,
};

const loadingMap = new Map();
const nonGlobalLoadingMap = new Map();

const NON_GLOBAL_LOADINGS = [
  "searchRooms",
  "searchMoreRooms",
  "searchingBuildings",
  "searchingMoreBuildings",
  "searchingColleagues",
  "searchingMoreColleagues",
  "loadingPeople",
  "loadingMorePeople",
  "loadingEvents",
  "loadingColleagueReservations",
  "loadingMoreEventsBefore",
  "loadingMoreEventsAfter",
  "loadingEventDescriptionAndAttendees",
  "loadingReservationAttendees",
  "menuItems",
  "equipment",
  "loadingReservation",
];

export const loadingReducer = (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case loadingActionTypes.SET_LOADING:
      if (NON_GLOBAL_LOADINGS.includes(action.key)) {
        return {
          ...state,
          [action.key]: computeNonGlobalLoading(action.key, action.loading),
        };
      } else {
        return {
          ...state,
          main: computeLoading(action.key, action.loading),
        };
      }

    default:
      return state;
  }
};

export const computeLoading = (key, loading) => {
  updateLoadingMap(loadingMap, key, loading);
  for (const loadingCount of loadingMap.values()) {
    if (loadingCount > 0) return true;
  }
  return false;
};

function computeNonGlobalLoading(key, loading) {
  updateLoadingMap(nonGlobalLoadingMap, key, loading);
  return nonGlobalLoadingMap.get(key) > 0;
}

function updateLoadingMap(map, key, loading) {
  let loadingCount = map.get(key);
  if (loadingCount == null) loadingCount = 0;
  loading ? ++loadingCount : --loadingCount;
  map.set(key, loadingCount);
}

const mainLoadingSelector = (state) => state.loading.main;

const searchingRoomsSelector = (state) => state.loading.searchRooms;
const searchingMoreRoomsSelector = (state) => state.loading.searchMoreRooms;
const searchingBuildingsSelector = (state) => state.loading.searchingBuildings;
const searchingMoreBuildingsSelector = (state) =>
  state.loading.searchingMoreBuildings;
const searchingColleaguesSelector = (state) =>
  state.loading.searchingColleagues;
const searchingMoreColleaguesSelector = (state) =>
  state.loading.searchingMoreColleagues;
const loadingPeopleSelector = (state) => state.loading.loadingPeople;
const loadingMorePeopleSelector = (state) => state.loading.loadingMorePeople;
const loadingEventsSelector = (state) => state.loading.loadingEvents;
const loadingColleagueReservationsSelector = (state) =>
  state.loading.loadingColleagueReservations;
const loadingMoreEventsBeforeSelector = (state) =>
  state.loading.loadingMoreEventsBefore;
const loadingMoreEventsAfterSelector = (state) =>
  state.loading.loadingMoreEventsAfter;
const loadingEventDescriptionAndAttendeesSelector = (state) =>
  state.loading.loadingEventDescriptionAndAttendees;
const loadingReservationAttendeesSelector = (state) =>
  state.loading.loadingReservationAttendees;

export const LoadingSelectors = {
  mainLoadingSelector,
  searchingRoomsSelector,
  searchingBuildingsSelector,
  searchingMoreBuildingsSelector,
  searchingColleaguesSelector,
  searchingMoreColleaguesSelector,
  loadingPeopleSelector,
  loadingMorePeopleSelector,
  loadingColleagueReservationsSelector,
  loadingEventsSelector,
  loadingMoreEventsBeforeSelector,
  loadingMoreEventsAfterSelector,
  loadingEventDescriptionAndAttendeesSelector,
  loadingReservationAttendeesSelector,
  searchingMoreRoomsSelector,
};
