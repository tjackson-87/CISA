/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2022-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/


import { defaultTo, groupBy, isEmpty } from "lodash";
import moment from "moment-timezone";
import { createSelector } from "reselect";
import { CurrentUserSelectors, TimezonesSelectors } from "..";
import {
  eventDetailsActionTypes,
  formatStartEndDates,
  TimezoneUtils,
} from "../../utils";

const INITIAL_STATE = {
  event: null,
  attendees: [],
  description: null,
  onlineMeetingInfo: null,
};

export const eventDetailsReducer = (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case eventDetailsActionTypes.SET_EVENT_DETAIL:
      return {
        event: action.event,
        attendees: [],
        description: null,
        onlineMeetingInfo: null,
        Extension: null,
        costSummary: null,
      };
    case eventDetailsActionTypes.CLEAR_EVENT: {
      return INITIAL_STATE;
    }
    case eventDetailsActionTypes.SET_EVENT_EQUIPMENT: {
      const rooms = [];
      const equip = action.equipmentByRoom;
      if (state.event.rooms !== undefined)
        state.event.rooms.forEach((room) => {
          rooms.push({
            ...room,
            equipment: equip ? equip[room.spaceRecordId] : [],
          });
        });
      return { ...state, event: { ...state.event, rooms } };
    }

    case eventDetailsActionTypes.SET_EVENT_ONLINE_MEETING_DETAILS:
      return {
        ...state,
        onlineMeetingInfo: action.onlineMeetingInfo,
      };
    case eventDetailsActionTypes.SET_EVENT_DETAIL_OBJECT:
      return {
        ...state,
        ...action.stateObj,
      };

    case eventDetailsActionTypes.SET_EVENT_ATTENDEES_DESCRIPTION:
      return {
        ...state,
        attendees: action.attendees,
        description: action.description,
      };
    case eventDetailsActionTypes.SET_EVENT_COST_SUMMARY: {
      const reservationCostSummary = action.costSummary;
      let estimatedCostResource = reservationCostSummary.estimatedCostResource;
      let estimatedCostFood = reservationCostSummary.estimatedCostFood;
      let estimatedCostEquipment =
        reservationCostSummary.estimatedCostEquipment;

      if (
        estimatedCostResource &&
        parseFloat(estimatedCostResource.value) === 0
      ) {
        estimatedCostResource = null;
      }
      if (estimatedCostFood && parseFloat(estimatedCostFood.value) === 0) {
        estimatedCostFood = null;
      }
      if (
        estimatedCostEquipment &&
        parseFloat(estimatedCostEquipment.value) === 0
      ) {
        estimatedCostEquipment = null;
      }
      const costSummary = {
        accountCodeRoom: reservationCostSummary.accountCodeRoom,
        accountCodeFood: reservationCostSummary.accountCodeFood,
        accountCodeEquipment: reservationCostSummary.accountCodeEquipment,
        estimatedCostResource,
        estimatedCostFood,
        estimatedCostEquipment,
      };
      return {
        ...state,
        costSummary: costSummary,
      };
    }
    case eventDetailsActionTypes.SET_EVENT_CATERING: {
      const rooms = [];
      const catering = action.cateringByRoom;
      if (state.event.rooms !== undefined)
        state.event.rooms.forEach((room) => {
          rooms.push({
            ...room,
            catering: catering ? catering[room.spaceRecordId] : [],
          });
        });
      return { ...state, event: { ...state.event, rooms } };
    }
    case eventDetailsActionTypes.SET_EVENT_ROOMS_CONTACT_ROLES: {
      const rooms = [];
      const contactRoles = action.contactRoles;
      if (state.event.rooms) {
        state.event.rooms.forEach((room) => {
          rooms.push({
            ...room,
            contactRoles: contactRoles.filter(
              (item) => room.spaceRecordId === item.roomId
            ),
          });
        });
      }
      return { ...state, event: { ...state.event, rooms } };
    }
    case eventDetailsActionTypes.SET_EVENT_INSTANCE: {
      return {
        ...state,
        event: { ...state.event, instance: action.instance },
      };
    }

    case eventDetailsActionTypes.SET_EVENT_ROOMS_AVAILABLE_EQUIPMENT: {
      const newRooms = [];
      const availableEquipment = action.availableEquipmentForAllRooms;
      if (state.event && state.event.rooms) {
        state.event.rooms.forEach((room) => {
          const equipmentByRoom = availableEquipment.find(
            (item) => room.spaceRecordId === item.roomId
          );
          newRooms.push({
            ...room,
            availableEquipments: defaultTo(
              equipmentByRoom.availableEquipment,
              []
            ),
          });
        });
      }
      return {
        ...state,
        event: {
          ...state.event,
          rooms: newRooms,
        },
      };
    }
    case eventDetailsActionTypes.UPDATE_EVENT: {
      return {
        ...state,
        event: { ...state.event, ...action.event },
      };
    }
    case eventDetailsActionTypes.SET_EVENT_EXTENSION:
      return {
        ...state,
        Extension: action.Extension,
      };
    case eventDetailsActionTypes.SET_EVENT_ROOMS: {
      return {
        ...state,
        event: { ...state.event, rooms: action.rooms },
      };
    }
    case eventDetailsActionTypes.SET_IS_ALL_OCCURRENCE_HAS_RESOURCE: {
      return {
        ...state,
        event: {
          ...state.event,
          hasSomeButNotEveryResourceInSeriesOccurrences:
            action.hasSomeButNotEveryResourceInSeriesOccurrences,
        },
      };
    }
    default:
      return state;
  }
};

const eventDetailsSelector = (state) => state.eventDetails.event;
const attendeesSelector = (state) => state.eventDetails.attendees;
const descriptionSelector = (state) => state.eventDetails.description;
const costSummarySelector = (state) => state.eventDetails.costSummary;
const onlineMeetingInfoSelector = (state) =>
  state.eventDetails.onlineMeetingInfo;
const reservationInstanceSelector = (state) => state.eventDetails.instance;
const eventExtensionSelector = (state) =>
  state.eventDetails.Extension ? state.eventDetails.Extension : {};
const eventRoomsSelector = (state) => state.eventDetails.event?.rooms;

const formattedStartEndDatesSelector = createSelector(
  [
    eventDetailsSelector,
    CurrentUserSelectors.dateFormatSelector,
    CurrentUserSelectors.localeSelector,
    TimezonesSelectors.timezonesSelector,
    CurrentUserSelectors.defaultTimezoneSelector,
  ],
  (event, dateFormat, locale, timezones, defaultTimezone) => {
    if (!event) return "";
    const zone = isEmpty(event.reservationId)
      ? defaultTimezone
      : TimezoneUtils.getTimeZoneName(event.reservationTimezone);
    return formatStartEndDates(
      moment.tz(event.start, zone).toISOString(true),
      moment.tz(event.end, zone).toISOString(true),
      event.isAllDay,
      dateFormat,
      locale,
      zone,
      timezones,
      event.locationType,
      null
    );
  }
);

const eventDetailsCateringGroupByRoomIdAndOrderIdSelector = createSelector(
  [
    eventDetailsSelector,
    CurrentUserSelectors.defaultTimezoneSelector,
    CurrentUserSelectors.localeSelector,
  ],
  (event, timezone, locale) => {
    if (!isEmpty(event?.rooms)) {
      const caterings = [];
      event.rooms.forEach((r) => {
        if (!isEmpty(r.catering))
          r.catering.forEach((c) => {
            caterings.push(c);
          });
      });
      if (isEmpty(caterings)) return {};
      const cateringsByRoomId = groupBy(caterings, (c) => c.resourceId);
      for (const room in cateringsByRoomId) {
        const cateringByOrderId = groupBy(
          cateringsByRoomId[room],
          (c) => c.orderId
        );
        moment.locale(locale);
        cateringsByRoomId[room] = Object.values(cateringByOrderId).map((c) => ({
          additionalInformation: {
            orderName: defaultTo(c[0].name, ""),
            deliveryDate: moment
              .tz(event.start, timezone)
              .startOf("day")
              .toDate(),
            deliveryTime: moment
              .tz(c[0].foodOrderRequestedDateTime, timezone)
              .format("hh:mm"),
            deliveryTimePeriod: moment
              .tz(c[0].foodOrderRequestedDateTime, timezone)
              .format("A"),
          },
          items: c,
        }));
      }
      return cateringsByRoomId;
    }
    return {};
  }
);

const timeConvertedToReservationTimezoneDetailsSelector = createSelector(
  [
    eventDetailsSelector,
    CurrentUserSelectors.dateFormatSelector,
    CurrentUserSelectors.localeSelector,
    CurrentUserSelectors.defaultTimezoneSelector,
    TimezonesSelectors.timezonesSelector,
  ],
  (event, dateFormat, locale, timezone, timezones) => {
    if (!event) return "";
    return formatStartEndDates(
      moment.tz(event.start, timezone).toISOString(true),
      moment.tz(event.end, timezone).toISOString(true),
      event.isAllDay,
      dateFormat,
      locale,
      timezone,
      timezones,
      event.locationType,
      null
    );
  }
);

export const EventDetailsSelectors = {
  eventDetailsSelector,
  attendeesSelector,
  descriptionSelector,
  costSummarySelector,
  formattedStartEndDatesSelector,
  onlineMeetingInfoSelector,
  eventDetailsCateringGroupByRoomIdAndOrderIdSelector,
  reservationInstanceSelector,
  timeConvertedToReservationTimezoneDetailsSelector,
  eventExtensionSelector,
  eventRoomsSelector,
};
