/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import { createSelector } from "reselect";
import { roomDetailsActionTypes } from "../../utils";
import { CurrentUserSelectors } from "./CurrentUserReducer";

const INITIAL_STATE = {
  data: null,
  roomId: null,
};

export const roomDetailsReducer = (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case roomDetailsActionTypes.SET_ROOM_DETAIL:
      return { ...state, data: action.room, contactRoles: action.contactRoles };

    case roomDetailsActionTypes.SET_ROOM_ID:
      return { ...state, roomId: action.roomId };

    default:
      return state;
  }
};

const roomDetailsSelector = (state) => state.roomDetails.data;
const contactRolesSelector = (state) => state.roomDetails.contactRoles;
const isPrivateRoomSelector = createSelector(
  [roomDetailsSelector, CurrentUserSelectors.privateRoomsSelector],
  (room, privateRooms) => {
    return room == null
      ? null
      : !!privateRooms.find((privateRoom) => privateRoom._id === room._id);
  }
);
const roomIdSelector = (state) => state.roomDetails.roomId;

export const RoomDetailsSelectors = {
  roomDetailsSelector,
  contactRolesSelector,
  isPrivateRoomSelector,
  roomIdSelector,
};
