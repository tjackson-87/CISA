/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import { createSelector } from "reselect";
import { colleagueActionTypes } from "../../utils";
import { isNil } from "lodash";

const INITIAL_STATE = {
  colleagues: [],
  from: 0,
  totalSize: 0,
  searchText: "",
  selectedColleague: null,
  colleagueReservation: null,
  zoomToColleague: false,
};

export const colleagueReducer = (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case colleagueActionTypes.SET_COLLEAGUES: {
      return {
        ...state,
        searchText: action.searchText,
        colleagues: action.colleagues,
        from: action.from,
        totalSize: action.totalSize,
      };
    }

    case colleagueActionTypes.CLEAR_COLLEAGUE_SEARCH: {
      return {
        ...state,
        colleagues: [],
        from: 0,
        totalSize: 0,
        searchText: "",
      };
    }

    case colleagueActionTypes.SET_SELECTED_COLLEAGUE: {
      return {
        ...state,
        selectedColleague: action.selectedColleague,
      };
    }

    case colleagueActionTypes.SET_COLLEAGUE_DETAILS: {
      if (isNil(action.details)) {
        return {
          ...state,
          colleagueReservation: {
            colleagueDetails: action.details,
          },
          selectedColleague: null
        };
      }
      return {
        ...state,
        colleagueReservation: {
          colleagueDetails: action.details,
        },
        selectedColleague: {
          ...state.selectedColleague,
          name: action.details?.name,
          email: action.details?.email
        }
      };
    }

    case colleagueActionTypes.SET_COLLEAGUE_UPCOMING_RESERVATION: {
      return {
        ...state,
        colleagueReservation: {
          ...state.colleagueReservation,
          upcomingReservations: action.events,
        },
      };
    }
    case colleagueActionTypes.SET_SELECTED_COLLEAGUE_RESERVATION_ROOM: {
      return {
        ...state,
        selectedColleague: {
          ...state.selectedColleague,
          reservation: {
            ...state.selectedColleague?.reservation,
            room: action.room,
          },
        },
      };
    }

    case colleagueActionTypes.SET_SELECTED_COLLEAGUE_RESERVATION_FLOOR: {
      return {
        ...state,
        selectedColleague: {
          ...state.selectedColleague,
          reservation: {
            ...state.selectedColleague?.reservation,
            floor: action.floor,
          },
        },
      };
    }

    case colleagueActionTypes.SET_SELECTED_COLLEAGUE_RESERVATION_BUILDING: {
      return {
        ...state,
        selectedColleague: {
          ...state.selectedColleague,
          reservation: {
            ...state.selectedColleague?.reservation,
            building: action.building,
          },
        },
      };
    }
    case colleagueActionTypes.SET_COLLEAGUE_RESERVED_ROOM: {
      return {
        ...state,
        colleagueReservation: {
          ...state.colleagueReservation,
          reservedRoom: action.room,
        },
      };
    }

    case colleagueActionTypes.SET_ZOOM_TO_COLLEAGUE: {
      return {
        ...state,
        zoomToColleague: action.zoomToColleague,
      };
    }

    default:
      return state;
  }
};

const colleaguesSelector = ({ colleague }) => colleague.colleagues;

const totalSizeSelector = ({ colleague }) => colleague.totalSize;

const zoomToColleagueSelector = ({ colleague }) => colleague.zoomToColleague;

const selectedColleagueSelector = ({ colleague }) =>
  colleague.selectedColleague;

const colleagueReservationSelector = (state) => {
  return state.colleague.colleagueReservation || {};
};

const colleagueDetailsSelector = createSelector(
  [colleagueReservationSelector],
  (reservation) => reservation.colleagueDetails
);

const colleagueUpcomingReservationsSelector = createSelector(
  [colleagueReservationSelector],
  (reservation) => reservation.upcomingReservations?.reservations
);

const limitUpcomingReservationsSelector = createSelector(
  [colleagueReservationSelector],
  (reservation) => reservation.upcomingReservations?.reservationsLimit
);

const lastIndexUpcomingReservationsSelector = createSelector(
  [colleagueReservationSelector],
  (reservation) => reservation.upcomingReservations?.lastIndex
);

const selectedColleagueReservationSelector = createSelector(
  [selectedColleagueSelector],
  (colleague) => colleague?.reservation || {}
);

const selectedColleagueReservationRoomSelector = createSelector(
  [selectedColleagueReservationSelector],
  (reservation) => reservation.room
);

const selectedColleagueReservationBuildingSelector = createSelector(
  [selectedColleagueReservationSelector],
  (reservation) => reservation.building
);

const selectedColleagueReservationFloorSelector = createSelector(
  [selectedColleagueReservationSelector],
  (reservation) => reservation.floor
);

const colleagueReservedRoomSelector = createSelector(
  [colleagueReservationSelector],
  (reservation) => reservation.reservedRoom
);

export const ColleagueSelectors = {
  colleaguesSelector,
  totalSizeSelector,
  selectedColleagueSelector,
  zoomToColleagueSelector,
  colleagueDetailsSelector,
  colleagueUpcomingReservationsSelector,
  limitUpcomingReservationsSelector,
  lastIndexUpcomingReservationsSelector,
  selectedColleagueReservationSelector,
  selectedColleagueReservationRoomSelector,
  selectedColleagueReservationBuildingSelector,
  selectedColleagueReservationFloorSelector,
  colleagueReservedRoomSelector,
};
