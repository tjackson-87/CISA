/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import { reserveEventTypesActionTypes } from "../../utils";

const INITIAL_STATE = null;

export const reserveEventTypesReducer = (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case reserveEventTypesActionTypes.SET_RESERVE_EVENT_TYPES: {
      return action.reserveEventTypes;
    }
    default:
      return state;
  }
};

const reserveEventTypesSelector = ({ reserveEventTypes }) => reserveEventTypes;

export const ReserveEventTypesSelectors = {
  reserveEventTypesSelector,
};
