/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2022 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/

import { reservationActionTypes } from "../../utils";

const INITIAL_STATE = {
  create: false,
  data: null,
  timeStepTempData: null,
  type: null,
  exchangeEventId: null,
  editMode: null,
  selectedResource: null,
  reservationLoaded: false,
};

export const savedReservationReducer = (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case reservationActionTypes.SAVE_RESERVATION_IN_STORE: {
      return {
        ...INITIAL_STATE,
        create: action.value.create,
        data: action.value.data,
        timeStepTempData: action.value.timeStepTempData,
        type: action.value.type,
        exchangeEventId: action.value.exchangeEventId,
        editMode: action.value.editMode,
        selectedResource: action.value.selectedResource,
      };
    }

    case reservationActionTypes.UPDATE_SAVED_RESERVATION_DATA: {
      return {
        ...state,
        data: {
          ...state.data,
          ...action.value,
        },
      };
    }

    case reservationActionTypes.CLEAR_SAVED_RESERVATION: {
      return INITIAL_STATE;
    }

    case reservationActionTypes.SET_SAVED_RESERVATION_LOADED: {
      return {
        ...state,
        reservationLoaded: action.value,
      };
    }

    default:
      return state;
  }
};
