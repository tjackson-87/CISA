/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import { equipmentDetailsActionTypes } from "../../utils";

const INITIAL_STATE = {
  data: null,
  isEquipmentModalOpen: false,
  equipmentId: null,
};

export const equipmentDetailsReducer = (state = INITIAL_STATE, action) => {
  switch (action.type) {
    case equipmentDetailsActionTypes.SET_EQUIPMENT_DETAIL:
      return { ...state, data: action.equipment };
    case equipmentDetailsActionTypes.SET_EQUIPMENT_DETAIL_MODAL:
      return { ...state, isEquipmentModalOpen: action.isOpen };
    case equipmentDetailsActionTypes.SET_EQUIPMENT_ID:
      return { ...state, equipmentId: action.equipmentId };
    default:
      return state;
  }
};

const equipmentDetailsSelector = (state) => state.equipmentDetails.data;
const equipmentDetailsModalSelector = ({ equipmentDetails }) =>
  equipmentDetails.isEquipmentModalOpen;
const equipmentIdSelector = ({ equipmentDetails }) =>
  !equipmentDetails?.equipmentId ? 0 : equipmentDetails.equipmentId;

export const EquipmentDetailsSelectors = {
  equipmentDetailsSelector,
  equipmentDetailsModalSelector,
  equipmentIdSelector,
};
