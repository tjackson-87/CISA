/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
import moment from "moment-timezone";
import {
  ReservationActions,
  RoomSearchActions,
  getAppStore,
  RoomSearchSelectors,
} from "..";
import { setupTests } from "../../setupTests";
import { reservationActionTypes, ReservationTypes } from "../../utils";

let store = null;

beforeAll(async () => {
  await setupTests;
  store = getAppStore();
}, 60000);

test("Create Meeting", async () => {
  await store.dispatch(
    ReservationActions.initializeNewReservation(ReservationTypes.MEETING)
  );
  const { reservation } = store.getState();
  expect(reservation).toBeTruthy();
  expect(reservation.create).toBeTruthy();
  expect(reservation.locationFilters.length).toBeGreaterThan(0);
  expect(reservation.data.timezone).not.toBeNull();
}, 30000);

function createRandomMeetingTime() {
  const startDate = moment()
    .add(Math.trunc(Math.random() * 3) + 1, "weeks")
    .day(Math.trunc(Math.random() * 4) + 1)
    .hour(Math.trunc(Math.random() * 5) + 9)
    .minute(0)
    .second(0)
    .millisecond(0);
  const endDate = startDate
    .clone()
    .add((Math.trunc(Math.random() * 6) + 1) * 30, "minutes");
  return {
    startDate: startDate.toISOString(),
    startTime: startDate.format("hh:mm"),
    startTimePeriod: startDate.format("A"),
    endDate: endDate.toISOString(),
    endTime: endDate.format("hh:mm"),
    endTimePeriod: endDate.format("A"),
    timezone: "Brazil/East",
  };
}

test("Search meeting rooms from User Primary Building", async () => {
  await store.dispatch(
    ReservationActions.initializeNewReservation(ReservationTypes.MEETING)
  );
  const meetingParams = createRandomMeetingTime();

  await store.dispatch({
    type: reservationActionTypes.UPDATE_RESERVATION_DATA,
    value: meetingParams,
  });

  await store.dispatch(RoomSearchActions.searchRooms());
  const { reservation } = store.getState();
  expect(reservation.roomSearchResult).toBeTruthy();
  expect(reservation.roomSearchResult.length).toBeGreaterThan(0);
}, 30000);

test("Search Unavailable meeting rooms from User Primary Building", async () => {
  await store.dispatch(
    ReservationActions.initializeNewReservation(ReservationTypes.MEETING)
  );
  const meetingParams = {
    startDate: "2020-05-20T22:00:00.000-0300",
    startTime: "11:00",
    startTimePeriod: "PM",
    endDate: "2020-05-20T22:00:00.000-0300",
    endTime: "11:30",
    endTimePeriod: "PM",
    timezone: "Brazil/East",
  };
  await store.dispatch({
    type: reservationActionTypes.UPDATE_RESERVATION_DATA,
    value: meetingParams,
  });

  await store.dispatch(RoomSearchActions.searchRooms());
  const rooms = RoomSearchSelectors.roomsToDisplaySelector(store.getState());
  expect(rooms).toBeTruthy();
  expect(rooms.length).toBe(0);
}, 30000);
