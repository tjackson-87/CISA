/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2022 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import { setLoading } from "./LoadingActions.js";
import { ApplicationSettingsDS } from "../../model";
import { applicationSettingsActionTypes } from "../../utils";
import { getAppStore, CurrentUserActions, OAuthProfileActions } from "..";

const setApplicationSettings = (applicationSettings) => {
  return {
    type: applicationSettingsActionTypes.SET_APPLICATION_SETTINGS,
    applicationSettings: applicationSettings,
  };
};

export const getApplicationSettings = () => {
  return async (dispatch, getState) => {
    let { applicationSettings } = getState();
    if (applicationSettings != null) return applicationSettings;
    try {
      dispatch(setLoading("getApplicationSettings", true));
      applicationSettings = await ApplicationSettingsDS.getApplicationSettings();
      let oauthProfileName = applicationSettings.oauthProfile;
      let oauthProfileDomain = null;
      if (applicationSettings.exchangeIntegrated) {
        const oauthProfile = await getOAuthProfile();
        oauthProfileName = oauthProfile.oauthProfileName;
        oauthProfileDomain = oauthProfile.oauthProfileDomain;
      }
      if (process.env.REACT_APP_TRIRIGA_OAUTH_PROFILE_NAME != null) {
        oauthProfileName = process.env.REACT_APP_TRIRIGA_OAUTH_PROFILE_NAME;
      }

      dispatch(
        setApplicationSettings({
          ...applicationSettings,
          oauthProfile: oauthProfileName,
          oauthProfileDomain,
        })
      );
    } finally {
      dispatch(setLoading("getApplicationSettings", false));
    }
    return applicationSettings;
  };
};

async function getOAuthProfile() {
  const currentUser = await getAppStore().dispatch(
    CurrentUserActions.getCurrentUser()
  );
  const domain = currentUser.email.replace(/.*@/, "");

  return await getAppStore().dispatch(
    OAuthProfileActions.getOAuthProfile(domain)
  );
}
