/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import isEmpty from "lodash/isEmpty";
import { setLoading } from "./LoadingActions.js";
import { FloorsDS, ReservableSpacesDS } from "../../model";
import {
  RoomsUtils,
  RecurrenceConstants,
  getRecurPropName,
  roomSearchActionTypes,
  ReservationTypes,
} from "../../utils";

import {
  ReservationSelectors,
  ApplicationSettingsSelectors,
  RoomSearchSelectors,
  CurrentUserActions,
  CurrentUserSelectors,
  LocationSelectors,
  ColleagueSelectors,
} from "..";
import { RESERVATION_CLASS_PRIVATE } from "../../utils/constants/ReservableSpacesConstants.js";
import {
  searchBox,
  searchNearby,
} from "../../model/tririga-platform-api/Drawings.js";

export function initRoomSearch() {
  return {
    type: roomSearchActionTypes.INIT_ROOM_SEARCH,
  };
}

function getReservableParams(state, checkMore = false) {
  const { reservation, currentUser } = state;
  const {
    startAndEndDate,
    filters,
    reserveContextRecurrence,
  } = RoomSearchSelectors.searchFiltersSelector(state);
  const selectedException = ReservationSelectors.selectedResourceSelectedExceptionSelector(
    state
  );
  const holdRooms = ReservationSelectors.roomsSelector(state);
  const excludeRooms = !isEmpty(selectedException) ? holdRooms : null;
  const searchFilters = {
    filters,
    startDate: !isEmpty(selectedException)
      ? selectedException.start
      : startAndEndDate && startAndEndDate.startDate,
    endDate: !isEmpty(selectedException)
      ? selectedException.end
      : startAndEndDate && startAndEndDate.endDate,
  };

  return {
    reservation,
    currentUser,
    startAndEndDate,
    reserveContextRecurrence: !isEmpty(selectedException)
      ? null
      : reserveContextRecurrence,
    occurrenceMatch:
      reserveContextRecurrence &&
      ApplicationSettingsSelectors.occurrenceMatchSelector(state),
    occurrenceEndDateTime:
      reserveContextRecurrence &&
      ReservationSelectors.occurrenceEndDateTimeSelector(state),
    searchFilters,
    isExchangeIntegrated: ApplicationSettingsSelectors.isExchangeIntegratedSelector(
      state
    ),
    pageSize: ApplicationSettingsSelectors.roomSearchPageSizeSelector(state),
    pageFrom: checkMore ? RoomSearchSelectors.pageFromSelector(state) : 0,
    reservationType: ReservationSelectors.reservationTypeSelector(state),
    filterWorkspaceByRole: ApplicationSettingsSelectors.filterWorkspaceByRoleSelector(
      state
    ),
    rooms: RoomSearchSelectors.roomsFilterSelector(state),
    excludeRooms,
    oauthProfileDomain: ApplicationSettingsSelectors.oauthProfileDomainSelector(
      state
    ),
  };
}

export function searchMore() {
  return searchRooms(true);
}

export function searchRooms(checkMore = false) {
  return async (dispatch, getState) => {
    const {
      reservation,
      currentUser,
      startAndEndDate,
      reserveContextRecurrence,
      occurrenceMatch,
      occurrenceEndDateTime,
      searchFilters,
      isExchangeIntegrated,
      pageSize,
      pageFrom,
      reservationType,
      filterWorkspaceByRole,
      rooms,
      excludeRooms,
      oauthProfileDomain,
    } = getReservableParams(getState(), checkMore);
    let currentUserRole = null;
    const lastFloorPlanPosition = RoomSearchSelectors.rememberFloorplanLastPositionSelector(
      getState()
    );
    const colleagueRoom = ColleagueSelectors.selectedColleagueReservationRoomSelector(
      getState()
    );
    const building = LocationSelectors.selectedBuildingSelector(getState());
    const buildingId = building?._id;
    const floor = RoomSearchSelectors.floorSelector(getState());
    const cache =
      lastFloorPlanPosition &&
      building?._id === colleagueRoom?.buildingSystemRecordID &&
      floor?._id === colleagueRoom?.floorSystemRecordID;
    if (!checkMore && !cache) {
      dispatch(setRoomSearchResult([], false, 0, 0, checkMore));
    }
    if (!startAndEndDate || !reservation || isEmpty(reservation.data)) return;
    try {
      dispatch(setLoading(checkMore ? "searchMoreRooms" : "searchRooms", true));

      if (
        reservationType === ReservationTypes.WORKSPACE &&
        filterWorkspaceByRole
      ) {
        currentUserRole = await dispatch(
          CurrentUserActions.getCurrentUserRole(
            checkMore ? "searchMoreRooms" : "searchRooms"
          )
        );
      }
      const {
        data: roomSearchResult,
        hasMoreResults,
        pageFrom: newPageFrom,
        totalSize,
      } = await ReservableSpacesDS.queryReservableSpaces(
        reservationType,
        searchFilters,
        isExchangeIntegrated,
        pageFrom,
        pageSize,
        reserveContextRecurrence,
        occurrenceMatch,
        currentUser.favoriteRooms,
        currentUserRole,
        filterWorkspaceByRole,
        null,
        rooms,
        excludeRooms,
        null,
        buildingId,
        oauthProfileDomain
      );
      if (reserveContextRecurrence) {
        computeOccurrencesAvailability(roomSearchResult);
      }
      computeRoomsAvailability(
        searchFilters,
        roomSearchResult,
        reserveContextRecurrence,
        occurrenceEndDateTime
      );
      const privateRooms = CurrentUserSelectors.privateRoomsSelector(
        getState()
      );
      computeRoomsReservable(roomSearchResult, privateRooms);
      dispatch(
        setRoomSearchResult(
          roomSearchResult,
          hasMoreResults,
          newPageFrom,
          totalSize,
          checkMore,
          cache
        )
      );
    } finally {
      dispatch(
        setLoading(checkMore ? "searchMoreRooms" : "searchRooms", false)
      );
    }
  };
}

export function searchRoomByCode(code) {
  return async (dispatch, getState) => {
    const {
      reservation,
      currentUser,
      startAndEndDate,
      reserveContextRecurrence,
      occurrenceMatch,
      occurrenceEndDateTime,
      searchFilters,
      isExchangeIntegrated,
      pageFrom,
      pageSize,
      reservationType,
      filterWorkspaceByRole,
      oauthProfileDomain,
    } = getReservableParams(getState());
    let currentUserRole = null;

    if (!startAndEndDate || !reservation || isEmpty(reservation.data)) return;

    try {
      dispatch(setLoading("searchRooms", true));
      if (
        reservationType === ReservationTypes.WORKSPACE &&
        filterWorkspaceByRole
      ) {
        currentUserRole = await dispatch(
          CurrentUserActions.getCurrentUserRole()
        );
      }
      const {
        data: scannedResult,
      } = await ReservableSpacesDS.queryReservableSpaces(
        reservationType,
        {
          filters: {
            showRequestableRooms: true,
          },
          startDate: searchFilters.startDate,
          endDate: searchFilters.endDate,
        },
        isExchangeIntegrated,
        pageFrom,
        pageSize,
        reserveContextRecurrence,
        occurrenceMatch,
        currentUser.favoriteRooms,
        currentUserRole,
        filterWorkspaceByRole,
        code,
        null,
        null,
        null,
        null,
        oauthProfileDomain
      );
      if (reserveContextRecurrence) {
        computeOccurrencesAvailability(scannedResult);
      }
      computeRoomsAvailability(
        searchFilters,
        scannedResult,
        reserveContextRecurrence,
        occurrenceEndDateTime
      );
      dispatch(setScannedRoomResult(scannedResult[0]));
    } finally {
      dispatch(setLoading("searchRooms", false));
    }
  };
}

export function searchRoomByName(searchText, buildingId, checkMore, fromRoom) {
  return async (dispatch, getState) => {
    const {
      reservation,
      currentUser,
      startAndEndDate,
      reserveContextRecurrence,
      occurrenceMatch,
      occurrenceEndDateTime,
      searchFilters,
      isExchangeIntegrated,
      pageSize,
      pageFrom,
      reservationType,
      filterWorkspaceByRole,
      oauthProfileDomain,
    } = getReservableParams(getState(), checkMore);
    let filter;
    if (isEmpty(searchText) || fromRoom) {
      filter = searchFilters;
    } else {
      filter = {
        filters: {
          showRequestableRooms: true,
        },
        startDate: searchFilters.startDate,
        endDate: searchFilters.endDate,
      };
    }
    if (isEmpty(searchText)) {
      searchText = RoomSearchSelectors.searchTextSelector(getState());
    }
    const selectedBuilding = LocationSelectors.selectedBuildingSelector(
      getState()
    );
    if (isEmpty(buildingId) && !isEmpty(selectedBuilding)) {
      buildingId = selectedBuilding._id;
    }
    let currentUserRole = null;
    if (!checkMore) {
      dispatch(setSearchRoomByNameResult([], false, 0, 0, checkMore));
    }
    if (!startAndEndDate || !reservation || isEmpty(reservation.data)) return;
    try {
      dispatch(setLoading(checkMore ? "searchMoreRooms" : "searchRooms", true));

      if (
        reservationType === ReservationTypes.WORKSPACE &&
        filterWorkspaceByRole
      ) {
        currentUserRole = await dispatch(
          CurrentUserActions.getCurrentUserRole(
            checkMore ? "searchMoreRooms" : "searchRooms"
          )
        );
      }
      const {
        data: roomSearchResult,
        hasMoreResults: moreResults,
        pageFrom: newPageFrom,
        totalSize,
      } = await ReservableSpacesDS.queryReservableSpaces(
        reservationType,
        filter,
        isExchangeIntegrated,
        pageFrom,
        pageSize,
        reserveContextRecurrence,
        occurrenceMatch,
        currentUser.favoriteRooms,
        currentUserRole,
        filterWorkspaceByRole,
        null,
        null,
        null,
        searchText,
        buildingId,
        oauthProfileDomain
      );
      if (reserveContextRecurrence) {
        computeOccurrencesAvailability(roomSearchResult);
      }
      computeRoomsAvailability(
        searchFilters,
        roomSearchResult,
        reserveContextRecurrence,
        occurrenceEndDateTime
      );
      const privateRooms = CurrentUserSelectors.privateRoomsSelector(
        getState()
      );
      computeRoomsReservable(roomSearchResult, privateRooms);
      dispatch(
        setSearchRoomByNameResult(
          roomSearchResult,
          moreResults,
          newPageFrom,
          totalSize,
          checkMore,
          searchText
        )
      );
    } finally {
      dispatch(
        setLoading(checkMore ? "searchMoreRooms" : "searchRooms", false)
      );
    }
  };
}

export function getRoomsInFloorplanViewport(floorPlanId, x, y, width, height) {
  return async (dispatch, getState) => {
    try {
      dispatch(setLoading("searchRooms", true));
      const searchBoxResult = await searchBox(floorPlanId, x, y, width, height);
      const roomsInViewport = searchBoxResult.records;
      dispatch(setRoomsFilter(roomsInViewport));
    } finally {
      dispatch(setLoading("searchRooms", false));
    }
  };
}

export function getRoomsInFloorPlanNearBy({
  spaceRecordId,
  floorSystemRecordID,
  buildingSystemRecordID,
  area,
}) {
  return async (dispatch, getState) => {
    try {
      const drawingId = await RoomsUtils.getFloorplanId(floorSystemRecordID);
      const floors = await FloorsDS.getBuildingFloors(
        buildingSystemRecordID,
        ReservationTypes.WORKSPACE,
        false
      );
      const selectedFloor = floors.find(
        (floor) => floor._id === floorSystemRecordID
      );
      let radius = 10000;
      const roomFloorPercentage = (area / selectedFloor.area) * 100;
      if (roomFloorPercentage > 2.5) {
        radius = 10000;
      } else if (roomFloorPercentage > 1) {
        radius = area / 8;
      } else if (roomFloorPercentage > 0.5) {
        radius = area / 4;
      } else if (roomFloorPercentage > 0.1) {
        radius = area / 2;
      } else {
        radius = area;
      }
      dispatch(setLoading("searchRooms", true));
      let roomsNearBy = [];
      if (drawingId) {
        const searchNearByResult = await searchNearby(
          drawingId,
          spaceRecordId,
          radius
        );
        roomsNearBy = searchNearByResult.records;
      }
      dispatch(setRoomsFilter(roomsNearBy));
    } finally {
      dispatch(setLoading("searchRooms", false));
    }
  };
}

function setSearchRoomByNameResult(
  roomSearchResult,
  hasMoreResults,
  pageFrom,
  totalSize,
  checkMore = false,
  searchText
) {
  return {
    type: roomSearchActionTypes.SET_ROOM_SEARCH_BY_NAME_RESULT,
    roomSearchResult,
    hasMoreResults,
    pageFrom,
    totalSize,
    checkMore,
    searchText,
  };
}

export function setSelectedRooms(selectedRoom) {
  return {
    type: roomSearchActionTypes.SET_SELECTED_ROOMS,
    selectedRoom,
  };
}

function setScannedRoomResult(scannedResult) {
  return {
    type: roomSearchActionTypes.SET_SCANNED_ROOM_SEARCH_RESULT,
    scannedResult,
  };
}

export function setRoomSearchResult(
  roomSearchResult,
  hasMoreResults,
  pageFrom,
  totalSize,
  checkMore = false,
  cache = false
) {
  return {
    type: roomSearchActionTypes.SET_ROOM_SEARCH_RESULT,
    roomSearchResult,
    hasMoreResults,
    pageFrom,
    totalSize,
    checkMore,
    cache,
  };
}

export function setFloorFilter(floor) {
  return {
    type: roomSearchActionTypes.SET_FLOOR_FILTER,
    floor,
  };
}

export function setFilters(filters) {
  return {
    type: roomSearchActionTypes.UPDATE_FILTERS,
    filters,
  };
}

export function setRoomsFilter(rooms) {
  return {
    type: roomSearchActionTypes.SET_ROOMS_FILTER,
    rooms,
  };
}

export function setCapacityFilters(capacity) {
  return {
    type: roomSearchActionTypes.UPDATE_CAPACITY_FILTERS,
    capacity,
  };
}

export function setRoomViewMode(mode) {
  return {
    type: roomSearchActionTypes.SET_ROOM_VIEW_MODE,
    mode,
  };
}

export function setSelectedRoomOnFloorplan(selectedRoom) {
  return {
    type: roomSearchActionTypes.SET_SELECTED_ROOM_ON_FLOORPLAN,
    selectedRoom,
  };
}

export function setSelectedRoom(checkedRooms) {
  return {
    type: roomSearchActionTypes.SET_SELECTED_ROOM,
    checkedRooms,
  };
}

export function removeCheckedRooms() {
  return {
    type: roomSearchActionTypes.REMOVE_CHECKED_ROOMS,
  };
}

export function removeRoomFromSearchResult(roomToRemove) {
  return async (dispatch, getState) => {
    if (roomToRemove && roomToRemove._id) {
      try {
        dispatch(setLoading("removeRoomFromSearchResults", true));
        const state = getState();
        const roomSearchResult = RoomSearchSelectors.roomSearchResultSelector(
          state
        );
        const finalRoomSearchResult = roomSearchResult.filter(
          (room) => room._id !== roomToRemove._id
        );
        const hasMoreResults = RoomSearchSelectors.hasMoreResultsSelector(
          state
        );
        const pageFrom = RoomSearchSelectors.pageFromSelector(state);
        const totalSize = RoomSearchSelectors.totalSizeSelector(state);
        dispatch(
          setRoomSearchResult(
            finalRoomSearchResult,
            hasMoreResults,
            pageFrom - 1,
            totalSize - 1
          )
        );
      } finally {
        dispatch(setLoading("removeRoomFromSearchResults", false));
      }
    }
  };
}

function computeOccurrencesAvailability(roomSearchResult) {
  if (!isEmpty(roomSearchResult)) {
    roomSearchResult.forEach((room) => {
      let availCount = 0;
      room._occurrenceList.forEach((occurrence) => {
        occurrence.isAvailable = isOccurrenceAvailable(occurrence, room);
        if (occurrence.isAvailable) {
          availCount++;
        }
      });
      room._availCount = availCount;
    });
  }
}

function isOccurrenceAvailable(occurrence, room) {
  return (
    occurrence.isAvailable &&
    !RoomsUtils.isStartDateBeforeAdvanceLimit(
      occurrence.start,
      room.reserveAdvanceLimit
    ) &&
    !RoomsUtils.isEndDateAfterCutOffDuration(
      occurrence.end,
      room.reserveCutOffDuration
    )
  );
}

function computeRoomsAvailability(
  searchFilters,
  roomSearchResult,
  recurrence,
  occurrenceEndDateTime
) {
  if (!isEmpty(roomSearchResult)) {
    roomSearchResult.forEach((room) => {
      if (recurrence) {
        return (room.isAvailable = isAvailableRecur(
          searchFilters,
          room,
          recurrence,
          occurrenceEndDateTime
        ));
      } else {
        return (room.isAvailable = isAvailable(searchFilters, room));
      }
    });
  }
}

function isAvailable(searchFilters, room) {
  return (
    room._isAvailable &&
    !RoomsUtils.isStartDateBeforeAdvanceLimit(
      searchFilters.startDate,
      room.reserveAdvanceLimit
    ) &&
    !RoomsUtils.isEndDateAfterCutOffDuration(
      searchFilters.endDate,
      room.reserveCutOffDuration
    )
  );
}

function isAvailableRecur(
  searchFilters,
  room,
  recurrence,
  occurrenceEndDateTime
) {
  let isAvailableEnd = true;
  let recurrenceLatestEndDate;

  const properties = recurrence[getRecurPropName(recurrence.type)];
  const endType = properties.end.type;
  if (endType !== RecurrenceConstants.RECUR_END_VALUES.NO_END_DATE) {
    recurrenceLatestEndDate = occurrenceEndDateTime;
  }

  if (recurrenceLatestEndDate) {
    isAvailableEnd = !RoomsUtils.isEndDateAfterCutOffDuration(
      recurrenceLatestEndDate,
      room.reserveCutOffDuration
    );
  }

  return (
    room._isAvailable &&
    !RoomsUtils.isStartDateBeforeAdvanceLimit(
      searchFilters.startDate,
      room.reserveAdvanceLimit
    ) &&
    isAvailableEnd
  );
}

function computeRoomsReservable(roomSearchResult, privateRooms) {
  if (!isEmpty(roomSearchResult)) {
    roomSearchResult.forEach((room) => {
      return (room.isReservable = isReservable(room, privateRooms));
    });
  }
}

function isReservable(room, privateRooms) {
  const isPrivate = room.reservationClassNameENUS === RESERVATION_CLASS_PRIVATE;
  const roomIsInPrivateRooms =
    !isEmpty(privateRooms) &&
    !isEmpty(privateRooms.find((privateRoom) => privateRoom._id === room._id));
  const isReservable = !isPrivate || roomIsInPrivateRooms;
  return isReservable;
}

export function setScannerType(scannerType) {
  return {
    type: roomSearchActionTypes.SET_SCANNER_TYPE,
    scannerType,
  };
}

export function setLocationModal(isOpen) {
  return {
    type: roomSearchActionTypes.SET_LOCATION_MODAL,
    isOpen,
  };
}

export function setSearchColleagueModal(isOpen) {
  return {
    type: roomSearchActionTypes.SET_SEARCH_COLLEAGUE_MODAL,
    isOpen,
  };
}

export function setFilterModal(isOpen) {
  return {
    type: roomSearchActionTypes.SET_FILTER_MODAL,
    isOpen,
  };
}

export function setRoomDetailsModal(isOpen) {
  return {
    type: roomSearchActionTypes.SET_ROOM_DETAILS_MODAL,
    isOpen,
  };
}

export function setRoomRecurrenceDetailsModal(isOpen) {
  return {
    type: roomSearchActionTypes.SET_ROOM_RECURRENCE_DETAILS_MODAL,
    isOpen,
  };
}

export function setRecurrenceModal(isOpen) {
  return {
    type: roomSearchActionTypes.SET_RECURRENCE_MODAL,
    isOpen,
  };
}

export function setRememberFloorplanLastPosition(remember) {
  return {
    type: roomSearchActionTypes.SET_REMEMBER_FLOORPLAN_LAST_POSITION,
    remember,
  };
}
