/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/

import {
  messageActionTypes,
  AppMsg,
  ReservationTypes,
  MessageTypes,
} from "../../utils";

function setMessage({
  kind,
  type,
  title,
  subtitle1 = "",
  subtitle2 = "",
  caption = "",
  hideCloseButton = false,
}) {
  return {
    type: messageActionTypes.SET_MESSAGE,
    message: {
      kind,
      type,
      title,
      subtitle1,
      subtitle2,
      caption,
      hideCloseButton,
    },
  };
}

export function clearMessage() {
  return {
    type: messageActionTypes.CLEAR_MESSAGE,
  };
}

export function showCreateReservationSuccess(reservationType) {
  return setMessage({
    kind: "success",
    title: AppMsg.getMessage(
      reservationType === ReservationTypes.MEETING ? AppMsg.RESERVATION_MESSAGE.MEETING_SUCCESSFULLY_CREATED
        : reservationType === ReservationTypes.OFFICE ? AppMsg.RESERVATION_MESSAGE.OFFICE_SUCCESSFULLY_CREATED // CISA
        : AppMsg.RESERVATION_MESSAGE.WORKSPACE_SUCCESSFULLY_CREATED
    ),
  });
}

export function showUpdateReservationSuccess(reservationType) {
  return setMessage({
    kind: "success",
    title: AppMsg.getMessage(
      reservationType === ReservationTypes.MEETING ? AppMsg.RESERVATION_MESSAGE.MEETING_SUCCESSFULLY_UPDATED
        : reservationType === ReservationTypes.OFFICE ? AppMsg.RESERVATION_MESSAGE.OFFICE_SUCCESSFULLY_UPDATED // CISA
        : AppMsg.RESERVATION_MESSAGE.WORKSPACE_SUCCESSFULLY_UPDATED
    ),
  });
}

export function showCreateReservationError(messages) {
  return setMessage({
    kind: "error",
    title: messages ? messages : AppMsg.getMessage(AppMsg.ERRORS.RESERVATION_CREATE_ERROR),
  });
}

export function showUpdateReservationError(messages) {
  return setMessage({
    kind: "error",
    title: messages ? messages : AppMsg.getMessage(AppMsg.ERRORS.RESERVATION_CREATE_ERROR),
  });
}

export function showOnlineMeetingError(operation) {
  let message = "";
  if (operation === "Create") {
    message = AppMsg.getMessage(AppMsg.ERRORS.MEETING_CREATE_ERROR);
  } else if (operation === "Update") {
    message = AppMsg.getMessage(AppMsg.ERRORS.MEETING_UPDATE_ERROR);
  } else if (operation === "Delete") {
    message = AppMsg.getMessage(AppMsg.ERRORS.MEETING_DELETE_ERROR);
  }
  return setMessage({
    kind: "error",
    title: message,
  });
}

export function showPeopleListError() {
  return setMessage({
    kind: "error",
    title: AppMsg.getMessage(AppMsg.ERRORS.PEOPLE_LIST_ERROR),
  });
}

export function showGetMyCalendarError() {
  return setMessage({
    kind: "error",
    title: AppMsg.getMessage(AppMsg.ERRORS.MY_CALENDAR_ERROR),
  });
}

export function showSessionExpiredError() {
  return setMessage({
    kind: "modal",
    type: MessageTypes.SESSION_EXPIRED,
  });
}

export function showGetRecurrenceDetailsError() {
  return setMessage({
    kind: "error",
    title: AppMsg.getMessage(AppMsg.ERRORS.RECURRENCE_GET_ERROR),
  });
}

export function showGetAttendeesScheduleError() {
  return setMessage({
    kind: "error",
    title: AppMsg.getMessage(AppMsg.ERRORS.EXCHANGE_GET_SCHEDULE_ERROR),
  });
}

export function showGetResourcesScheduleError() {
  return setMessage({
    kind: "error",
    title: AppMsg.getMessage(AppMsg.ERRORS.RESOURCES_SCHEDULE_ERROR),
  });
}

export function showGetResourcesAvailabilityError() {
  return setMessage({
    kind: "error",
    title: AppMsg.getMessage(AppMsg.ERRORS.RESOURCES_AVAILABILITY_ERROR),
  });
}

export function showGetUserExchangeProfileError() {
  return setMessage({
    kind: "error",
    title: AppMsg.getMessage(AppMsg.ERRORS.EXCHANGE_GET_USER_ERROR),
  });
}

export function showAuthenticatingWithExchange() {
  return setMessage({
    kind: "modal",
    type: MessageTypes.EXCHANGE_AUTHENTICATION,
  });
}

export function showPopupBlocked() {
  return setMessage({
    kind: "modal",
    type: MessageTypes.POPUP_BLOCKED,
  });
}

export function showAuthenticationWithExchangeFailed() {
  return setMessage({
    kind: "modal",
    type: MessageTypes.EXCHANGE_AUTHENTICATION_FAILED,
  });
}

export function showSecurityError() {
  return setMessage({
    kind: "error",
    title: AppMsg.getMessage(AppMsg.ERRORS.SECURITY_ERROR_TITLE),
    subtitle1: AppMsg.getMessage(AppMsg.ERRORS.SECURITY_ERROR_DESCRIPTION),
    subtitle2: AppMsg.getMessage(AppMsg.ERRORS.SECURITY_ERROR_ACTION),
  });
}

export function showGeneralError() {
  return setMessage({
    kind: "error",
    title: AppMsg.getMessage(AppMsg.ERRORS.GENERAL_ERROR_TITLE),
    subtitle1: AppMsg.getMessage(AppMsg.ERRORS.GENERAL_ERROR_DESCRIPTION),
  });
}

export function showHoldRoomError(holdError) {
  return setMessage({
    kind: "error",
    title: AppMsg.getMessage(AppMsg.ERRORS.GENERAL_ERROR_TITLE),
    subtitle1: holdError,
  });
}

export function showCannotRetrieveCheckInData() {
  return setMessage({
    kind: "error",
    title: AppMsg.getMessage(AppMsg.ERRORS.CHECK_IN_DATA_FETCH_ERROR),
  });
}

export function showGetExchangeDelegateCalendarsError() {
  return setMessage({
    kind: "error",
    title: AppMsg.getMessage(
      AppMsg.ERRORS.EXCHANGE_GET_DELEGATE_CALENDARS_ERROR
    ),
  });
}
