/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - 2023 The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import {
  push as historyPush,
  replace as historyReplace,
  goBack as historyGoBack,
} from "connected-react-router";
import moment from "moment-timezone";
import {
  Routes,
  ReservationTypes,
  getReservationRoute,
  ReservationEditMode,
} from "../../utils";
import {
  ReservationSelectors,
  RoomSearchActions,
  ReservationActions,
  ColleagueSelectors,
} from "..";
import {
  ActiveUsersDS,
} from "../../model";
import { isNil } from "lodash";

export function navigateBack() {
  return historyGoBack();
}

export function navigateToReservationSummary(replace = false) {
  return async (dispatch, getState) => {
    const { router } = getState();
    if (router.location.state && router.location.state.routedFromSummary) {
      dispatch(navigateBack());
    } else {
      const reservationType = ReservationSelectors.reservationTypeSelector(
        getState()
      );
      const reservationRoute = getReservationRoute(reservationType);
      dispatch(
        replace
          ? historyReplace(reservationRoute)
          : historyPush(reservationRoute)
      );
    }
  };
}

export function navigateToHomePage(replace = false) {
  return replace ? historyReplace(Routes.HOME) : historyPush(Routes.HOME);
}

export function navigateBackToHomePage() {
  return async (dispatch, getState) => {
    const { router } = getState();
    if (router.location.state && router.location.state.routedFromHome) {
      dispatch(navigateBack());
    } else {
      dispatch(navigateToHomePage());
    }
  };
}

export function navigateToMeetingReservationPage(replace = false) {
  return navigateToReservationPage(ReservationTypes.MEETING, replace);
}

export function navigateToReservationPage(reservationType, replace = false) {
  return async (dispatch, getState) => {
    const { router } = getState();
    const routedFromHome = router.location.pathname === Routes.HOME;
    const route = getReservationRoute(reservationType);
    return replace
      ? dispatch(historyReplace(route))
      : dispatch(historyPush(route, { routedFromHome }));
  };
}

export function navigateToMeetingAttendees() {
  return historyPush(`${Routes.MEETING}${Routes.ATTENDEES}`, {
    routedFromSummary: true,
  });
}

export function navigateToReservationSearch(routedFromSummary = true) {
  return async (dispatch, getState) => {
    const reservationType = ReservationSelectors.reservationTypeSelector(
      getState()
    );
    dispatch(
      historyPush(`${getReservationRoute(reservationType)}${Routes.SEARCH}`, {
        routedFromSummary,
      })
    );
  };
}

export function navigateToReservationSearchfromColleaguePage(routedFromColleaguePage = true) {
  return async (dispatch, getState) => {
    const reservationType = ReservationSelectors.reservationTypeSelector(
      getState()
    );
    dispatch(
      historyPush(`${getReservationRoute(reservationType)}${Routes.SEARCH}`, {
        routedFromColleaguePage,
      })
    );
  };
}

export function navigateToMeetingDetails() {
  return historyPush(`${Routes.MEETING}${Routes.DETAILS}`, {
    routedFromSummary: true,
  });
}

export function navigateToEquipmentList(roomId) {
  return historyPush(
    `${Routes.MEETING}${Routes.SPACE_DETAILS}/${roomId}${Routes.EQUIPMENT}`,
    {
      routedFromSummary: true,
    }
  );
}

export function navigateToCateringList(roomId) {
  return historyPush(
    `${Routes.MEETING}${Routes.SPACE_DETAILS}/${roomId}${Routes.CATERING}`,
    {
      routedFromSummary: true,
    }
  );
}

export function navigateToCateringListFromEventDetails(roomId, data) {
  return async (dispatch) => {
    dispatch(
      historyPush(
        `${Routes.EVENT_DETAILS}/${data.eventId}${Routes.SPACE_DETAILS}/${roomId}${Routes.CATERING}`,
        data
      )
    );
  };
}

export function navigateBackFromEquipment() {
  return async (dispatch, getState) => {
    const { router } = getState();
    const locationState = router.location.state;
    if (
      locationState &&
      (locationState.routedFromSummary ||
        locationState.routedFromEventDetailPage)
    ) {
      dispatch(navigateBack());
    } else {
      dispatch(navigateToReservationSummary(false));
    }
  };
}

export function navigateBackFromRoomDetails() {
  return async (dispatch, getState) => {
    const { router } = getState();
    const locationState = router.location.state;
    if (
      locationState &&
      (locationState.routedFromRooms ||
        locationState.routedFromSummary ||
        locationState.routedFromEvents)
    ) {
      dispatch(navigateBack());
    } else {
      dispatch(navigateToReservationSummary(false));
    }
  };
}

export function navigateBackFromEquipmentDetails() {
  return async (dispatch, getState) => {
    const { router } = getState();
    const locationState = router.location.state;
    if (
      locationState &&
      (locationState.routedFromEquipment ||
        locationState.routedFromEventDetailPage)
    ) {
      dispatch(navigateBack());
    } else {
      dispatch(navigateToReservationSummary(false));
    }
  };
}

export function navigateBackToReservationSearch() {
  return async (dispatch, getState) => {
    const { router } = getState();
    if (router.location.state && router.location.state.routedFromRooms) {
      dispatch(navigateBack());
    } else {
      dispatch(navigateToReservationSearch(false));
    }
  };
}

export function navigateToSearchByName() {
  return async (dispatch, getState) => {
    const reservationType = ReservationSelectors.reservationTypeSelector(
      getState()
    );

    dispatch(
      historyPush(
        `${getReservationRoute(reservationType)}${Routes.SEARCH}${
          Routes.ROOMSEARCH
        }`,
        {
          routedFromRooms: true,
        }
      )
    );
  };
}

export function navigateToRoomSearchFilter() {
  return async (dispatch, getState) => {
    const reservationType = ReservationSelectors.reservationTypeSelector(
      getState()
    );
    dispatch(
      historyPush(
        `${getReservationRoute(reservationType)}${Routes.SEARCH}${
          Routes.SEARCH_FILTER
        }`,
        {
          routedFromRooms: true,
        }
      )
    );
  };
}

export function navigateToEquipmentDetails(equipmentId, roomId, state) {
  return async (dispatch, getState) => {
    const reservationType = ReservationSelectors.reservationTypeSelector(
      getState()
    );
    const isReadOnlyPage = ReservationSelectors.detailPageRouteSelector(
      getState()
    );
    if (isReadOnlyPage) {
      const match = getState().router.location.pathname.match(
        new RegExp(
          `(${Routes.EVENT_DETAILS})/(.*?)(${Routes.SPACE_DETAILS})/(\\d+)(${Routes.EQUIPMENT}|${Routes.CATERING})`
        )
      );
      let eventId = "";
      if (match != null) {
        eventId = match[2];
      }
      dispatch(
        historyPush(
          `${Routes.EVENT_DETAILS}/${eventId}${Routes.SPACE_DETAILS}/${roomId}${Routes.EQUIPMENT}/${equipmentId}`,
          state
        )
      );
    } else {
      dispatch(
        historyPush(
          `${getReservationRoute(reservationType)}${
            Routes.SPACE_DETAILS
          }/${roomId}${Routes.EQUIPMENT}/${equipmentId}`,
          state
        )
      );
    }
  };
}

export function navigateToEquipmentPageFromEventDetails(roomId, data) {
  return async (dispatch, getState) => {
    dispatch(
      historyPush(
        `${Routes.EVENT_DETAILS}/${data.eventId}${Routes.SPACE_DETAILS}/${roomId}${Routes.EQUIPMENT}`,
        data
      )
    );
  };
}
export function navigateToWorkspaceReservationPage(replace = false) {
  return navigateToReservationPage(ReservationTypes.WORKSPACE, replace);
}

export function navigateToTime(routedFromSummary = true, replace = false) {
  return async (dispatch, getState) => {
    const reservationType = ReservationSelectors.reservationTypeSelector(
      getState()
    );
    const { router } = getState();
    if (router.location.state && router.location.state.routedFromTime) {
      dispatch(navigateBack());
    } else {
      dispatch(
        replace
          ? historyReplace(
              `${getReservationRoute(reservationType)}${Routes.TIME}`,
              {
                routedFromSummary,
              }
            )
          : historyPush(
              `${getReservationRoute(reservationType)}${Routes.TIME}`,
              {
                routedFromSummary,
              }
            )
      );
    }
  };
}

export function navigateToOnlineMeeting() {
  return historyPush(`${Routes.MEETING}${Routes.ONLINE_MEETING}`, {
    routedFromSummary: true,
  });
}

export function navigateBackToReservationTime() {
  return async (dispatch, getState) => {
    const { router } = getState();
    const reservationType = ReservationSelectors.reservationTypeSelector(
      getState()
    );
    if (reservationType === ReservationTypes.WORKSPACE) {
      if (router.location.state && router.location.state.routedFromTime) {
        dispatch(navigateBack());
      } else {
        dispatch(navigateToTime(false));
      }
    } else {
      if (router.location.state && router.location.state.routedFromTime) {
        dispatch(navigateBack());
      } else {
        dispatch(navigateToTime(false));
      }
    }
  };
}

export function navigateToAvailability() {
  return async (dispatch, getState) => {
    const reservationType = ReservationSelectors.reservationTypeSelector(
      getState()
    );
    dispatch(
      historyPush(
        `${getReservationRoute(reservationType)}${Routes.TIME}${
          Routes.AVAILABILITY
        }`,
        { routedFromTime: true }
      )
    );
  };
}

export function navigateBackFromCatering() {
  return async (dispatch, getState) => {
    const { router } = getState();
    const locationState = router.location.state;
    if (locationState && locationState.routedFromSummary) {
      dispatch(navigateBack());
    } else if (locationState && locationState.routedFromEventDetailPage) {
      dispatch(navigateBack());
    } else {
      dispatch(navigateToReservationSummary(false));
    }
  };
}

export function navigateToEventDetails(eventId, start, end) {
  return async (dispatch) => {
    dispatch(ReservationActions.clearSavedReservation());
    dispatch(
      historyPush(
        `${Routes.EVENT_DETAILS}/${eventId}/${moment(start).valueOf()}/${moment(
          end
        ).valueOf()}`
      )
    );
  };
}

export function navigateToRoomDetail(roomId, state) {
  return async (dispatch) => {
    dispatch(
      historyPush(
        `${Routes.EVENT_DETAILS}${Routes.SPACE_DETAILS}/${roomId}`,
        state
      )
    );
  };
}

export function navigateToEditReservation(event, editMode) {
  return async (dispatch) => {
    let reservationEditMode = editMode;
    if (
      reservationEditMode === ReservationEditMode.SERIES_OCCURRENCE &&
      event.isRecurringException
    ) {
      reservationEditMode = ReservationEditMode.SERIES_EXCEPTION;
    }
    const reservationId =
      reservationEditMode === ReservationEditMode.SERIES
        ? event.seriesReservationId
        : event.reservationId;
    const { eventId } = event;
    const editRoute = reservationId
      ? `${Routes.EDIT_RESERVATION}/${reservationId}`
      : `${Routes.EDIT_EVENT}/${eventId}`;

    if (
      reservationEditMode === ReservationEditMode.SERIES_OCCURRENCE ||
      reservationEditMode === ReservationEditMode.SERIES_EXCEPTION
    ) {
      dispatch(
        historyPush(
          `${editRoute}/${editMode}/${moment(event.start).valueOf()}/${moment(
            event.end
          ).valueOf()}`
        )
      );
    } else {
      dispatch(historyPush(`${editRoute}/${reservationEditMode}`));
    }
  };
}

export function navigateToReservationCostSummaryPage(id, editMode, start, end) {
  if (isNil(id) || isNil(start) || isNil(end)) {
    return async (dispatch) => {
      dispatch(historyReplace(Routes.HOME));
    };
  }
  return async (dispatch) => {
    dispatch(
      historyPush(`${Routes.COST_SUMMARY}/${id}/${editMode}/${start}/${end}`)
    );
  };
}

export function navigateToRoomScanPage(scannerType) {
  return async (dispatch, getState) => {
    const reservationType = ReservationSelectors.reservationTypeSelector(
      getState()
    );
    dispatch(RoomSearchActions.setScannerType(scannerType));
    dispatch(
      historyPush(`${getReservationRoute(reservationType)}${Routes.SCAN}`, {
        routedFromSummary: true,
      })
    );
  };
}

export function navigateToOccurrenceExceptionsPage(resourceId) {
  return async (dispatch, getState) => {
    const reservationType = ReservationSelectors.reservationTypeSelector(
      getState()
    );
    dispatch(
      historyPush(
        `${getReservationRoute(reservationType)}${
          Routes.EXCEPTION
        }/${resourceId}`,
        {
          routedFromSummary: true,
        }
      )
    );
  };
}

export function navigateToColleagueReservation() {
  return async (dispatch, getState) => {
    const selectedColleague = ColleagueSelectors.selectedColleagueSelector(
      getState()
    );
    const person = await ActiveUsersDS.getUserByEmail(selectedColleague.email);
    if (person && person.personId) {
      dispatch(
        historyPush(
          `${Routes.COLLEAGUE_RESERVATION}/${person.personId}`
        )
      );
    }
  };
}