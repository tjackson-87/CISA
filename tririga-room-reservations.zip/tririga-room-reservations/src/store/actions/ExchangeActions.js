/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import moment from "moment-timezone";
import { getTriAppConfig } from "@tririga/tririga-react-components";
import {
  LoadingActions,
  ExchangeSelectors,
  ApplicationSettingsSelectors,
  MessageActions,
  MyCalendarActions,
} from "..";
import {
  exchangeActionTypes,
  AppMsg,
  Routes,
  ExchangeConstants,
  getLocationInfo,
} from "../../utils";
import { Exchange } from "../../model";
import isEmpty from "lodash/isEmpty";

export const setAccessToken = (accessToken, expiresIn) => {
  return {
    type: exchangeActionTypes.SET_ACCESS_TOKEN,
    accessToken,
    accessTokenExpireDate:
      expiresIn != null
        ? moment()
            .add(expiresIn - 120, "seconds")
            .toDate()
        : null,
  };
};

export const setPeopleList = (peopleList, append = false) => {
  return {
    type: exchangeActionTypes.SET_PEOPLE_LIST,
    peopleList,
    append,
  };
};

export const clearPeopleList = () => {
  return {
    type: exchangeActionTypes.CLEAR_PEOPLE_LIST,
  };
};

export const getInitialPeopleList = (search) => {
  return {
    type: exchangeActionTypes.GET_INITIAL_PEOPLE_LIST,
    search,
  };
};

export const openAuthenticationPopup = () => {
  return {
    type: exchangeActionTypes.OPEN_AUTHENTICATION_POPUP,
  };
};

export const setAuthenticationSuccess = (accessToken, expiresIn) => {
  return {
    type: exchangeActionTypes.AUTHENTICATION_SUCCESS,
    accessToken,
    expiresIn,
  };
};

export const retryExchangeAuthentication = () => {
  return {
    type: exchangeActionTypes.RETRY_AUTHENTICATION,
  };
};

export const cancelExchangeAuthentication = () => {
  return {
    type: exchangeActionTypes.CANCEL_GET_ACCESS_TOKEN,
  };
};

export const setAuthenticationError = (error) => {
  return {
    type: exchangeActionTypes.AUTHENTICATION_ERROR,
    error,
  };
};

export const initAuthentication = (error) => {
  return {
    type: exchangeActionTypes.INIT_AUTHENTICATION,
    error,
  };
};

export const setAuthenticationPopupBlocked = (error) => {
  return {
    type: exchangeActionTypes.AUTHENTICATION_POPUP_BLOCKED,
    error,
  };
};

export const getNextPagePeopleList = () => {
  return {
    type: exchangeActionTypes.GET_NEXT_PAGE_PEOPLE_LIST,
  };
};

let getAzureAccessTokenPromise = null;

export function getAzureAccessToken() {
  return async (dispatch, getState) => {
    if (ExchangeSelectors.hasAccessTokenSelector(getState())) {
      return ExchangeSelectors.accessTokenSelector(getState());
    }
    if (getAzureAccessTokenPromise != null) return getAzureAccessTokenPromise;
    getAzureAccessTokenPromise = new Promise((resolve, reject) => {
      dispatch({
        type: exchangeActionTypes.GET_ACCESS_TOKEN,
        resolveGetToken: resolve,
        rejectGetToken: reject,
      });
    });
    try {
      const accessToken = await getAzureAccessTokenPromise;
      return accessToken;
    } finally {
      getAzureAccessTokenPromise = null;
    }
  };
}

export function getPhoto(attendee) {
  return async (dispatch, getState) => {
    const accessToken = ExchangeSelectors.accessTokenSelector(getState());
    switch (attendee.type) {
      case Exchange.ORGANIZATION_USER: {
        return Exchange.getUserPhoto(accessToken, attendee.email);
      }

      case Exchange.PERSONAL_CONTACT_TYPE: {
        return Exchange.getContactPhoto(accessToken, attendee.email);
      }

      default:
        return null;
    }
  };
}

export function createEvent(
  eventParams,
  resources,
  additionalLocationInfo,
  selectedOnlineMeeting,
  calendarId
) {
  return async (dispatch) => {
    const accessToken = await dispatch(getAzureAccessToken());
    try {
      dispatch(LoadingActions.setLoading("createEvent", true));
      const event = await Exchange.createEvent(
        accessToken,
        {
          ...eventParams,
          description: computeEventBodyContent(
            eventParams.description,
            resources,
            selectedOnlineMeeting
          ),
          location: computeEventLocation(
            additionalLocationInfo,
            selectedOnlineMeeting,
            resources
          ),
          onlineMeetingID: selectedOnlineMeeting?._id,
          resources,
        },
        calendarId
      );
      await Exchange.createEventExtension(accessToken, event.id, {
        ...eventParams,
        onlineMeetingID: selectedOnlineMeeting?._id,
      });
      return event;
    } finally {
      dispatch(LoadingActions.setLoading("createEvent", false));
    }
  };
}

function computeEventLocation(
  additionalLocationInfo,
  selectedOnlineMeeting,
  resources
) {
  let rooms = resources
    ?.map(function (rooms) {
      return rooms.room.name;
    })
    .join(" | ");

  rooms += isEmpty(rooms)
    ? getLocationInfo(additionalLocationInfo, false)
    : getLocationInfo(additionalLocationInfo, true);
  rooms += isEmpty(rooms)
    ? getLocationInfo(selectedOnlineMeeting?.url, false)
    : getLocationInfo(selectedOnlineMeeting?.url, true);
  rooms += isEmpty(rooms)
    ? getLocationInfo(selectedOnlineMeeting?.callInInformation, false)
    : getLocationInfo(selectedOnlineMeeting?.callInInformation, true);

  return rooms;
}

function computeEventBodyContent(
  description,
  resources,
  selectedOnlineMeeting
) {
  const openFloorPlanMessage = AppMsg.getMessage(
    AppMsg.BUTTON.LINK_OPEN_FLOOR_PLAN
  );
  const roomLinks = resources?.reduce((accumulator, currentValue) => {
    const linkText = openFloorPlanMessage.replace(
      "{1}",
      currentValue.room.name
    );

    return (
      accumulator +
      `<p><a href="${
        getTriAppConfig().tririgaUrl
      }${Routes.ROOM_LOCATE_APP.replace(
        "{roomId}",
        currentValue.room._id
      )}">${linkText}</a></p>`
    );
  }, "");

  let onlineMeetingInfo = "";
  if (!isEmpty(selectedOnlineMeeting)) {
    onlineMeetingInfo += `<h4>${AppMsg.getMessage(
      AppMsg.RESERVATION_MESSAGE.ONLINE_MEETING_INFORMATION
    )}</h4>`;

    if (!isEmpty(selectedOnlineMeeting.url)) {
      onlineMeetingInfo += `<p><b>${AppMsg.getMessage(
        AppMsg.RESERVATION_MESSAGE.MEETING_URL
      )}: </b><a href="${selectedOnlineMeeting.url}">${
        selectedOnlineMeeting.url
      }</a></p>`;
    }

    if (!isEmpty(selectedOnlineMeeting.password)) {
      onlineMeetingInfo += `<p><b>${AppMsg.getMessage(
        AppMsg.RESERVATION_MESSAGE.MEETING_PASSWORD
      )}: </b>${selectedOnlineMeeting.password}</p>`;
    }

    if (!isEmpty(selectedOnlineMeeting.callInInformation)) {
      onlineMeetingInfo += `<p><b>${AppMsg.getMessage(
        AppMsg.RESERVATION_MESSAGE.MEETING_CALL_IN_INFO
      )}: </b>${selectedOnlineMeeting.callInInformation}</p>`;
    }
  }
  if (!isEmpty(onlineMeetingInfo)) {
    onlineMeetingInfo = `<div id="${ExchangeConstants.ONLINE_MEETING_KEY_ON_EVENT_BODY}">${onlineMeetingInfo}</div>`;
  }
  let head = "";
  let body = "";
  if (!isEmpty(description)) {
    const descriptionTokens = description.split("<body>");
    head = descriptionTokens.length > 1 ? descriptionTokens[0] + "<body>" : "";
    body =
      `<br id="${ExchangeConstants.LINE_BREAK_ON_EVENT_BODY}" />` +
      (descriptionTokens.length > 1
        ? descriptionTokens[1]
        : descriptionTokens[0]);
  }
  return `${head}${body}<div id="${
    ExchangeConstants.ROOM_LINKS_KEY_ON_EVENT_BODY
  }">${isEmpty(roomLinks) ? "" : roomLinks}</div>${onlineMeetingInfo}`;
}

export function updateEvent(
  eventId,
  eventParams,
  attendees,
  resources,
  onlineMeeting,
  additionalLocationInfo,
  calendarId
) {
  return async (dispatch) => {
    const accessToken = await dispatch(getAzureAccessToken());
    try {
      dispatch(LoadingActions.setLoading("updateEvent", true));
      const event = await Exchange.updateEvent(
        accessToken,
        eventId,
        {
          ...eventParams,
          description: computeEventBodyContent(
            eventParams.description,
            resources,
            onlineMeeting
          ),
          location: computeEventLocation(
            additionalLocationInfo,
            onlineMeeting,
            resources
          ),
          resources,
        },
        attendees,
        resources,
        calendarId
      );
      await Exchange.updateEventExtension(accessToken, eventId, {
        ...eventParams,
        onlineMeetingID: onlineMeeting?._id,
      });
      return event;
    } finally {
      dispatch(LoadingActions.setLoading("updateEvent", false));
    }
  };
}

export function updateEventAttendees(eventId, attendees, resources) {
  return async (dispatch) => {
    const accessToken = await dispatch(getAzureAccessToken());
    try {
      dispatch(LoadingActions.setLoading("updateEventAttendees", true));
      const event = await Exchange.updateEventAttendees(
        accessToken,
        eventId,
        attendees,
        resources
      );
      return event;
    } finally {
      dispatch(LoadingActions.setLoading("updateEventAttendees", false));
    }
  };
}

export function deleteEvent(eventId) {
  return async (dispatch, getState) => {
    const accessToken = await dispatch(getAzureAccessToken());
    try {
      dispatch(LoadingActions.setLoading("deleteEvent", true));
      const event = await Exchange.deleteEvent(accessToken, eventId);
      return event;
    } finally {
      dispatch(LoadingActions.setLoading("deleteEvent", false));
    }
  };
}

export function updateResponse(eventId, newStatus) {
  return async (dispatch, getState) => {
    const accessToken = await dispatch(getAzureAccessToken());
    try {
      dispatch(LoadingActions.setLoading("updateResponse", true));
      const event = await Exchange.updateResponse(
        accessToken,
        eventId,
        newStatus
      );
      dispatch(MyCalendarActions.refreshMyCalendar());
      return event;
    } finally {
      dispatch(LoadingActions.setLoading("updateResponse", false));
    }
  };
}

export function getSchedule(eventParams, attendees) {
  return async (dispatch) => {
    const accessToken = await dispatch(getAzureAccessToken());
    const response = await Exchange.getSchedule(
      accessToken,
      eventParams,
      attendees
    );

    return {
      result: response.result,
      success: true,
    };
  };
}

function setUserExchangeProfile(exchangeProfile) {
  return {
    type: exchangeActionTypes.SET_USER_EXCHANGE_PROFILE,
    exchangeProfile,
  };
}

export function setDelegateCalendars(delegateCalendars) {
  return {
    type: exchangeActionTypes.SET_DELEGATE_CALENDARS,
    delegateCalendars,
  };
}

export function setCurrentCalendar(calendar, reset = true) {
  return {
    type: exchangeActionTypes.SET_CURRENT_CALENDAR,
    calendar,
    reset,
  };
}
// CISA
export function createTeamsMeeting(startDateTime, endDateTime, subject){
  return async (dispatch, getState) => {
    const accessToken = await dispatch(getAzureAccessToken());
    try {
      dispatch(LoadingActions.setLoading("isCreatingOnlineMeeting", true));
      const event = await Exchange.createTeamsMeeting(
        accessToken,
        startDateTime,
        endDateTime,
        subject
      );
      return event;
    } finally {
      dispatch(LoadingActions.setLoading("isCreatingOnlineMeeting", false));
    }
  };
}
// CISA
export function updateTeamsMeeting(startDateTime, endDateTime, subject, id){
  return async (dispatch, getState) => {
    const accessToken = await dispatch(getAzureAccessToken());
    try {
      dispatch(LoadingActions.setLoading("isUpdatingOnlineMeeting", true));
      const event = await Exchange.updateTeamsMeeting(
        accessToken,
        startDateTime,
        endDateTime,
        subject,
        id
      );
      return event;
    } finally {
      dispatch(LoadingActions.setLoading("isUpdatingOnlineMeeting", false));
    }
  };
}
// CISA
export function deleteTeamsMeeting(id){
  return async (dispatch, getState) => {
    const accessToken = await dispatch(getAzureAccessToken());
    try {
      dispatch(LoadingActions.setLoading("isDeleteingOnlineMeeting", true));
      const event = await Exchange.deleteTeamsMeeting(
        accessToken,
        id
      );
      return event;
    } finally {
      dispatch(LoadingActions.setLoading("isDeleteingOnlineMeeting", false));
    }
  };
}
// CISA
export function removeTeamsMeeting(){
  return {
    type: exchangeActionTypes.REMOVE_TEAMS_MEETING
  };
}

export function getMyUserExchangeProfile() {
  return async (dispatch, getState) => {
    const isExchangeIntegrated = ApplicationSettingsSelectors.isExchangeIntegratedSelector(
      getState()
    );
    if (!isExchangeIntegrated) return;
    if (ExchangeSelectors.userExchangeProfileSelector(getState()) != null)
      return;
    const accessToken = await dispatch(getAzureAccessToken());
    try {
      dispatch(LoadingActions.setLoading("getMyUserExchangeProfile", true));
      const response = await Exchange.getMe(accessToken);
      if (response.success) {
        dispatch(setUserExchangeProfile(response.result));
      } else {
        dispatch(MessageActions.showGetUserExchangeProfileError());
      }
      return response.result;
    } catch (e) {
      dispatch(MessageActions.showGetUserExchangeProfileError());
    } finally {
      dispatch(LoadingActions.setLoading("getMyUserExchangeProfile", false));
    }
  };
}

export function getExchangePerson(email) {
  return async (dispatch, getState) => {
    const isExchangeIntegrated = ApplicationSettingsSelectors.isExchangeIntegratedSelector(
      getState()
    );
    if (!isExchangeIntegrated) return;
    const accessToken = await dispatch(getAzureAccessToken());
    try {
      dispatch(LoadingActions.setLoading("getExchangePerson", true));
      const response = await Exchange.getPeople(accessToken, email);
      if (!response) {
        dispatch(MessageActions.showPeopleListError());
      }
      return response.data;
    } catch (e) {
      dispatch(MessageActions.showPeopleListError());
    } finally {
      dispatch(LoadingActions.setLoading("getExchangePerson", false));
    }
  };
}

export function updateEventEndTime(eventId, start, end, timezone, calendarId) {
  return async (dispatch) => {
    const accessToken = await dispatch(getAzureAccessToken());
    try {
      dispatch(LoadingActions.setLoading("updateEventEndTime", true));

      if (moment(start).valueOf() > moment(end).valueOf()) {
        end = moment.tz(start, timezone).add(1, "seconds").toISOString(true);
      }

      const event = await Exchange.updateEventEndTime(
        accessToken,
        eventId,
        start,
        end,
        timezone,
        calendarId
      );
      return event;
    } finally {
      dispatch(LoadingActions.setLoading("updateEventEndTime", false));
    }
  };
}
