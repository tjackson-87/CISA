/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import moment from "moment-timezone";
import { setLoading } from "./LoadingActions.js";
import { CurrentUserDS } from "../../model";
import {
  currentUserActionTypes,
  DefaultValues,
  TimezoneUtils,
  WindowsZones,
} from "../../utils";
import { TriDateTimeUtils } from "@tririga/tririga-react-components";
import { RoomSearchActions, CurrentUserSelectors, TimezoneActions } from "..";
import isEmpty from "lodash/isEmpty";
import { RoomSearchSelectors } from "../selectors/RoomSearchSelectors.js";

const setCurrentUser = (currentUser) => {
  const carbonDateFormat = TriDateTimeUtils.getCarbonDateFormat(
    currentUser._DateFormat
  );

  const carbonLocale = currentUser._Locale.slice(0, 2);

  return {
    type: currentUserActionTypes.SET_CURRENT_USER,
    data: currentUser,
    carbonDateFormat: carbonDateFormat,
    carbonLocale: carbonLocale,
  };
};

const setFavoriteRooms = (favoriteRooms) => {
  return {
    type: currentUserActionTypes.SET_FAVORITE_ROOMS,
    favoriteRooms,
  };
};

const updateFavoriteRooms = (favoriteRooms) => {
  return {
    type: currentUserActionTypes.UPDATE_FAVORITE_ROOMS,
    favoriteRooms,
  };
};

const setCurrentUserRole = (role) => {
  return {
    type: currentUserActionTypes.SET_CURRENT_USER_ROLE,
    role,
  };
};

const setPrivateRooms = (privateRooms) => {
  return {
    type: currentUserActionTypes.SET_PRIVATE_ROOMS,
    privateRooms,
  };
};

const setDefaultTimezone = (timezone) => {
  return {
    type: currentUserActionTypes.SET_DEFAULT_TIMEZONE,
    timezone,
  };
};

export const getCurrentUser = () => {
  return async (dispatch, getState) => {
    const { currentUser } = getState();
    if (currentUser != null && currentUser.data != null)
      return currentUser.data;
    let data;
    try {
      dispatch(setLoading("currentUser", true));
      data = await CurrentUserDS.getCurrentUser();
      dispatch(setCurrentUser(data));
    } finally {
      dispatch(setLoading("currentUser", false));
    }
    return data;
  };
};

export const getFavoriteRooms = () => {
  return async (dispatch, getState) => {
    const { currentUser } = getState();
    let favRooms =
      currentUser && currentUser.favoriteRooms
        ? currentUser.favoriteRooms
        : null;
    if (favRooms) return favRooms;
    try {
      dispatch(setLoading("searchRooms", true));
      favRooms = await CurrentUserDS.getFavoriteRooms();
      dispatch(setFavoriteRooms(favRooms));
    } finally {
      dispatch(setLoading("searchRooms", false));
    }
    return favRooms;
  };
};

export const addFavoriteRoom = (room) => {
  return async (dispatch, getState) => {
    const { currentUser } = getState();
    let updatedFavoriteRooms;
    try {
      dispatch(setLoading("favoriteRooms", true));
      updatedFavoriteRooms = await getUpdatedFavoriteRooms(
        room,
        currentUser.favoriteRooms,
        CurrentUserDS.addFavoriteRoom
      );
      dispatch(updateFavoriteRooms(updatedFavoriteRooms));
    } finally {
      dispatch(setLoading("favoriteRooms", false));
    }
    return updatedFavoriteRooms;
  };
};

export const removeFavoriteRoom = (room) => {
  return async (dispatch, getState) => {
    const favoriteRooms = CurrentUserSelectors.favoriteRoomsSelector(
      getState()
    );
    const filters = RoomSearchSelectors.filtersSelector(getState());
    const isSearchingOnlyFavorites = RoomSearchSelectors.isSearchingOnlyFavoritesSelector(
      getState()
    );
    let updatedFavoriteRooms;
    try {
      dispatch(setLoading("favoriteRooms", true));
      if (filters.showFavoritesOnly || isSearchingOnlyFavorites)
        dispatch(RoomSearchActions.removeRoomFromSearchResult(room));
      updatedFavoriteRooms = await getUpdatedFavoriteRooms(
        room,
        favoriteRooms,
        CurrentUserDS.removeFavoriteRoom
      );
      dispatch(updateFavoriteRooms(updatedFavoriteRooms));
    } finally {
      dispatch(setLoading("favoriteRooms", false));
    }
    return updatedFavoriteRooms;
  };
};

async function getUpdatedFavoriteRooms(
  room,
  favoriteRooms,
  datasourceActionCall
) {
  const response = await datasourceActionCall(room._id);
  if (response) {
    const updatedFavRooms = [...favoriteRooms];
    const foundIndex = updatedFavRooms.findIndex(
      (favRoom) => favRoom._id === room._id
    );
    if (foundIndex === -1) {
      updatedFavRooms.push({ _id: room._id, name: room.name });
    } else {
      updatedFavRooms.splice(foundIndex, 1);
    }
    return updatedFavRooms;
  }
  return null;
}

export const getCurrentUserRole = (loadType = "") => {
  return async (dispatch, getState) => {
    let currentUserRole = CurrentUserSelectors.currentUserRoleSelector(
      getState()
    );
    if (currentUserRole == null) {
      const load = loadType === "searchMoreRooms" ? loadType : "searchRooms";
      try {
        dispatch(setLoading(load, true));
        currentUserRole = await CurrentUserDS.getCurrentUserRole();
        dispatch(setCurrentUserRole(currentUserRole));
      } finally {
        dispatch(setLoading(load, false));
      }
    }
    return currentUserRole;
  };
};

export const getPrivateRooms = () => {
  return async (dispatch, getState) => {
    let privateRooms = CurrentUserSelectors.privateRoomsSelector(getState());
    if (isEmpty(privateRooms)) {
      try {
        dispatch(setLoading("searchRooms", true));
        privateRooms = await CurrentUserDS.getPrivateRooms();
        dispatch(setPrivateRooms(privateRooms));
      } finally {
        dispatch(setLoading("searchRooms", false));
      }
    }
    return privateRooms;
  };
};

export const getDefaultTimezone = () => {
  return async (dispatch, getState) => {
    let defaultTimezone = CurrentUserSelectors.defaultTimezoneSelector(
      getState()
    );
    if (defaultTimezone == null) {
      await dispatch(getCurrentUser());
      const timezones = await dispatch(TimezoneActions.getTimezones());
      let userTimezone = moment.tz.guess(true);

      const isTririgaTimezone = timezones.some(
        (item) =>
          TimezoneUtils.getTimeZoneName(item.englishName) === userTimezone
      );
      let newUserTimezone = [];
      let mappedTimezone = "";
      if (!isTririgaTimezone) {
        mappedTimezone = WindowsZones.findTimezoneInWindowZones(
          userTimezone,
          timezones
        );
        if (
          !isEmpty(mappedTimezone) &&
          TimezoneUtils.getUtcOffset(
            mappedTimezone,
            DefaultValues.withoutDSTDate
          ) ===
            TimezoneUtils.getUtcOffset(
              userTimezone,
              DefaultValues.withoutDSTDate
            )
        ) {
          userTimezone = mappedTimezone;
        } else {
          newUserTimezone = timezones.filter((item) => {
            const utcOffset = moment().isDST()
              ? TimezoneUtils.getUtcOffset(
                  userTimezone,
                  DefaultValues.withoutDSTDate
                )
              : TimezoneUtils.getUtcOffset(userTimezone);
            return (
              utcOffset === TimezoneUtils.convertOffsetToMinutes(item.timezone)
            );
          });
          if (!isEmpty(newUserTimezone))
            userTimezone = TimezoneUtils.getTimeZoneName(
              newUserTimezone[0].englishName
            );
        }
      }
      defaultTimezone =
        isTririgaTimezone ||
        !isEmpty(newUserTimezone) ||
        !isEmpty(mappedTimezone)
          ? userTimezone
          : DefaultValues.TIMEZONE;
      dispatch(setDefaultTimezone(defaultTimezone));
    }
    return defaultTimezone;
  };
};

export function setUserSelectedScan(scanType) {
  return {
    type: currentUserActionTypes.SET_SCAN_TYPE,
    scanType,
  };
}
