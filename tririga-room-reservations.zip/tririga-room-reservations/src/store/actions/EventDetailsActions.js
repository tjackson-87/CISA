/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2022-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name:Mike Tremblay
*/
import { eventDetailsActionTypes } from "../../utils";

export const setEventDetail = (event) => {
  return {
    type: eventDetailsActionTypes.SET_EVENT_DETAIL,
    event,
  };
};

export const setEquipmentToEventDetail = (equipmentByRoom) => {
  return {
    type: eventDetailsActionTypes.SET_EVENT_EQUIPMENT,
    equipmentByRoom,
  };
};

export const setCateringToEventDetail = (cateringByRoom) => {
  return {
    type: eventDetailsActionTypes.SET_EVENT_CATERING,
    cateringByRoom,
  };
};

export const setOnlineMeetingToEventDetail = (onlineMeetingInfo) => {
  return {
    type: eventDetailsActionTypes.SET_EVENT_ONLINE_MEETING_DETAILS,
    onlineMeetingInfo,
  };
};

export const setEventDescriptionAndAttendees = (description, attendees) => {
  return {
    type: eventDetailsActionTypes.SET_EVENT_ATTENDEES_DESCRIPTION,
    attendees,
    description,
  };
};

export const setReservationCostSummary = (costSummary) => {
  return {
    type: eventDetailsActionTypes.SET_EVENT_COST_SUMMARY,
    costSummary,
  };
};

export const setEventRoomsContactRole = (contactRoles) => {
  return {
    type: eventDetailsActionTypes.SET_EVENT_ROOMS_CONTACT_ROLES,
    contactRoles,
  };
};

export const setEventInstance = (instance) => {
  return {
    type: eventDetailsActionTypes.SET_EVENT_INSTANCE,
    instance,
  };
};

export const setEventRoomsAvailableEquipments = (
  availableEquipmentForAllRooms
) => {
  return {
    type: eventDetailsActionTypes.SET_EVENT_ROOMS_AVAILABLE_EQUIPMENT,
    availableEquipmentForAllRooms,
  };
};

export const reFetchEvent = () => {
  return {
    type: eventDetailsActionTypes.REFETCH_EVENT,
  };
};

export const fetchEvent = () => {
  return {
    type: eventDetailsActionTypes.FETCH_EVENT,
  };
};

export const clearEvent = () => {
  return {
    type: eventDetailsActionTypes.CLEAR_EVENT,
  };
};

export const setEventExtension = (Extension) => {
  return {
    type: eventDetailsActionTypes.SET_EVENT_EXTENSION,
    Extension,
  };
};

export const setEventRooms = (rooms) => {
  return {
    type: eventDetailsActionTypes.SET_EVENT_ROOMS,
    rooms,
  };
};

export const setEventDetailObject = (stateObj) => {
  return {
    type: eventDetailsActionTypes.SET_EVENT_DETAIL_OBJECT,
    stateObj,
  };
};

export const setHasSomeButNotEveryResourceInSeriesOccurrences = (
  hasSomeButNotEveryResourceInSeriesOccurrences
) => {
  return {
    type: eventDetailsActionTypes.SET_IS_ALL_OCCURRENCE_HAS_RESOURCE,
    hasSomeButNotEveryResourceInSeriesOccurrences,
  };
};
