/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import { reserveEventTypesActionTypes } from "../../utils";
import { ReserveEventTypesDS } from "../../model";
import { setLoading } from "./LoadingActions";
import isEmpty from "lodash/isEmpty";
import { ReserveEventTypesSelectors } from "..";

export const getReserveEventTypes = () => {
  return async (dispatch, getState) => {
    let reserveEventTypes;
    reserveEventTypes = ReserveEventTypesSelectors.reserveEventTypesSelector(
      getState()
    );

    if (!isEmpty(reserveEventTypes)) return reserveEventTypes;
    try {
      dispatch(setLoading("getReserveEventTypes", true));
      reserveEventTypes = await ReserveEventTypesDS.getReserveEventTypes();
      dispatch(setReserveEventTypes(reserveEventTypes));
    } finally {
      dispatch(setLoading("getReserveEventTypes", false));
    }
    return reserveEventTypes;
  };
};

const setReserveEventTypes = (reserveEventTypes) => {
  return {
    type: reserveEventTypesActionTypes.SET_RESERVE_EVENT_TYPES,
    reserveEventTypes,
  };
};
