/* IBM Confidential· - OCO Source Materials· - (C) COPYRIGHT IBM CORP. 2023 - The source code for this program is not published or otherwise· divested of its trade secrets, irrespective of what has been· deposited with the U.S. Copyright Office. */

import { AllUserProfileDS, BuildingsDS, MyCalendarDS } from "../../model";
import {
  colleagueActionTypes,
  LocationConstants,
  REQUEST_DISCARDED,
  ColleagueReservationUtils,
  DefaultValues,
  EventUtils,
  getColleagueReservationDateTime,
} from "../../utils";
import {
  LoadingActions,
  getAppStore,
  CurrentUserActions,
  MyCalendarActions,
  ColleagueSelectors,
  ReserveEventTypesActions,
  LocationActions,
  ReservationActions,
  CurrentUserSelectors,
} from "..";
import { isEmpty, sortBy } from "lodash";
import moment from "moment-timezone";

const LOCATION_SEARCH_QUERY_PAGE_SIZE =
  LocationConstants.LOCATION_SEARCH_QUERY_PAGE_SIZE;

export function clearSearch() {
  return {
    type: colleagueActionTypes.CLEAR_COLLEAGUE_SEARCH,
  };
}

export function setSelectedColleague(selectedColleague) {
  return {
    type: colleagueActionTypes.SET_SELECTED_COLLEAGUE,
    selectedColleague,
  };
}

export const setColleagueDetails = (details) => {
  return {
    type: colleagueActionTypes.SET_COLLEAGUE_DETAILS,
    details: details,
  };
};

function setColleagues(colleagues) {
  return {
    type: colleagueActionTypes.SET_COLLEAGUES,
    ...colleagues,
  };
}

export function searchColleagues(searchText) {
  return async (dispatch) => {
    if (isEmpty(searchText)) {
      dispatch(clearSearch());
    } else {
      try {
        dispatch(LoadingActions.setLoading("searchingColleagues", true));
        const result = await AllUserProfileDS.queryColleagues(searchText);
        if (result !== REQUEST_DISCARDED) {
          dispatch(
            setColleagues({
              colleagues: result.data,
              from: result.from + LOCATION_SEARCH_QUERY_PAGE_SIZE,
              totalSize: result.totalSize,
              searchText,
            })
          );
        }
      } finally {
        dispatch(LoadingActions.setLoading("searchingColleagues", false));
      }
    }
  };
}

export function searchMoreColleagues() {
  return async (dispatch, getState) => {
    const {
      colleague: { searchText, colleagues, from, totalSize },
    } = getState();
    if (from < totalSize) {
      try {
        dispatch(LoadingActions.setLoading("searchingMoreColleagues", true));
        const result = await AllUserProfileDS.queryMoreColleagues(
          searchText,
          from
        );
        if (result) {
          dispatch(
            setColleagues({
              colleagues: colleagues.concat(result.data),
              from: result.from + LOCATION_SEARCH_QUERY_PAGE_SIZE,
              totalSize,
              searchText,
            })
          );
        }
      } finally {
        dispatch(LoadingActions.setLoading("searchingMoreColleagues", false));
      }
    }
  };
}

export function getColleagueUpcomingReservation(personId) {
  return async (dispatch, getState) => {
    getAppStore().dispatch(
      LoadingActions.setLoading("loadingColleagueReservations", true)
    );
    const timezone = await getAppStore().dispatch(
      CurrentUserActions.getDefaultTimezone()
    );
    const start = moment.tz(new Date(), timezone).toISOString(true);
    const end = moment.tz(start, timezone).add(5, "years").toISOString(true);
    let events = await MyCalendarDS.getMyCalendar(start, end, personId);
    const reserveEventTypes = await getAppStore().dispatch(
      ReserveEventTypesActions.getReserveEventTypes()
    );
    EventUtils.computeEventsLocationType(events, reserveEventTypes);
    events = sortBy(events, function (event) {
      return moment.tz(event.start, timezone);
    });
    let eventsLimit = events.slice(
      0,
      DefaultValues.UPCOMING_RESERVATION_COUNT - 1
    );
    await MyCalendarActions.getEventRooms(eventsLimit);
    eventsLimit = await ColleagueReservationUtils.upcomingReservationList(
      eventsLimit
    );
    dispatch({
      type: colleagueActionTypes.SET_COLLEAGUE_UPCOMING_RESERVATION,
      events: {
        reservations: events,
        reservationsLimit: eventsLimit,
      },
    });
    getAppStore().dispatch(
      LoadingActions.setLoading("loadingColleagueReservations", false)
    );

    return events;
  };
}

export function loadMoreReservations(indexFrom, indexTo) {
  return async (dispatch, getState) => {
    getAppStore().dispatch(
      LoadingActions.setLoading("loadingMoreEventsAfter", true)
    );
    const reservations = ColleagueSelectors.colleagueUpcomingReservationsSelector(
      getState()
    );
    let eventsLimit = reservations.slice(indexFrom, indexTo);
    await MyCalendarActions.getEventRooms(eventsLimit);
    eventsLimit = await ColleagueReservationUtils.upcomingReservationList(
      eventsLimit
    );
    const events = ColleagueSelectors.limitUpcomingReservationsSelector(
      getState()
    );
    const combineEvents = [...events, ...eventsLimit];
    dispatch({
      type: colleagueActionTypes.SET_COLLEAGUE_UPCOMING_RESERVATION,
      events: {
        reservations,
        reservationsLimit: combineEvents,
      },
    });
    getAppStore().dispatch(
      LoadingActions.setLoading("loadingMoreEventsAfter", false)
    );
  };
}

export function clearUpcomingReservation() {
  return {
    type: colleagueActionTypes.SET_COLLEAGUE_UPCOMING_RESERVATION,
    events: {
      reservations: [],
      reservationsLimit: [],
      lastIndex: "",
    },
  };
}

export function setSelectedColleagueReservation(event) {
  return {
    type: colleagueActionTypes.SET_SELECTED_COLLEAGUE_RESERVATION,
    event,
  };
}

export function setSelectedColleagueReservationRoom(room) {
  return {
    type: colleagueActionTypes.SET_SELECTED_COLLEAGUE_RESERVATION_ROOM,
    room,
  };
}

export function setSelectedColleagueReservationFloor(floor) {
  return {
    type: colleagueActionTypes.SET_SELECTED_COLLEAGUE_RESERVATION_FLOOR,
    floor,
  };
}

export function setSelectedColleagueReservationBuilding(building) {
  return {
    type: colleagueActionTypes.SET_SELECTED_COLLEAGUE_RESERVATION_BUILDING,
    building,
  };
}

export function handleSetSelectedColleagueReservationBuilding(buildingId) {
  return async (dispatch) => {
    try {
      dispatch(LoadingActions.setLoading("changingBuilding", true));
      const building = await BuildingsDS.getBuildingByID(buildingId);
      if (building) {
        dispatch(LocationActions.setSelectedBuilding(building));
        dispatch(setSelectedColleagueReservationBuilding(building));
      }
    } finally {
      dispatch(LoadingActions.setLoading("changingBuilding", false));
    }
  };
}

export function setZoomToColleague(zoomToColleague) {
  return {
    type: colleagueActionTypes.SET_ZOOM_TO_COLLEAGUE,
    zoomToColleague,
  };
}

export const setColleagueReservedRoom = (room) => {
  return {
    type: colleagueActionTypes.SET_COLLEAGUE_RESERVED_ROOM,
    room: room,
  };
};

export function setAssignedSeatData(selectedRoom, colleague) {
  return async (dispatch, getState) => {
    const selectedRoom = ColleagueSelectors.selectedColleagueReservationRoomSelector(
      getState()
    );
    const selectedBuilding = ColleagueSelectors.selectedColleagueReservationBuildingSelector(
      getState()
    );
    const defaultTimezone = CurrentUserSelectors.defaultTimezoneSelector(
      getState()
    );
    const startDateTime = moment
      .tz(new Date(), selectedBuilding.timeZone)
      .set({
        hour: 8,
        minute: 0,
      })
      .format("YYYY-MM-DD hh:mm A");
    const endDateTime = moment
      .tz(new Date(), selectedBuilding.timeZone)
      .set({
        hour: 17,
        minute: 0,
      })
      .format("YYYY-MM-DD hh:mm A");
    colleague.isMeetingSpace = colleague.isMeetingSpace === "FALSE" ? 0 : 1;
    const room = {
      country: colleague.country,
      endDate: startDateTime,
      floorSystemRecordID: colleague.floorSystemRecordID,
      networkConnection: null,
      reservationClassDescription: "No Approval Required",
      type: selectedBuilding.type,
      building: colleague.building,
      roomId: selectedRoom._id,
      usageCost: null,
      reservationDefinitionRecordID: "",
      layoutDefault: true,
      cateringAvailable: null,
      reservationStart: startDateTime,
      spaceclassname: colleague.isMeetingSpace
        ? "Meeting"
        : "Dedicated Open Workstation",
      state: selectedBuilding.state,
      isMeetingSpace: colleague.isMeetingSpace,
      area: colleague.roomArea + "",
      image: colleague.image,
      exchangeMailbox: null,
      ipPhone: null,
      floorLevel: colleague.floorLevel,
      inRoomProjector: null,
      spaceRecordId: selectedRoom.spaceRecordId,
      resourceInstanceRecordId: null,
      noiseBarrier: null,
      reservationEnd: endDateTime,
      setupCost: 0,
      name: colleague.primaryLocation,
      statusENUS: "Accepted",
      citySystemRecordID: selectedBuilding.systemRecordID,
      _id: selectedRoom._id,
      startDate: startDateTime,
      status: "Accepted",
      city: selectedBuilding.city,
      timezone: selectedBuilding.timeZone,
      reservationClassNameENUS: "Reservable",
      whiteboard: null,
      capacity: colleague.capacity ? Number(colleague.capacity) : 0,
      naturalLight: null,
      layoutType: colleague.isMeetingSpace ? "Conference" : "Workspace",
      currency: colleague.currency,
      floor: colleague.floor,
      buildingSystemRecordID: colleague.buildingSystemRecordID,
      usageUnit: "Hour",
      telephoneConference: null,
      videoConferenceRoom: null,
      adaAvailable: null,
      reservationClassName: "Reservable",
      adjustableHeightDesk: null,
      layoutTypeInternal: colleague.isMeetingSpace ? "Conference" : "Workspace",
      isWorkSpace: true,
      layoutImage: colleague.layoutImage,
    };
    dispatch(setColleagueReservedRoom({ ...room, reservedRoom: true }));
    const dateTimeObject = getColleagueReservationDateTime(
      {
        start: startDateTime,
        end: endDateTime,
        reservationTimezone: selectedBuilding.timeZone,
        isAllDay: true,
      },
      defaultTimezone
    );
    dispatch(ReservationActions.updateDateAndTime(dateTimeObject));
  };
}
