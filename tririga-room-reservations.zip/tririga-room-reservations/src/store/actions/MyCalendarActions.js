/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import moment from "moment-timezone";
import { sortBy, isEmpty } from "lodash";
import {
  myCalendarActionTypes,
  getCurrentDateTime,
  ReservationEditMode,
  isWithinAnHourFromNow,
} from "../../utils";
import {
  LoadingActions,
  CurrentUserActions,
  ApplicationSettingsSelectors,
  ExchangeActions,
  CheckInActions,
} from "..";
import {
  ReservationDS,
  ReservationInstancesDS,
  ReservationSpacesDS,
} from "../../model";

const { SERIES, SERIES_EXCEPTION } = ReservationEditMode;

export function initializeMyCalendarDate() {
  return async (dispatch, getState) => {
    try {
      dispatch(LoadingActions.setLoading("initializeMyCalendarDate", true));
      const timezone = await dispatch(CurrentUserActions.getDefaultTimezone());
      dispatch(setMyCalendarTimezone(timezone));
      dispatch(
        setMyCalendarDate(moment(getCurrentDateTime(timezone)).toDate())
      );
    } finally {
      dispatch(LoadingActions.setLoading("initializeMyCalendarDate", false));
    }
  };
}

export function setMyCalendarTimezone(timezone) {
  return {
    type: myCalendarActionTypes.SET_MY_CALENDAR_TIMEZONE,
    timezone,
  };
}

export function setMyCalendarDate(date, reset = true, timezone) {
  return {
    type: myCalendarActionTypes.SET_MY_CALENDAR_DATE,
    date,
    reset,
    timezone,
  };
}

export function getMoreCalendarEvents(after) {
  return {
    type: myCalendarActionTypes.GET_MORE_CALENDAR_EVENTS,
    after,
  };
}

export function refreshMyCalendar() {
  return {
    type: myCalendarActionTypes.REFRESH_MY_CALENDAR,
  };
}

export function setMyCalendarEvents(events, start, end) {
  return {
    type: myCalendarActionTypes.SET_MY_CALENDAR_EVENTS,
    events: sortBy(events, (ev) => moment(ev.start).valueOf()),
    start,
    end,
  };
}

export function deleteMyCalendarEvent(eventId, start) {
  return {
    type: myCalendarActionTypes.DELETE_MY_CALENDAR_EVENT,
    eventId,
    start,
  };
}

export function deleteEvent(
  {
    eventId,
    iCalUId,
    reservationId,
    seriesMasterId,
    seriesReservationId,
    start,
    end,
    isRecurringException,
  },
  reservationEditMode
) {
  return async (dispatch, getState) => {
    dispatch(LoadingActions.setLoading("delete event", true));
    let isExchangeIntegrated = false;
    const state = getState();
    const reservationDeleteParam = {
      start,
      end,
      reservationEditMode: isRecurringException
        ? SERIES_EXCEPTION
        : reservationEditMode,
    };
    try {
      isExchangeIntegrated = ApplicationSettingsSelectors.isExchangeIntegratedSelector(
        state
      );
      if (reservationId) {
        await ReservationDS.deleteReservation(
          reservationEditMode === SERIES ? seriesReservationId : reservationId,
          reservationDeleteParam
        );
      }
      if (iCalUId && isExchangeIntegrated) {
        if (reservationEditMode === SERIES) {
          await dispatch(ExchangeActions.deleteEvent(seriesMasterId));
        } else {
          await dispatch(ExchangeActions.deleteEvent(eventId));
        }
      }
      if (reservationEditMode !== SERIES) {
        dispatch(deleteMyCalendarEvent(eventId));
      }
      dispatch(refreshMyCalendar());
    } finally {
      dispatch(LoadingActions.setLoading("delete event", false));
    }
  };
}

export async function getEventRooms(events) {
  const reservationIds = events
    .filter((item) => item.reservationId != null)
    .map((item) => item.reservationId);
  if (!isEmpty(reservationIds)) {
    const reservationSpaces = await ReservationSpacesDS.getReservationSpaces(
      reservationIds
    );
    const spacesByReservation = reservationSpaces.reduce((acc, item) => {
      const itemInMap = acc[item.reservationDefinitionRecordID];
      if (itemInMap) {
        const foundRoomIndex = itemInMap.findIndex(
          (itemInMap) => itemInMap.spaceRecordId === item.spaceRecordId
        );
        if (foundRoomIndex !== -1) {
          if (
            parseInt(item._id) > parseInt(itemInMap[foundRoomIndex]._id) ||
            (item.resourceInstanceRecordId !== null &&
              itemInMap[foundRoomIndex].resourceInstanceRecordId === null)
          ) {
            itemInMap[foundRoomIndex] = item;
          }
        } else {
          acc[item.reservationDefinitionRecordID] = [...itemInMap, item];
        }
      } else {
        acc[item.reservationDefinitionRecordID] = [item];
      }
      return acc;
    }, {});
    events.forEach((item) => {
      item.rooms = spacesByReservation[item.reservationId];
    });
  }
  return events;
}

export async function getReservationInstances(events) {
  const reservationInstances = await ReservationInstancesDS.getReservationInstances();
  if (!isEmpty(reservationInstances)) {
    events.forEach((event) => {
      const instancesForEvent = reservationInstances.filter(
        (instance) =>
          (event.reservationId === instance.reservationId ||
            event.seriesReservationId === instance.reservationId) &&
          new Date(event.start).getTime() ===
            new Date(instance.plannedStart).getTime()
      );
      if (!isEmpty(instancesForEvent)) {
        const latestInstance = instancesForEvent[0];
        event.instance = latestInstance;
      }
    });
  }
  return events;
}

export async function getMissingReservationInstances(events) {
  const upcomingEventsWithoutInstances = events.filter(
    (e) => e.rooms && !e.instance && isWithinAnHourFromNow(e.start)
  );
  if (!isEmpty(upcomingEventsWithoutInstances)) {
    await upcomingEventsWithoutInstances.reduce(async (promise, e) => {
      await promise;
      const updatedInstance = await CheckInActions.waitUntilValidInstanceIsCreated(
        e.reservationId,
        e.start
      );
      if (!isEmpty(updatedInstance)) {
        const eventSpaces = await ReservationSpacesDS.getReservationSpaces(
          e.reservationId
        );
        events.forEach((event) => {
          if (event.reservationId === e.reservationId) {
            event.instance = updatedInstance;
            event.rooms = eventSpaces;
          }
        });
      }
    }, Promise.resolve());
  }
  return events;
}
