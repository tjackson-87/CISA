/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import { equipmentDetailsActionTypes } from "../../utils";
import { EquipmentDS } from "../../model";
import {
  LoadingActions,
  ReservationActions,
  ReservationSelectors,
  RecurrenceSelectors,
  EventDetailsSelectors,
  EventDetailsActions,
} from "..";

export const setEquipmentDetail = (equipment) => {
  return {
    type: equipmentDetailsActionTypes.SET_EQUIPMENT_DETAIL,
    equipment,
  };
};

export const setEquipmentDetailModal = (isOpen) => {
  return {
    type: equipmentDetailsActionTypes.SET_EQUIPMENT_DETAIL_MODAL,
    isOpen,
  };
};

export const setEquipmentId = (equipmentId) => {
  return {
    type: equipmentDetailsActionTypes.SET_EQUIPMENT_ID,
    equipmentId,
  };
};

export function getAvailableEquipmentForAllResources() {
  return async (dispatch, getState) => {
    const availableEquipmentForAllResources = [];
    try {
      dispatch(LoadingActions.setLoading("equipment", true));
      const state = getState();
      const isReadOnlyPage = ReservationSelectors.detailPageRouteSelector(
        state
      );
      const resources = ReservationSelectors.orderedResourcesSelector(state);
      let startDate = "";
      let endDate = "";
      if (isReadOnlyPage) {
        const event = EventDetailsSelectors.eventDetailsSelector(state);
        startDate = event ? event.start : null;
        endDate = event ? event.end : null;
      } else {
        const dates = ReservationSelectors.firstOccurStartAndEndDateSelector(
          state
        );
        startDate = dates.startDate;
        endDate = dates.endDate;
      }
      const recurrence = isReadOnlyPage
        ? null
        : RecurrenceSelectors.reserveContextRecurrenceSelector(state);
      for (const resource of resources) {
        const buildingID = isReadOnlyPage
          ? resource.buildingSystemRecordID
          : resource.room.buildingSystemRecordID;
        const roomEquipment = await EquipmentDS.getEquipment(
          isReadOnlyPage ? resource.spaceRecordId : resource.room._id,
          buildingID,
          startDate,
          endDate,
          recurrence
        );
        availableEquipmentForAllResources.push({
          roomId: isReadOnlyPage
            ? resource.spaceRecordId
            : resource.data.roomId,
          availableEquipment: roomEquipment,
        });
      }
      if (isReadOnlyPage) {
        dispatch(
          EventDetailsActions.setEventRoomsAvailableEquipments(
            availableEquipmentForAllResources
          )
        );
      } else {
        dispatch(
          ReservationActions.setAvailableEquipmentForAllResources(
            availableEquipmentForAllResources
          )
        );
      }
    } finally {
      dispatch(LoadingActions.setLoading("equipment", false));
    }
    return availableEquipmentForAllResources;
  };
}
