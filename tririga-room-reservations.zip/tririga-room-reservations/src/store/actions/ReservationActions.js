/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for update 7/29/2024
  Name: Mike Tremblay
*/
import moment from "moment-timezone";
import defaultTo from "lodash/defaultTo";
import { isEmpty, groupBy, isEqual } from "lodash";
import { getUserBuilding } from "./UserBuildingActions.js";
import { setLoading } from "./LoadingActions.js";
import {
  ReservableSpacesDS,
  ReservationDS,
  Exchange,
  BuildingsDS,
  MyCalendarDS,
} from "../../model";
import {
  reservationActionTypes,
  Status,
  RecurrenceConstants,
  ReservationTypes,
  ReservationUtils,
  AppMsg,
  DateTimeConstants,
  getTimeType,
  getDayType,
  computeMomentStartAndEndDates,
  needAdvancedView,
  getCurrentDateTime,
  getTimeAsAllDay,
  ReservationEditMode,
  isWorkplaceServicesAppHome,
  cateringActionType,
  setEventEndDate,
} from "../../utils";
import {
  ReservationSelectors,
  RouteActions,
  MessageActions,
  RoomSearchActions,
  ApplicationSettingsSelectors,
  ExchangeActions,
  RecurrenceSelectors,
  CurrentUserActions,
  MyCalendarActions,
  LocationActions,
  ExchangeSelectors,
  EventDetailsActions,
  SyncWithOutlookSelectors,
  SyncWithOutlookActions,
  ColleagueActions,
  OnlineMeetingActions, // CISA
} from "..";
import { TRIDATA_SESSION_STORAGE_KEY } from "../../app/TririgaRoomReservationApp.js";

const { DateTimeViewMode, WORKSPACE_DAY, WORKSPACE_TIME } = DateTimeConstants;
const { SERIES_EXCEPTION } = ReservationEditMode;
const doInitializeNewReservation = (
  reservationType,
  reservationInitialTime,
  subject = "",
  accountCodeEquipment = "",
  accountCodeFood = "",
  accountCodeRoom = ""
) => {
  return {
    type: reservationActionTypes.INITIALIZE_NEW_RESERVATION,
    ...reservationInitialTime,
    reservationType,
    subject,
    accountCodeEquipment,
    accountCodeFood,
    accountCodeRoom,
  };
};

export function initializeNewReservation(
  reservationType,
  navigateToReservationPage = false,
  historyReplace = false,
  startDate,
  endDate,
  isDateOnly
) {
  return async (dispatch, getState) => {
    try {
      if (reservationType === ReservationTypes.MEETING) {
        const isExchangeIntegrated = ApplicationSettingsSelectors.isExchangeIntegratedSelector(
          getState()
        );
        if (isExchangeIntegrated) {
          try {
            await dispatch(ExchangeActions.getAzureAccessToken());
            await dispatch(ExchangeActions.getMyUserExchangeProfile());
          } catch (error) {
            return;
          }
        }
      }
      dispatch(setLoading("initializeNewReservation", true));
      const currentUser = await dispatch(CurrentUserActions.getCurrentUser());
      const timezone = await dispatch(CurrentUserActions.getDefaultTimezone());
      const reservationInitialTime = ReservationUtils.computeReservationInitialTime(
        reservationType,
        timezone,
        startDate,
        endDate,
        isDateOnly
      );
      await ReservationDS.unholdRoomsFromUser();
      const subject =
        reservationType === ReservationTypes.WORKSPACE
          ? AppMsg.getMessage(
              AppMsg.RESERVATION_MESSAGE.WORKSPACE_SUBJECT
            ).replace("{1}", `${currentUser.firstName} ${currentUser.lastName}`)
          //CISA
          : reservationType === ReservationTypes.OFFICE ? AppMsg.getMessage( 
            AppMsg.RESERVATION_MESSAGE.OFFICE_SUBJECT 
          ).replace("{1}", `${currentUser.firstName} ${currentUser.lastName}`)
          : "";
      dispatch(
        doInitializeNewReservation(
          reservationType,
          reservationInitialTime,
          subject,
          currentUser.accountCodeEquipment,
          currentUser.accountCodeFood,
          currentUser.accountCodeRoom
        )
      );
      const primaryBuilding = await dispatch(getUserBuilding());
      dispatch(RoomSearchActions.initRoomSearch());
      isWorkplaceServicesAppHome()
        ? await loadBuildingFromStorage(dispatch)
        : dispatch(LocationActions.setSelectedBuilding(primaryBuilding));
      dispatch(LocationActions.setPrevSelectedBuilding(null));
      dispatch(LocationActions.setLastMeetingSearchFilters(null));
      dispatch(ColleagueActions.setSelectedColleague(null));
      dispatch(EventDetailsActions.clearEvent());
      if (navigateToReservationPage) {
        dispatch(
          RouteActions.navigateToReservationPage(
            reservationType,
            historyReplace
          )
        );
      }
    } finally {
      dispatch(setLoading("initializeNewReservation", false));
    }
  };
}

async function loadBuildingFromStorage(dispatch) {
  try {
    let savedLocationDetails = localStorage.getItem(
      TRIDATA_SESSION_STORAGE_KEY
    );
    savedLocationDetails =
      savedLocationDetails !== null ? JSON.parse(savedLocationDetails) : null;
    const savedBuilding = await BuildingsDS.getBuildingByID(
      savedLocationDetails?.locationContextSelectedBuildingId
    );
    dispatch(LocationActions.setSelectedBuilding(savedBuilding));
  } catch (error) {
    return null;
  }
}

export function loadReservation(reservation, shouldReplaceURL = true) {
  return async (dispatch) => {
    await ReservationDS.unholdRoomsFromUser();
    await dispatch(CurrentUserActions.getCurrentUser());
    await dispatch(CurrentUserActions.getDefaultTimezone());
    dispatch({
      type: reservationActionTypes.LOAD_RESERVATION,
      ...reservation,
    });
    const primaryBuilding = await dispatch(getUserBuilding());
    dispatch(RoomSearchActions.initRoomSearch());
    dispatch(LocationActions.setSelectedBuilding(primaryBuilding));
    if (shouldReplaceURL) {
      dispatch(
        RouteActions.navigateToReservationPage(
          reservation.reservationType,
          true
        )
      );
    }
  };
}

export function cancelNewReservation() {
  return async (dispatch, getState) => {
    try {
      dispatch(setLoading("cancelNewReservation", true));
      const hasResourcesOnHold = ReservationSelectors.hasResourcesOnHoldSelector(
        getState()
      );
      if (hasResourcesOnHold) {
        await ReservationDS.unholdRoomsFromUser();
      }
      dispatch(clearReservation());
    } finally {
      dispatch(setLoading("cancelNewReservation", false));
    }
  };
}

const updateReservationData = (value) => {
  return {
    type: reservationActionTypes.UPDATE_RESERVATION_DATA,
    value,
  };
};

const updateSavedReservationData = (value) => {
  return {
    type: reservationActionTypes.UPDATE_SAVED_RESERVATION_DATA,
    value,
  };
};

export const setIsReservationSeriesWithExceptionData = (value) => {
  return {
    type: reservationActionTypes.IS_RESERVATION_SERIES_WITH_EXCEPTIONS_DATA,
    value: value,
  };
};

const updateMeetingTimeStepTempData = (value) => {
  return {
    type: reservationActionTypes.UPDATE_TIME_STEP_TEMP_DATA,
    value,
  };
};

export function updateSubject(subject) {
  return updateReservationData({ subject });
}
// CISA
export function updateOnlineTeamsMeeting(generateOnlineMeeting){
  return updateReservationData({ generateOnlineMeeting });
}

export function updateAdditionalLocationInfo(additionalLocationInfo) {
  return updateReservationData({ additionalLocationInfo });
}

export function updateDescription(description) {
  return updateReservationData({ description });
}

export function setResourceSelectedEquipment(selectedEquipment, roomId) {
  return {
    type: reservationActionTypes.SET_RESOURCE_SELECTED_EQUIPMENT,
    selectedEquipment,
    roomId,
  };
}

export function setResourceAddedEquipment(addedEquipment, roomId) {
  return {
    type: reservationActionTypes.SET_RESOURCE_ADDED_EQUIPMENT,
    addedEquipment,
    roomId,
  };
}

export function setResourceSelectedCatering(selectedCatering, roomId) {
  return {
    type: reservationActionTypes.SET_RESOURCE_SELECTED_CATERING,
    selectedCatering,
    roomId,
  };
}
export function setResourceSelectedCateringDeliveryTime(
  startTime,
  startTimePeriod
) {
  return {
    type: reservationActionTypes.SET_RESOURCES_SELECTED_CATERING_DELIVERY_TIME,
    startTime,
    startTimePeriod,
  };
}

export function setAvailableEquipmentForAllResources(
  availableEquipmentForAllResources
) {
  return {
    type: reservationActionTypes.SET_RESOURCES_AVAILABLE_EQUIPMENT,
    availableEquipmentForAllResources,
  };
}

export function setAvailableCateringsForAllResources(menuItemsForAllResources) {
  return {
    type: reservationActionTypes.SET_RESOURCES_AVAILABLE_CATERING_ITEMS,
    menuItemsForAllResources,
  };
}

export function setAttendees(attendees) {
  if (attendees != null) {
    attendees.forEach((attendee) => {
      if (isEmpty(attendee.firstName)) {
        attendee.firstName = attendee.name;
      }
      if (isEmpty(attendee.lastName)) {
        attendee.lastName = attendee.name;
      }
      if (isEmpty(attendee.displayName)) {
        attendee.displayName = attendee.name;
      }
    });
  }
  return {
    type: reservationActionTypes.SET_ATTENDEES,
    attendees,
  };
}

function updateHoldTimeEnd(holdTimeEnd) {
  return {
    type: reservationActionTypes.UPDATE_HOLD_TIME_END,
    holdTimeEnd,
  };
}

export function setHoldTimeExpired() {
  return {
    type: reservationActionTypes.SET_HOLD_TIME_EXPIRED,
  };
}

function setResourcesOnHold(resources) {
  return {
    type: reservationActionTypes.SET_RESOURCES_ON_HOLD,
    resources,
  };
}

export function setReservedResources(resources) {
  return {
    type: reservationActionTypes.SET_RESERVED_RESOURCES,
    resources,
  };
}

function removeResourceSeriesException(resourceId) {
  return {
    type: reservationActionTypes.REMOVE_RESOURCE_UNHOLD_ROOM_SERIES_EXCEPTION,
    resourceId,
  };
}

function removeResource(resourceId) {
  return {
    type: reservationActionTypes.REMOVE_RESOURCE,
    resourceId,
  };
}

function undoRemoveResource(resourceId) {
  return {
    type: reservationActionTypes.UNDO_REMOVE_RESOURCE,
    resourceId,
  };
}

export function updateResourceShowMore(roomId, showMoreOptions) {
  return {
    type: reservationActionTypes.SET_RESOURCE_SHOW_MORE_FLAG,
    roomId,
    showMoreOptions,
  };
}

export function handleAccountCodeChanged(accountCodeName, accountCodeValue) {
  return updateReservationData({ [accountCodeName]: accountCodeValue });
}

export function handleAccountCodeChangedInSavedReservation(
  accountCodeName,
  accountCodeValue
) {
  return updateSavedReservationData({ [accountCodeName]: accountCodeValue });
}

export function updateDateAndTime(dateAndTime) {
  return async (dispatch, getState) => {
    if (
      dateAndTime.recurrence &&
      dateAndTime.recurrence.type === RecurrenceConstants.RECUR_TYPE_VALUES.NONE
    ) {
      dateAndTime.recurrence = null;
    }
    dispatch(
      updateReservationData({
        ...dateAndTime,
      })
    );
    if (ReservationSelectors.isCreateSelector(getState())) {
      dispatch(
        setResourceSelectedCateringDeliveryTime(
          dateAndTime.startTime,
          dateAndTime.startTimePeriod
        )
      );
    }

    const isRecurrence = !isEmpty(
      ReservationSelectors.recurrenceSelector(getState())
    );
    if (!isRecurrence) {
      const rooms = ReservationSelectors.roomsSelector(getState());
      const resources = ReservationSelectors.resourcesSelector(getState());
      if (!isEmpty(resources)) {
        await dispatch(holdRooms(rooms));
      }
    }
  };
}

export function updateRoomsWhenDateTimeAndOccurrenceRuleChanged() {
  return async (dispatch, getState) => {
    dispatch(setSelectedResource(null));
    const rooms = ReservationSelectors.roomsSelector(getState());
    dispatch(setLoading("updateRoomWhenRecurrenceChanged", true));
    const roomSearchResult = await getSearchedRooms(rooms, getState);
    const isCreate = ReservationSelectors.isCreateSelector(getState());
    const {
      resources: initUpdatedResources,
      recurrence: initUpdatedRecurrence,
    } = isCreate
      ? { resources: [] }
      : ReservationSelectors.initUpdatedDataSelector(getState());
    try {
      const resources = ReservationSelectors.resourcesSelector(getState());
      const recurrence = ReservationSelectors.recurrenceSelector(getState());
      const initUpdatedRoomIds = initUpdatedResources.map((r) => r.room._id);
      const roomIds = resources.map((r) => r.room._id);
      const noUpdate =
        !isEmpty(initUpdatedRecurrence) &&
        isEqual(recurrence.details, initUpdatedRecurrence.details) &&
        isEqual(initUpdatedRoomIds, roomIds);
      if (!isEmpty(resources)) {
        if (isCreate) {
          await dispatch(holdRooms(roomSearchResult, true));
        } else {
          await handleSetResourcesWhenUpdatedReservationRecurrenceRuleChanged(
            getState,
            dispatch,
            roomSearchResult,
            initUpdatedResources,
            noUpdate
          );
        }
      }
    } catch (error) {
      dispatch(MessageActions.showGeneralError());
    } finally {
      dispatch(setLoading("updateRoomWhenRecurrenceChanged", false));
    }
  };
}

async function getSearchedRooms(rooms, getState) {
  const reservationType = ReservationSelectors.reservationTypeSelector(
    getState()
  );
  const {
    startDate,
    endDate,
  } = ReservationSelectors.firstOccurStartAndEndDateSelector(getState());
  const searchFilters = {
    startDate,
    endDate,
    filters: { showRequestableRooms: true, showPrivateRooms: true },
  };
  const occurrenceMatch = ApplicationSettingsSelectors.occurrenceMatchSelector(
    getState()
  );
  const reserveContextRecurrence = RecurrenceSelectors.reserveContextRecurrenceSelector(
    getState()
  );
  const {
    data: roomSearchResult,
  } = await ReservableSpacesDS.queryReservableSpaces(
    reservationType,
    searchFilters,
    null,
    0,
    rooms.length,
    reserveContextRecurrence,
    occurrenceMatch,
    null,
    null,
    false,
    null,
    rooms,
    null
  );
  return roomSearchResult;
}

function getNewReplaceReservedResourcesAndLookupResourcesIds(getState) {
  const {
    resources: initResources,
  } = ReservationSelectors.initUpdatedDataSelector(getState());
  const initRoomsIds = initResources.map((ir) => ir.room._id);
  let lookupResourceIDs = initResources.map((ir) => ir.data._id);
  const newReplaceReservedResources = [];

  lookupResourceIDs = ReservationSelectors.resourcesSelector(getState()).map(
    (r) =>
      initRoomsIds.includes(r.room._id)
        ? initResources.find((ir) => {
            if (ir.room._id === r.room._id)
              newReplaceReservedResources.push({
                ...r,
                initResourceId: ir.data._id,
              });
            return ir.room._id === r.room._id;
          }).data._id
        : r.data._id
  );

  return { newReplaceReservedResources, lookupResourceIDs };
}

async function getComputedOccurrenceException(
  getState,
  dispatch,
  lookupResourceIDs,
  newReplaceReservedResources
) {
  const recurrenceParams = RecurrenceSelectors.timeStepTempRecurrenceParamsSelector(
    getState()
  );
  const exceptionOccurrences = await dispatch(
    getOccurrenceExceptions(recurrenceParams, lookupResourceIDs)
  );
  newReplaceReservedResources.forEach((nr) => {
    if (
      exceptionOccurrences
        .map((e) => String(e.resource.id))
        .includes(nr.initResourceId)
    ) {
      const editException = exceptionOccurrences.find(
        (e) => e.resource.id === Number(nr.initResourceId)
      );
      const index = exceptionOccurrences.indexOf(editException);
      editException.resource.id = nr.data._id;
      exceptionOccurrences.splice(index, 1, editException);
    }
  });
  return exceptionOccurrences;
}

async function unholdPreviousNewHeldResources(
  newReplaceReservedResources,
  lookupResourceIDs
) {
  if (
    newReplaceReservedResources.length &&
    newReplaceReservedResources.length < lookupResourceIDs.length
  ) {
    await ReservationDS.unholdResources(
      newReplaceReservedResources.map((r) => ({ resourceId: r.data._id }))
    );
  }
}

async function handleSetResourcesWhenUpdatedReservationRecurrenceRuleChanged(
  getState,
  dispatch,
  rooms,
  initUpdatedResources,
  noUpdate
) {
  const recurrence = ReservationSelectors.recurrenceSelector(getState());
  const isUpdate = !ReservationSelectors.isCreateSelector(getState());
  const initUpdatedRooms = initUpdatedResources.map(
    (resource) => resource.room
  );

  if (noUpdate) {
    await dispatch(setResources(initUpdatedResources));
    return;
  }
  if (isUpdate && recurrence) {
    const resetRoomAvailabilities = rooms.map((room) => ({
      ...room,
      _occurrenceList:
        initUpdatedRooms.findIndex((r) => r._id === room._id) > -1
          ? room._occurrenceList.map((o) => ({
              ...o,
              isAvailable: true,
            }))
          : [...room._occurrenceList],
    }));

    const {
      newReplaceReservedResources,
      lookupResourceIDs,
    } = getNewReplaceReservedResourcesAndLookupResourcesIds(getState);
    await unholdPreviousNewHeldResources(
      newReplaceReservedResources,
      lookupResourceIDs
    );
    const exceptionOccurrences = await getComputedOccurrenceException(
      getState,
      dispatch,
      lookupResourceIDs,
      newReplaceReservedResources
    );

    const groupExceptionsByResourceId = groupBy(
      exceptionOccurrences,
      (e) => e.resource.id
    );
    const updateResourcesOccurrenceList = ReservationSelectors.resourcesSelector(
      getState()
    ).map((resource) => ({
      ...resource,
      room: {
        ...resource.room,
        _occurrenceList: resetRoomAvailabilities.find(
          (room) => room._id === resource.room._id
        )._occurrenceList,
      },
    }));

    const adjustedResources = updateResourcesOccurrenceList.map((resource) => {
      const occurrenceExceptions = groupExceptionsByResourceId[
        resource.data._id
      ]
        ? groupExceptionsByResourceId[resource.data._id].map((exception) => ({
            start: exception.exceptionStartDT,
            end: exception.exceptionEndDT,
            isAvailable: false,
            room: null,
          }))
        : [];

      const newOccurrencesList = resource.room._occurrenceList.filter(
        (occurrence) =>
          !occurrenceExceptions.map((oe) => oe.start).includes(occurrence.start)
      );

      const computedStatus = [
        ...newOccurrencesList,
        ...occurrenceExceptions,
      ].every((o) => !o.isAvailable)
        ? Status.DECLINED
        : Status.ACCEPTED;
      return {
        ...resource,
        data: {
          ...resource.data,
          status: computedStatus,
          statusENUS: computedStatus,
        },
        room: {
          ...resource.room,
          _occurrenceList: [...newOccurrencesList, ...occurrenceExceptions],
          _availCount: newOccurrencesList.length,
          _maxOccurrenceCount: [...newOccurrencesList, ...occurrenceExceptions]
            .length,
        },
        exceptions: [...newOccurrencesList, ...occurrenceExceptions]
          .filter((occurrence) => !occurrence.isAvailable)
          .map((occurrence) => {
            return {
              start: occurrence.start,
              end: occurrence.end,
              room: null,
            };
          }),
      };
    });
    await dispatch(setResources(adjustedResources));
  }
}

export function updateTimeStepTempDateAndTime(dateAndTime) {
  return async (dispatch) => {
    if (
      dateAndTime.recurrence &&
      dateAndTime.recurrence.type === RecurrenceConstants.RECUR_TYPE_VALUES.NONE
    ) {
      dateAndTime.recurrence = null;
    }
    dispatch(
      updateMeetingTimeStepTempData({
        ...dateAndTime,
      })
    );
  };
}

function getSimpleViewData(dateAndTime) {
  const { startDateTime, endDateTime } = computeMomentStartAndEndDates(
    dateAndTime
  );
  const timeType = getTimeType(
    dateAndTime.timezone,
    startDateTime,
    endDateTime
  );
  const dayType = getDayType(dateAndTime.timezone, startDateTime);
  return {
    ...dateAndTime,
    recurrence: null,
    startDate: getDate(dateAndTime, dayType),
    endDate: getDate(dateAndTime, dayType),
    ...getTime(dateAndTime, timeType),
    dayType: dayType === null ? WORKSPACE_DAY.TODAY : dayType,
    timeType: timeType === null ? WORKSPACE_TIME.ALLDAY : timeType,
  };
}

function getDate(dateAndTime, dayType) {
  const today = moment(
    getCurrentDateTime(dateAndTime.timezone).format("YYYY-MM-DD")
  ).toDate();
  return dayType === null ? today : dateAndTime.startDate;
}

function getTime(dateAndTime, timeType) {
  const { startTime, endTime, startTimePeriod, endTimePeriod } = dateAndTime;
  return timeType === null
    ? getTimeAsAllDay()
    : { startTime, endTime, startTimePeriod, endTimePeriod };
}

export function updateDateTimeViewMode(dateAndTime, dateTimeViewMode) {
  return async (dispatch) => {
    let dateAndTimeNew = dateAndTime;
    if (dateTimeViewMode === DateTimeViewMode.SIMPLE)
      dateAndTimeNew = getSimpleViewData(dateAndTime);
    dispatch(
      updateMeetingTimeStepTempData({ ...dateAndTimeNew, dateTimeViewMode })
    );
  };
}

export function resetTimeStepTempDateAndTime() {
  return async (dispatch, getState) => {
    const state = getState();
    const dateAndTime = ReservationSelectors.dateAndTimeSelector(state);
    const reservationType = ReservationSelectors.reservationTypeSelector(state);
    let dateTimeViewMode;
    let dateAndTimeNew = dateAndTime;
    let dayType = null;
    let timeType = null;
    if (reservationType === ReservationTypes.MEETING) {
      dispatch(updateTimeStepTempDateAndTime(dateAndTime));
    } else {
      if (needAdvancedView(dateAndTime))
        dateTimeViewMode = DateTimeViewMode.ADVANCED;
      else {
        dateTimeViewMode = DateTimeViewMode.SIMPLE;
        const { startDateTime, endDateTime } = computeMomentStartAndEndDates(
          dateAndTime
        );
        dayType = getDayType(dateAndTime.timezone, startDateTime);
        timeType = getTimeType(
          dateAndTime.timezone,
          startDateTime,
          endDateTime
        );
      }
      dateAndTimeNew = {
        ...dateAndTime,
        dateTimeViewMode,
        dayType,
        timeType,
      };
      dispatch(
        updateTimeStepTempDateAndTime({
          ...dateAndTimeNew,
        })
      );
    }
  };
}

function clearReservation() {
  return {
    type: reservationActionTypes.CLEAR_RESERVATION,
  };
}

export function clearSavedReservation() {
  return {
    type: reservationActionTypes.CLEAR_SAVED_RESERVATION,
  };
}

export function setSavedReservationLoadedFlag(value) {
  return {
    type: reservationActionTypes.SET_SAVED_RESERVATION_LOADED,
    value,
  };
}

export function renewHold() {
  return async (dispatch, getState) => {
    const rooms = ReservationSelectors.roomsSelector(getState());
    await dispatch(holdRooms(rooms));
  };
}

export function holdRooms(rooms, isDateTimeRecurChanged = false) {
  return async (dispatch, getState) => {
    try {
      dispatch(setLoading("holdRooms", true));
      const roomsToHold = computeRoomsToHold(dispatch, getState, rooms);
      const selectedExceptions = ReservationSelectors.selectedResourceExceptionsSelector(
        getState()
      );
      const isReservationSeriesWithExceptionData = ReservationSelectors.isReservationSeriesWithExceptionDataSelector(
        getState()
      );
      const exceptions = ReservationSelectors.allHoldExceptionsSelector(
        getState()
      );
      const isUpdate = !ReservationSelectors.isCreateSelector(getState());
      const recurrence = ReservationSelectors.recurrenceSelector(getState());
      const reservationParams = ReservationSelectors.reservationParamsSelector(
        getState()
      );
      const holdResult = await ReservationDS.holdRooms(
        !isReservationSeriesWithExceptionData.isReservationSeriesWithException
          ? reservationParams
          : {
              ...reservationParams,
              eventStart: null,
              eventEnd: null,
              editMode: null,
            },
        roomsToHold.map((room) => ({
          spaceId: room._id,
          layoutTypeInternal: room.layoutTypeInternal,
          resourceId: room.resourceId,
        })),
        isReservationSeriesWithExceptionData.isReservationSeriesWithException
          ? null
          : ReservationSelectors.reservationIdSelector(getState()),
        ReservationSelectors.removedResourcesSelector(getState()),
        exceptions
      );
      dispatch(updateHoldTimeEnd(holdResult.result.holdTimeEnd));
      const stateResources = ReservationSelectors.resourcesSelector(getState());
      const resources = addRoomDetailsToResourcesOnHold(
        holdResult.resources,
        roomsToHold,
        selectedExceptions,
        stateResources,
        recurrence,
        isUpdate ? rooms : [],
        isDateTimeRecurChanged
      );
      if (
        isReservationSeriesWithExceptionData.isReservationSeriesWithException
      ) {
        stateResources.forEach((resource) => {
          if (!resource.reserved) {
            dispatch(removeResourceSeriesException(resource.data._id));
          }
        });
      }
      dispatch(setResourcesOnHold(resources));
      if (!holdResult.result.success) {
        dispatch(MessageActions.showHoldRoomError(holdResult.result.error));
      }

      return holdResult.result.success;
    } finally {
      dispatch(setLoading("holdRooms", false));
    }
  };
}

function computeRoomsToHold(dispatch, getState, rooms) {
  const reservedResources = ReservationSelectors.reservedResourcesSelector(
    getState()
  );
  const isReservationSeriesWithExceptionData = ReservationSelectors.isReservationSeriesWithExceptionDataSelector(
    getState()
  );
  reservedResources.forEach((resource) => {
    if (
      !resource.removed &&
      !rooms.some((room) => room._id === resource.room._id)
    ) {
      dispatch(removeResource(resource.data._id));
    }
  });
  const roomsToHold = [];
  rooms.forEach((room) => {
    const resource = reservedResources.find(
      (resource) => room._id === resource.room._id
    );
    if (
      resource == null ||
      isReservationSeriesWithExceptionData?.isReservationSeriesWithException
    ) {
      roomsToHold.push(room);
    } else if (resource.removed) {
      dispatch(undoRemoveResource(resource.data._id));
    }
  });
  return roomsToHold;
}

export function removeRoom(resource) {
  return async (dispatch, getState) => {
    try {
      dispatch(setLoading("removeRoom", true));
      if (resource.onHold) {
        await ReservationDS.unholdRoom(resource);
      }
      dispatch(removeResource(resource.data._id));
      const hasResourcesOnHold = ReservationSelectors.hasResourcesOnHoldSelector(
        getState()
      );
      if (!hasResourcesOnHold) {
        dispatch(updateHoldTimeEnd(null));
      }
    } finally {
      dispatch(setLoading("removeRoom", false));
    }
  };
}

function addRoomDetailsToResourcesOnHold(
  resources,
  rooms,
  exceptions,
  stateResources,
  recurrence,
  heldRooms,
  isDateTimeRecurChanged
) {
  const resourcesNew = [];
  let holdRoomId = null;
  if (exceptions.length > 0) [{ holdRoomId }] = exceptions;
  if (!isEmpty(resources)) {
    resources.forEach((resource) => {
      const matchedRoom =
        rooms.find((room) => room._id === resource.roomId) ||
        heldRooms.find((room) => room._id === resource.roomId);
      const stateExceptions = stateResources.find(
        (r) => r.room._id === resource.roomId
      );
      const updatedStatus =
        recurrence && matchedRoom && matchedRoom._occurrenceList
          ? matchedRoom._occurrenceList?.some((o) => o.isAvailable)
            ? Status.ACCEPTED
            : Status.DECLINED
          : resource.status;
      const updatedStatusENUS =
        recurrence && matchedRoom && matchedRoom._occurrenceList
          ? matchedRoom._occurrenceList?.some((o) => o.isAvailable)
            ? Status.ACCEPTED
            : Status.DECLINED
          : resource.statusENUS;
      const newExceptions = getComputedExceptions(
        exceptions,
        stateExceptions,
        resource,
        matchedRoom,
        holdRoomId,
        isDateTimeRecurChanged
      );
      const resourceNew = {
        data: {
          ...resource,
          status: updatedStatus,
          statusENUS: updatedStatusENUS,
        },
        room: matchedRoom,
        exceptions: newExceptions,
      };
      resourcesNew.push(resourceNew);
    });
  }
  return resourcesNew;
}

function getComputedExceptions(
  exceptions,
  stateExceptions,
  resource,
  matchedRoom,
  holdRoomId,
  isDateTimeRecurChanged
) {
  if (exceptions.length) {
    return holdRoomId === resource.roomId
      ? [...(exceptions || [])]
      : stateExceptions && stateExceptions.exceptions;
  } else {
    if (
      matchedRoom &&
      matchedRoom._occurrenceList?.every((o) => o.isAvailable)
    ) {
      return [];
    } else if (
      matchedRoom &&
      matchedRoom._occurrenceList?.some((o) => o.isAvailable) &&
      (!stateExceptions ||
        isEmpty(stateExceptions.exceptions) ||
        isDateTimeRecurChanged)
    ) {
      return matchedRoom._occurrenceList
        .map((o) => ({ ...o, room: null }))
        .filter((o) => !o.isAvailable);
    } else if (
      matchedRoom &&
      matchedRoom._occurrenceList?.every((o) => !o.isAvailable)
    ) {
      return null;
    } else {
      return stateExceptions && stateExceptions.exceptions;
    }
  }
}
function saveReservationInStore(value) {
  return {
    type: reservationActionTypes.SAVE_RESERVATION_IN_STORE,
    value,
  };
}

export function submitReservation() {
  return async (dispatch, getState) => {
    dispatch(
      saveReservationInStore(
        ReservationSelectors.savedReservationSelector(getState())
      )
    );
    const isCreate = ReservationSelectors.isCreateSelector(getState());
    if (isCreate) {
      return dispatch(createReservation());
    } else {
      return dispatch(updateReservation());
    }
  };
}

function createReservation() {
  return async (dispatch, getState) => {
    let isExchangeIntegrated = false;
    let exchangeEvent = null;
    let generateOnlineMeeting = false; //CISA
    let teamsMeeting = null; //CISA
    try {
      dispatch(setLoading("createReservation", true));
      // CISA
      generateOnlineMeeting = ReservationSelectors.generateOnlineMeetingSelector(
        getState()
      );
      let reservationParams = ReservationSelectors.reservationParamsSelector(
        getState()
      );      
      isExchangeIntegrated = ApplicationSettingsSelectors.isExchangeIntegratedSelector(
        getState()
      );
      if (
        reservationParams.reservationType === ReservationTypes.MEETING &&
        isExchangeIntegrated
      ) {
        if(generateOnlineMeeting){
          const startDateTimeAndEndDateTime = ReservationSelectors.startAndEndDateSelector(getState());
          const startDateTime = startDateTimeAndEndDateTime.startDate;
          const endDateTime = startDateTimeAndEndDateTime.endDate;

          teamsMeeting = await dispatch(ExchangeActions.createTeamsMeeting(
            startDateTime,
            endDateTime,
            reservationParams.subject
            ));
          await dispatch(OnlineMeetingActions.createTririgaTeamsMeeting(teamsMeeting));
        }
      }
      const resources = ReservationSelectors.newResourcesSelector(getState());
      const onlineMeeting = ReservationSelectors.exchangeLocationSelector(
        getState()
      );
      const additionalLocationInfo = ReservationSelectors.additionalLocationInfoSelector(
        getState()
      );
     
      const timezone = ReservationSelectors.timezoneSelector(getState());
      const attendees = ReservationSelectors.attendeesSelector(getState());

      const selectedEquipment = ReservationSelectors.allSelectedEquipmentSelector(
        getState()
      );
      const { foodItems, foodOrders } = ReservationSelectors.foodOrdersSelector(
        getState()
      );
      const costSummaryAccountCodes = ReservationSelectors.costSummaryAccountCodesSelector(
        getState()
      );

      const { email: requestedForEmail, id: calendarId } =
        ExchangeSelectors.currentCalendarSelector(getState()) || {};

      if (
        reservationParams.reservationType === ReservationTypes.MEETING &&
        isExchangeIntegrated
      ) {
        const recurrence = RecurrenceSelectors.exchangeRecurrenceParams(
          getState()
        );
        exchangeEvent = await dispatch(
          ExchangeActions.createEvent(
            { ...reservationParams, timezone, recurrence },
            null,
            null,
            null,
            calendarId
          )
        );
        reservationParams = {
          ...reservationParams,
          iCalUId: exchangeEvent.iCalUId,
          requestedForEmail,
        };
        await dispatch(
          ExchangeActions.updateEventAttendees(
            exchangeEvent.id,
            attendees,
            resources
          )
        );

        await dispatch(
          ExchangeActions.updateEvent(
            exchangeEvent.id,
            { ...reservationParams, timezone, recurrence },
            attendees,
            resources,
            onlineMeeting,
            additionalLocationInfo,
            calendarId
          )
        );
        

        if (resources.length === 0) {
          dispatch(
            MessageActions.showCreateReservationSuccess(
              reservationParams.reservationType
            )
          );
          dispatch(clearReservation());
          dispatch(MyCalendarActions.refreshMyCalendar());
          return -1;
        }
      }
      reservationParams = {
        ...reservationParams,
        accountCodeRoom: defaultTo(costSummaryAccountCodes.accountCodeRoom, ""),
        accountCodeFood: defaultTo(costSummaryAccountCodes.accountCodeFood, ""),
        accountCodeEquipment: defaultTo(
          costSummaryAccountCodes.accountCodeEquipment,
          ""
        ),
      };
      const foodItemsToAdd = foodItems.filter(
        (d) => d.actionType === cateringActionType.ADD
      );
      const reservation = await ReservationDS.createNewReservation(
        reservationParams,
        resources,
        attendees,
        foodOrders,
        foodItemsToAdd,
        selectedEquipment,
        onlineMeeting
      );
/*
      if (meetingSpaceWithExchange) {
        await dispatch(
          ExchangeActions.updateEvent(
            exchangeEvent.id,
            { ...reservationParams, timezone, recurrence },
            attendees,
            resources,
            onlineMeeting,
            additionalLocationInfo,
            calendarId
          )
        );
      }
*/
      if (
        reservation &&
        reservation._id &&
        (reservation.status === Status.ACTIVE ||
          reservation.status === Status.PROCESSING)
      ) {
        if (reservation.status === Status.PROCESSING) {
          await waitUntilStatusActive(reservation);
        }
        const allResolvedExceptions = ReservationSelectors.allResolvedExceptionsSelector(
          getState()
        );
        if (
          isExchangeIntegrated &&
          ReservationSelectors.recurrenceSelector(getState()) &&
          !isEmpty(allResolvedExceptions) &&
          reservationParams.reservationType === ReservationTypes.MEETING
        ) {
          await updateExchangeExceptionEvents(
            dispatch,
            getState,
            isExchangeIntegrated,
            timezone,
            exchangeEvent,
            reservationParams,
            attendees,
            onlineMeeting,
            additionalLocationInfo
          );
        }
        dispatch(
          MessageActions.showCreateReservationSuccess(
            reservationParams.reservationType
          )
        );
        dispatch(MyCalendarActions.refreshMyCalendar());
        return reservation;
      } else {
      throw new Error("Create new Reservation Failed.");
      }
    } catch (e) {
      dispatch(MessageActions.showCreateReservationError(e.message));
      if (isExchangeIntegrated && exchangeEvent != null) {
        // CISA
        if(generateOnlineMeeting){
          await dispatch(ExchangeActions.deleteTeamsMeeting(teamsMeeting.id));
        }
        await dispatch(ExchangeActions.deleteEvent(exchangeEvent.id));
      }
      return null;
    } finally {
      dispatch(setLoading("createReservation", false));
    }
  };
}
/*
async function createExchangeOnlyEvent(
  reservationParams,
  resources,
  attendees,
  additionalLocationInfo,
  onlineMeeting,
  calendarId,
  dispatch
) {
  const exchangeEvent = await dispatch(
    ExchangeActions.createEvent(
      reservationParams,
      resources,
      additionalLocationInfo,
      onlineMeeting,
      calendarId
    )
  );

  await dispatch(
    ExchangeActions.updateEventAttendees(exchangeEvent.id, attendees, [])
  );

  dispatch(
    MessageActions.showCreateReservationSuccess(
      reservationParams.reservationType
    )
  );
  dispatch(clearReservation());
  dispatch(MyCalendarActions.refreshMyCalendar());
  return -1;
}
*/
// This is not an ideal solution until we figure out an enhancement or a custom task to handle async workflow process
let attempt = 20;
const WAIT_TIME = 5000;
async function waitUntilStatusActive(reservation) {
  if (reservation.status === Status.PROCESSING) {
    await new Promise((resolve) =>
      setTimeout(() => {
        resolve("done");
      }, WAIT_TIME)
    );
    const fetchedReservation = await ReservationDS.getReservation(
      reservation._id
    );
    if (
      (!fetchedReservation.statusENUS ||
        fetchedReservation.statusENUS === Status.PROCESSING) &&
      attempt > 0
    ) {
      attempt--;
      return waitUntilStatusActive(fetchedReservation);
    } else if (fetchedReservation.statusENUS === Status.ACTIVE) {
      return fetchedReservation;
    } else {
      throw new Error("Unable to retrieve data");
    }
  }
}

async function updateExchangeExceptionEvents(
  dispatch,
  getState,
  isExchangeIntegrated,
  timezone,
  exchangeEvent,
  reservationParams,
  attendees,
  onlineMeeting,
  additionalLocationInfo
) {
  const {
    details: { startDate, endDate },
  } = ReservationSelectors.recurrenceSelector(getState());
  const accessToken = await dispatch(ExchangeActions.getAzureAccessToken());
  const iCalUId = isEmpty(exchangeEvent.iCalUId)
    ? exchangeEvent
    : exchangeEvent.iCalUId;
  const currentCalendar = ExchangeSelectors.currentCalendarSelector(getState());
  try {
    const createdExchangeEvents = (
      await Exchange.getUserCalendarView(
        accessToken,
        currentCalendar,
        startDate,
        endDate,
        timezone
      )
    ).filter(
      (event) => event.iCalUId === iCalUId || event.seriesICalUId === iCalUId
    );
    const exceptionStarts = ReservationSelectors.resolvedExceptionsStartDatesSelector(
      getState()
    );
    const toBeUpdatedEvents = createdExchangeEvents.filter((event) =>
      exceptionStarts.has(moment.tz(event.start, timezone).format("MM/DD/YYYY"))
    );

    for (const event of toBeUpdatedEvents) {
      const eventStartDate = moment
        .tz(event.start, timezone)
        .format("MM/DD/YYYY");
      if (
        event.id &&
        reservationParams.reservationType === ReservationTypes.MEETING &&
        isExchangeIntegrated
      ) {
        const recurrence = RecurrenceSelectors.exchangeRecurrenceParams(
          getState()
        );

        const resolvedExceptionResources =
          ReservationSelectors.allResolvedResourcesGroupStartDateSelector(
            getState()
          )[eventStartDate]?.map((r) => r.resource) || [];

        const excludedExceptionResources = ReservationSelectors.resourcesSelector(
          getState()
        ).filter(
          (r) => !r.exceptions?.some((e) => e.startDate === eventStartDate)
        );

        const allResolvedResources = [
          ...excludedExceptionResources,
          ...resolvedExceptionResources,
        ];

        await dispatch(
          ExchangeActions.updateEvent(
            event.id,
            {
              ...reservationParams,
              start: event.start,
              end: setEventEndDate(event.isAllDay, event.end, timezone),
              timezone,
              recurrence,
            },
            attendees,
            allResolvedResources,
            onlineMeeting,
            additionalLocationInfo
          )
        );
      }
    }
  } catch (error) {
    throw new Error(error);
  }
}

function updateReservation() {
  return async (dispatch, getState) => {
    let isExchangeIntegrated = false;
    // CISA
    let generateOnlineMeeting = false;
    let teamsMeeting = null;
    let onlineMeeting = null;
    try {
      dispatch(setLoading("updateReservation", true));
      // CISA
      generateOnlineMeeting = ReservationSelectors.generateOnlineMeetingSelector(
        getState()
      );

      let reservationParams = ReservationSelectors.reservationParamsSelector(
        getState()
      );
      // CISA
      isExchangeIntegrated = ApplicationSettingsSelectors.isExchangeIntegratedSelector(
        getState()
      );

      onlineMeeting = ReservationSelectors.exchangeLocationSelector(
        getState()
      );
      //Add teams meeting is toggled yes, and online meeting is null
      if (
        reservationParams.reservationType === ReservationTypes.MEETING &&
        isExchangeIntegrated && onlineMeeting == null
      ) {
        if(generateOnlineMeeting){
          const startDateTimeAndEndDateTime = ReservationSelectors.startAndEndDateSelector(getState());
          const startDateTime = startDateTimeAndEndDateTime.startDate;
          const endDateTime = startDateTimeAndEndDateTime.endDate;

          teamsMeeting = await dispatch(ExchangeActions.createTeamsMeeting(
            startDateTime,
            endDateTime,
            reservationParams.subject
            ));
          await dispatch(OnlineMeetingActions.createTririgaTeamsMeeting(teamsMeeting));
        }
      }
      //Remove teams meeting if toggle no, and online meeting exists
      if (
        reservationParams.reservationType === ReservationTypes.MEETING &&
        isExchangeIntegrated && onlineMeeting != null
      ) {
        if(generateOnlineMeeting === false){
          if(onlineMeeting.teamsMeetingId){
            await dispatch(ExchangeActions.deleteTeamsMeeting(onlineMeeting.teamsMeetingId));
            await dispatch(OnlineMeetingActions.deleteOnlineMeeting(onlineMeeting._id));
          }
        }
      }
      const reservationId = ReservationSelectors.reservationIdSelector(
        getState()
      );
      const { foodOrders, foodItems } = ReservationSelectors.foodOrdersSelector(
        getState()
      );
      onlineMeeting = ReservationSelectors.exchangeLocationSelector(
        getState()
      );
      const attendees = ReservationSelectors.attendeesSelector(getState());
      let updatedReservation = null;
      const selectedEquipment = ReservationSelectors.allSelectedEquipmentSelector(
        getState()
      );
      const additionalLocationInfo = ReservationSelectors.additionalLocationInfoSelector(
        getState()
      );
      isExchangeIntegrated = ApplicationSettingsSelectors.isExchangeIntegratedSelector(
        getState()
      );
      const eventiCalUid = ReservationSelectors.iCalUIdSelector(getState());
      const isReservationSeriesWithExceptionDataSelector = ReservationSelectors.isReservationSeriesWithExceptionDataSelector(
        getState()
      );
      let exchangeEventId = ReservationSelectors.exchangeEventIdSelector(
        getState()
      );
      const recurrence = RecurrenceSelectors.exchangeRecurrenceParams(
        getState()
      );
      const timezone = ReservationSelectors.timezoneSelector(getState());
      const isReservationExchangeOnly = ReservationSelectors.isReservationExchangeOnlySelector(
        getState()
      );
      const resources = ReservationUtils.getAvailableResources(
        ReservationSelectors.resourcesSelector(getState())
      );
      const costSummaryAccountCodes = ReservationSelectors.costSummaryAccountCodesSelector(
        getState()
      );
      let exchangeEvent = null;
      const { email: requestedForEmail, id: calendarId } =
        ExchangeSelectors.currentCalendarSelector(getState()) || {};
      reservationParams = {
        ...reservationParams,
        requestedForEmail,
      };

      if (
        isEmpty(exchangeEventId) &&
        reservationParams.reservationType === ReservationTypes.MEETING &&
        isExchangeIntegrated
      ) {
        exchangeEvent = await createExchangeReservationForRoomOnlyReservation(
          dispatch,
          getState(),
          reservationParams,
          timezone,
          recurrence,
          additionalLocationInfo,
          onlineMeeting,
          calendarId
        );
        reservationParams = {
          ...reservationParams,
          iCalUId: exchangeEvent.iCalUId,
        };
        exchangeEventId = exchangeEvent.id;
        const isSyncingWithOutlook = SyncWithOutlookSelectors.isSyncingSelector(
          getState()
        );
        if (isSyncingWithOutlook) {
          dispatch(SyncWithOutlookActions.setICalUId(exchangeEvent.iCalUId));
        }
      }

      reservationParams = {
        ...reservationParams,
        accountCodeRoom: defaultTo(costSummaryAccountCodes.accountCodeRoom, ""),
        accountCodeFood: defaultTo(costSummaryAccountCodes.accountCodeFood, ""),
        accountCodeEquipment: defaultTo(
          costSummaryAccountCodes.accountCodeEquipment,
          ""
        ),
      };

      if (!reservationId && isReservationExchangeOnly) {
        updatedReservation = await updateExchangeOnlyEventWithResource(
          dispatch,
          exchangeEventId,
          reservationParams,
          timezone,
          recurrence,
          attendees,
          onlineMeeting,
          additionalLocationInfo,
          resources,
          reservationId,
          calendarId,
          getState,
          foodOrders,
          foodItems,
          selectedEquipment
        );
      }

      if (reservationId != null) {
        if (isExchangeIntegrated && isEmpty(resources)) {
          updatedReservation = await updateExchangeEventByRemovingResources(
            dispatch,
            exchangeEventId,
            reservationParams,
            timezone,
            recurrence,
            attendees,
            onlineMeeting,
            additionalLocationInfo,
            resources,
            reservationId,
            isReservationSeriesWithExceptionDataSelector,
            calendarId,
            getState
          );
        } else if (
          isReservationSeriesWithExceptionDataSelector.isReservationSeriesWithException &&
          !isEmpty(ReservationSelectors.allExceptionsSelector(getState()))
        ) {
          updatedReservation = await updateSeriesReservationWithException(
            dispatch,
            getState,
            reservationParams,
            reservationId,
            isReservationSeriesWithExceptionDataSelector,
            eventiCalUid,
            isExchangeIntegrated,
            recurrence,
            timezone,
            additionalLocationInfo,
            onlineMeeting,
            attendees,
            foodOrders,
            foodItems,
            selectedEquipment,
            exchangeEvent,
            calendarId,
            resources
          );
        } else {
          updatedReservation = await updateReservationWithoutException(
            dispatch,
            getState,
            reservationParams,
            reservationId,
            isExchangeIntegrated,
            recurrence,
            timezone,
            additionalLocationInfo,
            onlineMeeting,
            attendees,
            foodOrders,
            foodItems,
            selectedEquipment,
            exchangeEventId,
            calendarId,
            resources
          );
        }
      }

      if (
        !isReservationExchangeOnly &&
        !reservationId &&
        updatedReservation.status === Status.PROCESSING
      ) {
        await waitUntilStatusActive(updatedReservation);
      }

      dispatch(
        MessageActions.showUpdateReservationSuccess(
          reservationParams.reservationType
        )
      );
      dispatch(clearReservation());
      dispatch(MyCalendarActions.refreshMyCalendar());
      return updatedReservation;
    } catch (e) {
      dispatch(MessageActions.showUpdateReservationError());
    } finally {
      dispatch(setLoading("updateReservation", false));
    }
  };
}

async function createExchangeReservationForRoomOnlyReservation(
  dispatch,
  state,
  reservationParams,
  timezone,
  recurrence,
  additionalLocationInfo,
  onlineMeeting,
  calendarId
) {
  return await dispatch(
    ExchangeActions.createEvent(
      { ...reservationParams, timezone, recurrence },
      ReservationSelectors.resourcesSelector(state),
      additionalLocationInfo,
      onlineMeeting,
      calendarId
    )
  );
}

async function updateSeriesReservationWithException(
  dispatch,
  getState,
  reservationParams,
  reservationId,
  isReservationSeriesWithExceptionDataSelector,
  eventiCalUid,
  isExchangeIntegrated,
  recurrence,
  timezone,
  additionalLocationInfo,
  onlineMeeting,
  attendees,
  foodOrders,
  foodItems,
  selectedEquipment,
  exchangeEvent,
  calendarId,
  resources
) {
  const reservationDeleteParam = {
    start: reservationParams.eventStart,
    end: reservationParams.eventEnd,
    reservationEditMode: SERIES_EXCEPTION,
  };
  if (reservationId) {
    await ReservationDS.deleteReservation(
      isReservationSeriesWithExceptionDataSelector.seriesReservationId,
      reservationDeleteParam
    );
  }
  if (eventiCalUid && isExchangeIntegrated) {
    await dispatch(
      ExchangeActions.deleteEvent(
        isReservationSeriesWithExceptionDataSelector.seriesMasterId
      )
    );
  }
  if (
    reservationParams.reservationType === ReservationTypes.MEETING &&
    isExchangeIntegrated
  ) {
    exchangeEvent = await dispatch(
      ExchangeActions.createEvent(
        { ...reservationParams, timezone, recurrence },
        resources,
        additionalLocationInfo,
        onlineMeeting,
        calendarId
      )
    );
    reservationParams = {
      ...reservationParams,
      iCalUId: exchangeEvent.iCalUId,
      eventStart: null,
      eventEnd: null,
      editMode: null,
    };

    await dispatch(
      ExchangeActions.updateEvent(
        exchangeEvent.id,
        { ...reservationParams, timezone, recurrence },
        attendees,
        resources,
        onlineMeeting,
        additionalLocationInfo,
        calendarId
      )
    );
  }

  const updatedReservation = await ReservationDS.createNewReservation(
    reservationParams,
    resources.map((room) => ({ ...room, reserved: false })),
    attendees,
    foodOrders,
    foodItems,
    selectedEquipment,
    onlineMeeting
  );
  const allResolvedExceptions = ReservationSelectors.allResolvedExceptionsSelector(
    getState()
  );
  if (
    isExchangeIntegrated &&
    !isEmpty(allResolvedExceptions) &&
    ReservationSelectors.recurrenceSelector(getState()) &&
    reservationParams.reservationType === ReservationTypes.MEETING
  ) {
    await updateExchangeExceptionEvents(
      dispatch,
      getState,
      isExchangeIntegrated,
      timezone,
      isReservationSeriesWithExceptionDataSelector.isReservationSeriesWithException
        ? exchangeEvent
        : eventiCalUid,
      reservationParams,
      attendees,
      onlineMeeting,
      additionalLocationInfo
    );
  }

  return updatedReservation;
}

async function updateReservationWithoutException(
  dispatch,
  getState,
  reservationParams,
  reservationId,
  isExchangeIntegrated,
  recurrence,
  timezone,
  additionalLocationInfo,
  onlineMeeting,
  attendees,
  foodOrders,
  foodItems,
  selectedEquipment,
  exchangeEventId,
  calendarId,
  resources
) {
  const updatedReservation = await ReservationDS.updateReservation(
    reservationParams,
    ReservationSelectors.newResourcesSelector(getState()),
    ReservationSelectors.removedResourcesSelector(getState()),
    attendees,
    foodOrders,
    foodItems,
    reservationId,
    onlineMeeting,
    selectedEquipment
  );
  if (
    reservationParams.reservationType === ReservationTypes.MEETING &&
    isExchangeIntegrated
  ) {
    await dispatch(
      ExchangeActions.updateEvent(
        exchangeEventId,
        { ...reservationParams, timezone, recurrence },
        attendees,
        resources,
        onlineMeeting,
        additionalLocationInfo,
        calendarId
      )
    );
  }
  return updatedReservation;
}

async function updateExchangeEventByRemovingResources(
  dispatch,
  exchangeEventId,
  reservationParams,
  timezone,
  recurrence,
  attendees,
  onlineMeeting,
  additionalLocationInfo,
  resources,
  reservationId,
  isReservationSeriesWithExceptionDataSelector,
  calendarId,
  getState
) {
  const isRecurringException =
    isReservationSeriesWithExceptionDataSelector.isReservationSeriesWithException;
  const reservationDeleteParam = {
    start: reservationParams.eventStart,
    end: reservationParams.eventEnd,
    reservationEditMode: isRecurringException
      ? SERIES_EXCEPTION
      : reservationParams.editMode,
  };
  await ReservationDS.deleteReservation(
    isRecurringException
      ? isReservationSeriesWithExceptionDataSelector.seriesReservationId
      : reservationId,
    reservationDeleteParam
  );
  return await updateExchangeOnlyEvent(
    dispatch,
    exchangeEventId,
    reservationParams,
    timezone,
    recurrence,
    attendees,
    onlineMeeting,
    additionalLocationInfo,
    resources,
    reservationId,
    calendarId,
    getState
  );
}

async function updateExchangeOnlyEventWithResource(
  dispatch,
  exchangeEventId,
  reservationParams,
  timezone,
  recurrence,
  attendees,
  onlineMeeting,
  additionalLocationInfo,
  resources,
  reservationId,
  calendarId,
  getState,
  foodOrders,
  foodItems,
  selectedEquipment
) {
  const allResolvedExceptions = ReservationSelectors.allResolvedExceptionsSelector(
    getState()
  );
  if (isEmpty(allResolvedExceptions)) {
    let reservation = null;
    const isResourceAvailable = !isEmpty(
      ReservationSelectors.newResourcesSelector(getState())
    );
    if (isResourceAvailable) {
      reservation = await createReservationForExchangeOnlyEvent(
        reservationParams,
        attendees,
        foodOrders,
        foodItems,
        selectedEquipment,
        onlineMeeting,
        getState
      );

      await updateExchangeOnlyEvent(
        dispatch,
        exchangeEventId,
        reservationParams,
        timezone,
        recurrence,
        attendees,
        onlineMeeting,
        additionalLocationInfo,
        resources,
        reservationId,
        calendarId
      );
    } else {
      reservation = await updateExchangeOnlyEvent(
        dispatch,
        exchangeEventId,
        reservationParams,
        timezone,
        recurrence,
        attendees,
        onlineMeeting,
        additionalLocationInfo,
        resources,
        reservationId,
        calendarId
      );
    }

    return reservation;
  } else {
    return await updateExceptionEvents(
      dispatch,
      reservationParams,
      timezone,
      attendees,
      onlineMeeting,
      additionalLocationInfo,
      resources,
      getState,
      exchangeEventId,
      recurrence,
      calendarId
    );
  }
}

async function updateExchangeOnlyEvent(
  dispatch,
  exchangeEventId,
  reservationParams,
  timezone,
  recurrence,
  attendees,
  onlineMeeting,
  additionalLocationInfo,
  resources,
  reservationId,
  calendarId
) {
  return await dispatch(
    ExchangeActions.updateEvent(
      exchangeEventId,
      {
        ...reservationParams,
        timezone,
        recurrence,
        reservationId,
      },
      attendees,
      resources,
      onlineMeeting,
      additionalLocationInfo,
      calendarId
    )
  );
}

async function createReservationForExchangeOnlyEvent(
  reservationParams,
  attendees,
  foodOrders,
  foodItemsToAdd,
  selectedEquipment,
  onlineMeeting,
  getState
) {
  if (reservationParams.editMode === ReservationEditMode.SERIES_OCCURRENCE) {
    // for series occurrence reservation
    const seriesICalUId = ReservationSelectors.seriesICalUIdSelector(
      getState()
    );
    let seriesId = null;
    const sameICalUIdEvent = await MyCalendarDS.getReservationSeriesByICalUID(
      seriesICalUId
    );
    seriesId = sameICalUIdEvent?.reservationId;
    if (isEmpty(seriesId)) {
      const tempReservationParams = {
        ...reservationParams,
        recurrenceRule: "RRULE:FREQ=DAILY;INTERVAL=1;COUNT=1",
        iCalUId: seriesICalUId,
        eventStart: null,
        eventEnd: null,
        editMode: "",
        description: null,
      };

      // create a empty series reservation
      const newSeriesReservation = await ReservationDS.createNewReservation(
        tempReservationParams,
        null,
        null,
        null,
        null,
        null,
        null
      );
      seriesId = newSeriesReservation._id;
    }

    return await ReservationDS.updateReservation(
      {
        ...reservationParams,
        iCalUId: seriesICalUId,
      },
      ReservationSelectors.newResourcesSelector(getState()),
      ReservationSelectors.removedResourcesSelector(getState()),
      attendees,
      foodOrders,
      foodItemsToAdd,
      seriesId,
      onlineMeeting,
      selectedEquipment
    );
  } else if (reservationParams.editMode === ReservationEditMode.SERIES) {
    // for series reservation
    let seriesId = null;
    const sameICalUIdEvent = await MyCalendarDS.getReservationSeriesByICalUID(
      reservationParams.iCalUId
    );
    seriesId = sameICalUIdEvent?.reservationId;
    if (isEmpty(seriesId)) {
      reservationParams = {
        ...reservationParams,
        eventStart: null,
        eventEnd: null,
        editMode: "",
      };

      return await ReservationDS.createNewReservation(
        reservationParams,
        ReservationSelectors.newResourcesSelector(getState()),
        attendees,
        foodOrders,
        foodItemsToAdd,
        selectedEquipment,
        onlineMeeting
      );
    } else {
      return await ReservationDS.updateReservation(
        reservationParams,
        ReservationSelectors.newResourcesSelector(getState()),
        ReservationSelectors.removedResourcesSelector(getState()),
        attendees,
        foodOrders,
        foodItemsToAdd,
        seriesId,
        onlineMeeting,
        selectedEquipment
      );
    }
  } else {
    // for single occurrence reservation
    reservationParams = {
      ...reservationParams,
      eventStart: null,
      eventEnd: null,
      editMode: "",
    };

    return await ReservationDS.createNewReservation(
      reservationParams,
      ReservationSelectors.newResourcesSelector(getState()),
      attendees,
      foodOrders,
      foodItemsToAdd,
      selectedEquipment,
      onlineMeeting
    );
  }
}

async function updateExceptionEvents(
  dispatch,
  reservationParams,
  timezone,
  attendees,
  onlineMeeting,
  additionalLocationInfo,
  resources,
  getState,
  exchangeEventId,
  recurrence,
  calendarId
) {
  const selectedEquipment = ReservationSelectors.allSelectedEquipmentSelector(
    getState()
  );
  const { foodItems, foodOrders } = ReservationSelectors.foodOrdersSelector(
    getState()
  );

  const sameICalUIdEvent = await MyCalendarDS.getReservationSeriesByICalUID(
    reservationParams.iCalUId
  );
  const seriesId = sameICalUIdEvent?.reservationId;

  if (seriesId) {
    ReservationDS.deleteReservation(seriesId, null);
  }

  await dispatch(ExchangeActions.deleteEvent(exchangeEventId));

  const exchangeEvent = await dispatch(
    ExchangeActions.createEvent(
      { ...reservationParams, timezone, recurrence },
      resources,
      additionalLocationInfo,
      onlineMeeting,
      calendarId
    )
  );
  reservationParams = {
    ...reservationParams,
    iCalUId: exchangeEvent.iCalUId,
    eventStart: null,
    eventEnd: null,
    editMode: null,
  };

  await dispatch(
    ExchangeActions.updateEvent(
      exchangeEvent.id,
      { ...reservationParams, timezone, recurrence },
      attendees,
      resources,
      onlineMeeting,
      additionalLocationInfo,
      calendarId
    )
  );

  const updatedExceptionEvent = await ReservationDS.createNewReservation(
    reservationParams,
    resources.map((room) => ({ ...room, reserved: false })),
    attendees,
    foodOrders,
    foodItems,
    selectedEquipment,
    onlineMeeting
  );
  await updateExchangeExceptionEvents(
    dispatch,
    getState,
    true,
    timezone,
    exchangeEvent.iCalUId,
    reservationParams,
    attendees,
    onlineMeeting,
    additionalLocationInfo
  );
  return updatedExceptionEvent;
}

export function loadTempTimeStepData() {
  return {
    type: reservationActionTypes.LOAD_TEMP_TIME_STEP_DATA,
  };
}

function setTimeStepTempRecurrenceDetails(recurrenceDetails) {
  recurrenceDetails.ruleLabel =
    AppMsg.getMessage(AppMsg.RECURRENCE.REPEATS) +
    " " +
    recurrenceDetails.ruleLabel;
  const details = { ...recurrenceDetails };
  return {
    type: reservationActionTypes.SET_TEMP_RECURRENCE_DETAILS,
    details,
  };
}

export function getTimeStepTempRecurrenceDetails() {
  return async (dispatch, getState) => {
    try {
      const recurrence = ReservationSelectors.timeStepTempRecurrenceSelector(
        getState()
      );
      if (isEmpty(recurrence)) return;
      dispatch(setLoading("getTimeStepTempRecurrenceDetails", true));
      const recurrenceParams = RecurrenceSelectors.timeStepTempRecurrenceParamsSelector(
        getState()
      );
      const recurrenceDetailsResult = await ReservationDS.processRecurrence(
        recurrenceParams
      );

      if (recurrenceDetailsResult.result.success) {
        dispatch(
          setTimeStepTempRecurrenceDetails(recurrenceDetailsResult.result)
        );
      } else {
        dispatch(MessageActions.showGetRecurrenceDetailsError());
      }

      return recurrenceDetailsResult.result.success;
    } finally {
      dispatch(setLoading("getTimeStepTempRecurrenceDetails", false));
    }
  };
}

export function setReservationOnlineMeeting(onlineMeeting) {
  return {
    type: reservationActionTypes.SET_RESERVATION_ONLINE_MEETING,
    onlineMeeting,
  };
}
// CISA
export function setGenerateOnlineMeeting(generateOnlineMeeting) {
  return {
    type: reservationActionTypes.SET_GENERATE_ONLINE_MEETING,
    generateOnlineMeeting,
  };
}

export function setResourceOrderedCatering(orderedCatering, roomId) {
  return {
    type: reservationActionTypes.SET_RESOURCE_ORDERED_CATERING,
    orderedCatering,
    roomId,
  };
}

export function setResourceToBeUpdatedCatering(toBeUpdatedCatering, roomId) {
  return {
    type: reservationActionTypes.SET_RESOURCE_TO_BE_UPDATED_CATERING,
    toBeUpdatedCatering,
    roomId,
  };
}

export function setSelectedResource(resource) {
  return {
    type: reservationActionTypes.SET_SELECTED_RESOURCE,
    resource,
  };
}

export function setSelectedResourceException(exception) {
  return {
    type: reservationActionTypes.SET_SELECTED_EXCEPTION,
    exception,
  };
}

export function updateReservationResource(resource) {
  return {
    type: reservationActionTypes.UPDATE_RESERVATION_RESOURCE,
    resource,
  };
}

export function getOccurrenceExceptions(recurrenceParams, lookupResourceIDs) {
  return async (dispatch, getState) => {
    try {
      dispatch(setLoading("loadingOccurrenceExceptions", true));
      const occurrenceExceptions = await ReservationDS.getOccurrenceExceptions(
        recurrenceParams,
        lookupResourceIDs
      );
      return occurrenceExceptions;
    } catch (error) {
      return new Error(error);
    } finally {
      dispatch(setLoading("loadingOccurrenceExceptions", false));
    }
  };
}

export function setInitUpdatedData(data) {
  return {
    type: reservationActionTypes.SET_INIT_UPDATED_DATA,
    data,
  };
}

export function setResources(resources) {
  return {
    type: reservationActionTypes.SET_RESOURCES,
    resources,
  };
}

export function syncWithOutlook(start, end) {
  return async (dispatch, getState) => {
    try {
      let reservationParams = ReservationSelectors.reservationParamsSelector(
        getState()
      );
      const reservationId = ReservationSelectors.reservationIdSelector(
        getState()
      );
      const { foodOrders, foodItems } = ReservationSelectors.foodOrdersSelector(
        getState()
      );
      const onlineMeeting = ReservationSelectors.exchangeLocationSelector(
        getState()
      );
      const attendees = ReservationSelectors.attendeesSelector(getState());
      const selectedEquipment = ReservationSelectors.allSelectedEquipmentSelector(
        getState()
      );
      const additionalLocationInfo = ReservationSelectors.additionalLocationInfoSelector(
        getState()
      );
      const recurrence = RecurrenceSelectors.exchangeRecurrenceParams(
        getState()
      );
      const timezone = ReservationSelectors.timezoneSelector(getState());
      const resources = ReservationUtils.getAvailableResources(
        ReservationSelectors.resourcesSelector(getState())
      );
      const { email: requestedForEmail } =
        ExchangeSelectors.currentCalendarSelector(getState()) || {};
      reservationParams = {
        ...reservationParams,
        requestedForEmail,
      };

      const currentCalendar = ExchangeSelectors.currentCalendarSelector(
        getState()
      );
      const accessToken = await dispatch(ExchangeActions.getAzureAccessToken());
      const iCalUId = SyncWithOutlookSelectors.iCalUIdSelector(getState());
      const [exchangeExceptionEvent] = (
        await Exchange.getUserCalendarView(
          accessToken,
          currentCalendar,
          start,
          end,
          timezone
        )
      ).filter(
        (event) => event.iCalUId === iCalUId || event.seriesICalUId === iCalUId
      );

      const updatedReservation = await ReservationDS.updateReservation(
        {
          ...reservationParams,
          iCalUId: exchangeExceptionEvent.iCalUId,
        },
        ReservationSelectors.newResourcesSelector(getState()),
        ReservationSelectors.removedResourcesSelector(getState()),
        attendees,
        foodOrders,
        foodItems,
        reservationId,
        onlineMeeting,
        selectedEquipment
      );

      await dispatch(
        ExchangeActions.updateEvent(
          exchangeExceptionEvent.id,
          {
            ...reservationParams,
            start: exchangeExceptionEvent.start,
            end: exchangeExceptionEvent.end,
            timezone,
            recurrence,
          },
          attendees,
          resources,
          onlineMeeting,
          additionalLocationInfo
        )
      );

      if (!reservationId && updatedReservation.status === Status.PROCESSING) {
        await waitUntilStatusActive(updatedReservation);
      }
      dispatch(clearReservation());
      return updatedReservation;
    } catch (e) {
      dispatch(MessageActions.showUpdateReservationError());
    }
  };
}

export function setReservationType(reservationType) {
  return {
    type: reservationActionTypes.SET_RESERVATION_TYPE,
    reservationType,
  };
}