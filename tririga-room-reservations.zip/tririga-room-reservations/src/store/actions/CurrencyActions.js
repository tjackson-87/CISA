/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import { setLoading } from "./LoadingActions.js";
import { currencyActionTypes } from "../../utils";
import { CurrenciesDS } from "../../model";

const setCurrencies = (currencies) => {
  return {
    type: currencyActionTypes.SET_CURRENCIES,
    currencies,
  };
};

export function getCurrencies() {
  return async (dispatch, getState) => {
    let { currencies } = getState();
    if (currencies && currencies.length > 0) return currencies;
    try {
      dispatch(setLoading("currencies", true));
      currencies = await CurrenciesDS.getCurrencies();
      dispatch(setCurrencies(currencies));
    } finally {
      dispatch(setLoading("currencies", false));
    }
    return currencies;
  };
}
