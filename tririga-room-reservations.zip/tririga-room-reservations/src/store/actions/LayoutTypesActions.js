/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import { layoutTypesActionTypes } from "../../utils";
import { LayoutTypesDS } from "../../model";
import { setLoading } from "./LoadingActions";
import isEmpty from "lodash/isEmpty";
import { LayoutTypesSelectors } from "../reducers/LayoutTypesReducer";

export const initLayoutTypes = () => {
  return async (dispatch, getState) => {
    const meetingLayoutTypes = LayoutTypesSelectors.meetingLayoutTypesSelector(
      getState()
    );
    const workspaceLayoutTypes = LayoutTypesSelectors.workspaceLayoutTypesSelector(
      getState()
    );
    if (!isEmpty(meetingLayoutTypes) && !isEmpty(workspaceLayoutTypes))
      return { meeting: meetingLayoutTypes, workspace: workspaceLayoutTypes };
    let layoutTypes;
    try {
      dispatch(setLoading("layoutTypes", true));
      layoutTypes = await LayoutTypesDS.getLayoutTypes();
      dispatch(setLayoutTypes(layoutTypes));
    } finally {
      dispatch(setLoading("layoutTypes", false));
    }
    return layoutTypes;
  };
};

const setLayoutTypes = (layoutTypes) => {
  return {
    type: layoutTypesActionTypes.SET_LAYOUT_TYPES,
    layoutTypes,
  };
};
