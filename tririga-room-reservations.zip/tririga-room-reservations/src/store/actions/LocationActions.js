/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import { BuildingsDS, FloorsDS } from "../../model";
import {
  locationActionTypes,
  LocationConstants,
  REQUEST_DISCARDED,
} from "../../utils";
import {
  LocationSelectors,
  LoadingActions,
  ApplicationSettingsSelectors,
  ReservationSelectors,
} from "..";
import { isEmpty } from "lodash";
import { setLoading } from "./LoadingActions";

const LOCATION_SEARCH_QUERY_PAGE_SIZE =
  LocationConstants.LOCATION_SEARCH_QUERY_PAGE_SIZE;

export function clearSearch() {
  return {
    type: locationActionTypes.CLEAR_SEARCH_LOCATION_SEARCH,
  };
}

function setFloors(floors) {
  return {
    type: locationActionTypes.SET_FLOORS,
    floors,
  };
}

export function setSelectedBuilding(selectedBuilding) {
  return {
    type: locationActionTypes.SET_SELECTED_BUILDING,
    selectedBuilding,
  };
}

export function setPrevSelectedBuilding(prevSelectedBuilding) {
  return {
    type: locationActionTypes.SET_PREVSELECTED_BUILDING,
    prevSelectedBuilding,
  };
}

export function setLastMeetingSearchFilters(lastMeetingSearchFilters) {
  return {
    type: locationActionTypes.SET_LAST_SEARCH_FILTERS,
    lastMeetingSearchFilters,
  };
}

function setBuildings(buildings) {
  return {
    type: locationActionTypes.SET_BUILDINGS,
    ...buildings,
  };
}

export function searchBuildings(searchText) {
  return async (dispatch) => {
    if (isEmpty(searchText)) {
      dispatch(clearSearch());
    } else {
      try {
        dispatch(LoadingActions.setLoading("searchingBuildings", true));
        const result = await BuildingsDS.queryBuildings(searchText);
        if (result !== REQUEST_DISCARDED) {
          dispatch(
            setBuildings({
              buildings: result.data,
              from: result.from + LOCATION_SEARCH_QUERY_PAGE_SIZE,
              totalSize: result.totalSize,
              searchText,
            })
          );
        }
      } finally {
        dispatch(LoadingActions.setLoading("searchingBuildings", false));
      }
    }
  };
}

export function searchMoreBuildings() {
  return async (dispatch, getState) => {
    const {
      location: { searchText, buildings, from, totalSize },
    } = getState();
    if (from < totalSize) {
      try {
        dispatch(LoadingActions.setLoading("searchingMoreBuildings", true));
        const result = await BuildingsDS.queryMoreBuildings(searchText, from);
        if (result) {
          dispatch(
            setBuildings({
              buildings: buildings.concat(result.data),
              from: result.from + LOCATION_SEARCH_QUERY_PAGE_SIZE,
              totalSize,
              searchText,
            })
          );
        }
      } finally {
        dispatch(LoadingActions.setLoading("searchingMoreBuildings", false));
      }
    }
  };
}

export function getFloors() {
  return async (dispatch, getState) => {
    const state = getState();
    const building = LocationSelectors.selectedBuildingSelector(state);
    const reservationType = ReservationSelectors.reservationTypeSelector(
      getState()
    );
    const isExchangeIntegrated = ApplicationSettingsSelectors.isExchangeIntegratedSelector(
      getState()
    );
    try {
      dispatch(setLoading("searchRooms", true));
      const floors = !isEmpty(building)
        ? await FloorsDS.getBuildingFloors(
            building._id,
            reservationType,
            isExchangeIntegrated
          )
        : [];
      dispatch(setFloors(floors));
    } finally {
      dispatch(setLoading("searchRooms", false));
    }
  };
}
