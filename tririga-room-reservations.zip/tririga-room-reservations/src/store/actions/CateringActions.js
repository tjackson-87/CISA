/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
import { MenuItemsDS } from "../../model";
import { LoadingActions, ReservationActions, ReservationSelectors } from "..";

export function getMenuItemsForAllResources() {
  return async (dispatch, getState) => {
    const menuItemsForAllResources = [];
    try {
      dispatch(LoadingActions.setLoading("menuItems", true));
      const resources = ReservationSelectors.orderedResourcesSelector(
        getState()
      );
      for (const resource of resources) {
        const availableCatering = await MenuItemsDS.getMenuItems(
          resource.room._id
        );
        menuItemsForAllResources.push({
          roomId: resource.data.roomId,
          availableCatering,
        });
      }
      dispatch(
        ReservationActions.setAvailableCateringsForAllResources(
          menuItemsForAllResources
        )
      );
    } finally {
      dispatch(LoadingActions.setLoading("menuItems", false));
    }
    return menuItemsForAllResources;
  };
}
