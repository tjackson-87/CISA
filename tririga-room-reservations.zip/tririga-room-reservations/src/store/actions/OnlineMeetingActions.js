/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2022 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import { setLoading } from "./LoadingActions.js";
import { onlineMeetingActionTypes, OnlineMeetingConstants } from "../../utils";
import isEmpty from "lodash/isEmpty";
import { OnlineMeetingDS } from "../../model";
import {
  MessageActions,
  RouteActions,
  OnlineMeetingSelectors,
  ReservationActions,
  ReservationSelectors,
  ExchangeSelectors,
  //getAppStore,
  //ApplicationSettingsSelectors
} from "..";

const setOnlineMeetings = (onlineMeetings) => {
  return {
    type: onlineMeetingActionTypes.SET_ONLINE_MEETINGS,
    data: onlineMeetings,
  };
};

export function getOnlineMeetings() {
  return async (dispatch, getState) => {
    let onlineMeetings = OnlineMeetingSelectors.onlineMeetingsSelector(
      getState()
    );
    const userProfileId = ExchangeSelectors.userProfileIdSelector(getState());
    if (
      onlineMeetings &&
      onlineMeetings.length > 0 &&
      !onlineMeetings.some((meeting) => meeting.userProfileId !== userProfileId)
    ) {
      return onlineMeetings;
    }
    try {
      dispatch(setLoading("onlineMeetings", true));
      onlineMeetings = await OnlineMeetingDS.getOnlineMeetings(userProfileId);
      dispatch(setOnlineMeetings(onlineMeetings));
    } finally {
      dispatch(setLoading("onlineMeetings", false));
    }
    return onlineMeetings;
  };
}

export const setSelectedOnlineMeeting = (selectedId) => {
  /*
  const userProfileId = ExchangeSelectors.userProfileIdSelector(
    getAppStore().getState()
  );*/
  return {
    type: onlineMeetingActionTypes.SET_SELECTED_ONLINE_MEETING,
    selectedId,
  };
};
// CISA
export const setTeamsMeeting = (selectedId, data) => {
  return {
    type: onlineMeetingActionTypes.TEAMS_MEETING_KEY,
    selectedId,
    data
  };
};

export const setOnlineMeetingEditFlag = (edit) => {
  return async (dispatch, getState) => {
    if (!edit) {
      const selectedId = OnlineMeetingSelectors.selectedIdSelector(getState());
      if (selectedId === OnlineMeetingConstants.NEW_ONLINE_MEETING_KEY) {
        dispatch(
          setSelectedOnlineMeeting(
            OnlineMeetingConstants.NO_SELECTED_MEETING_KEY
          )
        );
      } else {
        dispatch(setSelectedOnlineMeeting(selectedId));
      }
    } else {
      dispatch({
        type: onlineMeetingActionTypes.SET_ONLINE_MEETING_EDIT_FLAG,
        edit,
      });
    }
  };
};

export function submitOnlineMeeting() {
  return async (dispatch, getState) => {
    const edit = OnlineMeetingSelectors.editRecordSelector(getState());
    const selectedId = OnlineMeetingSelectors.selectedIdSelector(getState());
    const record = OnlineMeetingSelectors.selectedRecordSelector(getState());
    if (edit) {
      if (selectedId === OnlineMeetingConstants.NEW_ONLINE_MEETING_KEY) {
        await createOnlineMeeting(dispatch, record);
      } else {
        await updateOnlineMeeting(dispatch, record);
      }
    } else {
      if (selectedId === OnlineMeetingConstants.NO_SELECTED_MEETING_KEY) {
        dispatch(ReservationActions.setReservationOnlineMeeting(null));
      }
      dispatch(ReservationActions.setReservationOnlineMeeting(record));
      dispatch(RouteActions.navigateToReservationSummary());
    }
  };
}

//TODO - will need to add actions for edit
// CISA
export const createTririgaTeamsMeeting = (record) => {
  return async (dispatch, getState) => {
    try {
      dispatch(setLoading("createTririgaTeamsMeeting", true));
      const {
        createdRecordId
      } = await OnlineMeetingDS.createNewTeamsMeeting(record);
      const meetingCreated = await OnlineMeetingDS.getTeamsMeetingByID(createdRecordId);
      dispatch(setTeamsMeeting(createdRecordId, meetingCreated));
      dispatch(ReservationActions.setReservationOnlineMeeting(meetingCreated));
    } catch (e) {
      dispatch(MessageActions.showOnlineMeetingError("Create"));
    } finally {
      dispatch(setLoading("createTririgaTeamsMeeting", false));
    }
  }
}

async function createOnlineMeeting(dispatch, record) {
  try {
    dispatch(setLoading("createOnlineMeeting", true));
    const {
      onlineMeetings,
      createdRecordId,
    } = await OnlineMeetingDS.createNewOnlineMeeting(record);
    dispatch(setOnlineMeetings(onlineMeetings));
    dispatch(setSelectedOnlineMeeting(createdRecordId));
  } catch (e) {
    dispatch(MessageActions.showOnlineMeetingError("Create"));
  } finally {
    dispatch(setLoading("createOnlineMeeting", false));
  }
}

async function updateOnlineMeeting(dispatch, record) {
  try {
    dispatch(setLoading("updateOnlineMeeting", true));
    const onlineMeetings = await OnlineMeetingDS.updateOnlineMeeting(record);
    dispatch(setOnlineMeetings(onlineMeetings));
    dispatch(setSelectedOnlineMeeting(record._id));
  } catch (e) {
    dispatch(MessageActions.showOnlineMeetingError("Update"));
  } finally {
    dispatch(setLoading("updateOnlineMeeting", false));
  }
}

export function checkOnlineMeetingDeleted(onlineMeetingId) {
  return async (dispatch, getState) => {
    const onlineMeeting = ReservationSelectors.onlineMeetingSelector(
      getState()
    );
    if (!isEmpty(onlineMeeting)) {
      if (onlineMeeting._id === onlineMeetingId) {
        dispatch(ReservationActions.setReservationOnlineMeeting(null));
      }
    }
  };
}

export function deleteOnlineMeeting(onlineMeetingId) {
  return async (dispatch, getState) => {
    try {
      dispatch(setLoading("deleteOnlineMeeting", true));
      const userProfileId = ExchangeSelectors.userProfileIdSelector(getState());
      const onlineMeetings = await OnlineMeetingDS.deleteOnlineMeeting(
        onlineMeetingId,
        userProfileId
      );
      dispatch(setOnlineMeetings(onlineMeetings));
      dispatch(
        setSelectedOnlineMeeting(OnlineMeetingConstants.NO_SELECTED_MEETING_KEY)
      );
      dispatch(checkOnlineMeetingDeleted(onlineMeetingId));
    } catch (e) {
      dispatch(MessageActions.showOnlineMeetingError("Delete"));
    } finally {
      dispatch(setLoading("deleteOnlineMeeting", false));
    }
  };
}

export function updateRecord(key, value) {
  return {
    type: onlineMeetingActionTypes.UPDATE_ONLINE_MEETING_RECORD,
    key,
    value,
  };
}

export function setReservationInitialOnlineMeeting() {
  return async (dispatch) => {
    const onlineMeetings = await dispatch(getOnlineMeetings());

    const defaultMeeting = !isEmpty(onlineMeetings)
      ? onlineMeetings.find((d) => d.defaultMeeting === true)
      : null;

    dispatch(ReservationActions.setReservationOnlineMeeting(defaultMeeting));
  };
}
