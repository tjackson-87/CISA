/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2022 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import { setLoading } from "./LoadingActions.js";
import { OAuthProfileDS } from "../../model";

export const getOAuthProfile = (Domain) => {
  return async (dispatch) => {
    let oauthProfile = null;
    try {
      dispatch(setLoading("getOAuthProfile", true));
      oauthProfile = await OAuthProfileDS.getOAuthProfile(Domain);
    } finally {
      dispatch(setLoading("getOAuthProfile", false));
    }
    return oauthProfile;
  };
};
