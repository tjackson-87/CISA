/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import { isEmpty, isNil } from "lodash";
import {
  eventDetailsActionTypes,
  myCalendarActionTypes,
  Routes,
  Status,
  getCurrentDateTime,
  DefaultValues,
  ReservationEditMode,
} from "../../utils";
import {
  ApplicationSettingsSelectors,
  EventDetailsActions,
  MessageActions,
  MyCalendarActions,
  RouteActions,
  CurrentUserActions,
  MyCalendarSelectors,
  ExchangeActions,
} from "..";
import {
  ReservationDS,
  ReservationInstancesDS,
  Exchange,
  MyCalendarDS,
  ActiveUsersDS,
} from "../../model";
import moment from "moment";
import { getLatestReservationInstanceByReservation } from "../../model/datasources/ReservationInstancesDS";

export function releaseRoom(
  reservationId,
  start,
  end,
  isRecurringReservation,
  eventId
) {
  return async (dispatch, getState) => {
    try {
      if (reservationId) {
        const isExchangeIntegrated = ApplicationSettingsSelectors.isExchangeIntegratedSelector(
          getState()
        );
        const reservationDeleteParam = {
          start,
          end,
          reservationEditMode: isRecurringReservation
            ? ReservationEditMode.SERIES_OCCURRENCE
            : ReservationEditMode.OCCURRENCE,
        };
        await ReservationDS.deleteReservation(
          reservationId,
          reservationDeleteParam
        );
        if (isExchangeIntegrated) {
          await removeRoomDetailsInExchange(
            eventId,
            reservationId,
            dispatch,
            getState
          );
          dispatch(updateEvents([{ eventId, rooms: [], instance: null }]));
          dispatch(EventDetailsActions.reFetchEvent());
          const timezone = await dispatch(
            CurrentUserActions.getDefaultTimezone()
          );
          dispatch(
            MyCalendarActions.setMyCalendarDate(
              moment(
                getCurrentDateTime(timezone).format(
                  DefaultValues.DATE_OBJECT_FORMAT
                )
              ).toDate()
            )
          );
        } else {
          dispatch(MyCalendarActions.deleteMyCalendarEvent(eventId, start));
          if (isDetailsPage(getState())) {
            dispatch(RouteActions.navigateBackToHomePage());
          }
        }
      }
    } catch (err) {
      console.error(err);
      dispatch(MessageActions.showGeneralError());
    }
  };
}

export function checkIn(reservationId, start, instanceId) {
  return async (dispatch, getState) => {
    try {
      await ReservationInstancesDS.checkIn(instanceId);
      const instance = await ReservationInstancesDS.getReservationInstance(
        instanceId
      );
      if (isDetailsPage(getState())) {
        dispatch(updateEvent({ instance }));
      }
      dispatch(updateEvents([{ reservationId, start, instance }]));
    } catch (err) {
      console.error(err);
      dispatch(MessageActions.showGeneralError());
    }
  };
}

export function releaseRoomEarly(
  reservationId,
  start,
  instanceId,
  checkInRequired,
  eventId,
  timezone,
  calendarId
) {
  return async (dispatch, getState) => {
    try {
      if (checkInRequired) {
        await ReservationInstancesDS.checkOut(instanceId);
      } else {
        await ReservationInstancesDS.endEarly(instanceId);
      }
      const instance = await ReservationInstancesDS.getReservationInstance(
        instanceId
      );
      if (eventId && calendarId) {
        await dispatch(
          ExchangeActions.updateEventEndTime(
            eventId,
            start,
            moment.tz(instance.actualEnd, timezone).toISOString(true),
            timezone,
            calendarId
          )
        );
      }
      if (isDetailsPage(getState())) {
        dispatch(updateEvent({ instance }));
      }
      dispatch(updateEvents([{ reservationId, start, instance }]));
    } catch (err) {
      console.error(err);
      dispatch(MessageActions.showGeneralError());
    }
  };
}

export function recheckRoom(
  reservationId,
  start,
  rooms,
  originalReservationId
) {
  return async (dispatch, getState) => {
    try {
      const recheckRoomResults = await ReservationDS.recheckRooms(
        reservationId,
        rooms.map((room) => ({
          spaceId: room.spaceRecordId,
          layoutTypeInternal: room.layoutTypeInternal,
        }))
      );
      const someAreDeclined = recheckRoomResults.wfParametersMap.resources.some(
        (resource) => resource.status === Status.DECLINED
      );
      if (!someAreDeclined) {
        const updatedInstance = await waitUntilValidInstanceIsCreated(
          reservationId,
          start
        );
        const updatedRooms = rooms.map((room) => ({
          ...room,
          status: Status.ACCEPTED,
        }));
        if (isDetailsPage(getState())) {
          dispatch(
            updateEvent({ instance: updatedInstance, rooms: updatedRooms })
          );
        }
        if (!isNil(originalReservationId)) {
          await dispatch(
            updateEventsWithReservationId(
              [
                {
                  reservationId: originalReservationId,
                  start,
                  instance: updatedInstance,
                  rooms: updatedRooms,
                },
              ],
              reservationId
            )
          );
        } else {
          await dispatch(
            updateEvents([
              {
                reservationId,
                start,
                instance: updatedInstance,
                rooms: updatedRooms,
              },
            ])
          );
        }

        const event = MyCalendarSelectors.eventByReservationIdSelector(
          getState(),
          reservationId,
          start
        );

        if (!isNil(event)) {
          const attendees = [];
          event.attendees.forEach((item) => {
            attendees.push({
              email: item.emailAddress.address,
              name: item.emailAddress.name,
            });
          });

          await dispatch(
            ExchangeActions.updateEventAttendees(event.id, [], [])
          );

          await dispatch(
            ExchangeActions.updateEventAttendees(event.id, attendees, [])
          );
        }
      }
      return {
        success: !someAreDeclined,
      };
    } catch (err) {
      console.error(err);
      dispatch(MessageActions.showGeneralError());
    }
  };
}

export function updateRoomsCanceled(reservationId, start, rooms) {
  return async (dispatch, getState) => {
    try {
      const updatedRooms = rooms.map((room) => ({
        ...room,
        status: Status.CANCELED,
      }));
      if (isDetailsPage(getState())) {
        dispatch(updateEvent({ rooms: updatedRooms }));
      }
      dispatch(updateEvents([{ reservationId, start, rooms: updatedRooms }]));
    } catch (err) {
      console.error(err);
      dispatch(MessageActions.showGeneralError());
    }
  };
}

function isDetailsPage(state) {
  const { router } = state;
  return (
    router.location && router.location.pathname.startsWith(Routes.EVENT_DETAILS)
  );
}

function updateEvents(events) {
  if (!isEmpty(events))
    return {
      type: myCalendarActionTypes.UPDATE_EVENTS,
      events,
    };
}
function updateEventsWithReservationId(events, updatedReservationId) {
  if (!isEmpty(events))
    return {
      type: myCalendarActionTypes.UPDATE_EVENTS_RESERVATION_ID,
      updatedReservationId: updatedReservationId,
      events,
    };
}

function updateEvent(event) {
  if (!isEmpty(event)) {
    return { type: eventDetailsActionTypes.UPDATE_EVENT, event };
  }
}

// This is not an ideal solution until we figure out an enhancement or a custom task to handle async workflow process
let attempt = 15;
const WAIT_TIME = Math.floor(Math.random() * 1000) + 1500;
export async function waitUntilValidInstanceIsCreated(reservationId, start) {
  await new Promise((resolve) =>
    setTimeout(() => {
      resolve("done");
    }, WAIT_TIME)
  );
  const instance = await getLatestReservationInstanceByReservation(
    reservationId,
    start
  );
  if ((!instance || instance.statusENUS !== Status.ACTIVE) && attempt > 0) {
    attempt--;
    return waitUntilValidInstanceIsCreated(reservationId, start);
  } else if (instance && instance.statusENUS === Status.ACTIVE) {
    return instance;
  }
}

const removeRoomDetailsInExchange = async (
  eventId,
  reservationId,
  dispatch,
  getState
) => {
  const event = MyCalendarSelectors.eventSelectorWithId(
    getState(),
    eventId,
    reservationId
  );
  if (!event.isRoomOnly) {
    const accessToken = await dispatch(ExchangeActions.getAzureAccessToken());
    const {
      description,
      attendees,
    } = await Exchange.getEventDescriptionAndAttendees(accessToken, eventId);
    let attendeesWithoutRooms;
    if (event.rooms != null) {
      attendeesWithoutRooms = attendees.filter(
        (attendee) =>
          !event.rooms.some(
            (room) => room.exchangeMailbox === attendee.emailAddress.address
          )
      );
    } else {
      attendeesWithoutRooms = attendees;
    }
    await Exchange.removeRoomDetails(
      accessToken,
      eventId,
      attendeesWithoutRooms,
      description
    );
  }
};

export async function waitUntilExceptionIsCreated(
  start,
  end,
  personId,
  seriesReservationId,
  delegateUserEmail
) {
  await new Promise((resolve) =>
    setTimeout(() => {
      resolve("done");
    }, WAIT_TIME)
  );
  let updatedPersonId = personId;
  if (delegateUserEmail !== null) {
    const user = await ActiveUsersDS.getUserByEmail(delegateUserEmail);
    updatedPersonId = user.personId;
    delegateUserEmail = null;
  }
  const reservationException = await MyCalendarDS.getMyCalendarEventBySeriesReservationId(
    start,
    end,
    updatedPersonId,
    seriesReservationId
  );
  if (
    (!reservationException ||
      parseInt(reservationException.reservationId) === seriesReservationId) &&
    attempt > 0
  ) {
    attempt--;
    return waitUntilExceptionIsCreated(
      start,
      end,
      updatedPersonId,
      seriesReservationId,
      delegateUserEmail
    );
  } else if (
    reservationException &&
    parseInt(reservationException.reservationId) !== seriesReservationId
  ) {
    return reservationException;
  }
}
