/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2022 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import moment from "moment-timezone";
import isEmpty from "lodash/isEmpty";
import defaultTo from "lodash/defaultTo";
import { ReservableSpacesDS } from "../../model";
import { availabilityActionTypes, ExchangeConstants } from "../../utils";
import {
  ReservationSelectors,
  MessageActions,
  ApplicationSettingsSelectors,
  ExchangeActions,
} from "..";

function setAttendeeSchedule(attendeesExchangeSchedule) {
  return {
    type: availabilityActionTypes.SET_ATTENDEES_EXCHANGE_SCHEDULE,
    attendeesExchangeSchedule,
  };
}

function setAttendeeScheduleForDay(attendeesExchangeSchedule) {
  return {
    type: availabilityActionTypes.SET_ATTENDEES_EXCHANGE_SCHEDULE_FOR_DAY,
    attendeesExchangeSchedule,
  };
}

export function getAttendeesSchedule({
  startAndEndDate = null,
  forDay = false,
} = {}) {
  return async (dispatch, getState) => {
    const isExchangeIntegrated = ApplicationSettingsSelectors.isExchangeIntegratedSelector(
      getState()
    );
    if (!isExchangeIntegrated) return;
    try {
      const eventParams = defaultTo(
        startAndEndDate,
        ReservationSelectors.timeStepTempStartAndEndDateSelector(getState())
      );
      const { startDate, endDate } = eventParams;
      const startMoment = moment.parseZone(startDate);
      const endMoment = moment.parseZone(endDate);
      if (
        endMoment.isSameOrBefore(startMoment) ||
        endMoment.diff(startMoment, "days") >
          ExchangeConstants.GET_SCHEDULE_MAX_DAYS_WINDOW
      )
        return;

      const exchangeAttendees = ReservationSelectors.exchangeAttendeesSelector(
        getState()
      );

      const scheduleResponse = await dispatch(
        ExchangeActions.getSchedule(
          eventParams,
          exchangeAttendees.map((item) => item.email)
        )
      );
      if (scheduleResponse.success) {
        if (forDay) {
          dispatch(setAttendeeScheduleForDay(scheduleResponse.result));
        } else {
          dispatch(setAttendeeSchedule(scheduleResponse.result));
        }
      } else {
        dispatch(MessageActions.showGetAttendeesScheduleError());
      }
      return scheduleResponse.result;
    } catch (error) {
      dispatch(MessageActions.showGetAttendeesScheduleError());
    }
  };
}

export function clearAttendeesSchedule() {
  return {
    type: availabilityActionTypes.CLEAR_ATTENDEES_EXCHANGE_SCHEDULE,
  };
}

export function clearAttendeesScheduleForDay() {
  return {
    type: availabilityActionTypes.CLEAR_ATTENDEES_EXCHANGE_SCHEDULE_FOR_DAY,
  };
}

function setResourcesEventsForDay(resourcesEvents) {
  return {
    type: availabilityActionTypes.SET_RESOURCES_EVENTS_FOR_DAY,
    resourcesEvents,
  };
}

export function getResourcesScheduleForDay(startAndEndDate) {
  return async (dispatch, getState) => {
    try {
      const resources = ReservationSelectors.orderedResourcesSelector(
        getState()
      );
      if (isEmpty(resources)) return;
      const eventParams = defaultTo(
        startAndEndDate,
        ReservationSelectors.timeStepTempStartAndEndDateSelector(getState())
      );

      const resourcesEventsResponse = await ReservableSpacesDS.getResourcesEvents(
        eventParams,
        resources.map((resource) => resource.data.roomId)
      );

      if (resourcesEventsResponse) {
        dispatch(setResourcesEventsForDay(resourcesEventsResponse.data));
      } else {
        dispatch(MessageActions.showGetResourcesScheduleError());
      }
    } catch (error) {
      dispatch(MessageActions.showGetResourcesScheduleError());
    }
  };
}

function setResourceAvailability(resourcesAvailability) {
  return {
    type: availabilityActionTypes.SET_RESOURCES_AVAILABILITY,
    resourcesAvailability,
  };
}

export function getResourcesAvailability(startAndEndDate) {
  return async (dispatch, getState) => {
    try {
      const state = getState();
      const resources = ReservationSelectors.orderedResourcesSelector(state);
      if (!startAndEndDate || isEmpty(resources)) return;
      const { startDate, endDate } = startAndEndDate;
      const searchFilters = {
        filters: {
          showRequestableRooms: true,
          showPrivateRooms: true,
        },
        startDate,
        endDate,
      };
      const isExchangeIntegrated = ApplicationSettingsSelectors.isExchangeIntegratedSelector(
        getState()
      );
      const reservationType = ReservationSelectors.reservationTypeSelector(
        getState()
      );
      const oauthProfileDomain = ApplicationSettingsSelectors.oauthProfileDomainSelector(
        getState()
      );
      const {
        data: resourcesAvailability,
      } = await ReservableSpacesDS.queryReservableSpaces(
        reservationType,
        searchFilters,
        isExchangeIntegrated,
        0,
        resources.length,
        null,
        null,
        null,
        null,
        false,
        null,
        resources.map((resource) => ({
          _id: resource.data.roomId,
        })),
        null,
        null,
        null,
        oauthProfileDomain
      );
      dispatch(setResourceAvailability(resourcesAvailability));
    } catch (error) {
      dispatch(MessageActions.showGetResourcesAvailabilityError());
    }
  };
}
