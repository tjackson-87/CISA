/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import { labelStylesActionTypes } from "../../utils";
import { LabelStylesDS } from "../../model";

const setLabelStyles = (labelStyles) => {
  return {
    type: labelStylesActionTypes.SET_LABEL_STYLES,
    labelStyles: labelStyles,
  };
};

export function getLabelStyles() {
  return async (dispatch, getState) => {
    let { labelStyles } = getState();
    if (labelStyles && labelStyles.length > 0) return labelStyles;
    labelStyles = await LabelStylesDS.getLabelStyles();
    dispatch(setLabelStyles(labelStyles));
    return labelStyles;
  };
}
