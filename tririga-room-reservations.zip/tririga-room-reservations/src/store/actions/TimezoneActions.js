/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import { setLoading } from "./LoadingActions.js";
import { timezoneActionTypes } from "../../utils";
import { TimezonesDS } from "../../model";

const setTimezones = (timezones) => {
  return {
    type: timezoneActionTypes.SET_TIME_ZONES,
    timezones: timezones,
  };
};

export function getTimezones() {
  return async (dispatch, getState) => {
    let { timezones } = getState();
    if (timezones && timezones.length > 0) return timezones;
    try {
      dispatch(setLoading("timezones", true));
      timezones = await TimezonesDS.getTimezones();
      dispatch(setTimezones(timezones));
    } finally {
      dispatch(setLoading("timezones", false));
    }
    return timezones;
  };
}
