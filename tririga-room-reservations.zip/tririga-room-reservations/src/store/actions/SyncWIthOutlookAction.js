/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2022 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import { syncWithOutlookActionTypes } from "../../utils";

export function setIsSyncingWithOutlook(isSyncing) {
  return {
    type: syncWithOutlookActionTypes.SET_IS_SYNCING_WITH_OUTLOOK,
    isSyncing,
  };
}

export function setICalUId(iCalUId) {
  return {
    type: syncWithOutlookActionTypes.SET_OUTLOOK_SYNC_ICAL_UID,
    iCalUId,
  };
}

export function reset() {
  return {
    type: syncWithOutlookActionTypes.SET_OUTLOOK_SYNC_RESET,
  };
}
