/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import { LoadingActions, CurrentUserSelectors } from "..";
import { MyPrimaryBuildingDS, BuildingsDS } from "../../model";
import { userBuildingActionTypes, GeoLocation } from "../../utils";

const USER_BUILDING_NOT_FOUND = "NOT_FOUND";
const USER_BUILDING_STORAGE_KEY = "USER_BUILDING";
const USER_BUILDING_STORAGE_EXPIRATION = 24 * 60 * 60 * 1000; // ONE DAY

const setMyPrimaryBuilding = (primaryBuilding) => {
  return {
    type: userBuildingActionTypes.SET_MY_PRIMARY_BUILDING,
    primaryBuilding,
  };
};

const queryMyPrimaryBuilding = async (dispatch, getState) => {
  let {
    userBuildings: { primaryBuilding },
  } = getState();
  if (primaryBuilding != null) return primaryBuilding;
  try {
    dispatch(LoadingActions.setLoading("myPrimaryBuilding", true));
    primaryBuilding = await MyPrimaryBuildingDS.getMyPrimaryBuilding();
    dispatch(setMyPrimaryBuilding(primaryBuilding));
  } finally {
    dispatch(LoadingActions.setLoading("myPrimaryBuilding", false));
  }
  return primaryBuilding;
};

export const getUserBuilding = () => {
  return async (dispatch, getState) => {
    const userId = CurrentUserSelectors.idSelector(getState());
    const savedBuilding = await loadUserBuildingFromStorage(userId);
    if (savedBuilding != null) {
      return savedBuilding === USER_BUILDING_NOT_FOUND ? null : savedBuilding;
    }
    let closestBuilding = null;
    try {
      const currentPosition = await GeoLocation.getCurrentPosition();
      if (currentPosition != null) {
        const buildingsWithGeoLocation = await BuildingsDS.getBuildingsWithGeoLocation();
        closestBuilding = await GeoLocation.findNearestBuilding(
          buildingsWithGeoLocation
        );
      }
    } catch (error) {
      closestBuilding = null;
    }
    let userBuilding = null;
    if (closestBuilding != null) {
      userBuilding = closestBuilding;
    } else {
      try {
        userBuilding = await queryMyPrimaryBuilding(dispatch, getState);
      } catch (error) {
        userBuilding = null;
      }
    }
    saveUserBuildingToStorage(userBuilding, userId);
    return userBuilding;
  };
};

function loadUserBuildingFromStorage(userId) {
  try {
    let userBuilding = localStorage.getItem(USER_BUILDING_STORAGE_KEY);
    userBuilding = userBuilding != null ? JSON.parse(userBuilding) : null;
    if (
      userBuilding &&
      userBuilding.userId === userId &&
      new Date().getTime() - userBuilding.updateDate <
        USER_BUILDING_STORAGE_EXPIRATION
    ) {
      return userBuilding.data;
    }
    return null;
  } catch (error) {
    return null;
  }
}

function saveUserBuildingToStorage(userBuilding, userId) {
  try {
    localStorage.setItem(
      USER_BUILDING_STORAGE_KEY,
      JSON.stringify({
        data: userBuilding != null ? userBuilding : USER_BUILDING_NOT_FOUND,
        updateDate: new Date().getTime(),
        userId,
      })
    );
  } catch (error) {}
}
