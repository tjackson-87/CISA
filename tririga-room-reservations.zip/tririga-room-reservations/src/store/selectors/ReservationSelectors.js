/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2022 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import { createSelector } from "reselect";
import sortBy from "lodash/sortBy";
import groupBy from "lodash/groupBy";
import orderBy from "lodash/orderBy";
import defaultTo from "lodash/defaultTo";
import moment from "moment-timezone";
import { ORGANIZATION_USER } from "../../model/exchange/ExchangePeople";

import {
  formatStartEndDates,
  computeMomentStartAndEndDates,
  DateTimeConstants,
  getMomentFrom,
  ReservationUtils,
  EquipmentUtils,
  ReservationEditMode,
  CateringUtils,
  setEventEndDate,
} from "../../utils";
import isEmpty from "lodash/isEmpty";
import { RoomDetailsSelectors } from "../reducers/RoomDetailsReducer";
import { CurrentUserSelectors } from "../reducers/CurrentUserReducer";
import { TimezonesSelectors } from "../reducers/TimezoneReducer";
import { ExchangeSelectors } from "../reducers/ExchangeReducer";
import { isNil } from "lodash";

const { roomDetailsSelector } = RoomDetailsSelectors;

const { WORKSPACE_DAY, WORKSPACE_TIME, DateTimeViewMode } = DateTimeConstants;

const dataSelector = ({ reservation: { data } }) => {
  return data;
};
const initUpdatedDataSelector = ({ reservation: { initUpdatedData } }) => {
  return initUpdatedData;
};
const startDateSelector = ({ reservation }) => {
  return !reservation.data || !reservation.data.startDate
    ? null
    : reservation.data.startDate;
};
const startTimeSelector = ({ reservation }) =>
  !reservation.data || !reservation.data.startTime
    ? "00:00"
    : reservation.data.startTime;
const startTimePeriodSelector = ({ reservation }) =>
  !reservation.data || !reservation.data.startTimePeriod
    ? "AM"
    : reservation.data.startTimePeriod;

const endDateSelector = ({ reservation }) => {
  return !reservation.data || !reservation.data.endDate
    ? null
    : reservation.data.endDate;
};
const endTimeSelector = ({ reservation }) =>
  !reservation.data || !reservation.data.endTime
    ? "00:00"
    : reservation.data.endTime;
const endTimePeriodSelector = ({ reservation }) =>
  !reservation.data || !reservation.data.endTimePeriod
    ? "AM"
    : reservation.data.endTimePeriod;

const timezoneSelector = ({ reservation }) =>
  !reservation.data || !reservation.data.timezone
    ? null
    : reservation.data.timezone;
const subjectSelector = ({ reservation }) =>
  !reservation.data ? "" : reservation.data.subject;
const generateOnlineMeetingSelector = ({ reservation }) =>
!reservation.data ? false : reservation.data.generateOnlineMeeting; // CISA
const onlineMeetingSelector = ({ reservation }) =>
  !reservation.data ? null : reservation.data.onlineMeeting;
const exchangeLocationSelector = ({ reservation }) =>
  !reservation.data ? "" : reservation.data.onlineMeeting;
const additionalLocationInfoSelector = ({ reservation }) =>
  !reservation.data || reservation.data.additionalLocationInfo === undefined
    ? ""
    : reservation.data.additionalLocationInfo;
const iCalUIdSelector = ({ reservation }) =>
  !reservation.data || reservation.data.iCalUId === undefined
    ? ""
    : reservation.data.iCalUId;
const seriesICalUIdSelector = ({ reservation }) =>
  !reservation.data || !reservation.data.seriesICalUId
    ? ""
    : reservation.data.seriesICalUId;
const descriptionSelector = ({ reservation }) =>
  !reservation.data ? "" : reservation.data.description;
const allDayEventSelector = ({ reservation }) =>
  !reservation.data || reservation.data.allDayEvent === undefined
    ? null
    : reservation.data.allDayEvent;

const detailPageRouteSelector = ({ router }) => {
  const path =
    router.location.state && router.location.state.routedFromEventDetailPage;
  return !(isEmpty(path) && !path);
};

const allResourcesSelector = ({ reservation, router, eventDetails }) => {
  const location = router.location.state;
  if (location && location.routedFromEventDetailPage) {
    return !eventDetails.event || !eventDetails.event.rooms
      ? null
      : eventDetails.event.rooms;
  }
  return !reservation.data || !reservation.data.resources
    ? null
    : reservation.data.resources;
};

const resourcesSelector = createSelector(
  [allResourcesSelector],
  (resources) => {
    if (!resources) return null;
    return resources.filter((item) => !item.removed);
  }
);

const removedResourcesSelector = createSelector(
  [allResourcesSelector],
  (resources) => {
    if (!resources) return null;
    return resources.filter((item) => item.removed);
  }
);

const holdTimeEndSelector = ({ reservation }) =>
  !reservation.data || !reservation.data.holdTimeEnd
    ? null
    : reservation.data.holdTimeEnd;

const holdTimeExpiredSelector = ({ reservation }) =>
  !reservation.data ? false : reservation.data.holdTimeExpired;

const reservationIdSelector = ({ reservation }) =>
  !reservation.data || !reservation.data.reservationId
    ? null
    : reservation.data.reservationId;

const exchangeEventIdSelector = ({ reservation }) =>
  reservation.exchangeEventId;

const nonOrderedAttendeesSelector = ({ reservation }) =>
  !reservation.data || !reservation.data.attendees
    ? null
    : reservation.data.attendees;

const attendeesSelector = createSelector(
  [nonOrderedAttendeesSelector],
  (attendees) => {
    if (attendees) {
      const attendeesNew = attendees.map((a) => {
        const displayName =
          a.firstName && a.firstName === a.lastName
            ? a.firstName
            : a.displayName;
        return { ...a, displayName };
      });
      return sortBy(attendeesNew, ["displayName"]);
    } else return null;
  }
);

const layoutTypesSelector = ({ meetingLayoutTypes }) => meetingLayoutTypes;

const isCreateSelector = ({ reservation }) =>
  !reservation.data ? false : reservation.create;

const editModeSelector = ({ reservation }) =>
  !reservation.data ? null : reservation.editMode;

const recurrenceSelector = ({ reservation }) =>
  !reservation.data || !reservation.data.recurrence
    ? null
    : reservation.data.recurrence;

const isReservationExchangeOnlySelector = ({ reservation }) =>
  !(!reservation.data || !reservation.data.isReservationExchangeOnly);

const eventStartandEndSelector = ({ reservation }) => {
  return !reservation.data || !reservation.data
    ? null
    : { start: reservation.data.startDate, end: reservation.data.endDate };
};

const eventStartSelector = ({ reservation }) =>
  !reservation.data || !reservation.data.eventStart
    ? null
    : reservation.data.eventStart;

const eventEndSelector = ({ reservation }) =>
  !reservation.data || !reservation.data.eventEnd
    ? null
    : reservation.data.eventEnd;

const tempStartDateSelector = ({ reservation }) => {
  return !reservation.timeStepTempData ||
    !reservation.timeStepTempData.startDate
    ? null
    : reservation.timeStepTempData.startDate;
};
const tempStartTimeSelector = ({ reservation }) =>
  !reservation.timeStepTempData || !reservation.timeStepTempData.startTime
    ? "00:00"
    : reservation.timeStepTempData.startTime;
const tempStartTimePeriodSelector = ({ reservation }) =>
  !reservation.timeStepTempData || !reservation.timeStepTempData.startTimePeriod
    ? "AM"
    : reservation.timeStepTempData.startTimePeriod;

const tempEndDateSelector = ({ reservation }) => {
  return !reservation.timeStepTempData || !reservation.timeStepTempData.endDate
    ? null
    : reservation.timeStepTempData.endDate;
};
const tempEndTimeSelector = ({ reservation }) =>
  !reservation.timeStepTempData || !reservation.timeStepTempData.endTime
    ? "00:00"
    : reservation.timeStepTempData.endTime;
const tempEndTimePeriodSelector = ({ reservation }) =>
  !reservation.timeStepTempData || !reservation.timeStepTempData.endTimePeriod
    ? "AM"
    : reservation.timeStepTempData.endTimePeriod;

const tempTimezoneSelector = ({ reservation }) =>
  !reservation.timeStepTempData || !reservation.timeStepTempData.timezone
    ? null
    : reservation.timeStepTempData.timezone;

const isReservationSeriesWithExceptionDataSelector = ({ reservation }) => ({
  isReservationSeriesWithException:
    reservation.isReservationSeriesWithException,
  seriesMasterId: reservation.seriesMasterId,
  seriesReservationId: reservation.seriesReservationId,
});

const tempAllDayEventSelector = ({ reservation }) =>
  !reservation.timeStepTempData ||
  reservation.timeStepTempData.allDayEvent === undefined
    ? null
    : reservation.timeStepTempData.allDayEvent;

const timeStepTempRecurrenceSelector = ({ reservation }) =>
  !reservation.timeStepTempData || !reservation.timeStepTempData.recurrence
    ? null
    : reservation.timeStepTempData.recurrence;

const tempDayTypeSelector = ({ reservation }) =>
  !reservation.timeStepTempData || !reservation.timeStepTempData.dayType
    ? WORKSPACE_DAY.TODAY
    : reservation.timeStepTempData.dayType;

const tempTimeTypeSelector = ({ reservation }) =>
  !reservation.timeStepTempData || !reservation.timeStepTempData.timeType
    ? WORKSPACE_TIME.ALLDAY
    : reservation.timeStepTempData.timeType;

const dateTimeViewModeSelector = ({ reservation }) =>
  !reservation.timeStepTempData ||
  !reservation.timeStepTempData.dateTimeViewMode
    ? DateTimeViewMode.SIMPLE
    : reservation.timeStepTempData.dateTimeViewMode;

const occurrenceStartDateTimeSelector = createSelector(
  [recurrenceSelector],
  (recurrence) =>
    !recurrence || !recurrence.details ? null : recurrence.details.startDate
);

const occurrenceEndDateTimeSelector = createSelector(
  [recurrenceSelector],
  (recurrence) =>
    !recurrence || !recurrence.details ? null : recurrence.details.endDate
);

const selectedResourceSelector = ({ reservation }) =>
  reservation.selectedResource;

const dateAndTimeSelector = createSelector(
  [
    CurrentUserSelectors.carbonDateFormatSelector,
    CurrentUserSelectors.carbonLocaleSelector,
    CurrentUserSelectors.localeSelector,
    CurrentUserSelectors.dateFormatSelector,
    startDateSelector,
    startTimeSelector,
    startTimePeriodSelector,
    endDateSelector,
    endTimeSelector,
    endTimePeriodSelector,
    timezoneSelector,
    allDayEventSelector,
    recurrenceSelector,
  ],
  (
    carbonDateFormat,
    carbonLocale,
    locale,
    dateFormat,
    startDate,
    startTime,
    startTimePeriod,
    endDate,
    endTime,
    endTimePeriod,
    timezone,
    allDayEvent,
    recurrence
  ) => ({
    carbonDateFormat,
    carbonLocale,
    locale,
    dateFormat,
    startDate,
    startTime,
    startTimePeriod,
    endDate,
    endTime,
    endTimePeriod,
    timezone,
    allDayEvent,
    recurrence,
  })
);

const timeStepTempDateAndTimeSelector = createSelector(
  [
    CurrentUserSelectors.carbonDateFormatSelector,
    CurrentUserSelectors.carbonLocaleSelector,
    CurrentUserSelectors.localeSelector,
    CurrentUserSelectors.dateFormatSelector,
    tempStartDateSelector,
    tempStartTimeSelector,
    tempStartTimePeriodSelector,
    tempEndDateSelector,
    tempEndTimeSelector,
    tempEndTimePeriodSelector,
    tempTimezoneSelector,
    tempAllDayEventSelector,
    timeStepTempRecurrenceSelector,
    tempDayTypeSelector,
    tempTimeTypeSelector,
    dateTimeViewModeSelector,
  ],
  (
    carbonDateFormat,
    carbonLocale,
    locale,
    dateFormat,
    startDate,
    startTime,
    startTimePeriod,
    endDate,
    endTime,
    endTimePeriod,
    timezone,
    allDayEvent,
    recurrence,
    dayType,
    timeType,
    dateTimeViewMode
  ) => ({
    carbonDateFormat,
    carbonLocale,
    locale,
    dateFormat,
    startDate,
    startTime,
    startTimePeriod,
    endDate,
    endTime,
    endTimePeriod,
    timezone,
    allDayEvent,
    recurrence,
    dayType,
    timeType,
    dateTimeViewMode,
  })
);

const startAndEndDateSelector = createSelector(
  [dateAndTimeSelector, TimezonesSelectors.timezonesSelector],
  (dateAndTime, timezones) => {
    return buildStartAndEndDate(dateAndTime, timezones);
  }
);

const timeStepTempStartAndEndDateSelector = createSelector(
  [timeStepTempDateAndTimeSelector, TimezonesSelectors.timezonesSelector],
  (dateAndTime, timezones) => {
    return buildStartAndEndDate(dateAndTime, timezones);
  }
);

function buildStartAndEndDate(
  {
    startDate,
    startTime,
    startTimePeriod,
    endDate,
    endTime,
    endTimePeriod,
    timezone,
    allDayEvent: allDay,
    recurrence,
  },
  timezones
) {
  if (!startDate || !startTime) return null;
  const { startDateTime, endDateTime } = computeMomentStartAndEndDates({
    allDayEvent: allDay,
    startDate,
    startTime,
    startTimePeriod,
    endDate,
    endTime,
    endTimePeriod,
    timezone,
  });
  let recurrenceRule;
  if (recurrence?.details) {
    recurrenceRule = recurrence.details.rule;
  }
  const { _id: timezoneId } = timezones.find((item) =>
    item.englishName.includes(timezone)
  );
  return {
    startDate: startDateTime.toISOString(true),
    endDate: endDateTime.toISOString(true),
    allDay,
    timezone,
    timezoneId,
    recurrenceRule,
  };
}

const startDateTimeSelector = createSelector(
  [startAndEndDateSelector],
  (startAndEndDate) =>
    startAndEndDate != null ? startAndEndDate.startDate : null
);

const endDateTimeSelector = createSelector(
  [startAndEndDateSelector],
  (startAndEndDate) =>
    startAndEndDate != null ? startAndEndDate.endDate : null
);

export const equipmentSelector = (state, roomId, equipmentId) => {
  if (equipmentId == null) return null;
  const resources = resourcesSelector(state);
  if (resources == null) return null;
  const isReadOnlyPage = detailPageRouteSelector(state);
  if (isReadOnlyPage) {
    const resource = !isEmpty(resources)
      ? resources.find((r) => r.spaceRecordId === roomId || r._id === roomId)
      : {};
    const equipment = resource.availableEquipments
      ? resource.availableEquipments.find((e) => e._id === equipmentId)
      : null;
    return equipment;
  }
  const resource = resources.find((e) => e.data.roomId === roomId);
  const equipment = resource.availableEquipment.find(
    (e) => e._id === equipmentId
  );
  return equipment === undefined ? null : equipment;
};

export const unresolvedExceptionsCheckSelector = (state) => {
  const resources = resourcesSelector(state);
  if (isEmpty(resources)) return false;
  return resources.some(
    (r) => !isEmpty(r.exceptions) && r.exceptions.some((e) => isEmpty(e.room))
  );
};

const firstOccurStartAndEndDateSelector = createSelector(
  [startAndEndDateSelector, occurrenceStartDateTimeSelector],
  (startAndEndDate, occurrenceStartDateTime) => {
    if (!startAndEndDate || !occurrenceStartDateTime) return startAndEndDate;
    const { startDate, endDate, timezone } = startAndEndDate;
    const startDateTimeMoment = moment(startDate);
    const endDateTimeMoment = moment(endDate);
    const originalDuration = moment.duration(
      endDateTimeMoment.diff(startDateTimeMoment)
    );
    const occurrenceStartDateTimeMoment = moment.tz(
      occurrenceStartDateTime,
      timezone
    );
    const occurrenceEndDateTimeMoment = occurrenceStartDateTimeMoment
      .clone()
      .add(originalDuration);
    return {
      ...startAndEndDate,
      startDate: occurrenceStartDateTimeMoment.toISOString(true),
      endDate: occurrenceEndDateTimeMoment.toISOString(true),
    };
  }
);

const reservationTypeSelector = ({ reservation }) => {
  return !reservation ? null : reservation.type;
};

const costSummaryAccountCodesSelector = ({ reservation }) => {
  if (!reservation || !reservation.data) return null;
  return {
    accountCodeRoom: reservation.data.accountCodeRoom,
    accountCodeFood: reservation.data.accountCodeFood,
    accountCodeEquipment: reservation.data.accountCodeEquipment,
    estimatedCostEquipment: reservation.data.estimatedCostEquipment,
    estimatedCostFood: reservation.data.estimatedCostFood,
    estimatedCostResource: reservation.data.estimatedCostResource,
  };
};

const savedReservationSelector = ({ reservation }) => {
  return reservation;
};

const allSelectedEquipmentSelector = createSelector(
  [resourcesSelector],
  (resources) => {
    const selectedEquipment = [];
    if (resources !== null)
      resources.forEach((r) => {
        if (!isEmpty(r.selectedEquipment))
          r.selectedEquipment.forEach((s) => {
            selectedEquipment.push({ ...s, resourceId: r.data._id });
          });
      });
    return selectedEquipment;
  }
);

const allSelectedCateringSelector = createSelector(
  [resourcesSelector],
  (resources) => {
    const selectedCatering = [];
    if (resources !== null)
      resources.forEach((r) => {
        if (!isEmpty(r.selectedCatering))
          r.selectedCatering.forEach((s) => {
            selectedCatering.push({ ...s, resourceId: r.data._id });
          });
      });
    return selectedCatering;
  }
);

const selectedResourceSelectedExceptionSelector = createSelector(
  [selectedResourceSelector],
  (resource) => resource?.selectedException
);

const reservationParamsSelector = createSelector(
  [
    subjectSelector,
    descriptionSelector,
    firstOccurStartAndEndDateSelector,
    reservationTypeSelector,
    editModeSelector,
    eventStartSelector,
    eventEndSelector,
    additionalLocationInfoSelector,
    iCalUIdSelector,
  ],
  (
    subject,
    description,
    {
      startDate: start,
      endDate: end,
      allDay,
      recurrenceRule,
      timezoneId,
      timezone,
    },
    reservationType,
    editMode,
    eventStart,
    eventEnd,
    additionalLocationInfo,
    iCalUId
  ) => {
    return {
      allDay,
      description,
      subject,
      start,
      end: setEventEndDate(allDay, end, timezone),
      recurrenceRule,
      timezone: {
        id: timezoneId,
      },
      reservationType,
      editMode,
      eventStart,
      eventEnd,
      additionalLocationInfo,
      iCalUId,
    };
  }
);

const reservedResourcesSelector = createSelector(
  [allResourcesSelector],
  (resources) => {
    if (!resources) return null;
    return resources.filter((resource) => resource.reserved);
  }
);

const resourcesOnHoldSelector = createSelector(
  [resourcesSelector],
  (resources) => {
    if (!resources) return null;
    return resources.filter((resource) => resource.onHold);
  }
);

const newResourcesSelector = createSelector(
  [resourcesOnHoldSelector],
  (resources) => {
    if (!resources) return null;
    return resources.filter((resource) => !resource.reserved);
  }
);

const roomsSelector = createSelector([resourcesSelector], (resources) => {
  if (!resources) return null;
  return resources.map((resource) => resource.room);
});

const orderedResourcesSelector = createSelector(
  [resourcesSelector, detailPageRouteSelector],
  (resources, path) => {
    const resourceList = [];
    if (!isEmpty(resources)) {
      resources.forEach((resourceItem) => {
        const resource = { ...resourceItem };
        resource.isUnavailable = !ReservationUtils.isAvailable(
          path ? resource.status : resource.data.statusENUS
        );
        resource.hasUnavailableSelectedEquipment = !EquipmentUtils.isResourceSelectedEquipmentAvailable(
          resource
        );
        resourceList.push(resource);
      });
      return sortBy(resourceList, ["room.building", "room.floor", "room.name"]);
    }
    return resourceList;
  }
);

const hasResourcesOnHoldSelector = createSelector(
  [resourcesOnHoldSelector],
  (resources) => defaultTo(resources, []).length > 0
);

const selectedEquipmentSelector = createSelector(
  [orderedResourcesSelector, roomDetailsSelector, detailPageRouteSelector],
  (resources, room, isReadOnlyPage) => {
    if (!resources || !room) return null;
    if (isReadOnlyPage) {
      const r = resources.find(
        (res) => res._id === room._id || res.spaceRecordId === room._id
      );
      let equipmentByRoom = [];
      if (r) {
        equipmentByRoom = Object.entries(
          groupBy(
            r.equipment.map((order) => ({
              image: order.image,
              name: order.equipment,
              description: order.equipmentDescription,
              _id: order.equipmentId,
              quantity: order.quantity,
              instructions: order.instructions,
              roomId: order.resource.id,
              orderId: order._id,
            })),
            (e) => e.roomId
          )
        );
      }
      const finalEquipmentOrder = equipmentByRoom.map((order) => order[1]);

      return finalEquipmentOrder[0];
    }
    const resource = resources.find((hold) => hold.data.roomId === room._id);
    return isEmpty(resource) ? null : resource.selectedEquipment;
  }
);

const availableEquipmentSelector = createSelector(
  [orderedResourcesSelector, roomDetailsSelector, detailPageRouteSelector],
  (resources, room, isReadOnlyPage) => {
    if (!resources || !room) return null;
    if (isReadOnlyPage) {
      const r = resources.find(
        (res) => res._id === room._id || res.spaceRecordId === room._id
      );
      return r.availableEquipments;
    }
    const resource = resources.find((hold) => hold.data.roomId === room._id);
    return isEmpty(resource) ? null : resource.availableEquipment;
  }
);

const addedEquipmentSelector = createSelector(
  [orderedResourcesSelector, roomDetailsSelector, detailPageRouteSelector],
  (resources, room, isReadOnlyPage) => {
    if (!resources || !room) return null;
    if (isReadOnlyPage) return [];
    const resource = resources.find((hold) => hold.data.roomId === room._id);
    return resource?.addedEquipment;
  }
);

const addedEquipmentSavedSelector = createSelector(
  [orderedResourcesSelector, roomDetailsSelector, detailPageRouteSelector],
  (resources, room, isReadOnlyPage) => {
    if (!resources || !room) return null;
    if (isReadOnlyPage) return false;
    const resource = resources.find((hold) => hold.data.roomId === room._id);
    return resource?.addedEquipmentSaved;
  }
);

const isReservationValidSelector = createSelector(
  [
    subjectSelector,
    startDateSelector,
    startTimeSelector,
    startTimePeriodSelector,
    endDateSelector,
    endTimeSelector,
    endTimePeriodSelector,
    resourcesSelector,
    holdTimeExpiredSelector,
    ExchangeSelectors.hasAccessTokenSelector,
    reservationTypeSelector,
  ],
  ReservationUtils.isReservationValid
);

const formattedStartEndDatesSelector = createSelector(
  [
    startDateTimeSelector,
    endDateTimeSelector,
    allDayEventSelector,
    CurrentUserSelectors.dateFormatSelector,
    CurrentUserSelectors.localeSelector,
    timezoneSelector,
    TimezonesSelectors.timezonesSelector,
    reservationTypeSelector,
    recurrenceSelector,
  ],
  formatStartEndDates
);

const nonExchangeAttendeesSelector = createSelector(
  [attendeesSelector],
  (attendees) => {
    if (!isEmpty(attendees))
      return attendees.filter((item) => item.type !== ORGANIZATION_USER);
    return [];
  }
);

const exchangeAttendeesSelector = createSelector(
  [attendeesSelector, ExchangeSelectors.currentCalenderProfileSelector],
  (attendees, currentCalenderProfileSelector) => {
    const attendeesList = [];
    if (currentCalenderProfileSelector)
      attendeesList.push(currentCalenderProfileSelector);
    if (!isEmpty(attendees)) {
      attendeesList.push(
        ...attendees.filter((item) => item.type === ORGANIZATION_USER)
      );
    }
    return attendeesList;
  }
);

const availableCateringSelector = createSelector(
  [resourcesSelector, roomDetailsSelector, detailPageRouteSelector],
  (resources, room, isReadOnlyPage) => {
    if (!resources || !room || isReadOnlyPage) return {};
    const resource = resources.find((hold) => hold.data.roomId === room._id);
    return groupBy(
      orderBy(
        resource.availableCatering,
        ["specClass", "menuItem"],
        ["asc", "asc"]
      ),
      "specClass"
    );
  }
);

const selectedCateringsSelector = createSelector(
  [
    orderedResourcesSelector,
    roomDetailsSelector,
    detailPageRouteSelector,
    CurrentUserSelectors.defaultTimezoneSelector,
  ],
  (resources, room, isReadOnlyPage, timezone) => {
    if (!resources || !room) return null;
    if (isReadOnlyPage) {
      const r = resources.find(
        (res) => res._id === room._id || res.spaceRecordId === room._id
      );
      const cateringByRoom = r.catering.map((order) => ({
        image: order.image,
        name: order.name,
        menuItem: order.menuItem,
        specClass: order.specClass,
        requestedDateTime: order.requestedDateTime,
        description: order.equipmentDescription,
        _id: order.productId,
        purchaseLineItemId: order._id,
        qty: order.quantity,
        costPerItem: order.costPerItem,
        roomId: order.resource.id,
        currency: order.currency,
        orderId: order.orderId,
        purchaseOrderId: order.purchaseOrderId,
        orderInstructions: order.orderInstructions,
        status: order.purchaseOrderStatus,
        instructions: order.itemInstructions,
        foodOrderRequestedDateTime: order.foodOrderRequestedDateTime,
      }));
      const cateringByOrderId = groupBy(cateringByRoom, (c) => c.orderId);
      const cateringWithAdditionalInfo = Object.values(cateringByOrderId).map(
        (order) => ({
          additionalInformation: {
            orderName: order[0].name,
            instructions: order[0].orderInstructions,
            purchaseOrderId: order[0].purchaseOrderId,
            status: order[0].status,
            deliveryDate: moment
              .tz(order[0].foodOrderRequestedDateTime, timezone)
              .startOf("day")
              .toDate(),
            deliveryTime: moment(order[0].foodOrderRequestedDateTime)
              .tz(timezone)
              .format("hh:mm"),
            deliveryTimePeriod: moment
              .tz(order[0].foodOrderRequestedDateTime, timezone)
              .format("A"),
          },
          items: order,
        })
      );
      return cateringWithAdditionalInfo;
    } else {
      const resource = resources.find((hold) => hold.data.roomId === room._id);
      if (isEmpty(resource)) return null;
      return resource.selectedCatering;
    }
  }
);

const estimatedResourceCostSelector = createSelector(
  [roomsSelector],
  (resources) => {
    let sum = 0;
    let currency = "";
    if (!isNil(resources) && resources.length > 0) {
      resources.forEach((resource) => {
        if (!isNil(resource.usageCost)) {
          sum = sum + resource.usageCost;
        }
        if (!isNil(resource.setupCost)) {
          sum = sum + resource.setupCost;
        }
        currency = resource.currency;
      });
    } else {
      return null;
    }
    return sum === 0 ? null : { uom: currency, value: sum };
  }
);

const isCateringCostsSameCurrencySelector = createSelector(
  [allSelectedCateringSelector],
  (selectedCatering) => {
    const currencies = [];
    if (isNil(selectedCatering) || selectedCatering.length === 0) return true;
    selectedCatering.forEach((cater) => {
      cater.items.forEach((cur) => {
        currencies.push(cur.currency);
      });
    });
    return currencies.every((v) => v === currencies[0]);
  }
);

const cateringTotalCostSelector = createSelector(
  [allSelectedCateringSelector],
  (selectedCatering) => {
    let total = 0;
    let currency = "";
    if (isNil(selectedCatering) || selectedCatering.length === 0) return null;
    selectedCatering.forEach((cater) => {
      if (cater.items.length > 0) {
        currency = cater.items[0].currency;
      }
      total = total + CateringUtils.getItemsOrderTotal(cater.items);
    });
    return total === 0 ? null : { uom: currency, value: total };
  }
);

const isEquipmentCostsSameCurrencySelector = createSelector(
  [allSelectedEquipmentSelector],
  (selectedEquipment) => {
    if (isNil(selectedEquipment) || selectedEquipment.length === 0) return true;
    return selectedEquipment?.every(
      (equipment) => equipment.currency === selectedEquipment[0].currency
    );
  }
);

const equipmentTotalCostSelector = createSelector(
  [allSelectedEquipmentSelector],
  (selectedEquipments) => {
    let total = 0;
    let currency = "";
    if (isNil(selectedEquipments) || selectedEquipments.length === 0)
      return null;
    currency = selectedEquipments[0].currency;
    total =
      EquipmentUtils.computeEquipmentTotalCost(selectedEquipments) +
      EquipmentUtils.computeEquipmentUsageCost(selectedEquipments);

    return total === 0 ? null : { uom: currency, value: total };
  }
);

const hasReservationCostSelector = createSelector(
  [
    estimatedResourceCostSelector,
    equipmentTotalCostSelector,
    cateringTotalCostSelector,
  ],
  (resourceCost, equipmentCost, foodCost) => {
    if (!isNil(resourceCost) || !isNil(equipmentCost) || !isNil(foodCost)) {
      return true;
    }
    return false;
  }
);

const orderedCateringsSelector = createSelector(
  [orderedResourcesSelector, roomDetailsSelector, detailPageRouteSelector],
  (resources, room, isReadOnlyPage) => {
    if (!resources || !room || isReadOnlyPage) return [];
    const resource = resources.find((hold) => hold.data.roomId === room._id);
    return resource ? resource.orderedCatering : [];
  }
);

const toBeUpdatedCateringsSelector = createSelector(
  [orderedResourcesSelector, roomDetailsSelector, detailPageRouteSelector],
  (resources, room, isReadOnlyPage) => {
    if (!resources || !room || isReadOnlyPage) return [];
    const resource = resources.find((hold) => hold.data.roomId === room._id);
    return resource ? resource.toBeUpdatedCatering : [];
  }
);

const allToBeUpdatedCateringsSelector = createSelector(
  [resourcesSelector],
  (resources) => {
    const toBeUpdatedCaterings = [];
    if (resources != null)
      resources.forEach((r) => {
        if (!isEmpty(r.toBeUpdatedCatering))
          r.toBeUpdatedCatering.forEach((s) => {
            toBeUpdatedCaterings.push({
              ...s,
              orderId: s.items[0]?.orderId,
              resourceId: r.data._id,
            });
          });
      });
    return toBeUpdatedCaterings;
  }
);

const foodOrdersSelector = createSelector(
  [allToBeUpdatedCateringsSelector, timezoneSelector],
  (selectedCaterings, timezone) => {
    const foodOrders = [];
    const foodItems = [];
    selectedCaterings.forEach((cateringOrder, index) => {
      const { additionalInformation, items } = cateringOrder;
      foodOrders.push({
        foodOrderId: `${cateringOrder.orderId}` || `${index}`,
        deliveryDate: getMomentFrom(
          additionalInformation.deliveryDate,
          additionalInformation.deliveryTime,
          additionalInformation.deliveryTimePeriod,
          timezone
        ).format(),
        instructions: defaultTo(additionalInformation.instructions, ""),
        name: defaultTo(additionalInformation.orderName, ""),
        resourceId: cateringOrder.resourceId,
        actionType: cateringOrder.actionType,
      });
      items.forEach((item) => {
        foodItems.push({
          foodOrderId: `${cateringOrder.orderId}` || `${index}`,
          productId: item._id,
          quantity: parseInt(item.qty),
          instructions: defaultTo(item.instructions, ""),
          actionType: item.actionType,
          purchaseLineItemId: defaultTo(item.purchaseLineItemId, ""),
        });
      });
    });
    return { foodOrders, foodItems };
  }
);

const isEditingSeriesOccurrenceSelector = createSelector(
  [editModeSelector],
  (editMode) =>
    editMode === ReservationEditMode.SERIES_OCCURRENCE ||
    editMode === ReservationEditMode.SERIES_EXCEPTION
);

const selectedResourceExceptionsSelector = createSelector(
  [
    selectedResourceSelector,
    timezoneSelector,
    CurrentUserSelectors.localeSelector,
  ],
  (resource, timezone, locale) =>
    resource?.exceptions?.map((e) => {
      moment.locale(locale);
      const startDate = moment.tz(e.start, timezone).format("MM/DD/YYYY");
      const endDate = moment.tz(e.end, timezone).format("MM/DD/YYYY");
      const startTime = moment.tz(e.start, timezone).format("hh:mm A");
      const endTime = moment.tz(e.end, timezone).format("hh:mm A");
      const timezoneStr = moment.tz(timezone).zoneName();
      const formattedDate = `${startDate}, ${startTime} - ${endTime} ${timezoneStr}`;
      return {
        ...e,
        startDate,
        endDate,
        formattedDate,
        holdRoomId: resource.room._id,
        resourceId: resource.reserved ? resource.data._id : null,
      };
    }) || []
);

const selectedResourceRoomSelector = createSelector(
  [selectedResourceSelector],
  (resource) => resource?.room
);

const selectedResourceExceptionRoomsSelector = createSelector(
  [selectedResourceExceptionsSelector],
  (exceptions) => exceptions?.filter((e) => e.room) || []
);

const selectedResourceResolvedCountSelector = createSelector(
  [selectedResourceSelector],
  (resource) =>
    resource &&
    resource.exceptions.reduce((acc, e) => (isEmpty(e.room) ? acc : ++acc), 0)
);

const allResolvedExceptionsSelector = createSelector(
  [resourcesSelector],
  (resources) =>
    resources
      ?.map((r) =>
        r.exceptions
          ?.map(
            (e) =>
              r.room && {
                ...e,
                resource: {
                  ...r,
                  data: { ...r.data, roomId: e.room?._id },
                  room: e.room,
                },
              }
          )
          .filter((r) => r.room)
      )
      .flat()
      .filter((r) => r) || []
);

const allResolvedResourcesGroupStartDateSelector = createSelector(
  [allResolvedExceptionsSelector],
  (resourcesByDate) =>
    groupBy(resourcesByDate, (resourceByDate) => resourceByDate.startDate)
);

const resolvedExceptionsStartDatesSelector = createSelector(
  [resourcesSelector, timezoneSelector],
  (resources, timezone) =>
    resources &&
    resources?.reduce((cv, v) => {
      if (!isEmpty(v.exceptions)) {
        v.exceptions
          .filter((e) => e.room)
          .forEach((e) =>
            cv.add(moment.tz(e.start, timezone).format("MM/DD/YYYY"))
          );
      }
      return cv;
    }, new Set())
);

const allHoldExceptionsSelector = createSelector(
  allResolvedExceptionsSelector,
  selectedResourceExceptionsSelector,
  (allResolvedExceptions, selectedResourceExceptions) => {
    return !isEmpty(selectedResourceExceptions)
      ? [
          ...allResolvedExceptions.filter(
            (e) =>
              !selectedResourceExceptions
                .map((e) => `${e.room?._id}${e.start}`)
                .includes(`${e.room?._id}${e.start}`)
          ),
          ...selectedResourceExceptions,
        ]
      : [];
  }
);

const allExceptionsSelector = createSelector(
  [resourcesSelector],
  (resources) =>
    resources
      .map((r) =>
        r.exceptions
          ?.map((e) => ({
            ...e,
            resource: {
              ...r,
              data: { ...r.data, roomId: e.room?._id },
              room: e.room,
            },
          }))
          .filter((r) => r.room)
      )
      .flat()
      .filter((r) => r) || []
);

export const ReservationSelectors = {
  savedReservationSelector,
  subjectSelector,
  generateOnlineMeetingSelector, // CISA
  additionalLocationInfoSelector,
  isReservationExchangeOnlySelector,
  onlineMeetingSelector,
  exchangeLocationSelector,
  unresolvedExceptionsCheckSelector,
  descriptionSelector,
  resourcesSelector,
  allDayEventSelector,
  startAndEndDateSelector,
  timeStepTempStartAndEndDateSelector,
  isReservationSeriesWithExceptionDataSelector,
  reservationParamsSelector,
  iCalUIdSelector,
  dateAndTimeSelector,
  timeStepTempDateAndTimeSelector,
  isReservationValidSelector,
  formattedStartEndDatesSelector,
  orderedResourcesSelector,
  holdTimeEndSelector,
  holdTimeExpiredSelector,
  nonExchangeAttendeesSelector,
  attendeesSelector,
  exchangeAttendeesSelector,
  timezoneSelector,
  layoutTypesSelector,
  recurrenceSelector,
  timeStepTempRecurrenceSelector,
  occurrenceEndDateTimeSelector,
  firstOccurStartAndEndDateSelector,
  reservationTypeSelector,
  costSummaryAccountCodesSelector,
  tempDayTypeSelector,
  tempTimeTypeSelector,
  equipmentSelector,
  allSelectedEquipmentSelector,
  allSelectedCateringSelector,
  availableEquipmentSelector,
  selectedEquipmentSelector,
  addedEquipmentSelector,
  addedEquipmentSavedSelector,
  availableCateringSelector,
  tempTimezoneSelector,
  isCreateSelector,
  reservationIdSelector,
  hasResourcesOnHoldSelector,
  removedResourcesSelector,
  resourcesOnHoldSelector,
  exchangeEventIdSelector,
  detailPageRouteSelector,
  newResourcesSelector,
  roomsSelector,
  reservedResourcesSelector,
  selectedCateringsSelector,
  foodOrdersSelector,
  cateringTotalCostSelector,
  equipmentTotalCostSelector,
  isEquipmentCostsSameCurrencySelector,
  isCateringCostsSameCurrencySelector,
  estimatedResourceCostSelector,
  orderedCateringsSelector,
  toBeUpdatedCateringsSelector,
  editModeSelector,
  isEditingSeriesOccurrenceSelector,
  selectedResourceSelector,
  selectedResourceRoomSelector,
  selectedResourceExceptionsSelector,
  selectedResourceResolvedCountSelector,
  selectedResourceSelectedExceptionSelector,
  selectedResourceExceptionRoomsSelector,
  resolvedExceptionsStartDatesSelector,
  allResolvedExceptionsSelector,
  allResolvedResourcesGroupStartDateSelector,
  allHoldExceptionsSelector,
  dataSelector,
  initUpdatedDataSelector,
  allExceptionsSelector,
  eventStartSelector,
  eventEndSelector,
  eventStartandEndSelector,
  hasReservationCostSelector,
  seriesICalUIdSelector,
};
