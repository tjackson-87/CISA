/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2022 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/20/2024
  Name: Mike Tremblay
*/
import { createSelector } from "reselect";
import { sortBy, isEmpty } from "lodash";
import { ReservationUtils, EquipmentUtils } from "../../utils";

const subjectSelector = ({ savedReservation }) =>
  !savedReservation.data ? "" : savedReservation.data.subject;

const additionalLocationInfoSelector = ({ savedReservation }) =>
  !savedReservation.data ||
  savedReservation.data.additionalLocationInfo === undefined
    ? ""
    : savedReservation.data.additionalLocationInfo;

const descriptionSelector = ({ savedReservation }) =>
  !savedReservation.data ? "" : savedReservation.data.description;

const onlineMeetingSelector = ({ savedReservation }) =>
  !savedReservation.data ? null : savedReservation.data.onlineMeeting;

const allResourcesSelector = ({ savedReservation, router, eventDetails }) => {
  const location = router.location.state;
  if (location && location.routedFromEventDetailPage) {
    return !eventDetails.event || !eventDetails.event.rooms
      ? null
      : eventDetails.event.rooms;
  }
  return !savedReservation.data || !savedReservation.data.resources
    ? null
    : savedReservation.data.resources;
};

const detailPageRouteSelector = ({ router }) => {
  const path =
    router.location.state && router.location.state.routedFromEventDetailPage;
  return !(isEmpty(path) && !path);
};

const resourcesSelector = createSelector(
  [allResourcesSelector],
  (resources) => {
    if (!resources) return null;
    return resources.filter((item) => !item.removed);
  }
);

const orderedResourcesSelector = createSelector(
  [resourcesSelector, detailPageRouteSelector],
  (resources, path) => {
    const resourceList = [];
    if (!isEmpty(resources)) {
      resources.forEach((resourceItem) => {
        const resource = { ...resourceItem };
        resource.isUnavailable = !ReservationUtils.isAvailable(
          path ? resource.status : resource.data.statusENUS
        );
        resource.hasUnavailableSelectedEquipment = !EquipmentUtils.isResourceSelectedEquipmentAvailable(
          resource
        );
        resourceList.push(resource);
      });
      return sortBy(resourceList, ["room.building", "room.floor", "room.name"]);
    }
    return resourceList;
  }
);

const nonOrderedAttendeesSelector = ({ savedReservation }) =>
  !savedReservation.data || !savedReservation.data.attendees
    ? null
    : savedReservation.data.attendees;

const attendeesSelector = createSelector(
  [nonOrderedAttendeesSelector],
  (attendees) => {
    if (attendees) {
      const attendeesNew = attendees.map((a) => {
        const displayName =
          a.firstName && a.firstName === a.lastName
            ? a.firstName
            : a.displayName;
        return { ...a, displayName };
      });
      return sortBy(attendeesNew, ["displayName"]);
    } else return null;
  }
);

const allSelectedCateringSelector = createSelector(
  [resourcesSelector],
  (resources) => {
    const selectedCatering = [];
    if (resources !== null)
      resources.forEach((r) => {
        if (!isEmpty(r.selectedCatering))
          r.selectedCatering.forEach((s) => {
            selectedCatering.push({ ...s, resourceId: r.data._id });
          });
      });
    return selectedCatering;
  }
);

const savedReservationLoadedSelector = ({ savedReservation }) =>
  savedReservation.reservationLoaded;

const exchangeEventIdSelector = ({ savedReservation }) =>
  savedReservation.exchangeEventId;

const accountCodeEquipmentSelector = ({ savedReservation }) =>
  savedReservation.data == null
    ? null
    : savedReservation.data.accountCodeEquipment;

const accountCodeFoodSelector = ({ savedReservation }) =>
  savedReservation.data == null ? null : savedReservation.data.accountCodeFood;

const accountCodeRoomSelector = ({ savedReservation }) =>
  savedReservation.data == null ? null : savedReservation.data.accountCodeRoom;

const savedReservationIdSelector = ({ savedReservation }) =>
  savedReservation.data?.reservationId;

export const SavedReservationSelectors = {
  subjectSelector,
  additionalLocationInfoSelector,
  descriptionSelector,
  attendeesSelector,
  orderedResourcesSelector,
  onlineMeetingSelector,
  exchangeEventIdSelector,
  accountCodeEquipmentSelector,
  accountCodeFoodSelector,
  accountCodeRoomSelector,
  allSelectedCateringSelector,
  savedReservationLoadedSelector,
  savedReservationIdSelector,
};
