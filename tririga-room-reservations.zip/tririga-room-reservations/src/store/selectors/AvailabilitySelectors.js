/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import { createSelector } from "reselect";
import { isEmpty, isNil } from "lodash";
import groupBy from "lodash/groupBy";
import keyBy from "lodash/keyBy";
import moment from "moment-timezone";
import { ExchangeConstants } from "../../utils";
import { ORGANIZATION_USER } from "../../model/exchange/ExchangePeople";
import { ReservationSelectors } from "./ReservationSelectors";
import { ExchangeSelectors } from "../reducers/ExchangeReducer";

function computeAttendeesSchedule(
  attendees = [],
  attendeesExchangeSchedule,
  currentUserExchangeProfile,
  timezone
) {
  const attendeesList = [];
  if (!isNil(currentUserExchangeProfile)) {
    if (
      !attendees?.some(
        (attendee) => attendee.email === currentUserExchangeProfile.email
      )
    ) {
      attendeesList.push({
        ...currentUserExchangeProfile,
      });
    }
  }
  if (!isEmpty(attendees)) attendeesList.push(...attendees);
  if (isEmpty(attendeesExchangeSchedule)) return attendeesList;
  const attendeesExchangeScheduleMap = keyBy(
    attendeesExchangeSchedule,
    "scheduleId"
  );

  return attendeesList.map((attendee) => {
    if (attendee.type === ORGANIZATION_USER) {
      let scheduleItems;
      const attendeeSchedule = attendeesExchangeScheduleMap[attendee.email];
      if (!isEmpty(attendeeSchedule?.scheduleItems)) {
        scheduleItems = attendeeSchedule.scheduleItems.map((item) => {
          return {
            ...item,
            start: moment.tz(item.start.dateTime, timezone).toISOString(true),
            end: moment.tz(item.end.dateTime, timezone).toISOString(true),
          };
        });
      }
      return {
        ...attendee,
        ...attendeesExchangeScheduleMap[attendee.email],
        scheduleItems,
      };
    } else {
      return attendee;
    }
  });
}

const attendeesExchangeScheduleSelector = ({ availability }) =>
  !availability.attendeesExchangeSchedule
    ? null
    : availability.attendeesExchangeSchedule;

const attendeesExchangeScheduleForDaySelector = ({ availability }) =>
  !availability.attendeesExchangeScheduleForDay
    ? null
    : availability.attendeesExchangeScheduleForDay;

const resourceEventsForDaySelector = ({ availability }) =>
  !availability.resourcesEventsForDay
    ? null
    : availability.resourcesEventsForDay;

const resourcesAvailabilitySelector = ({ availability }) =>
  !availability.resourcesAvailability
    ? null
    : availability.resourcesAvailability;

const attendeesScheduleSelector = createSelector(
  [
    ReservationSelectors.attendeesSelector,
    attendeesExchangeScheduleSelector,
    ExchangeSelectors.currentCalenderProfileSelector,
    ReservationSelectors.tempTimezoneSelector,
  ],
  (
    attendees,
    attendeesExchangeSchedule,
    currentUserExchangeProfile,
    timezone
  ) => {
    return computeAttendeesSchedule(
      attendees,
      attendeesExchangeSchedule,
      currentUserExchangeProfile,
      timezone
    );
  }
);

const attendeesScheduleForDaySelector = createSelector(
  [
    ReservationSelectors.attendeesSelector,
    attendeesExchangeScheduleForDaySelector,
    ExchangeSelectors.currentCalenderProfileSelector,
    ReservationSelectors.tempTimezoneSelector,
  ],
  (
    attendees,
    attendeesExchangeScheduleForDay,
    currentUserExchangeProfile,
    timezone
  ) => {
    return computeAttendeesSchedule(
      attendees,
      attendeesExchangeScheduleForDay,
      currentUserExchangeProfile,
      timezone
    );
  }
);

const resourcesAvailableSelector = createSelector(
  [
    ReservationSelectors.orderedResourcesSelector,
    resourcesAvailabilitySelector,
  ],
  (resources, resourcesAvailable) => {
    if (isEmpty(resources) || isEmpty(resourcesAvailable)) return 0;
    const resourcesAvailableMap = resourcesAvailable.reduce(
      (map, obj) => map.set(obj._id, obj),
      new Map()
    );

    return resources.filter(
      (resource) =>
        resourcesAvailableMap.has(resource.data.roomId) &&
        resourcesAvailableMap.get(resource.data.roomId)._isAvailable
    ).length;
  }
);

const exchangeAttendeesAvailableSelector = createSelector(
  [attendeesScheduleSelector],
  (attendeesSchedule) => {
    let count = 0;
    const exchangeAttendeesSchedule = attendeesSchedule.filter(
      (attendee) => attendee.type === ORGANIZATION_USER
    );
    const busyTypes = [
      ExchangeConstants.AVAILABILTY_TYPES.TENTATIVE,
      ExchangeConstants.AVAILABILTY_TYPES.BUSY,
      ExchangeConstants.AVAILABILTY_TYPES.OUT_OF_OFFICE,
      ExchangeConstants.AVAILABILTY_TYPES.WORKING_ELSEWHERE,
    ];

    const regex = new RegExp(busyTypes.join("|"));

    for (const { availabilityView } of exchangeAttendeesSchedule) {
      if (!regex.test(availabilityView)) count++;
    }

    return count;
  }
);

const resourcesScheduleForDaySelector = createSelector(
  [
    resourceEventsForDaySelector,
    ReservationSelectors.orderedResourcesSelector,
    ReservationSelectors.tempTimezoneSelector,
  ],
  (resourceEvents, resources, timezone) => {
    if (isEmpty(resources)) return null;
    const eventsByResources = groupBy(resourceEvents, "_Context_Id");

    return resources.map((resource) => {
      const scheduleItems = eventsByResources[resource.data.roomId];
      return {
        ...resource,
        scheduleItems: isEmpty(scheduleItems)
          ? []
          : scheduleItems.map((event) => {
              return {
                id: event._Event_Id,
                subject: event._Name,
                status: event._FreeBusyType.toLowerCase(),
                start: moment
                  .tz(event._Start_Datetime, timezone)
                  .toISOString(true),
                end: moment.tz(event._End_Datetime, timezone).toISOString(true),
              };
            }),
      };
    });
  }
);

export const AvailabilitySelectors = {
  attendeesScheduleSelector,
  attendeesScheduleForDaySelector,
  resourcesScheduleForDaySelector,
  resourcesAvailableSelector,
  exchangeAttendeesAvailableSelector,
};
