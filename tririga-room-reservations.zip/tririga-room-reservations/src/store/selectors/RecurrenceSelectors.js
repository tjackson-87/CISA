/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import moment from "moment-timezone";
import { createSelector } from "reselect";

import {
  getMomentFrom,
  RecurrenceConstants,
  getRecurPropName,
  ReservationUtils,
} from "../../utils";
import { defaultTo } from "lodash";
import { ReservationSelectors } from "./ReservationSelectors";

const reserveContextRecurrenceSelector = createSelector(
  [ReservationSelectors.dateAndTimeSelector],
  (dateAndTime) => {
    return buildReserveContextRecurrence(dateAndTime);
  }
);

const tempReserveContextRecurrenceSelector = createSelector(
  [ReservationSelectors.timeStepTempDateAndTimeSelector],
  (dateAndTime) => {
    return buildReserveContextRecurrence(dateAndTime);
  }
);

function buildReserveContextRecurrence({ timezone, recurrence }) {
  if (
    !recurrence ||
    (recurrence &&
      recurrence.type === RecurrenceConstants.RECUR_TYPE_VALUES.NONE)
  )
    return null;

  const type = recurrence.type;

  const propName = getRecurPropName(type);
  const properties = { ...recurrence[propName] };
  const end = { ...recurrence.end };

  if (type === RecurrenceConstants.RECUR_TYPE_VALUES.WEEKLY) {
    properties.weeklyDays = properties.weeklyDays
      .map((checked, idx) =>
        checked ? RecurrenceConstants.WEEK_DAYS[idx] : null
      )
      .filter((dayOfWeek) => dayOfWeek);
  }

  if (
    type === RecurrenceConstants.RECUR_TYPE_VALUES.MONTHLY ||
    type === RecurrenceConstants.RECUR_TYPE_VALUES.YEARLY
  ) {
    if (
      properties.weekOfMonth === RecurrenceConstants.RECUR_WEEK_OF_VALUES.DAY
    ) {
      properties.dayOfMonth = parseInt(properties.dayOfMonth);
      delete properties.dayOfWeek;
      delete properties.weekOfMonth;
    } else {
      // default to 0 required because field in BO defaults to 1
      properties.dayOfMonth = 0;
    }
  }

  if (type !== RecurrenceConstants.RECUR_TYPE_VALUES.YEARLY) {
    // defaulting to 1 because the scenario daily weekday/weekend day requires 1
    properties.interval =
      type === RecurrenceConstants.RECUR_TYPE_VALUES.DAILY &&
      properties.type !== RecurrenceConstants.RECUR_DAILY_VALUES.DAY
        ? 1
        : parseInt(properties.interval);
  }

  switch (end.type) {
    case RecurrenceConstants.RECUR_END_VALUES.END_AFTER:
      end.numberOfOccurrencesBeforeEnd = parseInt(
        end.numberOfOccurrencesBeforeEnd
      );
      delete end.endDate;
      break;
    case RecurrenceConstants.RECUR_END_VALUES.END_DATE:
      end.endDate = getMomentFrom(
        end.endDate,
        "11:59",
        "PM",
        timezone
      ).toISOString(true);
      // default to 0 required because field in BO defaults to 1
      end.numberOfOccurrencesBeforeEnd = 0;
      break;
    default:
      // default to 0 required because field in BO defaults to 1
      end.numberOfOccurrencesBeforeEnd = 0;
      delete end.endDate;
      break;
  }

  return {
    type,
    [propName]: { ...properties, end },
  };
}

const timeStepTempRecurrenceParamsSelector = createSelector(
  [
    ReservationSelectors.timeStepTempStartAndEndDateSelector,
    tempReserveContextRecurrenceSelector,
  ],
  (startAndEndDate, reserveContextRecurrence) => {
    return ReservationUtils.buildRecurrenceParams(
      startAndEndDate,
      reserveContextRecurrence
    );
  }
);

const exchangeRecurrenceParams = createSelector(
  [
    ReservationSelectors.startAndEndDateSelector,
    reserveContextRecurrenceSelector,
  ],
  (startAndEndDate, reserveContextRecurrence) => {
    if (
      !reserveContextRecurrence ||
      reserveContextRecurrence?.type ===
        RecurrenceConstants.RECUR_TYPE_VALUES.NONE
    )
      return;

    const type = reserveContextRecurrence.type;
    const properties = reserveContextRecurrence[getRecurPropName(type)];
    const pattern = buildExchangeRecurrencePattern(properties, type);
    const range = buildExchangeRecurrenceRange(properties.end);
    return {
      pattern,
      range: {
        startDate: moment(startAndEndDate.startDate).format("YYYY-MM-DD"),
        ...range,
      },
    };
  }
);

function buildExchangeRecurrencePattern(properties, type) {
  const interval = defaultTo(properties.interval, 1);

  switch (type) {
    case RecurrenceConstants.RECUR_TYPE_VALUES.WEEKLY:
      return {
        type: RecurrenceConstants.EXCHANGE_TYPE_VALUES.WEEKLY,
        interval,
        daysOfWeek: properties.weeklyDays.map((item) => item.toLowerCase()),
      };
    case RecurrenceConstants.RECUR_TYPE_VALUES.MONTHLY:
      if (
        properties.type ===
        RecurrenceConstants.RECUR_MONTH_VALUES.DAY_OF_EVERY_MONTH
      ) {
        return {
          type: RecurrenceConstants.EXCHANGE_TYPE_VALUES.ABSOLUTE_MONTHLY,
          interval,
          dayOfMonth: properties.dayOfMonth,
        };
      } else {
        return {
          type: RecurrenceConstants.EXCHANGE_TYPE_VALUES.RELATIVE_MONTHLY,
          interval,
          daysOfWeek: computeDaysOfWeek(properties.dayOfWeek),
          index: properties.weekOfMonth.toLowerCase(),
        };
      }
    case RecurrenceConstants.RECUR_TYPE_VALUES.YEARLY:
      if (
        properties.type === RecurrenceConstants.RECUR_YEAR_VALUES.DAY_OF_MONTH
      ) {
        return {
          type: RecurrenceConstants.EXCHANGE_TYPE_VALUES.ABSOLUTE_YEARLY,
          interval,
          dayOfMonth: properties.dayOfMonth,
          month: computeMonthValue(properties.month),
        };
      } else {
        return {
          type: RecurrenceConstants.EXCHANGE_TYPE_VALUES.RELATIVE_YEARLY,
          interval,
          daysOfWeek: computeDaysOfWeek(properties.dayOfWeek),
          index: properties.weekOfMonth.toLowerCase(),
          month: computeMonthValue(properties.month),
        };
      }
    default:
      if (properties.type === RecurrenceConstants.RECUR_DAILY_VALUES.DAY) {
        return {
          type: RecurrenceConstants.EXCHANGE_TYPE_VALUES.DAILY,
          interval,
        };
      } else {
        return {
          type: RecurrenceConstants.EXCHANGE_TYPE_VALUES.WEEKLY,
          interval,
          daysOfWeek:
            properties.type === RecurrenceConstants.RECUR_DAILY_VALUES.WEEKDAY
              ? RecurrenceConstants.EXCHANGE_WEEKDAYS
              : RecurrenceConstants.EXCHANGE_WEEKEND_DAYS,
        };
      }
  }
}

function buildExchangeRecurrenceRange(end) {
  switch (end.type) {
    case RecurrenceConstants.RECUR_END_VALUES.END_AFTER:
      return {
        type: RecurrenceConstants.EXCHANGE_END_VALUES.END_AFTER,
        numberOfOccurrences: end.numberOfOccurrencesBeforeEnd,
      };
    case RecurrenceConstants.RECUR_END_VALUES.END_DATE:
      return {
        type: RecurrenceConstants.EXCHANGE_END_VALUES.END_DATE,
        endDate: moment(end.endDate).format("YYYY-MM-DD"),
      };
    default:
      return { type: RecurrenceConstants.EXCHANGE_END_VALUES.NO_END_DATE };
  }
}

function computeDaysOfWeek(dayOfWeek) {
  if (!dayOfWeek) return [];
  switch (dayOfWeek) {
    case RecurrenceConstants.RECUR_DAY_OF_WEEK_VALUES.DAY:
      return [
        ...RecurrenceConstants.EXCHANGE_WEEKDAYS,
        ...RecurrenceConstants.EXCHANGE_WEEKEND_DAYS,
      ];
    case RecurrenceConstants.RECUR_DAY_OF_WEEK_VALUES.WEEKDAY:
      return RecurrenceConstants.EXCHANGE_WEEKDAYS;
    case RecurrenceConstants.RECUR_DAY_OF_WEEK_VALUES.WEEKEND_DAY:
      return RecurrenceConstants.EXCHANGE_WEEKEND_DAYS;
    default:
      return [dayOfWeek.toLowerCase()];
  }
}

function computeMonthValue(month) {
  if (!month) return 1;
  const months = Object.values(RecurrenceConstants.MONTHS);
  const idx = months.findIndex((item) => item === month);
  return idx > -1 ? idx + 1 : 1;
}

export const RecurrenceSelectors = {
  reserveContextRecurrenceSelector,
  timeStepTempRecurrenceParamsSelector,
  exchangeRecurrenceParams,
};
