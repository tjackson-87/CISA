/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/

import { createSelector } from "reselect";
import isEmpty from "lodash/isEmpty";
import { DefaultValues, Routes } from "../../utils";
import { LocationSelectors } from "../reducers/LocationReducer";
import { ReservationSelectors } from "./ReservationSelectors";
import { RecurrenceSelectors } from "./RecurrenceSelectors";

const isSearchingOnlyFavoritesSelector = (state) =>
  isEmpty(LocationSelectors.selectedBuildingSelector(state));

const filtersSelector = ({ roomSearch }) => roomSearch.filters;
const floorSelector = ({ roomSearch }) => roomSearch?.filters?.floor;
const roomsFilterSelector = ({ roomSearch }) => roomSearch?.filters?.rooms;
const rememberFloorplanLastPositionSelector = ({ roomSearch }) =>
  roomSearch?.rememberFloorplanLastPosition;

const roomSearchResultSelector = ({ roomSearch }) => roomSearch.result;
const roomSearchScannedResultSelector = ({ roomSearch }) =>
  roomSearch.scannedResult;
const hasMoreResultsSelector = ({ roomSearch }) => roomSearch.hasMoreResults;
const pageFromSelector = ({ roomSearch }) =>
  roomSearch.pageFrom != null ? roomSearch.pageFrom : 0;
const totalSizeSelector = ({ roomSearch }) =>
  roomSearch.totalSize != null ? roomSearch.totalSize : 0;
const scannerTypeSelector = ({ roomSearch }) => roomSearch.scannerType;
const roomSearchByNameSelector = ({ roomSearch }) =>
  roomSearch.searchByNameResult;
const SelectedRoomSearchByNameSelector = ({ roomSearch }) =>
  roomSearch.selectedRoomByName;
const totalCountSelector = ({ roomSearch }) =>
  roomSearch.total != null ? roomSearch.total : 0;
const hasMoreResultsInSearchSelector = ({ roomSearch }) =>
  roomSearch.moreResults;

const filtersCountSelector = createSelector(
  [filtersSelector, LocationSelectors.selectedBuildingSelector],
  (filters, selectedBuilding) => {
    let count = 1;
    if (filters) {
      const filtersKeys = Object.keys(filters);
      if (filtersKeys.length > 0) {
        count = filtersKeys.reduce((count, item) => {
          const filterItem = filters[item];
          return (item === "capacity" &&
            filterItem === DefaultValues.CAPACITY) ||
            (item === "layoutType" &&
              filterItem.internalValue ===
                DefaultValues.LAYOUT_TYPE.internalValue) ||
            (item === "amenities" &&
              Object.values(filterItem).indexOf(true) === -1) ||
            (item === "showUnavailable" &&
              filterItem === DefaultValues.SHOW_UNAVAILABLE_ROOMS) ||
            // Collateral types CISA
            (item === "showCollateralTypeOnly" &&
              filterItem === DefaultValues.SHOW_COLLATERAL_TYPE_ROOMS) ||
            (item === "showFavoritesOnly" &&
              (isEmpty(selectedBuilding) ||
                filterItem === DefaultValues.SHOW_FAVORITES_ONLY)) ||
            (item === "showRequestableRooms" &&
              filterItem !== DefaultValues.SHOW_REQUESTABLE_ROOMS) ||
            (item === "showPrivateRooms" &&
              filterItem === DefaultValues.SHOW_PRIVATE_ROOMS) ||
            item === "floor" ||
            item === "rooms"
            ? count
            : ++count;
        }, 0);
      }
    }
    return count;
  }
);

const checkedCountSelector = createSelector(
  [roomSearchResultSelector],
  (roomSearchResult) => {
    if (!roomSearchResult) return 0;
    return roomSearchResult.length;
  }
);

const availableCountSelector = createSelector(
  [roomSearchResultSelector],
  (roomSearchResult) => {
    if (!roomSearchResult) return 0;
    return roomSearchResult.filter((room) => room.isAvailable).length;
  }
);

const checkedCountByNameSelector = createSelector(
  [roomSearchByNameSelector],
  (roomSearchResult) => {
    if (!roomSearchResult) return 0;
    return roomSearchResult.length;
  }
);

const availableCountByNameSelector = createSelector(
  [roomSearchByNameSelector],
  (roomSearchResult) => {
    if (!roomSearchResult) return 0;
    return roomSearchResult.filter((room) => room.isAvailable).length;
  }
);

const roomsToDisplaySelector = createSelector(
  [roomSearchResultSelector, filtersSelector],
  (roomSearchResult, filters) => {
    if (!roomSearchResult) return null;
    return filters.showUnavailable
      ? roomSearchResult
      : roomSearchResult.filter((room) => room.isAvailable);
  }
);

const roomsByNameToDisplaySelector = createSelector(
  [roomSearchByNameSelector, filtersSelector],
  (roomSearchResult, filters) => {
    if (!roomSearchResult) return null;
    return filters.showUnavailable
      ? roomSearchResult
      : roomSearchResult.filter((room) => room.isAvailable);
  }
);

const selectedRoomToDisplaySelector = createSelector(
  [SelectedRoomSearchByNameSelector, filtersSelector],
  (roomSearchResult, filters) => {
    if (!roomSearchResult) return null;
    return filters.showUnavailable
      ? roomSearchResult
      : roomSearchResult.filter((room) => room.isAvailable);
  }
);

const searchFiltersSelector = createSelector(
  [
    ReservationSelectors.firstOccurStartAndEndDateSelector,
    filtersSelector,
    RecurrenceSelectors.reserveContextRecurrenceSelector,
  ],
  (startAndEndDate, filters, reserveContextRecurrence) => ({
    startAndEndDate: startAndEndDate,
    filters,
    reserveContextRecurrence,
  })
);

const roomSelector = (state, roomID) => {
  const { EVENT_DETAILS } = Routes;
  if (roomID == null) return null;
  let roomSearchResult = roomSearchResultSelector(state);
  if (
    state.eventDetails.event &&
    state.router.location.pathname.includes(`${EVENT_DETAILS}`)
  ) {
    roomSearchResult = state.eventDetails.event.rooms;
  }
  let room = roomSearchResult?.find(
    (room) => room._id === roomID || room.spaceRecordId === roomID
  );
  if (room == null) {
    const resources = ReservationSelectors.resourcesSelector(state);
    const resource = resources?.find((item) => item.room._id === roomID);
    room = resource?.room;
  }
  return room === undefined ? null : room;
};

const roomViewModeSelector = ({ roomSearch }) =>
  !roomSearch?.roomViewMode ? null : roomSearch.roomViewMode;

const selectedRoomOnFloorplanSelector = ({ roomSearch }) =>
  !roomSearch?.selectedRoom ? null : roomSearch.selectedRoom;

const checkedRoomsSelector = ({ roomSearch }) =>
  !roomSearch?.checkedRooms ? [] : roomSearch.checkedRooms;

const searchTextSelector = ({ roomSearch }) =>
  !roomSearch?.searchText ? "" : roomSearch.searchText;

const locationModalSelector = ({ roomSearch }) =>
  roomSearch.isLocationModalOpen;

const searchColleagueModalSelector = ({ roomSearch }) =>
  roomSearch.isSearchColleagueModalOpen;

const filterModalSelector = ({ roomSearch }) => roomSearch.isFilterModalOpen;
const roomModalSelector = ({ roomSearch }) => roomSearch.isRoomModalOpen;
const recurrenceRoomModalSelector = ({ roomSearch }) =>
  roomSearch.isRoomRecurrenceModalOpen;
const recurrenceModalSelector = ({ roomSearch }) =>
  roomSearch.isRecurrenceModalOpen;

export const RoomSearchSelectors = {
  filtersSelector,
  filtersCountSelector,
  roomSearchResultSelector,
  roomsToDisplaySelector,
  roomSelector,
  hasMoreResultsSelector,
  searchFiltersSelector,
  isSearchingOnlyFavoritesSelector,
  roomViewModeSelector,
  selectedRoomOnFloorplanSelector,
  roomSearchScannedResultSelector,
  scannerTypeSelector,
  pageFromSelector,
  totalSizeSelector,
  checkedCountSelector,
  availableCountSelector,
  floorSelector,
  roomsFilterSelector,
  checkedRoomsSelector,
  roomSearchByNameSelector,
  checkedCountByNameSelector,
  availableCountByNameSelector,
  roomsByNameToDisplaySelector,
  selectedRoomToDisplaySelector,
  SelectedRoomSearchByNameSelector,
  searchTextSelector,
  totalCountSelector,
  hasMoreResultsInSearchSelector,
  locationModalSelector,
  searchColleagueModalSelector,
  filterModalSelector,
  roomModalSelector,
  recurrenceRoomModalSelector,
  recurrenceModalSelector,
  rememberFloorplanLastPositionSelector,
};
