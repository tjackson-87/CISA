/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import { createStore, combineReducers, applyMiddleware, compose } from "redux";
import thunk from "redux-thunk";
import { connectRouter, routerMiddleware } from "connected-react-router";
import { createEpicMiddleware, combineEpics } from "redux-observable";
import { getAppHistory } from "../utils";
// Import Actions
import * as CurrentUserActions from "./actions/CurrentUserActions";
import * as UserBuildingActions from "./actions/UserBuildingActions";
import * as LayoutActions from "./actions/LayoutActions";
import * as LoadingActions from "./actions/LoadingActions";
import * as RouteActions from "./actions/RouteActions";
import * as ReservationActions from "./actions/ReservationActions";
import * as TimezoneActions from "./actions/TimezoneActions";
import * as OnlineMeetingActions from "./actions/OnlineMeetingActions";
import * as ExchangeActions from "./actions/ExchangeActions";
import * as MessageActions from "./actions/MessageActions";
import * as LocationActions from "./actions/LocationActions";
import * as ColleagueActions from "./actions/ColleagueActions";
import * as ApplicationSettingsActions from "./actions/ApplicationSettingsActions";
import * as LayoutTypesActions from "./actions/LayoutTypesActions";
import * as RoomDetailsActions from "./actions/RoomDetailsActions";
import * as LabelStylesActions from "./actions/LabelStylesActions";
import * as RoomSearchActions from "./actions/RoomSearchActions";
import * as MyCalendarActions from "./actions/MyCalendarActions";
import * as EventDetailsActions from "./actions/EventDetailsActions";
import * as CateringActions from "./actions/CateringActions";
import * as EquipmentActions from "./actions/EquipmentActions";
import * as CurrencyActions from "./actions/CurrencyActions";
import * as AvailabilityActions from "./actions/AvailabilityActions";
import * as ReserveEventTypesActions from "./actions/ReserveEventTypesActions";
import * as CheckInActions from "./actions/CheckInActions";
import * as SyncWithOutlookActions from "./actions/SyncWIthOutlookAction";
import * as OAuthProfileActions from "./actions/OAuthProfileActions";
// Import Reducers
import {
  currentUserReducer,
  CurrentUserSelectors,
} from "./reducers/CurrentUserReducer.js";
import { userBuildingReducer } from "./reducers/UserBuildingReducer.js";
import { layoutReducer, LayoutSelectors } from "./reducers/LayoutReducer.js";
import { loadingReducer, LoadingSelectors } from "./reducers/LoadingReducer.js";
import {
  exchangeReducer,
  ExchangeSelectors,
} from "./reducers/ExchangeReducer.js";
import { reservationReducer } from "./reducers/ReservationReducer.js";
import { savedReservationReducer } from "./reducers/SavedReservationReducer.js";
import { messageReducer, MessageSelectors } from "./reducers/MessageReducer.js";
import {
  locationReducer,
  LocationSelectors,
} from "./reducers/LocationReducer.js";
import { 
  colleagueReducer, 
  ColleagueSelectors, 
} from "./reducers/ColleaguesReducer";
import {
  applicationSettingsReducer,
  ApplicationSettingsSelectors,
} from "./reducers/ApplicationSettingsReducer.js";
import {
  layoutTypesReducer,
  LayoutTypesSelectors,
} from "./reducers/LayoutTypesReducer";
import {
  timezonesReducer,
  TimezonesSelectors,
} from "./reducers/TimezoneReducer";
import {
  onlineMeetingReducer,
  OnlineMeetingSelectors,
} from "./reducers/OnlineMeetingReducer";
import {
  roomDetailsReducer,
  RoomDetailsSelectors,
} from "./reducers/RoomDetailsReducer";
import {
  labelStylesReducer,
  LabelStylesSelectors,
} from "./reducers/LabelStylesReducer";
import { roomSearchReducer } from "./reducers/RoomSearchReducer";
import {
  myCalendarReducer,
  MyCalendarSelectors,
} from "./reducers/MyCalendarReducer";
import {
  eventDetailsReducer,
  EventDetailsSelectors,
} from "./reducers/EventDetailsReducer";
import {
  equipmentDetailsReducer,
  EquipmentDetailsSelectors,
} from "./reducers/EquipmentDetailsReducer";
import {
  currenciesReducer,
  CurrenciesSelectors,
} from "./reducers/CurrencyReducer";
import { availabilityReducer } from "./reducers/AvailabilityReducer";
import {
  reserveEventTypesReducer,
  ReserveEventTypesSelectors,
} from "./reducers/ReserveEventTypesReducer";
import {
  syncWithOutlookReducer,
  SyncWithOutlookSelectors,
} from "./reducers/SyncWithOutlookReducer";
// Import Epics
import * as ReservationEpics from "./epics/ReservationEpics";
import * as LoadReservationEpics from "./epics/LoadReservationEpics";
import * as ExchangeEpics from "./epics/ExchangeEpics";
import * as LocationEpics from "./epics/LocationEpics";
import * as RoomDetailsEpic from "./epics/RoomDetailsEpic";
import * as IntegrationEpic from "./epics/IntegrationEpic";
import * as RoomSearchEpic from "./epics/RoomSearchEpic";
import * as MyCalendarEpic from "./epics/MyCalendarEpics";
import * as EventDetailsEpic from "./epics/EventDetailsEpic";
import * as CateringEpics from "./epics/CateringEpics";
import * as EquipmentDetailsEpics from "./epics/EquipmentDetailsEpics";
import * as OnlineMeetingEpic from "./epics/OnlineMeetingEpic";
import * as CurrencyEpics from "./epics/CurrencyEpics";
import * as AvailabilityEpics from "./epics/AvailabilityEpics";
import * as TimezonesEpics from "./epics/TimezonesEpics";
import * as RoomSearchByNameEpic from "./epics/RoomSearchByNameEpic";
import * as ColleagueEpics from "./epics/ColleagueEpics";
// Import Selectors
import { ReservationSelectors } from "./selectors/ReservationSelectors";
import { SavedReservationSelectors } from "./selectors/SavedReservationSelectors";
import { RecurrenceSelectors } from "./selectors/RecurrenceSelectors";
import { RoomSearchSelectors } from "./selectors/RoomSearchSelectors";
import { AvailabilitySelectors } from "./selectors/AvailabilitySelectors";

let appStore = null;

function getAppStore() {
  if (appStore != null) {
    return appStore;
  }
  const appHistory = getAppHistory();
  const composeEnhancers =
    window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;
  const epicMiddleware = createEpicMiddleware();

  const rootReducer = combineReducers({
    loading: loadingReducer,
    currentUser: currentUserReducer,
    userBuildings: userBuildingReducer,
    layout: layoutReducer,
    reservation: reservationReducer,
    savedReservation: savedReservationReducer,
    layoutTypes: layoutTypesReducer,
    location: locationReducer,
    colleague: colleagueReducer,
    router: connectRouter(appHistory),
    exchange: exchangeReducer,
    message: messageReducer,
    applicationSettings: applicationSettingsReducer,
    timezones: timezonesReducer,
    onlineMeetings: onlineMeetingReducer,
    roomDetails: roomDetailsReducer,
    labelStyles: labelStylesReducer,
    roomSearch: roomSearchReducer,
    myCalendar: myCalendarReducer,
    eventDetails: eventDetailsReducer,
    equipmentDetails: equipmentDetailsReducer,
    currencies: currenciesReducer,
    availability: availabilityReducer,
    reserveEventTypes: reserveEventTypesReducer,
    syncWithOutlook: syncWithOutlookReducer,
  });

  const rootEpic = combineEpics(
    ...Object.values(ReservationEpics),
    ...Object.values(LoadReservationEpics),
    ...Object.values(ExchangeEpics),
    ...Object.values(LocationEpics),
    ...Object.values(RoomDetailsEpic),
    ...Object.values(IntegrationEpic),
    ...Object.values(RoomSearchEpic),
    ...Object.values(MyCalendarEpic),
    ...Object.values(EventDetailsEpic),
    ...Object.values(CateringEpics),
    ...Object.values(EquipmentDetailsEpics),
    ...Object.values(CurrencyEpics),
    ...Object.values(AvailabilityEpics),
    ...Object.values(TimezonesEpics),
    ...Object.values(OnlineMeetingEpic),
    ...Object.values(RoomSearchByNameEpic),
    ...Object.values(ColleagueEpics)
  );

  appStore = createStore(
    rootReducer,
    composeEnhancers(
      applyMiddleware(routerMiddleware(appHistory), thunk, epicMiddleware)
    )
  );

  epicMiddleware.run(rootEpic);

  return appStore;
}

export {
  getAppStore,
  CurrentUserActions,
  UserBuildingActions,
  LayoutActions,
  LoadingActions,
  RouteActions,
  ReservationActions,
  LayoutTypesActions,
  LayoutTypesSelectors,
  ReservationSelectors,
  SavedReservationSelectors,
  LocationActions,
  LocationSelectors,
  ColleagueActions,
  ColleagueSelectors,
  CurrentUserSelectors,
  ExchangeActions,
  ExchangeSelectors,
  MessageActions,
  MessageSelectors,
  LayoutSelectors,
  LoadingSelectors,
  ApplicationSettingsActions,
  ApplicationSettingsSelectors,
  TimezoneActions,
  OnlineMeetingActions,
  TimezonesSelectors,
  OnlineMeetingSelectors,
  RoomDetailsActions,
  RoomDetailsSelectors,
  RecurrenceSelectors,
  LabelStylesActions,
  LabelStylesSelectors,
  RoomSearchActions,
  RoomSearchSelectors,
  MyCalendarActions,
  MyCalendarSelectors,
  EventDetailsActions,
  EventDetailsSelectors,
  CateringActions,
  EquipmentActions,
  EquipmentDetailsSelectors,
  CurrencyActions,
  CurrenciesSelectors,
  AvailabilityActions,
  AvailabilitySelectors,
  ReserveEventTypesActions,
  ReserveEventTypesSelectors,
  CheckInActions,
  SyncWithOutlookActions,
  SyncWithOutlookSelectors,
  OAuthProfileActions,
};
