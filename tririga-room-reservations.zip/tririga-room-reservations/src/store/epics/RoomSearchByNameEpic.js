/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/

import { ofType } from "redux-observable";
import { map } from "rxjs/operators";

import { RoomSearchActions } from "..";
import { roomSearchActionTypes } from "../../utils";

const {
  SET_FLOOR_FILTER,
  UPDATE_FILTERS,
  UPDATE_CAPACITY_FILTERS,
  SET_SELECTED_ROOMS,
} = roomSearchActionTypes;

export function searchRoomsByNameEpic(action$, state$) {
  return action$.pipe(
    ofType(
      SET_FLOOR_FILTER,
      UPDATE_FILTERS,
      UPDATE_CAPACITY_FILTERS,
      SET_SELECTED_ROOMS
    ),
    map(() => RoomSearchActions.searchRoomByName())
  );
}
