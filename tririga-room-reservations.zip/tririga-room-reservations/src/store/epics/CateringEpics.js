/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import { ofType } from "redux-observable";
import { map, filter } from "rxjs/operators";
import { CateringActions, ReservationSelectors } from "..";
import { reservationActionTypes, ReservationTypes } from "../../utils";

export function getMenuItemsEpic(action$, state$) {
  return action$.pipe(
    ofType(
      reservationActionTypes.SET_RESOURCES_ON_HOLD,
      reservationActionTypes.SET_RESERVED_RESOURCES
    ),
    filter(
      () =>
        ReservationSelectors.reservationTypeSelector(state$.value) ===
        ReservationTypes.MEETING
    ),
    map(() => CateringActions.getMenuItemsForAllResources())
  );
}
