/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/

import { LOCATION_CHANGE } from "connected-react-router";
import { ofType } from "redux-observable";
import { from } from "rxjs";
import { map, filter, mergeMap, debounceTime } from "rxjs/operators";
import { isEqual, isEmpty } from "lodash";

import {
  RoomSearchActions,
  RoomSearchSelectors,
  LabelStylesActions,
  CurrentUserSelectors,
  LocationSelectors,
  LocationActions,
  getAppStore,
  ColleagueSelectors,
} from "..";
import {
  roomSearchActionTypes,
  Routes,
  currentUserActionTypes,
  locationActionTypes,
} from "../../utils";
import { ReservationSelectors } from "../selectors/ReservationSelectors";

const {
  INIT_ROOM_SEARCH,
  SET_FLOOR_FILTER,
  SET_ROOMS_FILTER,
  UPDATE_FILTERS,
  UPDATE_CAPACITY_FILTERS,
} = roomSearchActionTypes;

export function searchRoomsEpic(action$, state$) {
  return action$.pipe(
    ofType(
      LOCATION_CHANGE,
      INIT_ROOM_SEARCH,
      SET_FLOOR_FILTER,
      SET_ROOMS_FILTER,
      UPDATE_FILTERS,
      UPDATE_CAPACITY_FILTERS,
      currentUserActionTypes.SET_FAVORITE_ROOMS,
      locationActionTypes.SET_SELECTED_BUILDING
    ),
    filter(() => needRefreshRooms(state$.value)),
    debounceTime(300),
    map(() => RoomSearchActions.searchRooms())
  );
}

export function selectedFloorChangedEpic(action$, state$) {
  return action$.pipe(
    ofType(SET_FLOOR_FILTER),
    map(() => RoomSearchActions.setRememberFloorplanLastPosition(false))
  );
}

export function setInitialFloorFilterEpic(action$, state$) {
  return action$.pipe(
    ofType(locationActionTypes.SET_FLOORS),
    mergeMap(({ floors }) => {
      let floor = null;
      const actions = [];
      if (!isEmpty(floors)) {
        const colleagueFloor = ColleagueSelectors.selectedColleagueReservationFloorSelector(
          state$.value
        );
        const selectedFloor =
          colleagueFloor && floors.find((f) => f._id === colleagueFloor._id);
        floor = selectedFloor || floors[0];
      } else {
        actions.push(
          RoomSearchActions.setRoomSearchResult([], false, 0, 0, false)
        );
      }
      actions.push(RoomSearchActions.setFloorFilter(floor));
      return from(actions);
    })
  );
}

let lastFavRooms = null;
let lastException = null;

function needRefreshRooms(state) {
  const searchFilters = RoomSearchSelectors.searchFiltersSelector(state);
  const favRooms = CurrentUserSelectors.favoriteRoomsSelector(state);
  const selectedBuilding = LocationSelectors.selectedBuildingSelector(state);
  const lastMeetingSearchFilters = LocationSelectors.lastMeetingSearchFilters(
    state
  );
  const filtersChanged = checkFiltersChanged(
    searchFilters,
    lastMeetingSearchFilters
  );
  const selectedException = ReservationSelectors.selectedResourceSelectedExceptionSelector(
    state
  );
  const searchResult = RoomSearchSelectors.roomSearchResultSelector(state);
  if (
    !isEmpty(state.reservation.data) &&
    favRooms &&
    LocationSelectors.isSelectedBuildingInitializedSelector(state) &&
    state.router.location.pathname.indexOf(`${Routes.SEARCH}`) >= 0 &&
    ((filtersChanged && searchFilters?.filters?.floor != null) ||
      (isEmpty(selectedBuilding) &&
        (favRooms !== lastFavRooms || filtersChanged)) ||
      !isEqual(selectedException, lastException) ||
      !searchResult)
  ) {
    lastFavRooms = favRooms;
    getAppStore().dispatch(
      LocationActions.setLastMeetingSearchFilters(searchFilters)
    );
    lastException = selectedException;
    return true;
  }
  return false;
}

function checkFiltersChanged(prevSearchFilters, searchFilters) {
  return !isEqual(
    removeShowUnavailableProperty(prevSearchFilters),
    removeShowUnavailableProperty(searchFilters)
  );
}

function removeShowUnavailableProperty(searchFilters) {
  if (searchFilters == null) return null;
  const newFilters = {
    ...searchFilters,
    filters: { ...searchFilters.filters },
  };
  delete newFilters.filters.showUnavailable;
  return newFilters;
}

export function getLabelStylesEpic(action$, state$) {
  return action$.pipe(
    ofType(LOCATION_CHANGE),
    filter(() => shouldGetLabelStyles(state$.value)),
    map(() => LabelStylesActions.getLabelStyles())
  );
}

function shouldGetLabelStyles(state) {
  const pathname = state.router.location.pathname;
  return (
    pathname.indexOf(`${Routes.SEARCH}`) >= 0 ||
    pathname.indexOf(`${Routes.EVENT_DETAILS}`) >= 0
  );
}
