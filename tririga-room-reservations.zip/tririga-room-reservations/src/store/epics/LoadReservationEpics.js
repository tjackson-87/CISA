/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/

import { LOCATION_CHANGE } from "connected-react-router";
import { ofType } from "redux-observable";
import { filter, switchMap } from "rxjs/operators";
import { Observable } from "rxjs";
import { groupBy, keyBy, isEmpty, maxBy, isNil } from "lodash";
import Timeout from "await-timeout";
import moment from "moment-timezone";
import { matchPath } from "react-router-dom";
import {
  ReservationDS,
  Exchange,
  ReservationOnlineMeetingDS,
  RecurrenceDS,
  OnlineMeetingDS,
} from "../../model";
import {
  ReservationActions,
  EventDetailsActions,
  CurrentUserActions,
  ApplicationSettingsSelectors,
  MessageActions,
  LoadingActions,
  ExchangeActions,
  RouteActions,
  getAppStore,
  TimezoneActions,
  OnlineMeetingActions,
  ExchangeSelectors,
  CurrentUserSelectors,
  SavedReservationSelectors,
  ReservationSelectors,
  EventDetailsSelectors,
  SyncWithOutlookSelectors,
  SyncWithOutlookActions,
  MyCalendarActions,
} from "..";
import {
  Routes,
  ReservationTypes,
  ReservationUtils,
  ReservationEditMode,
  getRecurrenceInitial,
  RecurrenceConstants,
  Status,
} from "../../utils";
import { getCateringForOccurrence } from "../../utils/Catering/CateringUtils";

export function loadReservationEpic(action$, state$) {
  return action$.pipe(
    ofType(LOCATION_CHANGE),
    filter(
      () =>
        state$.value.router.location.pathname.indexOf(
          Routes.EDIT_RESERVATION
        ) >= 0
    ),
    switchMap(() => loadReservation(state$))
  );
}

export function loadReservationSummaryEpic(action$, state$) {
  return action$.pipe(
    ofType(LOCATION_CHANGE),
    filter(
      () =>
        state$.value.router.location.pathname.indexOf(Routes.COST_SUMMARY) >= 0
    ),
    switchMap(() => loadReservation(state$, false))
  );
}

export function loadNewReservationEpic(action$, state$) {
  return action$.pipe(
    ofType(LOCATION_CHANGE),
    filter(
      () =>
        state$.value.router.location.pathname.indexOf(Routes.EDIT_EVENT) >= 0
    ),
    switchMap(() => loadNewReservation(state$))
  );
}

let synced = false;
export function syncWithOutlook(action$, state$) {
  return action$.pipe(
    filter(
      () =>
        state$.value.router.location.pathname.indexOf(Routes.EVENT_DETAILS) >=
          0 &&
        state$.value.syncWithOutlook.isSyncing &&
        !synced
    ),
    switchMap(() => {
      synced = state$.value.syncWithOutlook.isSyncing;
      getAppStore().dispatch(
        LoadingActions.setLoading("syncWithOutlook", true)
      );
      return loadReservation(state$, false);
    })
  );
}

function loadReservation(state$, shouldReplaceURL = true) {
  return new Observable(async (subscriber) => {
    try {
      getAppStore().dispatch(
        LoadingActions.setLoading("loadingReservation", true)
      );
      let reservationParams = getReservationParamsFromRoute(state$);
      const isSyncingWithOutlook = SyncWithOutlookSelectors.isSyncingSelector(
        getAppStore().getState()
      );
      if (!reservationParams && isSyncingWithOutlook) {
        const {
          reservationId: id,
          seriesReservationId,
        } = EventDetailsSelectors.eventDetailsSelector(state$.value);
        const reservationId = seriesReservationId || id;
        reservationParams = {
          reservationId,
          editMode: seriesReservationId
            ? ReservationEditMode.SERIES
            : ReservationEditMode.OCCURRENCE,
        };
      }
      if (reservationParams === null) {
        throw new Error("Reservation id parameter was not found.");
      }
      let reservation = "";
      if (!shouldReplaceURL) {
        attemptMade = 10;
        reservation = await waitUntilCateringInstanceIsCreated(
          reservationParams
        );
      } else {
        reservation = await getReservation(reservationParams);
      }

      const { eventDetails } = state$.value;
      if (reservation == null) {
        throw new Error("Reservation was not found.");
      }

      reservation = {
        ...reservation,
        reservationAllSpaces: reservation.reservationSpaces.data,
      };

      reservation.reservationSpaces.data = getComputeLoadedReservationSpaceData(
        reservation.reservationSpaces.data
      );

      const { id: calendarId } =
        ExchangeSelectors.currentCalendarSelector(state$.value) || {};
      const exchangeEvent = await getExchangeEventAssociatedToReservation(
        state$,
        reservation,
        reservationParams.editMode,
        calendarId
      );
      const combinedReservation = combineReservationAndExchangeEvent(
        reservation,
        exchangeEvent,
        reservationParams.editMode,
        eventDetails.Extension,
        state$
      );
      if (!isEmpty(exchangeEvent)) {
        await getAppStore().dispatch(CurrentUserActions.getDefaultTimezone());
        const {
          currentUser: { defaultTimezone },
        } = state$.value;
        combinedReservation.recurrence = await getRecurrencePropertiesFromExchangeEvent(
          exchangeEvent,
          defaultTimezone
        );
      } else {
        combinedReservation.recurrence = await getRecurrenceInfo(reservation);
      }
      if (combinedReservation.recurrence) {
        combinedReservation.recurrence.details.ruleLabel = `Repeats ${combinedReservation.recurrence.details.ruleLabel}`;
      }
      let isReservationSeriesWithException, myCalendarEvents;
      if (
        combinedReservation.recurrence &&
        combinedReservation.reservationType === ReservationTypes.MEETING
      ) {
        myCalendarEvents = getAppStore()
          .getState()
          .myCalendar?.events?.filter(
            (ev) =>
              parseInt(ev.seriesReservationId) ===
              parseInt(combinedReservation.reservationId)
          );
        isReservationSeriesWithException = myCalendarEvents?.some(
          (ev) => ev.isRecurringException
        );
      } else if (
        combinedReservation.reservationType === ReservationTypes.WORKSPACE &&
        eventDetails.event.isRecurringReservation
      ) {
        myCalendarEvents = getAppStore()
          .getState()
          .myCalendar?.events?.filter(
            (ev) =>
              ev.seriesReservationId === eventDetails.event.seriesReservationId
          );
        isReservationSeriesWithException = myCalendarEvents?.some(
          (ev) => ev.isRecurringException
        );
      }
      await getAppStore().dispatch(
        ReservationActions.loadReservation(
          combinedReservation,
          shouldReplaceURL
        )
      );

      if (isReservationSeriesWithException) {
        subscriber.next(
          ReservationActions.setIsReservationSeriesWithExceptionData({
            isReservationSeriesWithException,
            seriesMasterId: myCalendarEvents[0].seriesMasterId,
            seriesReservationId: myCalendarEvents[0].seriesReservationId,
          })
        );
      }

      if (!shouldReplaceURL) {
        await getAppStore().dispatch(EventDetailsActions.fetchEvent());
        getAppStore().dispatch(
          ReservationActions.setSavedReservationLoadedFlag(true)
        );
      }

      getAppStore().dispatch(
        LoadingActions.setLoading("loadingReservation", false)
      );

      const reservedResources = loadReservedResources(
        subscriber,
        reservation.reservationSpaces
      );
      loadReservedEquipment(
        subscriber,
        reservedResources,
        reservation.equipmentOrders
      );
      loadReservedCatering(subscriber, reservedResources, reservation);
      if (!isEmpty(exchangeEvent) && eventDetails.Extension?.onlineMeetingID) {
        await loadOnlineMeeting(state$, subscriber, eventDetails.Extension);
      } else {
        await loadOnlineMeeting(state$, subscriber, reservation);
      }
      await loadReservationAttendees(
        subscriber,
        reservation,
        exchangeEvent,
        reservation.reservationAllSpaces
      );
      getAppStore().dispatch(
        ReservationActions.setInitUpdatedData(
          ReservationSelectors.dataSelector(state$.value)
        )
      );
      if (isSyncingWithOutlook) {
        const reservationExceptions = await ReservationDS.getReservationExceptions(
          reservation._id
        );
        await getAppStore().dispatch(ReservationActions.submitReservation());
        const loadAllExceptionReservations = [];
        for (let i = 0; i < reservationExceptions.length; i++) {
          const loadExceptionReservation = await loadExceptionReservationSyncWithOutlook(
            state$,
            reservationExceptions[i].exceptionId,
            subscriber
          );
          loadAllExceptionReservations.push(loadExceptionReservation);
        }
        await Promise.all(loadAllExceptionReservations);
      }
    } catch (err) {
      console.error(err);
      subscriber.next(MessageActions.showGeneralError());
      await Timeout.set(5000);
      subscriber.next(RouteActions.navigateToHomePage(true));
    } finally {
      getAppStore().dispatch(
        LoadingActions.setLoading("loadingReservation", false)
      );
      if (synced) {
        getAppStore().dispatch(
          LoadingActions.setLoading("syncWithOutlook", false)
        );
        synced = false;
        getAppStore().dispatch(SyncWithOutlookActions.reset());
        getAppStore().dispatch(MyCalendarActions.refreshMyCalendar());
        subscriber.next(RouteActions.navigateToHomePage(true));
      }
      subscriber.complete();
    }
  });
}

// This is not an ideal solution until we figure out an enhancement or a custom task to handle async workflow process
let attemptMade = 10;
const WAITING_TIME = Math.floor(Math.random() * 1000) + 1500;
async function waitUntilCateringInstanceIsCreated(reservationParams) {
  await new Promise((resolve) =>
    setTimeout(() => {
      resolve("done");
    }, WAITING_TIME)
  );
  const instance = await getReservation(reservationParams);
  const catering = instance.foodOrderItems.data;
  if ((!instance || !catering) && attemptMade > 0) {
    attemptMade--;
    return waitUntilCateringInstanceIsCreated(reservationParams);
  } else if (instance) {
    return instance;
  }
}

function getReservationParamsFromRoute(state$) {
  let match = matchPath(state$.value.router.location.pathname, {
    path: `${Routes.EDIT_RESERVATION}/:reservationId/:editMode/:start/:end`,
  });
  if (match == null) {
    match = matchPath(state$.value.router.location.pathname, {
      path: `${Routes.EDIT_RESERVATION}/:reservationId/:editMode`,
    });
  }

  if (match != null) {
    const params = {
      reservationId: match.params.reservationId,
      editMode: match.params.editMode,
    };
    if (match.params.start != null && match.params.end != null) {
      params.start = moment(Number(match.params.start)).toISOString(true);
      params.end = moment(Number(match.params.end)).toISOString(true);
    }
    return params;
  }

  if (match == null) {
    match = matchPath(state$.value.router.location.pathname, {
      path: `${Routes.COST_SUMMARY}/:reservationId/:editMode/:start/:end`,
    });
  }
  if (match != null) {
    const params = {
      reservationId: match.params.reservationId,
      editMode: match.params.editMode,
      start: match.params.start,
      end: match.params.end,
    };
    return params;
  }

  if (match == null) {
    match = matchPath(state$.value.router.location.pathname, {
      path: `${Routes.EDIT_EVENT}/:eventId/:editMode/:start/:end`,
    });
  }

  if (match == null) {
    match = matchPath(state$.value.router.location.pathname, {
      path: `${Routes.EDIT_EVENT}/:eventId/:editMode`,
    });
  }

  if (match != null) {
    const params = {
      eventId: match.params.eventId,
      editMode: match.params.editMode,
    };
    if (match.params.start != null && match.params.end != null) {
      params.start = moment(Number(match.params.start)).toISOString(true);
      params.end = moment(Number(match.params.end)).toISOString(true);
    }
    return params;
  }
  return null;
}

async function getReservation({ reservationId, start, end, editMode }) {
  const reservation = await ReservationDS.getReservation(
    reservationId,
    editMode,
    start,
    end
  );

  if (reservation != null && reservation.timezone == null) {
    reservation.timezone = await getAppStore().dispatch(
      CurrentUserActions.getDefaultTimezone()
    );
  }
  return reservation;
}

async function getExchangeEventAssociatedToReservation(
  state$,
  reservation,
  editMode,
  calendarId
) {
  if (reservation.locationType === ReservationTypes.MEETING) {
    const isExchangeIntegrated = ApplicationSettingsSelectors.isExchangeIntegratedSelector(
      state$.value
    );
    if (isExchangeIntegrated) {
      const accessToken = await getAppStore().dispatch(
        ExchangeActions.getAzureAccessToken()
      );
      await await getAppStore().dispatch(
        ExchangeActions.getMyUserExchangeProfile()
      );
      if (reservation.iCalUId != null) {
        if (
          editMode === ReservationEditMode.SERIES_OCCURRENCE ||
          editMode === ReservationEditMode.SERIES_EXCEPTION
        ) {
          const currentCalendar = ExchangeSelectors.currentCalendarSelector(
            state$.value
          );
          return Exchange.getCalendarEventByICalUId(
            accessToken,
            reservation.start,
            reservation.end,
            reservation.timezone,
            reservation.iCalUId,
            true,
            currentCalendar
          );
        } else {
          return Exchange.getEventByiCalUId(
            accessToken,
            reservation.timezone,
            reservation.iCalUId,
            reservation.start,
            reservation.end,
            calendarId
          );
        }
      }
    }
  }
  return null;
}

function combineReservationAndExchangeEvent(
  reservation,
  exchangeEvent,
  editMode,
  extension,
  state$
) {
  let combinedReservation = null;
  if (exchangeEvent == null) {
    combinedReservation = {
      exchangeEventId: null,
      subject: reservation.subject,
      description: reservation.description,
      allDayEvent: reservation.allDay,
      start: reservation.start,
      end: reservation.end,
      additionalLocationInfo: reservation.additionalLocationInfo,
    };
  } else {
    combinedReservation = {
      exchangeEventId: exchangeEvent.id,
      iCalUId: exchangeEvent.iCalUId,
      subject: exchangeEvent.subject,
      description: ReservationUtils.removeOnlineMeetingFromDescription(
        exchangeEvent.description
      ),
      allDayEvent: exchangeEvent.isAllDay,
      start: exchangeEvent.start,
      end: exchangeEvent.end,
      additionalLocationInfo: !isEmpty(extension?.additionalLocationInfo)
        ? extension.additionalLocationInfo
        : reservation.additionalLocationInfo,
    };
  }
  combinedReservation.reservationId = reservation._id;
  combinedReservation.timezone = reservation.timezone;
  combinedReservation.reservationType = reservation.locationType;
  combinedReservation.accountCodeEquipment = !isNil(
    SavedReservationSelectors.accountCodeEquipmentSelector(state$.value)
  )
    ? SavedReservationSelectors.accountCodeEquipmentSelector(state$.value)
    : reservation.accountCodeEquipment
    ? reservation.accountCodeEquipment
    : CurrentUserSelectors.accountCodeEquipmentSelector(state$.value);

  combinedReservation.accountCodeFood = !isNil(
    SavedReservationSelectors.accountCodeFoodSelector(state$.value)
  )
    ? SavedReservationSelectors.accountCodeFoodSelector(state$.value)
    : reservation.accountCodeFood
    ? reservation.accountCodeFood
    : CurrentUserSelectors.accountCodeFoodSelector(state$.value);

  combinedReservation.accountCodeRoom = !isNil(
    SavedReservationSelectors.accountCodeRoomSelector(state$.value)
  )
    ? SavedReservationSelectors.accountCodeRoomSelector(state$.value)
    : reservation.accountCodeRoom
    ? reservation.accountCodeRoom
    : CurrentUserSelectors.accountCodeRoomSelector(state$.value);

  combinedReservation.estimatedCostEquipment = reservation.estimatedCostEquipment
    ? reservation.estimatedCostEquipment
    : null;
  combinedReservation.estimatedCostFood = reservation.estimatedCostFood
    ? reservation.estimatedCostFood
    : null;
  combinedReservation.estimatedCostResource = reservation.estimatedCostResource
    ? reservation.estimatedCostResource
    : null;

  const reservationTime = ReservationUtils.computeReservationInitialTime(
    combinedReservation.reservationType,
    combinedReservation.timezone,
    moment(combinedReservation.start),
    moment(combinedReservation.end)
  );
  combinedReservation = {
    ...combinedReservation,
    ...reservationTime,
    editMode,
  };
  return combinedReservation;
}

function loadReservedResources(subscriber, reservationSpaces) {
  const reservedResources = reservationSpaces.data.map((resource) => ({
    room: {
      ...resource,
      _id: resource.spaceRecordId,
    },
    data: {
      _id: resource._id,
      resourceId: resource._id,
      roomId: resource.spaceRecordId,
      layoutTypeInternal: resource.layoutTypeInternal,
      layoutType: resource.layoutType,
      userMessage: null,
      status: resource.status,
      statusENUS: resource.statusENUS,
    },
  }));
  subscriber.next(ReservationActions.setReservedResources(reservedResources));
  return reservedResources;
}

async function loadOnlineMeeting(state$, subscriber, reservation) {
  if (reservation.locationType === ReservationTypes.WORKSPACE) {
    return;
  }
  // Teams meetings CISA
  const isExchangeIntegrated = ApplicationSettingsSelectors.isExchangeIntegratedSelector(
    state$.value
  );
  if(isExchangeIntegrated){
        const onlineMeetingInfo = reservation.onlineMeetingID
          ? await OnlineMeetingDS.getTeamsMeetingByID(reservation.onlineMeetingID)
          : await ReservationOnlineMeetingDS.getReservationOnlineMeeting(
              reservation._id
            );
        subscriber.next(
          ReservationActions.setReservationOnlineMeeting(onlineMeetingInfo)
        );
        if(onlineMeetingInfo != null && onlineMeetingInfo.teamsMeetingId != null){ 
          subscriber.next(
            ReservationActions.setGenerateOnlineMeeting(true)
          );
        }else{
          subscriber.next(
            ReservationActions.setGenerateOnlineMeeting(false)
          );
        }
  }else{
      subscriber.next(OnlineMeetingActions.getOnlineMeetings());
      const onlineMeetingInfo = reservation.onlineMeetingID
        ? await OnlineMeetingDS.getOnlineMeetingByID(reservation.onlineMeetingID)
        : await ReservationOnlineMeetingDS.getReservationOnlineMeeting(
            reservation._id
          );
      subscriber.next(
        ReservationActions.setReservationOnlineMeeting(onlineMeetingInfo)
      );
  }
}

async function getRecurrenceInfo(reservation) {
  if (isEmpty(reservation.recurrenceRule)) {
    return null;
  }
  const timezones = await getAppStore().dispatch(
    TimezoneActions.getTimezones()
  );
  const { _id: timezoneId } = timezones.find((item) =>
    item.englishName.includes(reservation.timezone)
  );
  const { result, recurrenceId } = await ReservationDS.getRecurrenceInfo(
    reservation.recurrenceRule,
    timezoneId,
    reservation.start,
    reservation.end
  );
  const recurrenceInfo = await RecurrenceDS.geRecurrence(recurrenceId);
  const recurrence = getRecurrenceInitial({
    startDateTime: reservation.start,
    timezone: reservation.timezone,
  });
  recurrence.details = result;
  recurrence.type = recurrenceInfo.type;
  recurrence.end = {
    type: recurrenceInfo.endOption,
    numberOfOccurrencesBeforeEnd: `${recurrenceInfo.numberOfOccurrencesBeforeEnd}`,
    ...(recurrenceInfo.endOption ===
      RecurrenceConstants.RECUR_END_VALUES.END_DATE && {
      endDate: moment(
        moment
          .tz(recurrenceInfo.endDate, reservation.timezone)
          .format("YYYY-MM-DD")
      ).toDate(),
    }),
  };
  switch (recurrence.type) {
    case RecurrenceConstants.RECUR_TYPE_VALUES.DAILY:
      recurrence.dailyProperties = {
        type: recurrenceInfo.dailyOption,
        interval: `${recurrenceInfo.dailyRecurrenceDays}`,
      };
      break;

    case RecurrenceConstants.RECUR_TYPE_VALUES.WEEKLY:
      recurrence.weeklyProperties = {
        weeklyDays: [
          recurrenceInfo.weeklySunday,
          recurrenceInfo.weeklyMonday,
          recurrenceInfo.weeklyTuesday,
          recurrenceInfo.weeklyWednesday,
          recurrenceInfo.weeklyThursday,
          recurrenceInfo.weeklyFriday,
          recurrenceInfo.weeklySaturday,
        ],
        interval: `${recurrenceInfo.weeklyRecurrenceWeeks}`,
      };
      break;

    case RecurrenceConstants.RECUR_TYPE_VALUES.MONTHLY:
      recurrence.monthlyProperties = {
        type: recurrenceInfo.monthlyOption,
        dayOfMonth: recurrenceInfo.monthlyDayOfMonth,
        dayOfWeek: recurrenceInfo.monthlyDayOfWeek,
        weekOfMonth: recurrenceInfo.monthlyWeekOfMonth,
        interval: `${recurrenceInfo.monthlyRecurrenceMonths}`,
      };
      break;

    case RecurrenceConstants.RECUR_TYPE_VALUES.YEARLY:
      recurrence.yearlyProperties = {
        type: recurrenceInfo.yearlyOption,
        dayOfMonth: recurrenceInfo.yearlyDayOfMonth,
        dayOfWeek: recurrenceInfo.yearlyDayOfWeek,
        weekOfMonth: recurrenceInfo.yearlyWeekOfMonth,
        month: recurrenceInfo.yearlyMonth,
      };
      break;

    default:
      break;
  }
  return recurrence;
}

function loadReservedEquipment(subscriber, reservedResources, equipmentOrders) {
  if (!isEmpty(equipmentOrders?.data)) {
    const resourcesById = keyBy(reservedResources, (e) => e.data._id);
    const equipmentByRoom = Object.entries(
      groupBy(
        equipmentOrders.data.map((order) => {
          if (
            resourcesById[order.resourceId] &&
            resourcesById[order.resourceId].room
          ) {
            return {
              image: order.image,
              name: order.equipment,
              description: order.equipmentDescription,
              totalCost: order.totalCost,
              usageCost: order.usageCost,
              currency: order.currency,
              _id: order.equipmentId,
              quantity: order.quantity,
              instructions: order.instructions,
              roomId: resourcesById[order.resourceId].room._id,
              orderId: order._id,
            };
          }
          return {};
        }),
        (e) => e.roomId
      )
    );
    equipmentByRoom.forEach(([roomId, equipment]) => {
      subscriber.next(
        ReservationActions.setResourceSelectedEquipment(equipment, roomId)
      );
    });
  }
}

function loadReservedCatering(subscriber, reservedResources, reservation) {
  const { foodOrderItems } = reservation;
  const cateringPerOccurrence = getCateringForOccurrence(
    foodOrderItems.data,
    reservedResources.map((resource) => resource.data)
  );
  if (!isEmpty(cateringPerOccurrence)) {
    const resourcesById = keyBy(reservedResources, (e) => e.data._id);
    const cateringByRoom = Object.entries(
      groupBy(
        cateringPerOccurrence.map((order) => ({
          image: order.image,
          name: order.name,
          menuItem: order.menuItem,
          specClass: order.specClass,
          requestedDateTime: order.requestedDateTime,
          description: order.equipmentDescription,
          _id: order.productId,
          purchaseLineItemId: order.purchaseLineItemId,
          qty: order.quantity,
          costPerItem: order.costPerItem,
          roomId: resourcesById[order.resourceId].room._id,
          currency: order.currency,
          orderId: order.orderId,
          orderInstructions: order.orderInstructions,
          instructions: order.itemInstructions,
          purchaseOrderStatusENUS: order.purchaseOrderStatusENUS,
          foodOrderRequestedDateTime: order.foodOrderRequestedDateTime,
        })),
        (e) => e.roomId
      )
    );
    cateringByRoom.forEach(([roomId, catering]) => {
      const cateringByOrderId = groupBy(catering, (c) => c.orderId);
      const cateringWithAdditionalInfo = Object.values(cateringByOrderId).map(
        (c) => ({
          additionalInformation: {
            orderName: c[0].name,
            instructions: c[0].orderInstructions,
            deliveryDate: moment
              .tz(reservation.start, reservation.timezone)
              .startOf("day")
              .toDate(),
            deliveryTime: moment
              .tz(c[0].foodOrderRequestedDateTime, reservation.timezone)
              .format("hh:mm"),
            deliveryTimePeriod: moment
              .tz(c[0].foodOrderRequestedDateTime, reservation.timezone)
              .format("A"),
          },
          items: c,
        })
      );
      subscriber.next(
        ReservationActions.setResourceSelectedCatering(
          cateringWithAdditionalInfo,
          roomId
        )
      );
      subscriber.next(
        ReservationActions.setResourceOrderedCatering(
          [...cateringWithAdditionalInfo],
          roomId
        )
      );
      subscriber.next(
        ReservationActions.setResourceToBeUpdatedCatering(
          [...cateringWithAdditionalInfo],
          roomId
        )
      );
    });
  }
}

async function loadReservationAttendees(
  subscriber,
  reservation,
  exchangeEvent,
  reservedResources
) {
  if (reservation.locationType === ReservationTypes.WORKSPACE) {
    return;
  }
  if (exchangeEvent == null) {
    subscriber.next(
      ReservationActions.setAttendees(reservation.attendees?.data)
    );
    return;
  }
  try {
    getAppStore().dispatch(
      LoadingActions.setLoading("loadingReservationAttendees", true)
    );
    if (isEmpty(exchangeEvent.attendees)) return [];
    const filteredAttendees = exchangeEvent.attendees.filter(
      (attendee) =>
        !reservedResources.some(
          (room) => room.exchangeMailbox === attendee.emailAddress.address
        )
    );
    const result = [];
    const accessToken = await getAppStore().dispatch(
      ExchangeActions.getAzureAccessToken()
    );
    for (let i = 0; i < filteredAttendees.length; i++) {
      const attendee = filteredAttendees[i];
      const exchangePerson = await Exchange.getPeopleByEmail(
        accessToken,
        attendee.emailAddress?.address
      );
      if (exchangePerson != null) {
        result.push({ ...exchangePerson, exchangeType: attendee.type });
      } else {
        result.push({
          name: attendee.emailAddress?.name,
          exchangeType: attendee.type,
          email: attendee.emailAddress?.address,
        });
      }
    }
    subscriber.next(ReservationActions.setAttendees(result));
  } catch (error) {
    subscriber.next(
      ReservationActions.setAttendees(reservation.attendees?.data)
    );
  } finally {
    getAppStore().dispatch(
      LoadingActions.setLoading("loadingReservationAttendees", false)
    );
  }
}

function loadNewReservation(state$) {
  return new Observable(async (subscriber) => {
    try {
      getAppStore().dispatch(
        LoadingActions.setLoading("loadingReservation", true)
      );
      const { eventDetails } = state$.value;
      const reservationParams = getReservationParamsFromRoute(state$);
      subscriber.next(
        ReservationActions.initializeNewReservation(ReservationTypes.MEETING)
      );
      const { reservation } = state$.value;
      const exchangeEvent = await getExchangeEventDetails(
        state$,
        eventDetails.event,
        reservationParams.editMode
      );

      const {
        currentUser: { defaultTimezone },
      } = state$.value;
      let combinedReservation = combineNewReservationAndExchangeEvent(
        exchangeEvent,
        defaultTimezone,
        reservationParams.editMode,
        eventDetails.Extension
      );
      combinedReservation = {
        ...combinedReservation,
        iCalUId: exchangeEvent.iCalUId,
        isReservationExchangeOnly: !!isEmpty(combinedReservation.reservationId),
        seriesICalUId: exchangeEvent.seriesICalUId,
      };

      combinedReservation.recurrence = await getRecurrencePropertiesFromExchangeEvent(
        exchangeEvent,
        defaultTimezone
      );

      await getAppStore().dispatch(
        ReservationActions.loadReservation(combinedReservation)
      );
      getAppStore().dispatch(
        LoadingActions.setLoading("loadingReservation", false)
      );
      if (eventDetails.Extension?.onlineMeetingID) {
        await loadOnlineMeeting(state$, subscriber, eventDetails.Extension);
      }
      await loadReservationAttendees(
        subscriber,
        reservation,
        exchangeEvent,
        []
      );
    } catch (err) {
      console.error(err);
      subscriber.next(MessageActions.showGeneralError());
      await Timeout.set(5000);
      subscriber.next(RouteActions.navigateToHomePage(true));
    } finally {
      getAppStore().dispatch(
        LoadingActions.setLoading("loadingReservation", false)
      );
      subscriber.complete();
    }
  });
}

async function getExchangeEventDetails(state$, event, editMode) {
  const isExchangeIntegrated = ApplicationSettingsSelectors.isExchangeIntegratedSelector(
    state$.value
  );
  if (isExchangeIntegrated) {
    const accessToken = await getAppStore().dispatch(
      ExchangeActions.getAzureAccessToken()
    );
    await await getAppStore().dispatch(
      ExchangeActions.getMyUserExchangeProfile()
    );
    if (event.iCalUId != null) {
      const {
        currentUser: { defaultTimezone },
      } = state$.value;
      const { id: calendarId } =
        ExchangeSelectors.currentCalendarSelector(state$.value) || {};
      if (
        editMode === ReservationEditMode.SERIES_OCCURRENCE ||
        editMode === ReservationEditMode.SERIES_EXCEPTION
      ) {
        const currentCalendar = ExchangeSelectors.currentCalendarSelector(
          state$.value
        );
        return Exchange.getCalendarEventByICalUId(
          accessToken,
          event.start,
          event.end,
          defaultTimezone,
          event.iCalUId,
          true,
          currentCalendar
        );
      } else if (editMode === ReservationEditMode.SERIES) {
        return Exchange.getEventByiCalUId(
          accessToken,
          defaultTimezone,
          event.seriesICalUId,
          event.start,
          event.end,
          calendarId
        );
      } else {
        return Exchange.getEventByiCalUId(
          accessToken,
          defaultTimezone,
          event.iCalUId,
          event.start,
          event.end,
          calendarId
        );
      }
    }
  }
}

function combineNewReservationAndExchangeEvent(
  exchangeEvent,
  timezone,
  editMode,
  eventExtension
) {
  let combinedReservation = null;

  combinedReservation = {
    exchangeEventId: exchangeEvent.id,
    subject: exchangeEvent.subject,
    description: ReservationUtils.removeOnlineMeetingFromDescription(
      exchangeEvent.description
    ),
    allDayEvent: exchangeEvent.isAllDay,
    start: exchangeEvent.start,
    end: exchangeEvent.end,
  };

  combinedReservation.timezone = timezone;
  combinedReservation.reservationType = ReservationTypes.MEETING;
  combinedReservation.additionalLocationInfo =
    eventExtension?.additionalLocationInfo;
  const reservationTime = ReservationUtils.computeReservationInitialTime(
    combinedReservation.reservationType,
    combinedReservation.timezone,
    moment(combinedReservation.start),
    moment(combinedReservation.end)
  );
  combinedReservation = {
    ...combinedReservation,
    ...reservationTime,
    editMode,
  };
  return combinedReservation;
}

async function getRecurrencePropertiesFromExchangeEvent(
  exchangeEvent,
  timezone
) {
  if (exchangeEvent.recurrence == null) return null;

  const timezones = await getAppStore().dispatch(
    TimezoneActions.getTimezones()
  );
  const { _id: timezoneId } = timezones.find((item) =>
    item.englishName.includes(timezone)
  );

  const startAndEndDate = {
    startDate: exchangeEvent.start,
    endDate: exchangeEvent.end,
    timezoneId,
  };
  const reserveContextRecurrence = ReservationUtils.getRecurrencePropertiesFromExchangeRecurrence(
    exchangeEvent.recurrence
  );
  const recurrenceParams = ReservationUtils.buildRecurrenceParams(
    startAndEndDate,
    reserveContextRecurrence
  );
  const recurrenceDetailsResult = await ReservationDS.processRecurrence(
    recurrenceParams
  );
  return {
    ...reserveContextRecurrence,
    details: recurrenceDetailsResult.result,
  };
}

function getComputeLoadedReservationSpaceData(spaceData) {
  return Object.values(groupBy(spaceData, (space) => space._id))
    .map((groupValue) => maxBy(groupValue, (v) => v._id))
    .filter(
      (r) =>
        r.statusENUS !== Status.CANCELED && r.statusENUS !== Status.DECLINED
    );
}

async function loadExceptionReservationSyncWithOutlook(
  state$,
  reservationId,
  subscriber
) {
  try {
    const reservationParams = {
      reservationId,
      editMode: ReservationEditMode.OCCURRENCE,
    };
    let reservation = await getReservation(reservationParams);
    const { eventDetails } = state$.value;
    if (reservation == null) {
      throw new Error("Reservation was not found.");
    }

    reservation = {
      ...reservation,
      reservationAllSpaces: reservation.reservationSpaces.data,
    };
    reservation.reservationSpaces.data = getComputeLoadedReservationSpaceData(
      reservation.reservationSpaces.data
    );
    const combinedReservation = combineReservationAndExchangeEvent(
      reservation,
      null,
      reservationParams.editMode,
      eventDetails.Extension,
      state$
    );
    combinedReservation.recurrence = null;

    await getAppStore().dispatch(
      ReservationActions.loadReservation(combinedReservation, false)
    );
    const reservedResources = loadReservedResources(
      subscriber,
      reservation.reservationSpaces
    );
    loadReservedEquipment(
      subscriber,
      reservedResources,
      reservation.equipmentOrders
    );
    loadReservedCatering(
      subscriber,
      reservedResources,
      reservation,
      reservationParams.editMode
    );
    await loadOnlineMeeting(state$, subscriber, reservation);
    await loadReservationAttendees(
      subscriber,
      reservation,
      null,
      reservation.reservationAllSpaces
    );
    await getAppStore().dispatch(
      ReservationActions.syncWithOutlook(reservation.start, reservation.end)
    );
  } catch (err) {
    console.error(err);
  }
}
