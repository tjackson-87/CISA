/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/

import { LOCATION_CHANGE } from "connected-react-router";
import moment from "moment-timezone";
import isEmpty from "lodash/isEmpty";
import { ofType } from "redux-observable";
import { Observable } from "rxjs";
import Timeout from "await-timeout";
import { switchMap, filter } from "rxjs/operators";
import { matchPath } from "react-router-dom";
import { ReservableSpaceTypeDS } from "../../model";
import {
  Routes,
  getNextMinuteInterval,
  DateTimeConstants,
  ReservationTypes,
} from "../../utils";
import {
  ReservationActions,
  LoadingActions,
  RouteActions,
  ApplicationSettingsSelectors,
  getAppStore,
} from "..";

export function newReservationEpic(action$, state$) {
  return action$.pipe(
    ofType(LOCATION_CHANGE),
    filter(() => shouldStartNewReservation(state$.value)),
    switchMap(() => initializeReservation(state$.value))
  );
}

function shouldStartNewReservation(state) {
  const pathname = state.router.location.pathname;
  return pathname.indexOf(`${Routes.NEW_RESERVATION_INTEGRATION}`) >= 0;
}

function initializeReservation(state) {
  return new Observable(async (subscriber) => {
    try {
      getAppStore().dispatch(
        LoadingActions.setLoading("initializeReservation", true)
      );
      const isExchangeIntegrated = ApplicationSettingsSelectors.isExchangeIntegratedSelector(
        state
      );
      let routeMatch = matchPath(state.router.location.pathname, {
        path: `${Routes.NEW_RESERVATION_INTEGRATION}/:spaceId/:startDate/:endDate`,
      });
      if (routeMatch == null) {
        routeMatch = matchPath(state.router.location.pathname, {
          path: `${Routes.NEW_RESERVATION_INTEGRATION}/:spaceId`,
        });
      }
      const spaceId = routeMatch?.params?.spaceId;
      const startDate = adjustTime(routeMatch?.params?.startDate);
      const endDate = adjustTime(routeMatch?.params?.endDate);
      validateInitializeReservationParams(spaceId, startDate, endDate);
      const space = await ReservableSpaceTypeDS.getReservableSpaceType(
        spaceId,
        isExchangeIntegrated
      );
      if (space == null) {
        throw new Error(`Space with specId: ${spaceId} was not found`);
      }
      await getAppStore().dispatch(
        ReservationActions.initializeNewReservation(
          space.isMeetingSpace
            ? ReservationTypes.MEETING
            : ReservationTypes.WORKSPACE,
          true,
          true,
          startDate,
          endDate
        )
      );
      subscriber.next(ReservationActions.holdRooms([space]));
    } catch (err) {
      console.error(err);
      await Timeout.set(100);
      subscriber.next(RouteActions.navigateToHomePage(true));
    } finally {
      getAppStore().dispatch(
        LoadingActions.setLoading("initializeReservation", false)
      );
      subscriber.complete();
    }
  });
}

function adjustTime(dateTime) {
  if (!dateTime) return null;
  const momentDateTime = isNaN(Number(dateTime))
    ? moment(dateTime)
    : moment(Number(dateTime));
  if (momentDateTime.minute() % DateTimeConstants.MIN_MINUTE_INTERVAL > 0) {
    return getNextMinuteInterval(
      momentDateTime,
      DateTimeConstants.MIN_MINUTE_INTERVAL
    );
  }
  return momentDateTime;
}

function validateInitializeReservationParams(spaceId, startDate, endDate) {
  if (isEmpty(spaceId)) {
    throw new Error("SpaceId parameter is required, but it was not provided");
  } else if (
    startDate != null &&
    endDate != null &&
    endDate.isSameOrBefore(startDate)
  ) {
    throw new Error("End date must be after the start date");
  }
}
