/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import { LOCATION_CHANGE } from "connected-react-router";
import { ofType } from "redux-observable";
import { map, filter } from "rxjs/operators";
import isEmpty from "lodash/isEmpty";
import {
  AvailabilityActions,
  ReservationSelectors,
  ApplicationSettingsSelectors,
  RouteActions,
} from "..";
import {
  reservationActionTypes,
  exchangeActionTypes,
  Routes,
  getMomentFrom,
  getReservationRoute,
} from "../../utils";

const { INITIALIZE_NEW_RESERVATION } = reservationActionTypes;

export function getAttendeesScheduleEpic(action$, state$) {
  return action$.pipe(
    ofType(LOCATION_CHANGE, INITIALIZE_NEW_RESERVATION),
    filter(() => needGetAttendeesSchedule(state$.value)),
    map(() => mapGetAttendeesSchedule(state$.value))
  );
}

function needGetAttendeesSchedule(state) {
  const isExchangeIntegrated = ApplicationSettingsSelectors.isExchangeIntegratedSelector(
    state
  );
  const exchangeAttendees = ReservationSelectors.exchangeAttendeesSelector(
    state
  );
  const validPath =
    state.router.location.pathname === `${Routes.MEETING}${Routes.TIME}` ||
    state.router.location.pathname ===
      `${Routes.MEETING}${Routes.TIME}${Routes.AVAILABILITY}`;
  return isExchangeIntegrated && !isEmpty(exchangeAttendees) && validPath;
}

function mapGetAttendeesSchedule(state) {
  if (
    state.router.location.pathname ===
    `${Routes.MEETING}${Routes.TIME}${Routes.AVAILABILITY}`
  ) {
    const {
      startDate,
      startTime,
      startTimePeriod,
      timezone,
    } = ReservationSelectors.timeStepTempDateAndTimeSelector(state);
    const startDateMoment = getMomentFrom(
      startDate,
      startTime,
      startTimePeriod,
      timezone
    );
    return AvailabilityActions.getAttendeesSchedule({
      startAndEndDate: {
        startDate: startDateMoment.startOf("day").toISOString(true),
        endDate: startDateMoment.endOf("day").toISOString(true),
        timezone,
      },
      forDay: true,
    });
  } else {
    return AvailabilityActions.getAttendeesSchedule();
  }
}

export function clearAttendeesScheduleEpic(action$, state$) {
  return action$.pipe(
    ofType(
      exchangeActionTypes.SET_USER_EXCHANGE_PROFILE,
      reservationActionTypes.SET_ATTENDEES
    ),
    filter(() => needClearAttendeesSchedule(state$.value)),
    map(() => AvailabilityActions.clearAttendeesSchedule())
  );
}

let lastExchangeAttendees = null;
function needClearAttendeesSchedule(state) {
  const exchangeAttendees = ReservationSelectors.exchangeAttendeesSelector(
    state
  );
  if (
    !isEmpty(exchangeAttendees) &&
    lastExchangeAttendees !== exchangeAttendees &&
    state.router.location.pathname === `${Routes.MEETING}`
  ) {
    lastExchangeAttendees = exchangeAttendees;
    return true;
  }
  return false;
}

export function clearAttendeesScheduleForDayEpic(action$, state$) {
  return action$.pipe(
    ofType(LOCATION_CHANGE),
    filter(() => needClearAttendeesScheduleForDay(state$.value)),
    map(() => AvailabilityActions.clearAttendeesScheduleForDay())
  );
}

let lastExchangeAttendeesForDay = null;
function needClearAttendeesScheduleForDay(state) {
  const exchangeAttendees = ReservationSelectors.exchangeAttendeesSelector(
    state
  );
  if (
    !isEmpty(exchangeAttendees) &&
    lastExchangeAttendeesForDay !== exchangeAttendees &&
    state.router.location.pathname === `${Routes.MEETING}${Routes.TIME}`
  ) {
    lastExchangeAttendeesForDay = exchangeAttendees;
    return true;
  }
  return false;
}

export function getResourcesScheduleForDayEpic(action$, state$) {
  return action$.pipe(
    ofType(LOCATION_CHANGE),
    filter(() => {
      const state = state$.value;
      const route = ReservationSelectors.detailPageRouteSelector(state);
      if (route) return false;
      const resources = ReservationSelectors.orderedResourcesSelector(state);
      const reservationRoute = getReservationRoute(
        ReservationSelectors.reservationTypeSelector(state)
      );
      return (
        !isEmpty(resources) &&
        state.router.location.pathname ===
          `${reservationRoute}${Routes.TIME}${Routes.AVAILABILITY}`
      );
    }),
    map(() => {
      const state = state$.value;
      const {
        startDate,
        startTime,
        startTimePeriod,
        timezone,
      } = ReservationSelectors.timeStepTempDateAndTimeSelector(state);
      const startDateMoment = getMomentFrom(
        startDate,
        startTime,
        startTimePeriod,
        timezone
      );
      return AvailabilityActions.getResourcesScheduleForDay({
        startDate: startDateMoment.startOf("day").toISOString(true),
        endDate: startDateMoment.endOf("day").toISOString(true),
        timezone,
      });
    })
  );
}

export function getResourcesAvailabilityEpic(action$, state$) {
  return action$.pipe(
    ofType(LOCATION_CHANGE),
    filter(() => {
      const state = state$.value;
      const resources = ReservationSelectors.orderedResourcesSelector(state);
      const reservationRoute = getReservationRoute(
        ReservationSelectors.reservationTypeSelector(state)
      );
      return (
        !isEmpty(resources) &&
        state.router.location.pathname ===
          `${reservationRoute}${Routes.TIME}${Routes.AVAILABILITY}`
      );
    }),
    map(() => {
      const state = state$.value;
      const {
        startDate,
        startTime,
        startTimePeriod,
        endDate,
        endTime,
        endTimePeriod,
        timezone,
      } = ReservationSelectors.timeStepTempDateAndTimeSelector(state);
      const startDateMoment = getMomentFrom(
        startDate,
        startTime,
        startTimePeriod,
        timezone
      );
      const endDateMoment = getMomentFrom(
        endDate,
        endTime,
        endTimePeriod,
        timezone
      );
      return AvailabilityActions.getResourcesAvailability({
        startDate: startDateMoment.toISOString(true),
        endDate: endDateMoment.toISOString(true),
        timezone,
      });
    })
  );
}

export function navigateBackFromMeetingAvailabilityEpic(action$, state$) {
  return action$.pipe(
    ofType(LOCATION_CHANGE),
    filter(() => needNavigateBackFromMeetingAvailability(state$.value)),
    map(() => RouteActions.navigateToTime(true, true))
  );
}

function needNavigateBackFromMeetingAvailability(state) {
  const isExchangeIntegrated = ApplicationSettingsSelectors.isExchangeIntegratedSelector(
    state
  );
  const attendees = ReservationSelectors.attendeesSelector(state);
  const resources = ReservationSelectors.orderedResourcesSelector(state);

  return isExchangeIntegrated
    ? false
    : isEmpty(attendees) &&
        isEmpty(resources) &&
        state.router.location.pathname ===
          `${Routes.MEETING}${Routes.TIME}${Routes.AVAILABILITY}`;
}
