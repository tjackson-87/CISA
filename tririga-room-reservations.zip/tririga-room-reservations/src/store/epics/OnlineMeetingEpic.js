/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2022 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/

import { LOCATION_CHANGE } from "connected-react-router";
import { ofType } from "redux-observable";
import { map, filter } from "rxjs/operators";
import {
  reservationActionTypes,
  ReservationTypes,
  Routes,
  OnlineMeetingConstants,
  exchangeActionTypes,
} from "../../utils";
import { ReservationSelectors, OnlineMeetingActions } from "..";

export function setReservationInitialOnlineMeetingEpic(action$, state$) {
  return action$.pipe(
    ofType(
      reservationActionTypes.INITIALIZE_NEW_RESERVATION,
      exchangeActionTypes.SET_CURRENT_CALENDAR
    ),
    filter(
      () =>
        ReservationSelectors.reservationTypeSelector(state$.value) ===
        ReservationTypes.MEETING
    ),
    map(() => OnlineMeetingActions.setReservationInitialOnlineMeeting())
  );
}

export function setSelectedOnlineMeetingEpic(action$, state$) {
  return action$.pipe(
    ofType(LOCATION_CHANGE),
    filter(
      () =>
        state$.value.router.location.pathname.indexOf(
          `${Routes.ONLINE_MEETING}`
        ) >= 0
    ),
    map(() => {
      const reservationOnlineMeeting = ReservationSelectors.onlineMeetingSelector(
        state$.value
      );
      return OnlineMeetingActions.setSelectedOnlineMeeting(
        reservationOnlineMeeting != null
          ? reservationOnlineMeeting._id
          : OnlineMeetingConstants.NO_SELECTED_MEETING_KEY
      );
    })
  );
}
