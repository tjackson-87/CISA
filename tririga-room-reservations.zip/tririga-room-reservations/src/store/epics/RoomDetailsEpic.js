/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/

import { ofType } from "redux-observable";
import { switchMap } from "rxjs/operators";
import { Observable } from "rxjs";
import Timeout from "await-timeout";
import isEmpty from "lodash/isEmpty";
import { Routes, roomDetailsActionTypes } from "../../utils";
import { ReservableSpacesDS } from "../../model";
import {
  RoomDetailsActions,
  RoomSearchSelectors,
  RouteActions,
  LoadingActions,
  RoomDetailsSelectors,
  getAppStore,
  EventDetailsSelectors,
  ReservationSelectors,
  ColleagueSelectors,
} from "..";

const { SET_ROOM_ID } = roomDetailsActionTypes;

export function getRoomDetailsEpic(action$, state$) {
  return action$.pipe(
    ofType(SET_ROOM_ID),
    switchMap(() => getRoomDetails(state$))
  );
}

function getRoomDetails(state$) {
  return new Observable(async (subscriber) => {
    try {
      const isReadOnlyPage = ReservationSelectors.detailPageRouteSelector(
        state$.value
      );
      const { roomIdParam, needContactRoles } = getRoomIdParam(
        state$.value,
        isReadOnlyPage
      );
      if (roomIdParam != null) {
        const currentRoomDetails = RoomDetailsSelectors.roomDetailsSelector(
          state$.value
        );
        const currentContactRoles = RoomDetailsSelectors.contactRolesSelector(
          state$.value
        );
        if (
          currentRoomDetails?._id !== roomIdParam ||
          (needContactRoles && isEmpty(currentContactRoles))
        ) {
          subscriber.next(RoomDetailsActions.setRoomDetail(null, []));
          let room = null;
          if (ReservationSelectors.detailPageRouteSelector(state$.value)) {
            const event = EventDetailsSelectors.eventDetailsSelector(
              state$.value
            );
            if (!isEmpty(event))
              room = event.rooms.find(
                (room) =>
                  room.spaceRecordId === roomIdParam || room._id === roomIdParam
              );
          } else {
            room = RoomSearchSelectors.roomSelector(state$.value, roomIdParam);
          }
          if (room === null) {
            room = ColleagueSelectors.colleagueReservedRoomSelector(state$.value);
          }
          if (room != null && room._id != null) {
            const contactRoles = await getContactRoles(
              subscriber,
              roomIdParam,
              needContactRoles
            );
            subscriber.next(
              RoomDetailsActions.setRoomDetail(room, contactRoles)
            );
          } else {
            await Timeout.set(100);
            subscriber.next(RouteActions.navigateToHomePage(true));
          }
        }
      }
    } finally {
      subscriber.complete();
    }
  });
}

async function getContactRoles(subscriber, roomIdParam, needContactRoles) {
  if (!needContactRoles) {
    return [];
  }
  try {
    getAppStore().dispatch(LoadingActions.setLoading("getContactRoles", true));
    const contactRoles = await ReservableSpacesDS.getContactRoles(roomIdParam);
    return contactRoles;
  } finally {
    getAppStore().dispatch(LoadingActions.setLoading("getContactRoles", false));
  }
}

function getRoomIdParam(state, isReadOnlyPage) {
  const { MEETING, SPACE_DETAILS, EQUIPMENT, CATERING, EVENT_DETAILS } = Routes;

  if (isReadOnlyPage) {
    const match = state.router.location.pathname.match(
      new RegExp(
        `(${EVENT_DETAILS})/(.*?)(${SPACE_DETAILS})/(\\d+)(${EQUIPMENT}|${CATERING})`
      )
    );
    if (match != null) {
      return {
        roomIdParam: match[4],
        needContactRoles: false,
      };
    } else {
      return { roomIdParam: null, needContactRoles: false };
    }
  }
  const equipMatch = state.router.location.pathname.match(
    `(${MEETING}|${EVENT_DETAILS})${SPACE_DETAILS}/(\\d+)${EQUIPMENT}`
  );
  const cateringMatch = state.router.location.pathname.match(
    `(${MEETING}|${EVENT_DETAILS})${SPACE_DETAILS}/(\\d+)${CATERING}`
  );
  const roomId = RoomDetailsSelectors.roomIdSelector(state);
  if (roomId != null) {
    return {
      roomIdParam: roomId,
      needContactRoles: equipMatch == null && cateringMatch == null,
    };
  } else {
    return { roomIdParam: null, needContactRoles: false };
  }
}
