/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2022 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import { LOCATION_CHANGE } from "connected-react-router";
import { ofType } from "redux-observable";
import {
  switchMap,
  concatMap,
  takeUntil,
  map,
  filter,
  scan,
} from "rxjs/operators";
import { TriModelApi } from "@tririga/tririga-react-components";
import { Observable, EMPTY } from "rxjs";
import Timeout from "await-timeout";
import {
  ExchangeActions,
  ExchangeSelectors,
  getAppStore,
  MessageActions,
  ApplicationSettingsSelectors,
  LoadingActions,
} from "..";
import { exchangeActionTypes, Routes, isIOS } from "../../utils";
import * as AppErrorHandlers from "../../app/AppErrorHandlers";
import { Exchange, AllUserProfileDS } from "../../model";

const AUTHENTICATION_POPUP_DELAY = 3000;

export function getInitialPeopleListEpic(action$) {
  return action$.pipe(
    ofType(exchangeActionTypes.GET_INITIAL_PEOPLE_LIST),
    switchMap((action) =>
      getInitialPeopleList(action).pipe(
        takeUntil(action$.pipe(ofType(exchangeActionTypes.CLEAR_PEOPLE_LIST)))
      )
    )
  );
}

export function getNextPagePeopleListEpic(action$, state$) {
  return action$.pipe(
    ofType(exchangeActionTypes.GET_NEXT_PAGE_PEOPLE_LIST),
    concatMap(() => getNextPagePeopleList(state$))
  );
}

export function clearPeopleListEpic(action$, state$) {
  return action$.pipe(
    ofType(LOCATION_CHANGE),
    filter(
      () => state$.value.router.location.pathname.indexOf(Routes.ATTENDEES) >= 0
    ),
    map(() => ExchangeActions.clearPeopleList())
  );
}

export function getCalendarListEpic(action$, state$) {
  return action$.pipe(
    ofType(exchangeActionTypes.AUTHENTICATION_SUCCESS),
    switchMap(() => getDelegateCalendars(state$.value))
  );
}

function getDelegateCalendars(state) {
  return new Observable(async (subscriber) => {
    const isExchangeIntegrated = ApplicationSettingsSelectors.isExchangeIntegratedSelector(
      state
    );
    if (isExchangeIntegrated) {
      try {
        const accessToken = await getAppStore().dispatch(
          ExchangeActions.getAzureAccessToken()
        );
        getAppStore().dispatch(
          LoadingActions.setLoading("getDelegateCalendars", true)
        );
        const response = await Exchange.getAllCalendars(accessToken);
        if (response.success) {
          const allUsers = await AllUserProfileDS.getallUserProfileByEmails(
            response.result.map((calendar) => calendar.email)
          );
          response.result.forEach((calendar) => {
            calendar.isValidInTririga =
              allUsers
                .map((user) => user.email)
                .filter((email) => email === calendar.email).length === 1;
            calendar.userProfileId = allUsers.filter(
              (user) => user.email === calendar.email
            )[0]?._id;
          });
          subscriber.next(
            ExchangeActions.setDelegateCalendars(response.result)
          );
          const defaultCalendar = response.result.find(
            (calendar) => calendar.isDefaultCalendar
          );
          subscriber.next(
            ExchangeActions.setCurrentCalendar(defaultCalendar, false)
          );
        } else {
          subscriber.next(
            MessageActions.showGetExchangeDelegateCalendarsError()
          );
        }
      } catch (e) {
        subscriber.next(MessageActions.showGetExchangeDelegateCalendarsError());
      } finally {
        getAppStore().dispatch(
          LoadingActions.setLoading("getDelegateCalendars", false)
        );
        subscriber.complete();
      }
    }
  });
}

function getInitialPeopleList(getInitialPeopleListAction) {
  return new Observable(async (subscriber) => {
    try {
      const accessToken = await getAppStore().dispatch(
        ExchangeActions.getAzureAccessToken()
      );
      getAppStore().dispatch(LoadingActions.setLoading("loadingPeople", true));
      const peopleList = await Exchange.getPeople(
        accessToken,
        getInitialPeopleListAction.search
      );
      subscriber.next(ExchangeActions.setPeopleList(peopleList));
    } catch (err) {
      subscriber.next(handleGetPeopleListError(err));
    } finally {
      getAppStore().dispatch(LoadingActions.setLoading("loadingPeople", false));
      subscriber.complete();
    }
  });
}

function getNextPagePeopleList(state$) {
  return new Observable(async (subscriber) => {
    try {
      const {
        nextLink,
        search,
        hasMore,
      } = ExchangeSelectors.peopleListSelector(state$.value);
      if (hasMore) {
        const accessToken = await getAppStore().dispatch(
          ExchangeActions.getAzureAccessToken()
        );
        getAppStore().dispatch(
          LoadingActions.setLoading("loadingMorePeople", true)
        );
        const peopleList = await Exchange.getPeople(
          accessToken,
          search,
          nextLink
        );
        subscriber.next(ExchangeActions.setPeopleList(peopleList, true));
      }
    } catch (err) {
      subscriber.next(handleGetPeopleListError(err));
    } finally {
      getAppStore().dispatch(
        LoadingActions.setLoading("loadingMorePeople", false)
      );
      subscriber.complete();
    }
  });
}

function handleGetPeopleListError(err) {
  console.error(err);
  if (err.error != null && err.error instanceof TriModelApi.ModelError) {
    return AppErrorHandlers.handleModelErrors(err.error, false);
  } else {
    return MessageActions.showPeopleListError();
  }
}

const accessTokenStates = {
  IDLE: 0,
  GET_FROM_REFRESH_TOKEN: 1,
  INITIATING: 2,
  AUTHENTICATING: 3,
  BLOCKED: 4,
  AUTH_ERROR: 5,
  TOKEN_SUCCESS: 6,
  TOKEN_ERROR: 7,
};

const accessTokenStateTransitions = [
  {
    states: [
      accessTokenStates.IDLE,
      accessTokenStates.TOKEN_SUCCESS,
      accessTokenStates.TOKEN_ERROR,
    ],
    action: exchangeActionTypes.GET_ACCESS_TOKEN,
    nextState: accessTokenStates.GET_FROM_REFRESH_TOKEN,
  },
  {
    states: [accessTokenStates.GET_FROM_REFRESH_TOKEN],
    action: exchangeActionTypes.AUTHENTICATION_SUCCESS,
    nextState: accessTokenStates.TOKEN_SUCCESS,
  },
  {
    states: [accessTokenStates.GET_FROM_REFRESH_TOKEN],
    action: exchangeActionTypes.INIT_AUTHENTICATION,
    nextState: accessTokenStates.INITIATING,
  },
  {
    states: [accessTokenStates.INITIATING],
    action: exchangeActionTypes.OPEN_AUTHENTICATION_POPUP,
    nextState: accessTokenStates.AUTHENTICATING,
  },
  {
    states: [accessTokenStates.AUTHENTICATING],
    action: exchangeActionTypes.AUTHENTICATION_SUCCESS,
    nextState: accessTokenStates.TOKEN_SUCCESS,
  },
  {
    states: [accessTokenStates.AUTHENTICATING],
    action: exchangeActionTypes.AUTHENTICATION_POPUP_BLOCKED,
    nextState: accessTokenStates.BLOCKED,
  },
  {
    states: [accessTokenStates.AUTHENTICATING],
    action: exchangeActionTypes.AUTHENTICATION_ERROR,
    nextState: accessTokenStates.AUTH_ERROR,
  },
  {
    states: [accessTokenStates.BLOCKED, accessTokenStates.AUTH_ERROR],
    action: exchangeActionTypes.RETRY_AUTHENTICATION,
    nextState: accessTokenStates.AUTHENTICATING,
  },
  {
    states: [accessTokenStates.BLOCKED, accessTokenStates.AUTH_ERROR],
    action: exchangeActionTypes.CANCEL_GET_ACCESS_TOKEN,
    nextState: accessTokenStates.TOKEN_ERROR,
  },
];

export function getAzureAccessTokenEpic(action$, state$) {
  return action$.pipe(
    scan(getNextAccessTokenState, { state: accessTokenStates.IDLE }),
    concatMap((accessTokenState) =>
      processNextAccessTokenState(accessTokenState, state$)
    )
  );
}

function processNextAccessTokenState(accessTokenState, state$) {
  if (!accessTokenState.transitioned) return EMPTY;
  return new Observable(async (subscriber) => {
    try {
      switch (accessTokenState.state) {
        case accessTokenStates.GET_FROM_REFRESH_TOKEN:
          await processGetFromRefreshTokenState(subscriber, state$);
          break;

        case accessTokenStates.INITIATING:
          await processInitiatingState(subscriber);
          break;

        case accessTokenStates.AUTHENTICATING:
          await processAuthenticatingState(subscriber, state$);
          break;

        case accessTokenStates.BLOCKED:
          processBlockedState(subscriber);
          break;

        case accessTokenStates.AUTH_ERROR:
          processAuthErrorState(subscriber);
          break;

        case accessTokenStates.TOKEN_ERROR:
          processTokenError(subscriber, accessTokenState);
          break;

        case accessTokenStates.TOKEN_SUCCESS:
          processTokenSuccess(subscriber, accessTokenState);
          break;

        default:
          break;
      }
    } finally {
      subscriber.complete();
    }
  });
}

async function processGetFromRefreshTokenState(subscriber, state$) {
  const profileName = ApplicationSettingsSelectors.oauthProfileSelector(
    state$.value
  );
  let accessToken = null;
  try {
    getAppStore().dispatch(
      LoadingActions.setLoading("getfromRefreshToken", true)
    );
    accessToken = await Exchange.getAccessTokenUsingRefreshToken(profileName);
  } finally {
    getAppStore().dispatch(
      LoadingActions.setLoading("getfromRefreshToken", false)
    );
  }
  if (accessToken != null) {
    subscriber.next(
      ExchangeActions.setAuthenticationSuccess(
        accessToken.access_token,
        accessToken.expires_in
      )
    );
  } else {
    subscriber.next(ExchangeActions.initAuthentication());
  }
}

async function processInitiatingState(subscriber) {
  if (isIOS) {
    subscriber.next(ExchangeActions.openAuthenticationPopup());
  } else {
    subscriber.next(MessageActions.showAuthenticatingWithExchange());
    await Timeout.set(AUTHENTICATION_POPUP_DELAY);
    subscriber.next(ExchangeActions.openAuthenticationPopup());
  }
}

async function processAuthenticatingState(subscriber, state$) {
  subscriber.next(MessageActions.showAuthenticatingWithExchange());
  const profileName = ApplicationSettingsSelectors.oauthProfileSelector(
    state$.value
  );
  try {
    const {
      access_token: accessToken,
      expires_in: expiresIn,
    } = await Exchange.getAzureAccessToken(profileName);
    subscriber.next(
      ExchangeActions.setAuthenticationSuccess(accessToken, expiresIn)
    );
  } catch (error) {
    if (error instanceof Exchange.PopupBlockedException) {
      subscriber.next(ExchangeActions.setAuthenticationPopupBlocked(error));
    } else {
      subscriber.next(ExchangeActions.setAuthenticationError(error));
    }
  }
}

function processBlockedState(subscriber) {
  subscriber.next(MessageActions.showPopupBlocked());
}

function processAuthErrorState(subscriber) {
  subscriber.next(MessageActions.showAuthenticationWithExchangeFailed());
}

function processTokenSuccess(subscriber, accessTokenState) {
  const { accessToken, expiresIn, resolveGetToken } = accessTokenState;
  subscriber.next(ExchangeActions.setAccessToken(accessToken, expiresIn));
  subscriber.next(MessageActions.clearMessage());
  resolveGetToken(accessToken);
}

function processTokenError(subscriber, accessTokenState) {
  const { rejectGetToken, error } = accessTokenState;
  subscriber.next(ExchangeActions.setAccessToken(null, null));
  subscriber.next(MessageActions.clearMessage());
  rejectGetToken(error);
}

function getNextAccessTokenState(accessTokenState, action) {
  const nextState = accessTokenStateTransitions.find(
    (transition) =>
      transition.states.includes(accessTokenState.state) &&
      transition.action === action.type
  )?.nextState;

  if (nextState != null) {
    return {
      ...accessTokenState,
      ...action,
      state: nextState,
      transitioned: true,
    };
  }
  return { ...accessTokenState, transitioned: false };
}
