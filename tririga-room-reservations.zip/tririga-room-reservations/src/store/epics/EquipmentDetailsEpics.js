/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import { LOCATION_CHANGE } from "connected-react-router";
import { ofType } from "redux-observable";
import { map, filter } from "rxjs/operators";
import {
  Routes,
  reservationActionTypes,
  ReservationTypes,
  equipmentDetailsActionTypes,
} from "../../utils";
import {
  RouteActions,
  EquipmentActions,
  ReservationSelectors,
  EquipmentDetailsSelectors,
  RoomDetailsSelectors,
} from "..";

const { SET_EQUIPMENT_ID } = equipmentDetailsActionTypes;

export function getEquipmentEpic(action$, state$) {
  return action$.pipe(
    ofType(
      reservationActionTypes.SET_RESOURCES_ON_HOLD,
      reservationActionTypes.SET_RESERVED_RESOURCES,
      LOCATION_CHANGE
    ),
    filter(
      () =>
        ReservationSelectors.reservationTypeSelector(state$.value) ===
          ReservationTypes.MEETING ||
        (ReservationSelectors.detailPageRouteSelector(state$.value) &&
          state$.value.router.location.state &&
          state$.value.router.location.state.forEquipment)
    ),
    map(() => EquipmentActions.getAvailableEquipmentForAllResources())
  );
}

export function getEquipmentDetailsEpic(action$, state$) {
  return action$.pipe(
    ofType(SET_EQUIPMENT_ID),
    map(() => mapToSetEquipmentDetails(state$.value))
  );
}

function mapToSetEquipmentDetails(state) {
  let equipment = null;
  const match = getMatch(state);
  const equipmentId = EquipmentDetailsSelectors.equipmentIdSelector(state);
  const roomId = RoomDetailsSelectors.roomIdSelector(state);
  if (match != null) {
    equipment = ReservationSelectors.equipmentSelector(
      state,
      roomId,
      equipmentId
    );
  }

  if (equipment != null) return EquipmentActions.setEquipmentDetail(equipment);
  else return RouteActions.navigateToHomePage(true);
}

function getMatch(state) {
  const { MEETING, SPACE_DETAILS, EVENT_DETAILS } = Routes;
  const isReadOnlyPage = ReservationSelectors.detailPageRouteSelector(state);
  return isReadOnlyPage
    ? state.router.location.pathname.match(
        new RegExp(
          `(${Routes.EVENT_DETAILS})/(.*?)(${Routes.SPACE_DETAILS})/(\\d+)(${Routes.EQUIPMENT}|${Routes.CATERING})`
        )
      )
    : state.router.location.pathname.match(
        new RegExp(
          `(${MEETING}|${EVENT_DETAILS})(${SPACE_DETAILS})/(\\d+)(${Routes.EQUIPMENT})`
        )
      );
}
