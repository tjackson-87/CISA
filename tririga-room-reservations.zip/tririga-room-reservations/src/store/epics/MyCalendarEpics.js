/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/

import moment from "moment-timezone";
import { LOCATION_CHANGE } from "connected-react-router";
import { ofType } from "redux-observable";
import { switchMap, filter, map, concatMap } from "rxjs/operators";
import { Observable } from "rxjs";
import {
  myCalendarActionTypes,
  Routes,
  getMomentFrom,
  ReservationTypes,
  EventUtils,
  MyCalendarUtils,
  exchangeActionTypes,
  TimezoneUtils,
} from "../../utils";
import { Exchange, MyCalendarDS, ActiveUsersDS } from "../../model";
import {
  MessageActions,
  ExchangeActions,
  getAppStore,
  MyCalendarSelectors,
  MyCalendarActions,
  ApplicationSettingsSelectors,
  CurrentUserSelectors,
  LoadingActions,
  ReserveEventTypesActions,
  TimezonesSelectors,
  ExchangeSelectors,
} from "..";

export function initializeMyCalendarDateEpic(action$, state$) {
  return action$.pipe(
    ofType(LOCATION_CHANGE),
    filter(
      () =>
        state$.value.router.location.pathname === Routes.HOME &&
        MyCalendarSelectors.dateSelector(state$.value) === null
    ),
    map(() => MyCalendarActions.initializeMyCalendarDate())
  );
}

export function getMyCalendarEpic(action$, state$) {
  return action$.pipe(
    filter((action) => needRefreshEvents(action, state$.value)),
    switchMap(() => getMyCalendar(state$))
  );
}

export function getMoreCalendarEventsEpic(action$, state$) {
  return action$.pipe(
    ofType(myCalendarActionTypes.GET_MORE_CALENDAR_EVENTS),
    concatMap((action) => getMyCalendar(state$, true, action.after))
  );
}

function getMyCalendar(state$, append = false, appendAfter = true) {
  return new Observable(async (subscriber) => {
    try {
      getAppStore().dispatch(
        LoadingActions.setLoading(
          append
            ? appendAfter
              ? "loadingMoreEventsAfter"
              : "loadingMoreEventsBefore"
            : "loadingEvents",
          true
        )
      );
      const timezone = MyCalendarSelectors.timezoneSelector(state$.value);
      const { start, end } = computeCalendarRequestStartAndEndDates(
        state$.value,
        timezone,
        append,
        appendAfter
      );
      const myCalendarRequests = [getMyCalendarEvents(state$, start, end)];
      const isExchangeIntegrated = ApplicationSettingsSelectors.isExchangeIntegratedSelector(
        state$.value
      );
      if (isExchangeIntegrated) {
        const currentCalendar = ExchangeSelectors.currentCalendarSelector(
          state$.value
        );
        myCalendarRequests.push(
          getMyExchangeCalendar(start, end, timezone, currentCalendar)
        );
      }
      const calendars = await Promise.all(myCalendarRequests);
      const events = combineCalendars(calendars, isExchangeIntegrated);
      await MyCalendarActions.getEventRooms(events);
      await MyCalendarActions.getReservationInstances(events);
      await MyCalendarActions.getMissingReservationInstances(events);
      if (append) {
        events.push(...MyCalendarSelectors.eventsSelector(state$.value));
      }
      const {
        start: newEventsStart,
        end: newEventsEnd,
      } = computeEventsStartAndEndDates(
        state$.value,
        start,
        end,
        append,
        appendAfter
      );
      subscriber.next(
        MyCalendarActions.setMyCalendarEvents(
          events,
          newEventsStart,
          newEventsEnd
        )
      );
    } catch (err) {
      subscriber.next(MessageActions.showGetMyCalendarError(err));
    } finally {
      getAppStore().dispatch(
        LoadingActions.setLoading(
          append
            ? appendAfter
              ? "loadingMoreEventsAfter"
              : "loadingMoreEventsBefore"
            : "loadingEvents",
          false
        )
      );
      subscriber.complete();
    }
  });
}

async function getMyCalendarEvents(state$, start, end) {
  const currentCalendar = ExchangeSelectors.currentCalendarSelector(
    state$.value
  );
  let user;
  if (currentCalendar) {
    user = await ActiveUsersDS.getUserByEmail(currentCalendar.email);
  }
  const personId = user
    ? user.personId
    : CurrentUserSelectors.personIdSelector(state$.value);
  const events = await MyCalendarDS.getMyCalendar(start, end, personId);
  const reserveEventTypes = await getAppStore().dispatch(
    ReserveEventTypesActions.getReserveEventTypes()
  );
  const timezones = TimezonesSelectors.timezonesSelector(state$.value);
  EventUtils.mapReservationTimezoneInEnglish(events, timezones);
  return EventUtils.computeEventsLocationType(events, reserveEventTypes);
}

async function getMyExchangeCalendar(start, end, timezone, currentCalendar) {
  const accessToken = await getAppStore().dispatch(
    ExchangeActions.getAzureAccessToken()
  );
  return Exchange.getUserCalendarView(
    accessToken,
    currentCalendar,
    start,
    end,
    timezone
  );
}

function combineCalendars(calendars, isExchangeIntegrated) {
  const myTririgaCalendar = calendars[0];
  let combinedEvents = null;
  if (!isExchangeIntegrated) {
    combinedEvents = myTririgaCalendar.map((item) => {
      EventUtils.setEventId(item);
      EventUtils.setIsRoomOnly(item);
      return item;
    });
  } else {
    const myExchangeCalendar = calendars[1];
    const workspaceEvents = myTririgaCalendar.filter(
      (ev) => ev.locationType === ReservationTypes.WORKSPACE
    );
    // Office support CISA
    const officeEvents = myTririgaCalendar.filter(
      (ev) => ev.locationType === ReservationTypes.OFFICE
    );
    combinedEvents = myExchangeCalendar.map((exchangeEvent) => {
      const tririgaEvent = getTririgaEvent(
        myTririgaCalendar,
        exchangeEvent.iCalUId,
        exchangeEvent.seriesICalUId,
        exchangeEvent.start,
        exchangeEvent.end,
        exchangeEvent.isAllDay,
        TimezoneUtils.getTimeZoneName(exchangeEvent.reservationTimezone)
      );
      return EventUtils.combineExchangeEventWithTririgaEvent(
        exchangeEvent,
        tririgaEvent
      );
    });
    combinedEvents.push(
      ...myTririgaCalendar
        .filter(
          (ev) =>
            ev.locationType === ReservationTypes.MEETING && ev.iCalUId === null
        )
        .map((ev) => {
          EventUtils.setEventId(ev);
          EventUtils.setIsRoomOnly(ev);
          return ev;
        })
    );
    combinedEvents.push(
      ...workspaceEvents.map((item) => {
        EventUtils.setEventId(item);
        EventUtils.setIsRoomOnly(item);
        return item;
      })
    );
    combinedEvents.push(
      ...officeEvents.map((item) => { // CISA
        EventUtils.setEventId(item);
        EventUtils.setIsRoomOnly(item);
        return item;
      })
    );
  }
  return combinedEvents;
}

function getTririgaEvent(
  myTririgaCalendar,
  iCalUId,
  seriesICalUId,
  start,
  end,
  isAllDay,
  timeZone
) {
  if (isAllDay) {
    return myTririgaCalendar
      .filter((event) => event.isAllDay)
      .find(
        (tririgaEvent) =>
          (tririgaEvent.iCalUId === iCalUId ||
            tririgaEvent.iCalUId === seriesICalUId) &&
          moment(start)
            .subtract(
              TimezoneUtils.getTimeZoneDiff(
                timeZone,
                TimezoneUtils.getTimeZoneName(tririgaEvent.reservationTimezone)
              ),
              "minutes"
            )
            .isSame(tririgaEvent.start, "minutes") &&
          moment(end)
            .subtract(
              TimezoneUtils.getTimeZoneDiff(
                timeZone,
                TimezoneUtils.getTimeZoneName(tririgaEvent.reservationTimezone)
              ),
              "minutes"
            )
            .isSame(tririgaEvent.end, "minutes")
      );
  } else {
    const momentStart = moment(start);
    const momentEnd = moment(end);
    return myTririgaCalendar.find(
      (tririgaEvent) =>
        (tririgaEvent.iCalUId === iCalUId ||
          tririgaEvent.iCalUId === seriesICalUId) &&
        momentStart.isSame(tririgaEvent.start, "minutes") &&
        momentEnd.isSame(
          validateEndDateTime(tririgaEvent.end, timeZone),
          "minutes"
        )
    );
  }
}

function validateEndDateTime(date, timeZone) {
  if (moment(date).seconds() === 59) {
    return moment.tz(date, timeZone).add(1, "seconds").toISOString(true);
  }
  return date;
}

function needRefreshEvents(action, state) {
  return (
    (action.type === myCalendarActionTypes.REFRESH_MY_CALENDAR ||
      (action.type === myCalendarActionTypes.SET_MY_CALENDAR_DATE,
      action.reset) ||
      (action.type === exchangeActionTypes.SET_CURRENT_CALENDAR,
      action.reset)) &&
    MyCalendarSelectors.dateSelector(state) != null
  );
}

function computeCalendarRequestStartAndEndDates(
  state,
  timezone,
  append,
  appendAfter
) {
  let start = null;
  let end = null;
  const screenHeight = window.innerHeight;
  const bufferDays =
    MyCalendarUtils.RESERVATION_LIST_BUFFER_DAYS +
    Math.floor(
      (screenHeight - MyCalendarUtils.RESERVATION_LIST_TOP) /
        MyCalendarUtils.RESERVATION_LIST_PAGE_HEIGHT_IN_PIXELS
    ) *
      MyCalendarUtils.RESERVATION_LIST_BUFFER_DAYS;
  if (!append) {
    const date = MyCalendarSelectors.dateSelector(state);
    start = getMomentFrom(date, "00:00", "AM", timezone)
      .subtract(MyCalendarUtils.RESERVATION_LIST_BUFFER_DAYS, "days")
      .toISOString(true);
    end = getMomentFrom(date, "11:59", "PM", timezone)
      .add(bufferDays, "days")
      .toISOString(true);
  } else {
    const currentEventsDates = MyCalendarSelectors.eventsStartAndEndSelector(
      state
    );
    if (appendAfter) {
      start = moment
        .tz(currentEventsDates.end, timezone)
        .add(1, "minute")
        .toISOString(true);
      end = moment
        .tz(start, timezone)
        .add(MyCalendarUtils.RESERVATION_LIST_BUFFER_DAYS, "days")
        .hours(23)
        .minutes(59)
        .toISOString(true);
    } else {
      end = moment
        .tz(currentEventsDates.start, timezone)
        .subtract(1, "minute")
        .toISOString(true);
      start = moment
        .tz(end, timezone)
        .subtract(MyCalendarUtils.RESERVATION_LIST_BUFFER_DAYS, "days")
        .hours(0)
        .minutes(0)
        .toISOString(true);
    }
  }
  return {
    start,
    end,
  };
}

function computeEventsStartAndEndDates(state, start, end, append, appendAfter) {
  if (!append) {
    return { start, end };
  }
  const currentEventsDates = MyCalendarSelectors.eventsStartAndEndSelector(
    state
  );
  if (appendAfter) {
    return { start: currentEventsDates.start, end };
  } else {
    return { start, end: currentEventsDates.end };
  }
}
