/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/

import { LOCATION_CHANGE } from "connected-react-router";
import { ofType } from "redux-observable";
import { map, filter } from "rxjs/operators";
import { LocationActions, LocationSelectors, getAppStore } from "..";
import { locationActionTypes, Routes } from "../../utils";

export function clearLocationSearchEpic(action$, state$) {
  return action$.pipe(
    ofType(LOCATION_CHANGE),
    filter(() => needClearLocationSearch(state$.value)),
    map(() => LocationActions.clearSearch())
  );
}

export function getFloorsEpic(action$, state$) {
  return action$.pipe(
    ofType(LOCATION_CHANGE, locationActionTypes.SET_SELECTED_BUILDING),
    filter(() => needGetFloors(state$.value)),
    map(() => LocationActions.getFloors())
  );
}

function needClearLocationSearch(state) {
  return (
    state.router.location.pathname.indexOf(
      `${Routes.SEARCH}${Routes.LOCATION}`
    ) >= 0
  );
}

function needGetFloors(state) {
  const selectedBuilding = LocationSelectors.selectedBuildingSelector(state);
  const prevSelectedBuilding = LocationSelectors.prevSelectedBuildingSelector(
    state
  );
  const trigger =
    selectedBuilding?._id !== prevSelectedBuilding?._id &&
    state.router.location.pathname.indexOf(`${Routes.SEARCH}`) >= 0;
  if (trigger) {
    getAppStore().dispatch(
      LocationActions.setPrevSelectedBuilding(selectedBuilding)
    );
    return true;
  }
  return false;
}
