/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2023 The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import { LOCATION_CHANGE } from "connected-react-router";
import { ofType } from "redux-observable";
import { filter, switchMap, map } from "rxjs/operators";
import { Observable } from "rxjs";
import {
  ColleagueActions,
  ColleagueSelectors,
  LocationSelectors,
  ReservationSelectors,
  RoomSearchActions,
  RoomSearchSelectors,
  getAppStore,
} from "..";
import {
  Routes,
  locationActionTypes,
  roomSearchActionTypes,
} from "../../utils";

import { matchPath } from "react-router-dom";
import { AllUserProfileDS, FloorsDS } from "../../model";
import { isEmpty, isEqual } from "lodash";

export function getColleagueReservationEpic(action$, state$) {
  return action$.pipe(
    ofType(LOCATION_CHANGE),
    filter(
      () =>
        state$.value.router.location.pathname.indexOf(
          Routes.COLLEAGUE_RESERVATION
        ) >= 0
    ),
    switchMap(() => getColleagueReservation(state$.value))
  );
}

function getColleagueReservation(state) {
  const match = matchPath(state.router.location.pathname, {
    path: `${Routes.COLLEAGUE_RESERVATION}/:colleagueId`,
  });
  return new Observable(async (subscriber) => {
    try {
      const personDetails = await AllUserProfileDS.getUserByPersonID(
        match ? match.params.colleagueId : null
      );
      subscriber.next(ColleagueActions.setColleagueDetails(personDetails));
      subscriber.next(ColleagueActions.clearUpcomingReservation());
      subscriber.next(
        ColleagueActions.getColleagueUpcomingReservation(personDetails.personId)
      );
    } catch (error) {
    } finally {
      subscriber.complete();
    }
  });
}

export function setSelectedColleagueReservationFloorEpic(action$, state$) {
  return action$.pipe(
    ofType(LOCATION_CHANGE, locationActionTypes.SET_SELECTED_BUILDING),
    filter(() => shouldSetColleagueFloor(state$.value)),
    switchMap(() => {
      return setSelectedFloor(state$.value);
    })
  );
}

function setSelectedFloor(state) {
  return new Observable(async (subscriber) => {
    try {
      const room = ColleagueSelectors.selectedColleagueReservationRoomSelector(
        state
      );
      const reservationType = ReservationSelectors.reservationTypeSelector(
        state
      );
      const floors = await FloorsDS.getBuildingFloors(
        room?.buildingSystemRecordID,
        reservationType,
        false
      );
      const selectedFloor = floors.find(
        (floor) => floor._id === room.floorSystemRecordID
      );
      subscriber.next(
        ColleagueActions.setSelectedColleagueReservationFloor(selectedFloor)
      );
      subscriber.next(RoomSearchActions.setFloorFilter(selectedFloor));
    } catch (error) {
    } finally {
      subscriber.complete();
    }
  });
}

let prevSelectedColleague = null;
function shouldSetColleagueFloor(state) {
  const building = ColleagueSelectors.selectedColleagueReservationBuildingSelector(
    state
  );
  const locationBuilding = LocationSelectors.selectedBuildingSelector(state);
  const selectedColleague = ColleagueSelectors.selectedColleagueSelector(state);
  if (
    isEqual(building, locationBuilding) &&
    !isEqual(prevSelectedColleague, selectedColleague)
  ) {
    prevSelectedColleague = selectedColleague;
    return true;
  }
  return false;
}

export function setZoomToColleagueEpic(action$, state$) {
  return action$.pipe(
    ofType(
      locationActionTypes.SET_SELECTED_BUILDING,
      roomSearchActionTypes.SET_FLOOR_FILTER
    ),
    filter(() => shouldSetZoomToColleague(state$.value)),
    map(() => ColleagueActions.setZoomToColleague(true))
  );
}

function shouldSetZoomToColleague(state) {
  const colleagueBuilding = ColleagueSelectors.selectedColleagueReservationBuildingSelector(
    state
  );
  const colleagueFloor = ColleagueSelectors.selectedColleagueReservationFloorSelector(
    state
  );
  const locationBuilding = LocationSelectors.selectedBuildingSelector(state);
  const locationFloor = RoomSearchSelectors.floorSelector(state);
  if (
    isEqual(colleagueBuilding, locationBuilding) &&
    isEqual(colleagueFloor, locationFloor)
  ) {
    const colleagueRoom = ColleagueSelectors.selectedColleagueReservationRoomSelector(
      state
    );
    const roomsFilter = RoomSearchSelectors.roomsFilterSelector(state);
    if (!isEmpty(colleagueRoom) && isEmpty(roomsFilter)) {
      getAppStore().dispatch(
        RoomSearchActions.getRoomsInFloorPlanNearBy(colleagueRoom)
      );
    }
    return true;
  }
  getAppStore().dispatch(ColleagueActions.setZoomToColleague(false));
  return false;
}
