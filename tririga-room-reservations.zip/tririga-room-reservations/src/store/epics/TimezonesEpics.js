/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import { LOCATION_CHANGE } from "connected-react-router";
import { ofType } from "redux-observable";
import { map, filter } from "rxjs/operators";
import isEmpty from "lodash/isEmpty";
import { TimezoneActions, TimezonesSelectors } from "..";
import { Routes } from "../../utils";

export function getTimezonesEpic(action$, state$) {
  return action$.pipe(
    ofType(LOCATION_CHANGE),
    filter(() => needInitializeSearchLocations(state$.value)),
    map(() => {
      return TimezoneActions.getTimezones();
    })
  );
}

function needInitializeSearchLocations(state) {
  const timezones = TimezonesSelectors.timezonesSelector(state);
  return (
    state.router.location.pathname.indexOf(`${Routes.TIME}`) >= 0 &&
    isEmpty(timezones)
  );
}
