/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2022 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import { LOCATION_CHANGE } from "connected-react-router";
import { ofType } from "redux-observable";
import { map, filter } from "rxjs/operators";

import { CurrencyActions, ReservationSelectors } from "..";
import { reservationActionTypes, eventDetailsActionTypes } from "../../utils";

export function getCurrenciesEpic(action$, state$) {
  return action$.pipe(
    ofType(
      reservationActionTypes.SET_RESOURCES_ON_HOLD,
      reservationActionTypes.SET_RESERVED_RESOURCES,
      eventDetailsActionTypes.SET_EVENT_COST_SUMMARY
    ),
    map(() => {
      return CurrencyActions.getCurrencies();
    })
  );
}

export function getCurrenciesForReadOnlyEpic(action$, state$) {
  return action$.pipe(
    ofType(LOCATION_CHANGE),
    filter(() => ReservationSelectors.detailPageRouteSelector(state$.value)),
    map(() => {
      return CurrencyActions.getCurrencies();
    })
  );
}
