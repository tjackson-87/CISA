/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/


import { LOCATION_CHANGE } from "connected-react-router";
import { ofType } from "redux-observable";
import { switchMap } from "rxjs/operators";
import { Observable } from "rxjs";
import groupBy from "lodash/groupBy";
import sortBy from "lodash/sortBy";
import isEmpty from "lodash/isEmpty";
import Timeout from "await-timeout";
import moment from "moment-timezone";
import { matchPath } from "react-router-dom";
import {
  Routes,
  EventUtils,
  ReservationTypes,
  ReservableSpacesConstants,
  Status,
  eventDetailsActionTypes,
  ReservationUtils,
} from "../../utils";
import {
  Exchange,
  EquipmentOrdersDS,
  MyCalendarDS,
  FoodOrderItemsDS,
  ReservationOnlineMeetingDS,
  ReservationDS,
  ReservableSpacesDS,
  ReservationInstancesDS,
  ActiveUsersDS,
  OnlineMeetingDS,
  ReservationSpacesDS,
  CurrentUserDS,
  PurchaseOrdersDS,
} from "../../model";
import {
  RouteActions,
  EventDetailsActions,
  MyCalendarSelectors,
  getAppStore,
  ExchangeActions,
  LoadingActions,
  CurrentUserSelectors,
  ApplicationSettingsSelectors,
  CurrentUserActions,
  MyCalendarActions,
  ReserveEventTypesActions,
  TimezonesSelectors,
  ReservationSelectors,
  EventDetailsSelectors,
  SavedReservationSelectors,
} from "..";
import { isNil } from "lodash";
import { getCateringForOccurrence } from "../../utils/Catering/CateringUtils";

const { RESERVATION_CLASS_REQUESTABLE } = ReservableSpacesConstants;

export function getEventDetailsEpic(action$, state$) {
  return action$.pipe(
    ofType(LOCATION_CHANGE),
    switchMap(() => getEventDetails(false, state$))
  );
}

export function reFetchDetailsEpic(action$, state$) {
  return action$.pipe(
    ofType(eventDetailsActionTypes.REFETCH_EVENT),
    switchMap(() => getEventDetails(true, state$))
  );
}

export function fetchDetailsEpic(action$, state$) {
  return action$.pipe(
    ofType(eventDetailsActionTypes.FETCH_EVENT),
    switchMap(() => getEventDetails(true, state$, true))
  );
}

function getEventDetails(force, state$, fetchParamsFromReservation) {
  return new Observable(async (subscriber) => {
    let needDescriptionAndAttendees = false;
    try {
      let eventParams = null;
      const savedReservationId = SavedReservationSelectors.savedReservationIdSelector(
        state$.value
      );
      const updatedReservationId = ReservationSelectors.reservationIdSelector(
        state$.value
      );
      if (fetchParamsFromReservation) {
        if (
          EventDetailsSelectors.eventDetailsSelector(state$.value) === null ||
          savedReservationId !== updatedReservationId
        ) {
          eventParams = {
            eventId: isNil(
              ReservationSelectors.exchangeEventIdSelector(state$.value)
            )
              ? ReservationSelectors.reservationIdSelector(state$.value)
              : ReservationSelectors.exchangeEventIdSelector(state$.value),
            start: ReservationSelectors.eventStartSelector(state$.value),
            end: ReservationSelectors.eventEndSelector(state$.value),
          };
        }
      } else {
        eventParams = ReservationSelectors.detailPageRouteSelector(state$.value)
          ? null
          : getEventParams(state$.value);
      }

      if (eventParams != null) {
        const event = await getEvent(eventParams, force, state$);
        if (event != null) {
          subscriber.next(EventDetailsActions.setEventDetail(event));
          const roomSpaceIdList = [];
          for (let i = 0; event.rooms && i < event.rooms.length; i++) {
            if (
              event.rooms[i].reservationClassNameENUS ===
                RESERVATION_CLASS_REQUESTABLE &&
              event.rooms[i].statusENUS === Status.REVIEW_IN_PROGRESS
            ) {
              roomSpaceIdList.push(event.rooms[i].spaceRecordId);
            }
            const contactRoles = !isEmpty(roomSpaceIdList)
              ? await ReservableSpacesDS.getContactRoles(null, roomSpaceIdList)
              : [];
            subscriber.next(
              EventDetailsActions.setEventRoomsContactRole(contactRoles)
            );
          }
          const contactRoles = !isEmpty(roomSpaceIdList)
            ? await ReservableSpacesDS.getContactRoles(null, roomSpaceIdList)
            : [];
          subscriber.next(
            EventDetailsActions.setEventRoomsContactRole(contactRoles)
          );
          const instance = await ReservationInstancesDS.getLatestReservationInstanceByReservation(
            event.reservationId,
            event.start
          );
          if (!isEmpty(instance)) {
            subscriber.next(EventDetailsActions.setEventInstance(instance));
          }
          if (
            event.reservationId != null &&
            event.locationType === ReservationTypes.MEETING
          ) {
            const equipment = await EquipmentOrdersDS.getEquipmentOrders(
              event.reservationId
            );
            const foodOrderItems = await FoodOrderItemsDS.getFoodOrderItems(
              event.reservationId
            );
            const purchaseOrders = await PurchaseOrdersDS.getPurchaseOrders(
              foodOrderItems?.map((item) => item.orderId)
            );
            const costSummary = await ReservationDS.getReservation(
              event.reservationId
            );
            subscriber.next(
              EventDetailsActions.setReservationCostSummary(costSummary)
            );
            const equipmentByRoom = groupBy(equipment, (space) => {
              return space.resource.id;
            });

            const cateringForOccurrence = getCateringForOccurrence(
              foodOrderItems,
              event.rooms,
              purchaseOrders,
              event.start,
              event.end,
              event.isAllDay
            );

            const cateringByRoom = groupBy(
              cateringForOccurrence,
              (space) => space.resource.id
            );

            subscriber.next(
              EventDetailsActions.setEquipmentToEventDetail(equipmentByRoom)
            );
            subscriber.next(
              EventDetailsActions.setCateringToEventDetail(cateringByRoom)
            );
            const onlineMeetingInfo = await ReservationOnlineMeetingDS.getReservationOnlineMeeting(
              event.reservationId
            );

            subscriber.next(
              EventDetailsActions.setOnlineMeetingToEventDetail(
                onlineMeetingInfo
              )
            );
          }
          if (event.id != null) {
            if (
              event.isOrganizer &&
              event.isRecurringReservation &&
              !event.isRoomOnly
            ) {
              getHasSomeButNotEveryResourceInSeriesOccurrences(
                state$.value,
                event.seriesICalUId
              );
            }

            if (isEmpty(event.room) && !event.isOrganizer) {
              await getEventRoomByExchangeMailbox(event);
            }
            getAppStore().dispatch(
              LoadingActions.setLoading(
                "loadingEventDescriptionAndAttendees",
                true
              )
            );
            needDescriptionAndAttendees = true;
            const {
              description,
              attendees,
              eventExtension,
            } = await getEventDescriptionAndAttendees(event, state$.value);
            subscriber.next(
              EventDetailsActions.setEventDescriptionAndAttendees(
                description,
                sortBy(attendees, "emailAddress.name")
              )
            );
            subscriber.next(
              EventDetailsActions.setEventExtension(eventExtension)
            );
            //TODO Exchange Intergration Check
            // CISA
            const isExchangeIntegrated = ApplicationSettingsSelectors.isExchangeIntegratedSelector(
              state$.value
            );
            if(isExchangeIntegrated){
              if (eventExtension.onlineMeetingID) {
                const onlineMeetingInfo = await OnlineMeetingDS.getTeamsMeetingByID(
                  eventExtension.onlineMeetingID
                );
                subscriber.next(
                  EventDetailsActions.setOnlineMeetingToEventDetail(
                    onlineMeetingInfo
                  )
                );
              }
            } else {
              if (eventExtension.onlineMeetingID) {
                const onlineMeetingInfo = await OnlineMeetingDS.getOnlineMeetingByID(
                  eventExtension.onlineMeetingID
                );
                subscriber.next(
                  EventDetailsActions.setOnlineMeetingToEventDetail(
                    onlineMeetingInfo
                  )
                );
              }
            }
          } else {
            if (event.reservationId != null) {
              getAppStore().dispatch(
                LoadingActions.setLoading(
                  "loadingEventDescriptionAndAttendees",
                  true
                )
              );
              needDescriptionAndAttendees = true;
              const {
                description,
                attendees,
              } = await ReservationDS.getReservationDescriptionAndAttendees(
                event.reservationId
              );
              subscriber.next(
                EventDetailsActions.setEventDescriptionAndAttendees(
                  description,
                  sortBy(attendees, "emailAddress.name")
                )
              );
            }
          }
        } else {
          await Timeout.set(100);
          subscriber.next(RouteActions.navigateToHomePage(true));
        }
      }
    } catch {
    } finally {
      if (needDescriptionAndAttendees) {
        getAppStore().dispatch(
          LoadingActions.setLoading(
            "loadingEventDescriptionAndAttendees",
            false
          )
        );
      }
      subscriber.complete();
    }
  });
}

async function checkIsDelegateFor(user) {
  const accessToken = await getAppStore().dispatch(
    ExchangeActions.getAzureAccessToken()
  );
  const response = await Exchange.getAllCalendars(accessToken);
  return (
    !isNil(response.result) &&
    response.result.findIndex((calendar) => calendar.email === user.email) > -1
  );
}

async function getEvent(eventParams, force, state$) {
  let event = MyCalendarSelectors.eventSelector(
    state$.value,
    eventParams.eventId,
    eventParams.start,
    eventParams.end
  );
  if (!event || force) {
    let tririgaEvent = null;
    let exchangeEvent = null;
    const isExchangeIntegrated = ApplicationSettingsSelectors.isExchangeIntegratedSelector(
      state$.value
    );
    const timezone = await getAppStore().dispatch(
      CurrentUserActions.getDefaultTimezone()
    );
    if (isNaN(eventParams.eventId) && isExchangeIntegrated) {
      exchangeEvent = await getExchangeEventById(timezone, eventParams.eventId);
      let personId = CurrentUserSelectors.personIdSelector(state$.value);
      if (!isNil(exchangeEvent.organizer.emailAddress.address)) {
        const user = await ActiveUsersDS.getUserByEmail(
          exchangeEvent.organizer.emailAddress.address
        );
        if (!isNil(user) && !isNil(checkIsDelegateFor(user))) {
          personId = user.personId;
        }
      }
      tririgaEvent = await MyCalendarDS.getMyCalendarEventByICalUId(
        eventParams.start,
        eventParams.end,
        personId,
        exchangeEvent.iCalUId,
        exchangeEvent.seriesICalUId
      );
    } else {
      const delegateUsers = await CurrentUserDS.getReservationDelegateFor();
      const delegateCalendarDetails = await CurrentUserDS.getDelegateCalendar(
        eventParams.eventId,
        delegateUsers
      );
      tririgaEvent = await MyCalendarDS.getMyCalendarEventByReservationId(
        eventParams.start,
        eventParams.end,
        delegateCalendarDetails?.delegatePersonID,
        eventParams.eventId
      );
      if (tririgaEvent.iCalUId != null && isExchangeIntegrated) {
        const currentCalendar = await getCurrentCalendar(
          delegateCalendarDetails.delegateEmailID
        );
        exchangeEvent = await getExchangeEventByICalUId(
          tririgaEvent.start,
          tririgaEvent.end,
          timezone,
          tririgaEvent.iCalUId,
          currentCalendar
        );
      }
    }
    const reserveEventTypes = await await getAppStore().dispatch(
      ReserveEventTypesActions.getReserveEventTypes()
    );
    const timezones = TimezonesSelectors.timezonesSelector(state$.value);
    EventUtils.mapReservationTimezoneInEnglish(tririgaEvent, timezones);
    tririgaEvent = EventUtils.computeEventLocationType(
      tririgaEvent,
      reserveEventTypes
    );
    event = EventUtils.combineExchangeEventWithTririgaEvent(
      exchangeEvent,
      tririgaEvent
    );
    await MyCalendarActions.getEventRooms([event]);
  }
  return event;
}

async function getCurrentCalendar(email) {
  const accessToken = await getAppStore().dispatch(
    ExchangeActions.getAzureAccessToken()
  );

  const response = await Exchange.getAllCalendars(accessToken);
  if (response.success) {
    return response.result.find((calendar) => calendar.email === email);
  }
}

function getEventParams(state) {
  const match = matchPath(state.router.location.pathname, {
    path: `${Routes.EVENT_DETAILS}/:eventId/:start/:end`,
  });
  return match != null
    ? {
        eventId: match.params.eventId,
        start: moment(Number(match.params.start)).toISOString(true),
        end: moment(Number(match.params.end)).toISOString(true),
      }
    : null;
}

async function getExchangeEventByICalUId(
  start,
  end,
  timezone,
  iCalUId,
  calendar
) {
  const accessToken = await getAppStore().dispatch(
    ExchangeActions.getAzureAccessToken()
  );
  return Exchange.getCalendarEventByICalUId(
    accessToken,
    start,
    end,
    timezone,
    iCalUId,
    true,
    calendar
  );
}

async function getExchangeEventById(timezone, eventId) {
  const accessToken = await getAppStore().dispatch(
    ExchangeActions.getAzureAccessToken()
  );
  return Exchange.getCalendarEventById(accessToken, timezone, eventId);
}

async function getEventDescriptionAndAttendees(event, state) {
  const accessToken = await getAppStore().dispatch(
    ExchangeActions.getAzureAccessToken()
  );
  const {
    description,
    attendees,
  } = await Exchange.getEventDescriptionAndAttendees(
    accessToken,
    event.id,
    event.reservationId
  );
  const eventExtension = await Exchange.getEventExtension(
    accessToken,
    event.id
  );
  const eventRoom = EventDetailsSelectors.eventRoomsSelector(state);
  let attendeesWithoutRooms, displayDescription;
  if (!isEmpty(event.rooms)) {
    attendeesWithoutRooms = attendees.filter(
      (attendee) =>
        !event.rooms.some(
          (room) => room.exchangeMailbox === attendee.emailAddress.address
        )
    );
    displayDescription = description;
  } else if (!event.isOrganizer) {
    const attendeesWithoutOrganizer = attendees.filter(
      (attendee) =>
        attendee.emailAddress.address !== event.organizer.emailAddress.address
    );
    attendeesWithoutRooms = attendeesWithoutOrganizer.filter(
      (attendee) =>
        !eventRoom?.some(
          (room) => room.exchangeMailbox === attendee.emailAddress.address
        )
    );
    displayDescription = description;
  } else {
    displayDescription = ReservationUtils.removeOnlineMeetingFromDescription(
      description
    );
    attendeesWithoutRooms = attendees;
  }

  return {
    description: displayDescription,
    attendees: attendeesWithoutRooms,
    eventExtension,
  };
}

async function getEventRoomByExchangeMailbox(event) {
  const ExchangeMailbox = event.attendees.map((e) => {
    return e.emailAddress.address;
  });
  if (!isEmpty(ExchangeMailbox)) {
    const reservedRoom = await ReservationSpacesDS.getReservationSpacesByRoomExchange(
      ExchangeMailbox
    );
    getAppStore().dispatch(EventDetailsActions.setEventRooms(reservedRoom));
  }
}

function getHasSomeButNotEveryResourceInSeriesOccurrences(state, iCalUId) {
  const seriesOccurrences = MyCalendarSelectors.seriesOccurrencesSelector(
    state,
    iCalUId
  );
  const hasSomeButNotEveryResourceInSeriesOccurrences =
    seriesOccurrences.some((item) => !isEmpty(item.attendees.filter((a) => a.type === "resource"))) &&
    !seriesOccurrences.every((item) =>  !isEmpty(item.attendees.filter((a) => a.type === "resource")))

  getAppStore().dispatch(
    EventDetailsActions.setHasSomeButNotEveryResourceInSeriesOccurrences(
      hasSomeButNotEveryResourceInSeriesOccurrences
    )
  );
}
