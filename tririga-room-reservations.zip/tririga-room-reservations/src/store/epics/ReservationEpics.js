/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/

import { LOCATION_CHANGE } from "connected-react-router";
import { ofType } from "redux-observable";
import { map, filter, switchMap, takeUntil } from "rxjs/operators";
import { Observable, timer, EMPTY } from "rxjs";
import { isEmpty, isEqual } from "lodash";
import {
  ReservationActions,
  LayoutTypesActions,
  ReservationSelectors,
  CurrentUserActions,
  CurrentUserSelectors,
} from "..";
import {
  reservationActionTypes,
  Routes,
  currentUserActionTypes,
  ReservationTypes,
  roomSearchActionTypes,
  getRecurrenceDetails,
} from "../../utils";

const {
  INITIALIZE_NEW_RESERVATION,
  UPDATE_HOLD_TIME_END,
  CLEAR_RESERVATION,
} = reservationActionTypes;

const { SET_FILTER_MODAL } = roomSearchActionTypes;

export function newReservationEpic(action$, state$) {
  return action$.pipe(
    ofType(LOCATION_CHANGE),
    switchMap(() => initializeNewReservation(state$))
  );
}

function initializeNewReservation(state$) {
  return new Observable(async (subscriber) => {
    const state = state$.value;
    try {
      if (isEmpty(state.reservation.data)) {
        // Office support CISA
        const { MEETING, WORKSPACE, OFFICE } = Routes;
        const pathname = state.router.location.pathname;
        const match = pathname.match(new RegExp(`(${MEETING}|${WORKSPACE}|${OFFICE})`));
        if (match != null)
          subscriber.next(
            ReservationActions.initializeNewReservation(
              match[1] === Routes.MEETING ? ReservationTypes.MEETING
                : match[1] === Routes.OFFICE ? ReservationTypes.OFFICE
                : ReservationTypes.WORKSPACE
            )
          );
      }
    } finally {
      subscriber.complete();
    }
  });
}

export function resetTimeStepTempData(action$, state$) {
  return action$.pipe(
    ofType(LOCATION_CHANGE),
    filter(() => needResetTimeStepTempData(state$.value)),
    map(() => ReservationActions.resetTimeStepTempDateAndTime())
  );
}

export function getLayoutTypesEpic(action$, state$) {
  return action$.pipe(
    ofType(SET_FILTER_MODAL),
    filter(() => isNavigatingToRoomSearchFilterPage(state$.value)),
    map(() => LayoutTypesActions.initLayoutTypes())
  );
}

function isNavigatingToRoomSearchFilterPage(state) {
  return state.roomSearch.isFilterModalOpen;
}

export function getFavoriteRoomsEpic(action$, state$) {
  return action$.pipe(
    ofType(
      LOCATION_CHANGE,
      currentUserActionTypes.SET_CURRENT_USER,
      reservationActionTypes.SET_RESERVED_RESOURCES
    ),
    filter(() => needGetCurrentUserRooms(state$.value)),
    map(() => CurrentUserActions.getFavoriteRooms())
  );
}

export function getPrivateRoomsEpic(action$, state$) {
  return action$.pipe(
    ofType(
      LOCATION_CHANGE,
      currentUserActionTypes.SET_CURRENT_USER,
      reservationActionTypes.SET_RESERVED_RESOURCES
    ),
    filter(() => needGetCurrentUserRooms(state$.value)),
    map(() => CurrentUserActions.getPrivateRooms())
  );
}

export function checkHoldTimeExpired(action$) {
  return action$.pipe(
    ofType(UPDATE_HOLD_TIME_END),
    switchMap(({ holdTimeEnd }) => {
      if (isEmpty(holdTimeEnd)) {
        return EMPTY;
      } else {
        return timer(new Date(holdTimeEnd)).pipe(
          map(() => ReservationActions.setHoldTimeExpired()),
          takeUntil(
            action$.pipe(
              ofType(
                UPDATE_HOLD_TIME_END,
                INITIALIZE_NEW_RESERVATION,
                CLEAR_RESERVATION
              )
            )
          )
        );
      }
    })
  );
}

let lastTimeStepTempData = null;

function needResetTimeStepTempData(state) {
  const timeStepTempData = ReservationSelectors.timeStepTempDateAndTimeSelector(
    state
  );
  if (
    !isEmpty(timeStepTempData) &&
    timeStepTempData !== lastTimeStepTempData &&
    (state.router.location.pathname === `${Routes.MEETING}` ||
      state.router.location.pathname === `${Routes.WORKSPACE}`)
  ) {
    lastTimeStepTempData = timeStepTempData;
    return true;
  }
  return false;
}

function needGetCurrentUserRooms(state) {
  const rooms = CurrentUserSelectors.favoriteRoomsSelector(state);
  const resources = ReservationSelectors.resourcesSelector(state);
  if (ReservationSelectors.detailPageRouteSelector(state)) {
    return false;
  }
  return (
    (!rooms &&
      state.router.location.pathname.indexOf(`${Routes.SEARCH}`) >= 0) ||
    !isEmpty(resources)
  );
}

export function updateRoomsWhenDateTimeAndOccurrenceRuleChanged(
  action$,
  state$
) {
  return action$.pipe(
    ofType(reservationActionTypes.UPDATE_RESERVATION_DATA),
    filter(() => shouldUpdateRooms(state$.value)),
    map(() =>
      ReservationActions.updateRoomsWhenDateTimeAndOccurrenceRuleChanged()
    )
  );
}

let lastUpdatedDateAndTime = null;
let lastRecurrence = null;
let lastSubject = null;

export function resetLastLocalVariables(action$, state$) {
  return action$.pipe(
    ofType(LOCATION_CHANGE),
    filter(() => {
      if (
        state$.value.router.location.pathname === Routes.HOME &&
        lastSubject
      ) {
        lastUpdatedDateAndTime = null;
        lastRecurrence = null;
        lastSubject = null;
      }
    })
  );
}

function shouldUpdateRooms(state) {
  const subject = ReservationSelectors.subjectSelector(state);
  const dateAndTime = ReservationSelectors.dateAndTimeSelector(state);
  const resources = ReservationSelectors.resourcesSelector(state);
  const isUpdate = !ReservationSelectors.isCreateSelector(state);
  const recurrence = getRecurrenceDetails(
    ReservationSelectors.recurrenceSelector(state)
  );
  const reservationType = ReservationSelectors.reservationTypeSelector(state);

  if (
    (!lastSubject || !lastRecurrence) &&
    isUpdate &&
    recurrence &&
    !isEmpty(ReservationSelectors.initUpdatedDataSelector(state))
  ) {
    const {
      subject: initUpdatedSubject,
      recurrence: initUpdatedRecurrence,
    } = ReservationSelectors.initUpdatedDataSelector(state);
    lastSubject = initUpdatedSubject;
    lastRecurrence = getRecurrenceDetails(initUpdatedRecurrence);
  }
  if (
    !isEmpty(subject) &&
    lastSubject !== subject &&
    reservationType === ReservationTypes.MEETING
  ) {
    lastSubject = subject;
    lastUpdatedDateAndTime = dateAndTime;
    lastRecurrence = recurrence;
    return false;
  }
  if (
    !isEmpty(resources) &&
    !isEmpty(recurrence) &&
    (!isEqual(lastUpdatedDateAndTime, dateAndTime) ||
      !isEqual(lastRecurrence, recurrence))
  ) {
    lastUpdatedDateAndTime = dateAndTime;
    lastRecurrence = recurrence;
    return true;
  }

  if (!lastUpdatedDateAndTime || !lastRecurrence) {
    lastUpdatedDateAndTime = dateAndTime;
    lastRecurrence = recurrence;
  }

  if (lastRecurrence && !recurrence) {
    lastRecurrence = null;
  }

  return false;
}
