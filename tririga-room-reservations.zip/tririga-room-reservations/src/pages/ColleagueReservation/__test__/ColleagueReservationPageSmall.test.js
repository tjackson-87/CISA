/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2023 The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import { screen, fireEvent } from "@testing-library/react";
import ColleagueReservationPageSmall from "../ColleagueReservationPageSmall";
import { AppMsg } from "../../../utils";
import { getAppStore, RouteActions } from "../../../store";
import { Button } from "carbon-addons-iot-react";
import { reservationReducer } from "../../../store/reducers/ReservationReducer";

import {
  renderWithReduxAndDictionaryProvider,
  MOCK_COLLEAGUE,
} from "../../../testUtils";

afterEach(() => jest.clearAllMocks());
const appMessages = AppMsg.getAppMessages();

jest.mock("../../../store/actions/RouteActions");
jest.mock("../../../store/actions/ReservationActions");

RouteActions.navigateToReservationSearch.mockImplementation(() => jest.fn());

jest.mock("../../../components/FooterButtons/FooterButtons", () => {
  return MockedFooterButtons;
});

function MockedFooterButtons({
  // eslint-disable-next-line react/prop-types
  secondaryClickedHandler,
}) {
  return (
    <>
      <Button onClick={secondaryClickedHandler} aria-label="cancel" />
    </>
  );
}

jest.mock("../../../components/UserCard/UserCard", () => {
  return MockedUserCard;
});

function MockedUserCard() {
  return (
    <>
      <div data-testid="userCard-name">{MOCK_COLLEAGUE.name}</div>
    </>
  );
}

const props = {};

describe("ColleagueReservationPageSmall", () => {
  beforeEach(() => {
    const initialReservationState = {
      ...getAppStore().getState.reservation,
      colleagueReservation: {
        colleagueDetails: MOCK_COLLEAGUE,
      },
    };

    const initialState = {
      ...getAppStore().getState(),
      reservation: initialReservationState,
    };

    renderWithReduxAndDictionaryProvider(
      <ColleagueReservationPageSmall {...props} />,
      {
        initialState,
        reducer: reservationReducer,
      },
      appMessages
    );
  });

  it("renders correctly", () => {
    const cancelButton = screen.getByRole("button", { name: /cancel/i });
    expect(cancelButton).toBeInTheDocument();
  });

  it("On click of cancel page should navigate to work space reservation", () => {
    const cancelButton = screen.getByRole("button", { name: /cancel/i });
    fireEvent.click(cancelButton);
    expect(RouteActions.navigateToReservationSearch).toBeCalled();
  });
});
