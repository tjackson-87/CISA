/* IBM Confidential· - OCO Source Materials· - (C) COPYRIGHT IBM CORP. 2023 - The source code for this program is not published or otherwise· divested of its trade secrets, irrespective of what has been· deposited with the U.S. Copyright Office. */

import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import {
  ColleagueReservationStepLink,
  ColleagueUpcomingReservations,
  FooterButtons,
  UserCard,
} from "../../components";
import {
  RouteActions,
  LoadingSelectors,
  ColleagueActions,
  CurrentUserSelectors,
  ColleagueSelectors,
  ReservationActions,
  RoomSearchActions,
} from "../../store";
import {
  AppMsg,
  getColleagueReservationDateTime,
  ReservationTypes,
} from "../../utils";
import { isNil } from "lodash";

const cssBase = "colleagueReservationPageSmall";

class ColleagueReservationPageSmall extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    navigateToReservationSearchfromColleaguePage: PropTypes.func,
    setSelectedColleague: PropTypes.func,
    setColleagueDetails: PropTypes.func,
    loadMoreReservations: PropTypes.func,
    colleagueDetails: PropTypes.object,
    upcomingReservations: PropTypes.array,
    defaultTimezone: PropTypes.string,
    loadingColleagueReservations: PropTypes.bool,
    loadingMoreEventsAfter: PropTypes.bool,
    updateDateAndTime: PropTypes.func,
    setSelectedColleagueReservationRoom: PropTypes.func,
    handleSetSelectedColleagueReservationBuilding: PropTypes.func,
    getRoomsInFloorPlanNearBy: PropTypes.func,
    setColleagueReservedRoom: PropTypes.func,
    setReservationType: PropTypes.func,
    setAssignedSeatData: PropTypes.func,
    setSelectedColleagueReservationFloor: PropTypes.func,
    setRoomsFilter: PropTypes.func,
  };

  constructor(props) {
    super(props);
    this.content = React.createRef();
    this.pageTitle = React.createRef();
  }

  componentDidMount() {
    if (this.pageTitle) {
      this.pageTitle.focus();
    }
  }

  onHandleCancel() {
    const {
      navigateToReservationSearchfromColleaguePage,
      setSelectedColleague,
      setColleagueDetails,
    } = this.props;
    setSelectedColleague(null);
    setColleagueDetails(null);
    navigateToReservationSearchfromColleaguePage();
  }

  render() {
    const {
      colleagueDetails,
      upcomingReservations,
      defaultTimezone,
      loadingColleagueReservations,
      loadingMoreEventsAfter,
      loadMoreReservations,
    } = this.props;
    return (
      <main className={cssBase}>
        <div className={`${cssBase}__header`}>
          <div className={`${cssBase}__title`}>
            <span
              tabIndex={0}
              aria-label={
                this.props.appMessages[AppMsg.SELECT_COLLEAGUE_RESERVATION]
              }
              ref={(element) => {
                this.pageTitle = element;
              }}
            >
              {this.props.appMessages[AppMsg.SELECT_COLLEAGUE_RESERVATION]}
            </span>
          </div>
        </div>
        <div
          className={`${cssBase}__content`}
          ref={(element) => {
            this.content = element;
          }}
        >
          <div className={`${cssBase}__userCard`}>
            {colleagueDetails && colleagueDetails.name && (
              <UserCard
                calendar={colleagueDetails}
                showChangeUser={false}
                isColleague={true}
              />
            )}
          </div>
          {colleagueDetails?.primaryLocation && (
            <ColleagueReservationStepLink
              name={[
                <span className={`${cssBase}__stepName`} key={1}>
                  {
                    this.props.appMessages[
                      AppMsg.RESERVATION_MESSAGE.STEP_ASSIGNED_SEAT
                    ]
                  }
                  , <strong key={2}>{colleagueDetails?.primaryLocation}</strong>
                </span>,
              ]}
              ariaLabel={
                this.props.appMessages[
                  AppMsg.RESERVATION_MESSAGE.STEP_ASSIGNED_SEAT
                ] +
                colleagueDetails?.primaryLocation +
                ", " +
                computeAddress(colleagueDetails)
              }
              children={
                <div className={`${cssBase}__stepChild`}>
                  <div className={`${cssBase}__childContent`}>
                    {computeAddress(colleagueDetails)}
                  </div>
                </div>
              }
              className={`${cssBase}__stepLink`}
              onClick={this.handleColleagueAssignSeatClick}
            />
          )}
          <ColleagueUpcomingReservations
            upcomingReservations={upcomingReservations}
            timezone={defaultTimezone}
            loading={loadingColleagueReservations}
            loadingMoreEventsAfter={loadingMoreEventsAfter}
            loadMore={loadMoreReservations}
            content={this.content.offsetHeight}
            onClick={this.handleUpcomingReservation}
            onKeyDown={this.handleKeyDown}
            shareWorkSpace={colleagueDetails?.shareWorkspace}
          />
        </div>
        <FooterButtons
          secondaryLabel={this.props.appMessages[AppMsg.BUTTON.CANCEL]}
          secondaryClickedHandler={() => this.onHandleCancel()}
        />
      </main>
    );
  }

  setColleagueLocation = async (room, buildingId) => {
    const {
      setSelectedColleagueReservationRoom,
      handleSetSelectedColleagueReservationBuilding,
      getRoomsInFloorPlanNearBy,
    } = this.props;
    await handleSetSelectedColleagueReservationBuilding(buildingId);
    setSelectedColleagueReservationRoom(room);
    getRoomsInFloorPlanNearBy(room);
  };

  handleUpcomingReservation = async (event) => {
    const {
      navigateToReservationSearchfromColleaguePage,
      updateDateAndTime,
      setColleagueReservedRoom,
      setReservationType,
      defaultTimezone,
      setSelectedColleagueReservationFloor,
      setRoomsFilter,
    } = this.props;
    if (!isNil(event)) {
      const dateTimeObject = getColleagueReservationDateTime(
        event,
        defaultTimezone
      );
      updateDateAndTime(dateTimeObject);
      setReservationType(ReservationTypes.WORKSPACE);
      let room = {};
      if (event.rooms && event.rooms.length) {
        room = event.rooms[0];
        const buildingId = room.buildingSystemRecordID;
        await this.setColleagueLocation(room, buildingId);
        setColleagueReservedRoom({ ...room, reservedRoom: true });
      }
      setSelectedColleagueReservationFloor({
        area: room.area,
        level: room.floorLevel,
        name: room.floor,
        _id: room.floorSystemRecordID,
        buildingSystemRecordID: room.buildingSystemRecordID,
      });

      setRoomsFilter([]);
      navigateToReservationSearchfromColleaguePage();
    }
  };

  handleKeyDown = (event) => {
    if (event.key === "Escape") {
      const cancelBtn = document.getElementById("secondary-button");
      if (cancelBtn) {
        cancelBtn.focus();
      }
    }
  };

  handleColleagueAssignSeatClick = async () => {
    const {
      colleagueDetails: colleague,
      navigateToReservationSearchfromColleaguePage,
      setReservationType,
      setAssignedSeatData,
      setSelectedColleagueReservationFloor,
      setRoomsFilter,
    } = this.props;
    setReservationType(ReservationTypes.WORKSPACE);
    const room = {
      _id: colleague.roomSystemRecordID,
      spaceRecordId: colleague.roomSystemRecordID,
      area: colleague.roomArea,
      grossArea: colleague.floorGrossArea,
      floorSystemRecordID: colleague.floorSystemRecordID,
      buildingSystemRecordID: colleague.buildingSystemRecordID,
    };
    const buildingId = colleague.buildingSystemRecordID;
    await this.setColleagueLocation(room, buildingId);
    setAssignedSeatData(room, colleague);
    setSelectedColleagueReservationFloor({
      area: colleague.roomArea,
      level: colleague.floorLevel,
      name: colleague.floor,
      _id: colleague.floorSystemRecordID,
      buildingSystemRecordID: colleague.buildingSystemRecordID,
    });
    setRoomsFilter([]);
    navigateToReservationSearchfromColleaguePage();
  };
}

function computeAddress(colleagueDetails) {
  if (!colleagueDetails) return "";
  const { floor, building, property } = colleagueDetails;
  const addressArr = [floor, building, property];
  return addressArr.filter((e) => e !== null).join(", ");
}

const { navigateToReservationSearchfromColleaguePage } = RouteActions;
const {
  setSelectedColleague,
  loadMoreReservations,
  setColleagueDetails,
  setSelectedColleagueReservationRoom,
  handleSetSelectedColleagueReservationBuilding,
  setColleagueReservedRoom,
  setAssignedSeatData,
  setSelectedColleagueReservationFloor,
} = ColleagueActions;
const { getRoomsInFloorPlanNearBy, setRoomsFilter } = RoomSearchActions;
const { updateDateAndTime, setReservationType } = ReservationActions;

const mapStateToProps = (state) => {
  return {
    colleagueDetails: ColleagueSelectors.colleagueDetailsSelector(state),
    upcomingReservations: ColleagueSelectors.limitUpcomingReservationsSelector(
      state
    ),
    defaultTimezone: CurrentUserSelectors.defaultTimezoneSelector(state),
    loadingMoreEventsAfter: LoadingSelectors.loadingMoreEventsAfterSelector(
      state
    ),
    loadingColleagueReservations: LoadingSelectors.loadingColleagueReservationsSelector(
      state
    ),
  };
};

export default withTriDictionary(
  connect(mapStateToProps, {
    navigateToReservationSearchfromColleaguePage,
    setSelectedColleague,
    setColleagueDetails,
    loadMoreReservations,
    updateDateAndTime,
    setSelectedColleagueReservationRoom,
    handleSetSelectedColleagueReservationBuilding,
    getRoomsInFloorPlanNearBy,
    setColleagueReservedRoom,
    setReservationType,
    setAssignedSeatData,
    setSelectedColleagueReservationFloor,
    setRoomsFilter,
  })(ColleagueReservationPageSmall)
);
