/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import { TooltipIcon } from "carbon-components-react";
import { Close20, Repeat16 } from "@carbon/icons-react";

import { AppMsg } from "../../utils";
import {
  ReservationActions,
  ReservationSelectors,
  RouteActions,
  LayoutSelectors,
} from "../../store";
import {
  FooterButtons,
  HoldCountDown,
  ExceptionList,
  SelectedRoom,
} from "../../components";
import { withTriDictionary } from "@tririga/tririga-react-components";
import { isEmpty } from "lodash";

const cssBase = "occurrenceExceptionsPageSmall";

class OccurrenceExceptionsPageSmall extends React.PureComponent {
  static propTypes = {
    reservationType: PropTypes.string,
    renewHold: PropTypes.func.isRequired,
    recurrence: PropTypes.object,
    navigateToReservationSummary: PropTypes.func,
    exceptions: PropTypes.array,
    room: PropTypes.object,
    resolvedCount: PropTypes.number,
    holdTimeEnd: PropTypes.string,
    appMessages: PropTypes.object,
    navigateToReservationSearch: PropTypes.func.isRequired,
    setSelectedResourceException: PropTypes.func.isRequired,
    dir: PropTypes.string,
    roomsOnHold: PropTypes.array,
    holdRooms: PropTypes.func.isRequired,
    exceptionRooms: PropTypes.array,
  };

  static defaultProps = {
    room: {},
    roomsOnHold: [],
    exceptions: [],
    resolvedCount: 0,
    holdTimeEnd: null,
    exceptionRooms: [],
  };

  constructor(props) {
    super(props);
    this.closeButtonRef = React.createRef();
  }

  render() {
    const {
      renewHold,
      reservationType,
      recurrence,
      navigateToReservationSummary,
      holdTimeEnd,
      appMessages,
      exceptions,
      resolvedCount,
      room,
      dir,
    } = this.props;

    return (
      <main className={cssBase}>
        <div className={`${cssBase}__header`}>
          <div className={`${cssBase}__titleContainer`}>
            <span className={`${cssBase}__title`}>
              {appMessages[AppMsg.RESERVATION_MESSAGE.OCCURRENCE_EXCEPTION]}
            </span>
            <div
              onClick={navigateToReservationSummary}
              onKeyDown={(e) =>
                e.key === "Enter" ? navigateToReservationSummary : null
              }
              className={`${cssBase}__closeButton`}
              ref={this.closeButtonRef}
            >
              <TooltipIcon
                direction="left"
                align={dir === "ltr" ? "start" : "end"}
                tooltipText={appMessages[AppMsg.BUTTON.CLOSE]}
                aria-label={appMessages[AppMsg.BUTTON.CLOSE]}
              >
                <Close20 />
              </TooltipIcon>
            </div>
          </div>
          {holdTimeEnd != null && (
            <div className={`${cssBase}__countDown`}>
              <HoldCountDown
                holdTimeEnd={holdTimeEnd}
                onRenewHoldTime={renewHold}
                reservationType={reservationType}
              />
            </div>
          )}
        </div>
        <div className={`${cssBase}__content`}>
          <SelectedRoom room={room} />
          <div className={`${cssBase}__recurrence`}>
            <Repeat16 className={`${cssBase}__recurrenceIcon`} />
            <div
              data-testid="recurrenceLabel"
              className={`${cssBase}__recurrence-label`}
            >
              {recurrence?.details?.ruleLabel}
            </div>
          </div>
          <ExceptionList
            exceptions={exceptions}
            onSelectRoom={(exception) => this.handleOnSelectRoom(exception)}
          />
        </div>
        <div className={`${cssBase}__footer`}>
          <div
            data-testid="resolvedLabel"
            className={`${cssBase}__exceptionsResolved`}
          >
            {`${!isEmpty(exceptions) ? exceptions.length : 0} ${
              appMessages[AppMsg.RESERVATION_MESSAGE.EXCEPTIONS]
            }, ${resolvedCount} ${
              appMessages[AppMsg.RESERVATION_MESSAGE.RESOLVED]
            }`}
          </div>
          <FooterButtons
            secondaryLabel={appMessages[AppMsg.BUTTON.CANCEL]}
            secondaryClickedHandler={navigateToReservationSummary}
            primaryLabel={appMessages[AppMsg.BUTTON.DONE]}
            primaryClickedHandler={this.onDoneClick}
          />
        </div>
      </main>
    );
  }

  onDoneClick = async () => {
    const {
      navigateToReservationSummary,
      roomsOnHold,
      holdRooms,
      exceptionRooms,
    } = this.props;
    if (!exceptionRooms.length) return navigateToReservationSummary();
    const holdSuccess = await holdRooms([...roomsOnHold]);
    if (holdSuccess) {
      navigateToReservationSummary();
    }
  };

  handleOnSelectRoom(exception) {
    const {
      navigateToReservationSearch,
      setSelectedResourceException,
    } = this.props;
    setSelectedResourceException(exception);
    navigateToReservationSearch();
  }

  componentDidMount() {
    if (isEmpty(this.props.exceptions)) {
      this.props.navigateToReservationSummary();
    }
    if (
      this.closeButtonRef &&
      this.closeButtonRef.current &&
      this.closeButtonRef.current.firstChild
    ) {
      this.closeButtonRef.current.firstChild.focus();
    }
  }
}

const {
  selectedResourceExceptionsSelector,
  selectedResourceRoomSelector,
  selectedResourceResolvedCountSelector,
  recurrenceSelector,
  holdTimeEndSelector,
  reservationTypeSelector,
  roomsSelector,
  selectedResourceExceptionRoomsSelector,
  selectedResourceSelector,
} = ReservationSelectors;

const mapStateToProps = (state) => {
  return {
    holdTimeEnd: holdTimeEndSelector(state),
    exceptions: selectedResourceExceptionsSelector(state),
    room: selectedResourceRoomSelector(state),
    recurrence: recurrenceSelector(state),
    reservationType: reservationTypeSelector(state),
    resolvedCount: selectedResourceResolvedCountSelector(state),
    dir: LayoutSelectors.dirSelector(state),
    roomsOnHold: roomsSelector(state),
    exceptionRooms: selectedResourceExceptionRoomsSelector(state),
    selectedResource: selectedResourceSelector(state),
  };
};

export default connect(mapStateToProps, {
  renewHold: ReservationActions.renewHold,
  navigateToReservationSummary: RouteActions.navigateToReservationSummary,
  navigateToReservationSearch: RouteActions.navigateToReservationSearch,
  setSelectedResourceException: ReservationActions.setSelectedResourceException,
  holdRooms: ReservationActions.holdRooms,
  updateReservationResource: ReservationActions.updateReservationResource,
})(withTriDictionary(OccurrenceExceptionsPageSmall));
