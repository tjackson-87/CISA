/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import { screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import OccurrenceExceptionsPageSmall from "../OccurrenceExceptionsPageSmall";
import { AppMsg } from "../../../utils";
import { getAppStore } from "../../../store";
import { reservationReducer } from "../../../store/reducers/ReservationReducer";
import {
  createException,
  createRecurrence,
  createReservableRoom,
  createReservationParam,
  createResource,
  renderWithReduxAndDictionaryProvider,
} from "../../../testUtils";
const RouteActions = require("../../../store/actions/RouteActions");
const ReservationActions = require("../../../store/actions/ReservationActions");

afterEach(() => jest.clearAllMocks());

jest.mock("../../../components/HoldCountDown/HoldCountDown", () => {
  return {
    __esModule: true,
    default: () => <div data-testid="holdCountDown">Hold count down</div>,
  };
});

jest.mock("../../../components/SelectedRoom/SelectedRoom", () => () => (
  <div data-testid="selectedRoom">selected room</div>
));

jest.mock(
  "../../../components/ExceptionList/ExceptionList",
  () => ({
    // eslint-disable-next-line react/prop-types
    onSelectRoom,
  }) => (
    <button data-testid="exceptionList" onClick={() => onSelectRoom()}>
      exception list
    </button>
  )
);

jest.mock("../../../store/actions/RouteActions");
jest.mock("../../../store/actions/ReservationActions");

describe("OccurrenceExceptionsPageSmall", () => {
  const fakeRoom = createReservableRoom("Spider-man", "Marvel");
  const reservationParam = createReservationParam();
  const resource = createResource(fakeRoom, [createException()]);

  it("renders correctly", () => {
    const reservationType = "Workspace";
    const exceptions = [{ id: "example" }];
    const resolvedCount = 0;
    const holdTimeEnd = "12-12-2022";
    const appMessages = AppMsg.getAppMessages();
    const recurrence = createRecurrence();
    const dir = "LTR";
    const roomsOnHold = [];
    const exceptionRooms = [];
    const props = {
      reservationType,
      exceptions,
      resolvedCount,
      holdTimeEnd,
      appMessages,
      dir,
      roomsOnHold,
      exceptionRooms,
    };

    const initialReservationState = {
      ...getAppStore().getState.reservation,
      data: {
        ...reservationParam,
        resources: [resource],
        recurrence,
      },
      selectedResource: resource,
    };

    const initialState = {
      ...getAppStore().getState(),
      reservation: initialReservationState,
    };

    renderWithReduxAndDictionaryProvider(
      <OccurrenceExceptionsPageSmall {...props} />,
      {
        initialState,
        reducer: reservationReducer,
      },
      appMessages
    );

    const pageTitle = screen.getByText(appMessages.OCCURRENCE_EXCEPTION);
    const closeButton = screen.getByRole("button", {
      name: appMessages.BUTTON_CLOSE,
    });
    const recurrenceLabel = screen.getByTestId("recurrenceLabel");
    const exceptionList = screen.getByTestId("exceptionList");
    const resolvedLabel = screen.getByTestId("resolvedLabel");
    const cancelButton = screen.getByRole("button", { name: /cancel/i });
    const doneButton = screen.getByRole("button", { name: /done/i });
    const holdCountDown = screen.queryByTestId("holdCountDown");
    const selectedRoom = screen.getByTestId("selectedRoom");

    expect(pageTitle).toBeInTheDocument();
    expect(closeButton).toBeInTheDocument();
    expect(recurrenceLabel).toBeInTheDocument();
    expect(recurrenceLabel.textContent).toEqual(recurrence.details.ruleLabel);
    expect(holdCountDown).not.toBeInTheDocument();
    expect(selectedRoom).toBeInTheDocument();
    expect(exceptionList).toBeInTheDocument();
    expect(resolvedLabel).toBeInTheDocument();
    expect(cancelButton).toBeInTheDocument();
    expect(doneButton).toBeInTheDocument();
  });

  it("shows hold time end", () => {
    const reservationType = "Workspace";
    const recurrence = createRecurrence();
    const resolvedCount = 0;
    const holdTimeEnd = "12-12-2022";
    const dir = "LTR";
    const appMessages = AppMsg.getAppMessages();
    const props = {
      reservationType,
      recurrence,
      resolvedCount,
      holdTimeEnd,
      dir,
    };
    const initialReservationState = {
      ...getAppStore().getState.reservation,
      data: {
        ...reservationParam,
        resources: [resource],
        recurrence,
        holdTimeEnd: "1000",
      },
      selectedResource: resource,
    };

    const initialState = {
      ...getAppStore().getState(),
      reservation: initialReservationState,
    };
    renderWithReduxAndDictionaryProvider(
      <OccurrenceExceptionsPageSmall {...props} />,
      {
        initialState,
        reducer: reservationReducer,
      },
      appMessages
    );
    const holdCountDown = screen.getByTestId("holdCountDown");
    expect(holdCountDown).toBeInTheDocument();
  });

  it("navigates to summary page when click x button", async () => {
    const user = userEvent.setup();
    RouteActions.navigateToReservationSummary.mockImplementation(() =>
      jest.fn()
    );
    const initialReservationState = {
      ...getAppStore().getState.reservation,
      data: {
        ...reservationParam,
        resources: [resource],
        recurrence: createRecurrence(),
        holdTimeEnd: "1000",
      },
      selectedResource: resource,
    };
    const appMessages = AppMsg.getAppMessages();
    const initialState = {
      ...getAppStore().getState(),
      reservation: initialReservationState,
    };
    renderWithReduxAndDictionaryProvider(
      <OccurrenceExceptionsPageSmall />,
      { initialState, reducer: reservationReducer },
      appMessages
    );

    const closeButton = screen.getByRole("button", {
      name: appMessages.BUTTON_CLOSE,
    });

    expect(closeButton).toBeInTheDocument();
    await user.click(closeButton);
    expect(RouteActions.navigateToReservationSummary).toBeCalled();
  });

  it("unresolved 1 exceptions, 0 resolved", () => {
    const initialReservationState = {
      ...getAppStore().getState.reservation,
      data: {
        ...reservationParam,
        resources: [resource],
        recurrence: createRecurrence(),
        holdTimeEnd: "1000",
      },
      selectedResource: resource,
    };
    const initialState = {
      ...getAppStore().getState(),
      reservation: initialReservationState,
    };
    const appMessages = AppMsg.getAppMessages();

    renderWithReduxAndDictionaryProvider(
      <OccurrenceExceptionsPageSmall />,
      { initialState, reducer: reservationReducer },
      appMessages
    );
    expect(
      screen.getByText(
        `${resource.exceptions.length} ${appMessages.EXCEPTIONS}, 0 ${appMessages.RESOLVED}`
      )
    ).toBeInTheDocument();
  });

  it("navigates away to summary page when click cancel button", async () => {
    const user = userEvent.setup();
    RouteActions.navigateToReservationSummary.mockImplementation(() =>
      jest.fn()
    );
    const initialReservationState = {
      ...getAppStore().getState.reservation,
      data: {
        ...reservationParam,
        resources: [resource],
        recurrence: createRecurrence(),
        holdTimeEnd: "1000",
      },
      selectedResource: resource,
    };
    const appMessages = AppMsg.getAppMessages();

    const initialState = {
      ...getAppStore().getState(),
      reservation: initialReservationState,
    };
    renderWithReduxAndDictionaryProvider(
      <OccurrenceExceptionsPageSmall />,
      { initialState, reducer: reservationReducer },
      appMessages
    );
    await user.click(screen.getByRole("button", { name: /cancel/i }));
    expect(RouteActions.navigateToReservationSummary).toHaveBeenCalled();
  });

  it("navigates away to summary page without hold rooms when click done", async () => {
    const user = userEvent.setup();
    RouteActions.navigateToReservationSummary.mockImplementation(() =>
      jest.fn()
    );
    ReservationActions.holdRooms.mockImplementation(() => jest.fn(() => false));
    const initialReservationState = {
      ...getAppStore().getState.reservation,
      data: {
        ...reservationParam,
        resources: [resource],
        recurrence: createRecurrence(),
        holdTimeEnd: "1000",
      },
      selectedResource: resource,
    };
    const appMessages = AppMsg.getAppMessages();

    const initialState = {
      ...getAppStore().getState(),
      reservation: initialReservationState,
    };
    renderWithReduxAndDictionaryProvider(
      <OccurrenceExceptionsPageSmall />,
      { initialState, reducer: reservationReducer },
      appMessages
    );
    await user.click(screen.getByRole("button", { name: /done/i }));
    expect(ReservationActions.holdRooms).not.toHaveBeenCalled();
    expect(RouteActions.navigateToReservationSummary).toHaveBeenCalled();
  });

  it("navigates away to summary page and hold rooms when click done", async () => {
    const user = userEvent.setup();
    RouteActions.navigateToReservationSummary.mockImplementation(() =>
      jest.fn()
    );
    ReservationActions.holdRooms.mockImplementation(() => jest.fn(() => true));
    const resolvedException = createException();
    const initialReservationState = {
      ...getAppStore().getState.reservation,
      data: {
        ...reservationParam,
        resources: [resource],
        recurrence: createRecurrence(),
        holdTimeEnd: "1000",
      },
      selectedResource: {
        ...resource,
        exceptions: [{ ...resolvedException, room: fakeRoom }],
      },
    };
    const appMessages = AppMsg.getAppMessages();

    const initialState = {
      ...getAppStore().getState(),
      reservation: initialReservationState,
    };
    renderWithReduxAndDictionaryProvider(
      <OccurrenceExceptionsPageSmall />,
      { initialState, reducer: reservationReducer },
      appMessages
    );
    await user.click(screen.getByRole("button", { name: /done/i }));
    expect(ReservationActions.holdRooms).toHaveBeenCalled();
    expect(RouteActions.navigateToReservationSummary).toHaveBeenCalled();
  });

  it("set selected resource exception and navigate to reservation search when select exception to resolve", async () => {
    const user = userEvent.setup();
    ReservationActions.setSelectedResourceException.mockImplementation(() =>
      jest.fn()
    );
    RouteActions.navigateToReservationSearch.mockImplementation(() =>
      jest.fn()
    );
    const resolvedException = createException();
    const initialReservationState = {
      ...getAppStore().getState.reservation,
      data: {
        ...reservationParam,
        resources: [resource],
        recurrence: createRecurrence(),
        holdTimeEnd: "1000",
      },
      selectedResource: {
        ...resource,
        exceptions: [{ ...resolvedException, room: fakeRoom }],
      },
    };
    const appMessages = AppMsg.getAppMessages();

    const initialState = {
      ...getAppStore().getState(),
      reservation: initialReservationState,
    };
    renderWithReduxAndDictionaryProvider(
      <OccurrenceExceptionsPageSmall />,
      { initialState, reducer: reservationReducer },
      appMessages
    );
    await user.click(screen.getByTestId("exceptionList"));

    expect(ReservationActions.setSelectedResourceException).toHaveBeenCalled();
    expect(RouteActions.navigateToReservationSearch).toHaveBeenCalled();
  });
});
