/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import { ComposedModal, ModalHeader } from "carbon-components-react";
import debounce from "debounce";
import { isNil } from 'lodash';
import { LocationSearch } from "../../components";
import {
  LocationActions,
  LocationSelectors,
  LayoutSelectors,
  LoadingSelectors,
  RoomSearchActions,
} from "../../store";
import { AppMsg } from "../../utils";
import { isMobile } from "react-device-detect";

const cssBase = "changeLocationPageSmall";

class ChangeLocationPageSmall extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    searchBuildings: PropTypes.func,
    searchMoreBuildings: PropTypes.func,
    setSelectedBuilding: PropTypes.func,
    buildings: PropTypes.array,
    loading: PropTypes.bool,
    loadingMore: PropTypes.bool,
    dir: PropTypes.string,
    isOpen: PropTypes.bool,
    setLocationModal: PropTypes.func,
    changeLocationButtonRef: PropTypes.any,
    viewMode: PropTypes.object,
    setRoomViewMode: PropTypes.func,
    onClose: PropTypes.func,
    overflowMenuRef: PropTypes.any,
  };

  state = {
    searchText: "",
    debouncingSearch: false,
  };

  render() {
    const {
      buildings,
      loading,
      loadingMore,
      dir,
      searchMoreBuildings,
      isOpen,
      onClose,
    } = this.props;

    const { searchText, debouncingSearch } = this.state;

    return (
      <main aria-labelledby="changeLocationModal">
        <ComposedModal
          id="changeLocationModal"
          open={isOpen}
          onClose={() => onClose()}
          aria-label={
            this.props.appMessages[AppMsg.RESERVATION_MESSAGE.CHANGE_LOCATION]
          }
          selectorPrimaryFocus=".bx--modal-close"
        >
          <ModalHeader
            title={
              this.props.appMessages[
                AppMsg.RESERVATION_MESSAGE.CHANGE_LOCATION_DESCRIPTION
              ]
            }
            iconDescription={this.props.appMessages[AppMsg.BUTTON.CLOSE]}
          />
          <div className={cssBase}>
            <div className={`${cssBase}__content`}>
              <LocationSearch
                searchText={searchText}
                onSearchTextChange={this.handleSearchTextChange}
                onSearchMore={searchMoreBuildings}
                onSelect={this.handleSelectBuilding}
                buildings={buildings}
                loading={loading || debouncingSearch}
                loadingMore={loadingMore}
                dir={dir}
                isModalOpen={isOpen}
              />
            </div>
          </div>
        </ComposedModal>
      </main>
    );
  }

  handleSearchTextChange = (searchText) => {
    this.setState({ searchText, debouncingSearch: true });
    this.debouncedSearch(searchText);
  };

  debouncedSearch = debounce((searchText) => {
    this.props.searchBuildings(searchText);
    setTimeout(() => this.setState({ debouncingSearch: false }), 50);
  }, 300);

  handleSelectBuilding = (building) => {
    const {
      setSelectedBuilding,
      setLocationModal,
      changeLocationButtonRef,
      setRoomViewMode,
      viewMode,
      overflowMenuRef,
    } = this.props;
    setSelectedBuilding(building);
    setLocationModal(false);
    this.setState({ searchText: "" });
    if (!isMobile) {
      if (changeLocationButtonRef && changeLocationButtonRef.current) {
        setTimeout(() => changeLocationButtonRef.current.focus(), 1);
      }
    } else {
      if (overflowMenuRef && overflowMenuRef.current) {
        setTimeout(() => overflowMenuRef.current.focus(), 1);
      }
    }
    if (!isNil(viewMode)){
      setRoomViewMode(viewMode.FLOORPLAN);
    }
  };
}

const mapStateToProps = (state) => {
  return {
    buildings: LocationSelectors.buildingsSelector(state),
    loading: LoadingSelectors.searchingBuildingsSelector(state),
    loadingMore: LoadingSelectors.searchingMoreBuildingsSelector(state),
    dir: LayoutSelectors.dirSelector(state),
  };
};

export default withTriDictionary(
  connect(mapStateToProps, {
    searchBuildings: LocationActions.searchBuildings,
    searchMoreBuildings: LocationActions.searchMoreBuildings,
    setSelectedBuilding: LocationActions.setSelectedBuilding,
    setLocationModal: RoomSearchActions.setLocationModal,
    setRoomViewMode: RoomSearchActions.setRoomViewMode,
  })(ChangeLocationPageSmall)
);
