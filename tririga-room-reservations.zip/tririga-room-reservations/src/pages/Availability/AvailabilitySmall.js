/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import defaultTo from "lodash/defaultTo";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import { Close32 } from "@carbon/icons-react";
import { Button } from "carbon-components-react";
import classnames from "classnames";
import moment from "moment";
import {
  Availability,
  AvailabilityDate,
  FooterButtons,
  AttendeesStatus,
} from "../../components";
import {
  RouteActions,
  LayoutSelectors,
  ReservationSelectors,
  TimezonesSelectors,
  AvailabilityActions,
  AvailabilitySelectors,
  ReservationActions,
  ApplicationSettingsSelectors,
  CurrentUserSelectors,
} from "../../store";
import {
  AppMsg,
  computeEndDateFromStartChange,
  getMomentFrom,
  TimezoneUtils,
  DefaultValues,
} from "../../utils";

const cssBase = "availabilitySmall";

class AvailabilitySmall extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    dateAndTime: PropTypes.object,
    navigateBackToReservationTime: PropTypes.func,
    dir: PropTypes.string,
    attendeesScheduleForDay: PropTypes.array,
    getAttendeesSchedule: PropTypes.func,
    updateTimeStepTempDateAndTime: PropTypes.func,
    exchangeAttendees: PropTypes.array,
    exchangeAttendeesAvailable: PropTypes.number,
    getResourcesScheduleForDay: PropTypes.func,
    getResourcesAvailability: PropTypes.func,
    resourcesSchedule: PropTypes.array,
    resourcesAvailable: PropTypes.number,
    isExchangeIntegrated: PropTypes.bool,
    nonExchangeAttendees: PropTypes.array,
    defaultTimezone: PropTypes.string,
    timezones: PropTypes.array,
  };

  static getDerivedStateFromProps({ dateAndTime }, { prevDateAndTime }) {
    if (dateAndTime !== prevDateAndTime) {
      return {
        prevDateAndTime: dateAndTime,
        prevStartDate: dateAndTime.startDate,
        dateAndTime: defaultTo(dateAndTime, {}),
      };
    }
    return null;
  }

  constructor(props) {
    super(props);
    const userLocaleData = moment.localeData(
      defaultTo(props.dateAndTime.locale, DefaultValues.LOCALE)
    );
    this.amLabel = userLocaleData.meridiem(1, 0);
    this.pmLabel = userLocaleData.meridiem(13, 0);
  }

  state = {};

  render() {
    const { dateAndTime } = this.state;
    const {
      navigateBackToReservationTime,
      dir,
      attendeesScheduleForDay,
      resourcesSchedule,
      exchangeAttendees,
      exchangeAttendeesAvailable,
      resourcesAvailable,
      isExchangeIntegrated,
      nonExchangeAttendees,
      defaultTimezone,
      timezones,
    } = this.props;
    const {
      carbonDateFormat,
      dateFormat,
      carbonLocale,
      startDate,
      startTime,
      endTime,
      startTimePeriod,
      endTimePeriod,
      timezone,
    } = dateAndTime;
    return (
      <div className={cssBase}>
        <div className={`${cssBase}__stepDescription`}>
          <div className={`${cssBase}__descriptionContainer`}>
            <span>
              {
                this.props.appMessages[
                  AppMsg.RESERVATION_MESSAGE.STEP_TIME_AVAILABILITY
                ]
              }
            </span>
            <AttendeesStatus
              isExchangeIntegrated={isExchangeIntegrated}
              exchangeAttendeesAvailable={exchangeAttendeesAvailable}
              exchangeAttendees={exchangeAttendees}
              nonExchangeAttendees={nonExchangeAttendees}
            />
            {this.displayAttendessLegends()}
          </div>
          <Button
            className={`${cssBase}__closeButton`}
            kind="ghost"
            hasIconOnly
            renderIcon={Close32}
            tooltipAlignment="center"
            tooltipPosition={dir === "ltr" ? "left" : "right"}
            iconDescription={this.props.appMessages[AppMsg.BUTTON.CLOSE]}
            onClick={navigateBackToReservationTime}
          />
        </div>
        <div className={`${cssBase}__content`}>
          {TimezoneUtils.areTimezonesDifferent(timezone, defaultTimezone) && (
            <div className={`${cssBase}__timeDetails`}>
              <span>
                {`${startTime}${
                  startTimePeriod.toLowerCase() === "am"
                    ? this.amLabel
                    : this.pmLabel
                } - ${endTime}${
                  endTimePeriod.toLowerCase() === "am"
                    ? this.amLabel
                    : this.pmLabel
                } ${TimezoneUtils.getTimezoneAbbr(timezone, timezones)}`}
              </span>
            </div>
          )}
          <AvailabilityDate
            className={`${cssBase}__date`}
            dir={dir}
            selectedDate={startDate}
            carbonDateFormat={carbonDateFormat}
            dateFormat={dateFormat}
            carbonLocale={carbonLocale}
            onSelectedDateChange={(value) =>
              this.handleDateAndTimeChange(value, "startDate")
            }
          />
          <Availability
            dateAndTime={dateAndTime}
            onDateAndTimeChange={this.handleDateAndTimeChange}
            dir={dir}
            attendees={attendeesScheduleForDay}
            rooms={resourcesSchedule}
            exchangeAttendees={exchangeAttendees}
            exchangeAttendeesAvailable={exchangeAttendeesAvailable}
            resourcesAvailable={resourcesAvailable}
          />
        </div>
        <FooterButtons
          secondaryLabel={this.props.appMessages[AppMsg.BUTTON.CANCEL]}
          secondaryClickedHandler={navigateBackToReservationTime}
          primaryLabel={this.props.appMessages[AppMsg.BUTTON.APPLY]}
          primaryClickedHandler={this.onApplyClick}
          primaryDisabled={false}
        />
      </div>
    );
  }

  onApplyClick = () => {
    const {
      startDate,
      startTime,
      startTimePeriod,
      endDate,
      endTime,
      endTimePeriod,
    } = this.state.dateAndTime;
    this.props.updateTimeStepTempDateAndTime({
      startDate,
      startTime,
      startTimePeriod,
      endDate,
      endTime,
      endTimePeriod,
    });
    this.props.navigateBackToReservationTime();
  };

  handleDateAndTimeChange = (value, key) => {
    let newDateAndTime = null;
    if (key != null) {
      let computedEndDate = {};
      if (key === "startDate") {
        computedEndDate = computeEndDateFromStartChange(
          this.state.dateAndTime,
          key,
          value
        );
      }
      newDateAndTime = {
        ...this.state.dateAndTime,
        [key]: value,
        ...computedEndDate,
      };
    } else {
      newDateAndTime = { ...this.state.dateAndTime, ...value };
    }
    this.setState(
      {
        dateAndTime: newDateAndTime,
        prevStartDate: this.state.dateAndTime.startDate,
      },
      this.handleDateAndTimeStateChange
    );
  };

  handleDateAndTimeStateChange = async () => {
    const {
      dateAndTime: {
        startDate,
        startTime,
        startTimePeriod,
        endDate,
        endTime,
        endTimePeriod,
        timezone,
      },
      prevStartDate,
    } = this.state;
    const startDateMoment = getMomentFrom(
      startDate,
      startTime,
      startTimePeriod,
      timezone
    );
    const endDateMoment = getMomentFrom(
      endDate,
      endTime,
      endTimePeriod,
      timezone
    );
    const startAndEndDate = {
      startDate: startDateMoment.toISOString(true),
      endDate: endDateMoment.toISOString(true),
      timezone,
    };
    this.props.getAttendeesSchedule({
      startAndEndDate,
      forDay: false,
    });
    this.props.getResourcesAvailability(startAndEndDate);

    if (startDate.getTime() !== prevStartDate.getTime()) {
      const startAndEndDateForDay = {
        startDate: startDateMoment.startOf("day").toISOString(true),
        endDate: startDateMoment.endOf("day").toISOString(true),
        timezone,
      };
      await this.props.getAttendeesSchedule({
        startAndEndDate: startAndEndDateForDay,
        forDay: true,
      });

      this.props.getResourcesScheduleForDay(startAndEndDateForDay);
    }
  };

  displayAttendessLegends = () => {
    return (
      <div className={`${cssBase}__attendeesLegend`}>
        <div className={`${cssBase}__singleLegend`}>
          <div
            className={classnames(
              `${cssBase}__attendeesLegendBox`,
              `${cssBase}__attendeesLegendAvailable`
            )}
          />
          <p className={`${cssBase}__attendeesLegendLabel`}>
            {this.props.appMessages[AppMsg.RESERVATION_MESSAGE.AVAILABLE]}
          </p>
        </div>
        <div className={`${cssBase}__singleLegend`}>
          <div
            className={classnames(
              `${cssBase}__attendeesLegendBox`,
              `${cssBase}__attendeesLegendUnavailable`
            )}
          />
          <p className={`${cssBase}__attendeesLegendLabel`}>
            {this.props.appMessages[AppMsg.RESERVATION_MESSAGE.UNAVAILABLE]}
          </p>
        </div>
        <div className={`${cssBase}__singleLegend`}>
          <div
            className={classnames(
              `${cssBase}__attendeesLegendBox`,
              `${cssBase}__attendeesLegendUnknown`
            )}
          />
          <p className={`${cssBase}__attendeesLegendLabel`}>
            {this.props.appMessages[AppMsg.RESERVATION_MESSAGE.UNKNOWN]}
          </p>
        </div>
      </div>
    );
  };
}

const mapStateToProps = (state) => {
  return {
    dateAndTime: ReservationSelectors.timeStepTempDateAndTimeSelector(state),
    dir: LayoutSelectors.dirSelector(state),
    attendeesScheduleForDay: AvailabilitySelectors.attendeesScheduleForDaySelector(
      state
    ),
    resourcesSchedule: AvailabilitySelectors.resourcesScheduleForDaySelector(
      state
    ),
    resourcesAvailable: AvailabilitySelectors.resourcesAvailableSelector(state),
    exchangeAttendees: ReservationSelectors.exchangeAttendeesSelector(state),
    exchangeAttendeesAvailable: AvailabilitySelectors.exchangeAttendeesAvailableSelector(
      state
    ),
    nonExchangeAttendees: ReservationSelectors.nonExchangeAttendeesSelector(
      state
    ),
    isExchangeIntegrated: ApplicationSettingsSelectors.isExchangeIntegratedSelector(
      state
    ),
    defaultTimezone: CurrentUserSelectors.defaultTimezoneSelector(state),
    timezones: TimezonesSelectors.timezonesSelector(state),
  };
};

export default withTriDictionary(
  connect(mapStateToProps, {
    navigateBackToReservationTime: RouteActions.navigateBackToReservationTime,
    getAttendeesSchedule: AvailabilityActions.getAttendeesSchedule,
    getResourcesScheduleForDay: AvailabilityActions.getResourcesScheduleForDay,
    getResourcesAvailability: AvailabilityActions.getResourcesAvailability,
    updateTimeStepTempDateAndTime:
      ReservationActions.updateTimeStepTempDateAndTime,
  })(AvailabilitySmall)
);
