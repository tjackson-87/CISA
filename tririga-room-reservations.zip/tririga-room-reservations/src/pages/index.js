/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - 2023 The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import ReservationListPage from "./ReservationList/ReservationListPage";
import MeetingReservationPage from "./MeetingReservation/MeetingReservationPage";
import RoomDetailsPageSmall from "./RoomDetails/RoomDetailsPageSmall";
import RoomRecurrenceDetailsPageSmall from "./RoomRecurrenceDetails/RoomRecurrenceDetailsPageSmall";
import WorkspaceReservationPage from "./WorkspaceReservation/WorkspaceReservationPage";
import OfficeReservationPage from "./OfficeReservation/OfficeReservationPage"; // CISA
import EventDetailsPageSmall from "./EventDetails/EventDetailsPageSmall";
import EquipmentListPageSmall from "./EquipmentList/EquipmentListPageSmall";
import RoomScanPage from "./RoomScan/RoomScanPage";
import OccurrenceExceptionsPageSmall from "./OccurrenceExceptions/OccurrenceExceptionsPageSmall";
import CateringListPageSmall from "./CateringList/CateringListPageSmall";
import EquipmentDetailsPageSmall from "./EquipmentDetails/EquipmentDetailsPageSmall";
import ReservationCostSummaryPage from "./ReservationCostSummaryPage/ReservationCostSummaryPage";
import CateringOrderListPageSmall from "./CateringOrderList/CateringOrderListPageSmall";
import ColleagueReservationPageSmall from "./ColleagueReservation/ColleagueReservationPageSmall";
export {
  ReservationListPage,
  MeetingReservationPage,
  RoomDetailsPageSmall,
  RoomRecurrenceDetailsPageSmall,
  EquipmentListPageSmall,
  WorkspaceReservationPage,
  OfficeReservationPage, // CISA
  EventDetailsPageSmall,
  RoomScanPage,
  OccurrenceExceptionsPageSmall,
  CateringListPageSmall,
  EquipmentDetailsPageSmall,
  ReservationCostSummaryPage,
  CateringOrderListPageSmall,
  ColleagueReservationPageSmall,
};
