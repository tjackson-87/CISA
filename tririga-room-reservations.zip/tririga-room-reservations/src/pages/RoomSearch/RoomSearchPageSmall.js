/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import { connect } from "react-redux";
import defaultTo from "lodash/defaultTo";
import PropTypes from "prop-types";
import {
  Bee32,
  FitToScreen20,
  ShrinkScreen20,
  Enterprise16,
  User16,
  Information16,
  Filter24,
} from "@carbon/icons-react";
import {
  Button,
  SkeletonPlaceholder,
  //InlineNotification, // having trouble with this not finding a title to use in all cases
  Select,
  SelectItem,
  Tag,
  TooltipIcon,
  OverflowMenu,
  OverflowMenuItem,
} from "carbon-components-react";
import isEmpty from "lodash/isEmpty";
import {
  AppMsg,
  ReservationTypes,
  RoomsUtils,
  LayoutTypesConstants,
} from "../../utils";
import {
  ReservationActions,
  ReservationSelectors,
  RouteActions,
  LoadingSelectors,
  LayoutSelectors,
  CurrentUserSelectors,
  CurrentUserActions,
  RoomSearchSelectors,
  RoomSearchActions,
  LabelStylesSelectors,
  LocationSelectors,
  LocationActions,
  RoomDetailsActions,
  ColleagueSelectors,
  ColleagueActions,
} from "../../store";
import {
  FilterButton,
  RoomViewSwitcher,
  RoomViewMode,
  RoomList,
  RoomResultsCounter,
  FloorPlanView,
  RoomSearchFooterButttons,
  SimpleMenu,
} from "../../components";
import ChangeLocationPageSmall from "../ChangeLocation/ChangeLocationPageSmall";
import SearchColleague from "../../components/SearchColleague/SearchColleague";
import RoomFiltersPageSmall from "../RoomFilters/RoomFiltersPageSmall";
import RoomDetailsPageSmall from "../RoomDetails/RoomDetailsPageSmall";
import RoomRecurrenceDetailsPageSmall from "../RoomRecurrenceDetails/RoomRecurrenceDetailsPageSmall";
import LocationFlyoutOptions from "../../components/LocationFlyoutOptions/LocationFlyoutOptions";
import MediaQuery from "react-responsive";
import { isNil } from "lodash";
import { isMobile } from "react-device-detect";

const cssBase = "roomSearchPageSmall";

class RoomSearchPageSmall extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    navigateToReservationSummary: PropTypes.func.isRequired,
    floors: PropTypes.array,
    selectedFloor: PropTypes.object,
    rooms: PropTypes.array,
    hasMoreResults: PropTypes.bool,
    checkedCount: PropTypes.number,
    checkedRooms: PropTypes.array,
    availableCount: PropTypes.number,
    totalSize: PropTypes.number,
    roomsOnHold: PropTypes.array,
    holdRooms: PropTypes.func,
    formattedDate: PropTypes.string,
    searchingRooms: PropTypes.bool,
    searchingMoreRooms: PropTypes.bool,
    selectedBuilding: PropTypes.object,
    selectedColleague: PropTypes.object,
    setSelectedBuilding: PropTypes.func,
    setSelectedRoom: PropTypes.func,
    removeCheckedRooms: PropTypes.func,
    filtersCount: PropTypes.number,
    dir: PropTypes.string,
    isRecurring: PropTypes.bool,
    favoriteRooms: PropTypes.array,
    addFavoriteRoom: PropTypes.func.isRequired,
    removeFavoriteRoom: PropTypes.func.isRequired,
    setRoomViewMode: PropTypes.func,
    roomViewMode: PropTypes.string,
    setSelectedRoomOnFloorplan: PropTypes.func,
    selectedRoom: PropTypes.object,
    labelStyles: PropTypes.array,
    recurrence: PropTypes.object,
    reservationType: PropTypes.string,
    searchMore: PropTypes.func,
    setFloorFilter: PropTypes.func,
    getRoomsInFloorplanViewport: PropTypes.func,
    selectedException: PropTypes.object,
    setSelectedResourceException: PropTypes.func.isRequired,
    setSelectedRooms: PropTypes.func,
    selectedRoomFromSearch: PropTypes.array,
    router: PropTypes.object,
    navigateToSearchByName: PropTypes.func,
    searchText: PropTypes.string,
    checkedByNameCount: PropTypes.number,
    availableByNameCount: PropTypes.number,
    roomsToDisplay: PropTypes.array,
    selectedRoomToDisplay: PropTypes.array,
    totalCount: PropTypes.number,
    hasMoreResultsInSearch: PropTypes.bool,
    searchRoomByName: PropTypes.func,
    setLocationModal: PropTypes.func,
    setSearchColleagueModal: PropTypes.func,
    setFilterModal: PropTypes.func,
    setRoomDetailsModal: PropTypes.func,
    isLocationModalOpen: PropTypes.bool,
    isSearchColleagueModalOpen: PropTypes.bool,
    isFilterModalOpen: PropTypes.bool,
    isRoomModalOpen: PropTypes.bool,
    setRoomId: PropTypes.func,
    setRoomDetail: PropTypes.func,
    setRoomRecurrenceDetailsModal: PropTypes.func,
    navigateBack: PropTypes.func,
    setSelectedColleague: PropTypes.func,
    setColleagueDetails: PropTypes.func,
    selectedColleagueRoom: PropTypes.object,
    setColleagueReservedRoom: PropTypes.func,
    colleagueReservedRoom: PropTypes.object,
    rememberFloorplanLastPosition: PropTypes.bool,
    setRememberFloorplanLastPosition: PropTypes.func,
    setZoomToColleague: PropTypes.func,
    setRoomsFilter: PropTypes.func,
  };

  static defaultProps = {
    rooms: [],
    roomsOnHold: [],
    searchingRooms: false,
    hasMoreResults: false,
    isRecurring: false,
    floorViewportChanged: false,
  };

  static getDerivedStateFromProps(props, state) {
    const { roomsOnHold, selectedException } = props;
    if (roomsOnHold !== state.prevRoomsOnHold) {
      const isException = !isEmpty(selectedException);
      return {
        prevRoomsOnHold: roomsOnHold,
        selectedRooms: isException
          ? [...(selectedException.room ? [selectedException.room] : [])]
          : defaultTo(roomsOnHold, []),
        isException,
      };
    }
    return null;
  }

  state = {
    selectedRooms: [],
    prevRoomsOnHold: [],
    isFloorPlanExpanded: false,
    isException: false,
    isOpen: true,
    disableSearchArea: true,
    floorplanViewportData: null,
    menuOpen: false,
    buildingFloorPlanId: null,
  };

  getFocusOnViewSwitcher() {
    const elements = document.getElementsByClassName(
      `${cssBase}__viewSwitcher`
    );
    const children = elements ? elements[0] : null;
    const firstChild = children ? children.firstChild : null;
    if (firstChild) firstChild.focus();
  }

  componentWillUnmount() {
    this.reSetReservedRoom();
    this.floorPlanId = null;
  }

  componentDidMount() {
    const {
      roomViewMode,
      checkedRooms,
      floors,
      reservationType,
      setRoomViewMode,
    } = this.props;
    if (reservationType === ReservationTypes.WORKSPACE)
      setRoomViewMode(RoomViewMode.FLOORPLAN);
    if (roomViewMode === RoomViewMode.LIST && !isEmpty(checkedRooms)) {
      this.setState({ selectedRooms: checkedRooms });
    }
    if (!isMobile) {
      if (isEmpty(floors)) {
        if (
          this.changeLocationButtonRef &&
          this.changeLocationButtonRef.current
        ) {
          setTimeout(() => this.changeLocationButtonRef.current.focus(), 1);
        }
      } else {
        this.getFocusOnViewSwitcher();
      }
    } else {
      if (isEmpty(floors)) {
        const element = document.querySelector(".bx--tooltip__trigger");
        this.mobileFilterRef = element;
        if (this.mobileFilterRef) {
          setTimeout(() => this.mobileFilterRef.focus(), 1000);
        }
      } else {
        this.getFocusOnViewSwitcher();
      }
    }
  }

  componentDidUpdate(prevProps) {
    const { rooms } = this.props;
    const getFloorPlanId = async () => {
      if (!isEmpty(rooms)) {
        this.floorPlanId = await RoomsUtils.getFloorplanId(
          rooms[0].floorSystemRecordID
        ).then((floorPlanId) => {
          return floorPlanId;
        });
        this.setState({ buildingFloorPlanId: this.floorPlanId });
      }
    };
    setTimeout(() => getFloorPlanId());
    if (!isEmpty(this.props.floors) && prevProps.floors !== this.props.floors) {
      this.getFocusOnViewSwitcher();
    }
  }

  constructor(props) {
    super(props);
    this.changeLocationButtonRef = React.createRef();
    this.searchColleagueButtonRef = React.createRef();
    this.filterRef = React.createRef();
    this.roomRef = "";
    this.recurrenceLabelLinkRef = null;
    this.floorPlanViewRef = null;
    this.floorPlanId = null;
    this.mobileFilterRef = React.createRef(null);
    this.overflowMenuRef = React.createRef();
    this.colleagueReservationMenu = {};
    this.toggleModal = this.toggleModal.bind(this);
    this.expandShrinkButtonRef = React.createRef();
  }

  toggleModal() {
    this.setState({ isOpen: !this.state.isOpen });
  }

  render() {
    const {
      roomsOnHold,
      formattedDate,
      selectedBuilding,
      filtersCount,
      searchingRooms,
      searchingMoreRooms,
      hasMoreResults,
      checkedCount,
      availableCount,
      totalSize,
      dir,
      isRecurring,
      favoriteRooms,
      addFavoriteRoom,
      removeFavoriteRoom,
      roomViewMode,
      selectedRoom,
      setRoomViewMode,
      setSelectedRoomOnFloorplan,
      labelStyles,
      reservationType,
      recurrence,
      searchMore,
      selectedException,
      router,
      selectedRoomFromSearch,
      roomsToDisplay,
      selectedRoomToDisplay,
      isLocationModalOpen,
      isSearchColleagueModalOpen,
      setSearchColleagueModal,
      isFilterModalOpen,
      isRoomModalOpen,
      selectedColleague,
      selectedColleagueRoom,
      selectedFloor,
      colleagueReservedRoom,
      rememberFloorplanLastPosition,
    } = this.props;
    let rooms = defaultTo(this.props.rooms, []);
    if (colleagueReservedRoom) {
      rooms = RoomsUtils.shiftReservedRoom(colleagueReservedRoom, rooms);
    }
    if (!selectedColleague) rooms = rooms.filter((room) => !room.reservedRoom);
    let floors = this.props.floors;
    const { selectedRooms, isFloorPlanExpanded, isException } = this.state;
    if (selectedRoomFromSearch) {
      if (selectedRoomFromSearch.length === 1) {
        floors = floors.filter(
          (f) => f._id === selectedRoomFromSearch[0].floorSystemRecordID
        );
        rooms = selectedRoomToDisplay;
      } else {
        rooms = roomsToDisplay;
      }
    }
    const isMeeting = reservationType === ReservationTypes.MEETING;
    return (
      <main className={cssBase}>
        {!isFloorPlanExpanded && (
          <div role="heading" aria-level="1" className={`${cssBase}__stepDescription`}>
            {
              this.props.appMessages[
                reservationType === ReservationTypes.MEETING
                  ? AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_DESCRIPTION:
                reservationType === ReservationTypes.WORKSPACE
                  ? AppMsg.RESERVATION_MESSAGE.STEP_WORKSPACE_SEARCH_DESCRIPTION:
                  AppMsg.RESERVATION_MESSAGE.STEP_OFFICE_DESCRIPTION
              ]
            }
           &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;     
                  <a href="https://cisa.usgov.tririga.com/p/web/reporting#/formReport/jMbYoFNkaUBvV_g-Fc72S" rel="noopener noreferrer" target="_blank"><b>Need to See Who Has a Space Booked?</b></a>
         
              
            <div className={`${cssBase}__switcher`}>
              {!isEmpty(floors) && (
                <RoomViewSwitcher
                  onChange={(mode) => {
                    setRoomViewMode(mode);
                    setSelectedRoomOnFloorplan(null);
                  }}
                  mode={defaultTo(roomViewMode, RoomViewMode.FLOORPLAN)}
                  className={`${cssBase}__viewSwitcher`}
                  dir={dir}
                />
              )}
            </div>
          </div>
        )}
        <div className={`${cssBase}__content`}>
          {
            <>
              {/* having trouble with this not finding a title to use in all cases */}
              {/*
              {this.renderShowingFavoritesLabel(
                selectedBuilding,
                reservationType
              )}
              */}
              {isMeeting && this.renderMeetingToolbar()}
              {!isMeeting && (
                <MediaQuery
                  minWidth={LayoutTypesConstants.MIN_LARGE_SCREEN_WIDTH}
                >
                  <div className={`${cssBase}__toolbar`}>
                    <div className={`${cssBase}__dropdown`}>
                      {this.renderFloorDropdown()}
                    </div>
                    <div>{this.renderLocationButton()}</div>
                    <div>
                      {!isEmpty(selectedBuilding) && (
                        <TooltipIcon
                          direction="bottom"
                          align={dir === "rtl" ? "start" : "end"}
                          tooltipText={selectedBuilding.timeZone}
                          color="danger"
                          className={`${cssBase}__timezone`}
                        >
                          <Information16 />
                        </TooltipIcon>
                      )}
                    </div>
                    <div>{this.renderColleagueButton()}</div>
                    <div>
                      <FilterButton
                        className={`${cssBase}__filterBtn`}
                        onClick={this.handleFilterButtonClick}
                        count={filtersCount}
                        filterRef={this.filterRef}
                      />
                    </div>
                    <Button
                      className={`${cssBase}__expandShrinkButton`}
                      kind="secondary"
                      size="small"
                      renderIcon={
                        isFloorPlanExpanded ? ShrinkScreen20 : FitToScreen20
                      }
                      tooltipAlignment="center"
                      tooltipPosition={dir === "ltr" ? "right" : "left"}
                      iconDescription={this.getExpandShrinkLabel(
                        isFloorPlanExpanded
                      )}
                      onClick={this.handleExpandShrink}
                      hidden={
                        !(
                          !searchingRooms &&
                          roomViewMode === RoomViewMode.FLOORPLAN &&
                          rooms.length > 0 &&
                          this.state.buildingFloorPlanId
                        )
                      }
                      aria-label={this.getExpandShrinkLabel(
                        isFloorPlanExpanded
                      )}
                      ref={this.expandShrinkButtonRef}
                    />
                  </div>
                </MediaQuery>
              )}
              {!isMeeting && (
                <MediaQuery
                  maxWidth={LayoutTypesConstants.MAX_SMALL_SCREEN_WIDTH}
                >
                  <div
                    className={`${cssBase}__toolbar`}
                    data-testid="mobile-toolbar"
                  >
                    <div className={`${cssBase}__dropdown`}>
                      {this.renderFloorDropdown()}
                    </div>
                    <div
                      onClick={this.handleFilterButtonClick}
                      data-testid="mobile-filter-button"
                      className={`${cssBase}__mobileFilterButton`}
                    >
                      <TooltipIcon
                        direction="bottom"
                        align={dir === "rtl" ? "start" : "end"}
                        tooltipText="Filter"
                        color="danger"
                      >
                        <Filter24 />
                      </TooltipIcon>
                    </div>
                    <div>{this.renderLocationFlyoutOptions()}</div>
                    <Button
                      className={`${cssBase}__expandShrinkButton`}
                      kind="secondary"
                      size="small"
                      renderIcon={
                        isFloorPlanExpanded ? ShrinkScreen20 : FitToScreen20
                      }
                      tooltipAlignment="center"
                      tooltipPosition={dir === "ltr" ? "right" : "left"}
                      iconDescription={this.getExpandShrinkLabel(
                        isFloorPlanExpanded
                      )}
                      onClick={this.handleExpandShrink}
                      hidden={
                        !(
                          !searchingRooms &&
                          roomViewMode === RoomViewMode.FLOORPLAN &&
                          rooms.length > 0 &&
                          this.state.buildingFloorPlanId
                        )
                      }
                      aria-label={this.getExpandShrinkLabel(
                        isFloorPlanExpanded
                      )}
                    />
                  </div>
                </MediaQuery>
              )}
              {this.renderSelectedRoomLabel()}
              {this.renderLoading(searchingRooms)}
              {this.renderRoomList(
                searchingRooms,
                searchingMoreRooms,
                rooms,
                selectedRooms,
                isRecurring,
                roomViewMode,
                favoriteRooms,
                addFavoriteRoom,
                removeFavoriteRoom,
                dir,
                reservationType,
                isException
              )}
              {this.renderEmptyMessage(searchingRooms, rooms, reservationType)}
            </>
          }
          {this.renderFloorPlanView(
            searchingRooms,
            searchingMoreRooms,
            roomViewMode,
            rooms,
            selectedRooms,
            isFloorPlanExpanded,
            favoriteRooms,
            addFavoriteRoom,
            removeFavoriteRoom,
            selectedRoom,
            setSelectedRoomOnFloorplan,
            isRecurring,
            labelStyles,
            isException,
            selectedColleague,
            selectedColleagueRoom,
            selectedFloor,
            rememberFloorplanLastPosition
          )}
          {this.renderRoomResultsCounter(
            formattedDate,
            dir,
            recurrence,
            isRecurring,
            checkedCount,
            availableCount,
            totalSize,
            hasMoreResults,
            searchMore,
            reservationType,
            selectedException,
            isException,
            searchingRooms,
            searchingMoreRooms,
            roomViewMode
          )}
        </div>
        <div className={`${cssBase}__roomSearchFooterButtons`}>
          <div className={`${cssBase}__container`} role="contentinfo">
            <div className={`${cssBase}__button`}>
              <Button
                kind="secondary"
                size="small"
                className={`${cssBase}__button`}
                onClick={
                  router &&
                  (router.routedFromSummary || router.routedFromColleaguePage)
                    ? this.onCancelClick
                    : this.onBackClick
                }
                aria-label={
                  router &&
                  (router.routedFromSummary || router.routedFromColleaguePage)
                    ? this.props.appMessages[AppMsg.BUTTON.CANCEL]
                    : this.props.appMessages[AppMsg.BUTTON.BACK]
                }
              >
                {router &&
                (router.routedFromSummary || router.routedFromColleaguePage)
                  ? this.props.appMessages[AppMsg.BUTTON.CANCEL]
                  : this.props.appMessages[AppMsg.BUTTON.BACK]}
              </Button>
            </div>
            <div className="bs-select-custom">
              <RoomSearchFooterButttons
                primaryLabel={this.props.appMessages[AppMsg.BUTTON.DONE]}
                primaryDisabled={this.computeDoneButtonDisabled(
                  selectedRooms,
                  roomsOnHold
                )}
                selectedRooms={selectedRooms}
                clickHandler={this.onDoneClick}
                toggleModal={this.toggleModal}
                onDelete={this.handleListChange}
              />
            </div>
          </div>
        </div>

        <ChangeLocationPageSmall
          isOpen={isLocationModalOpen}
          changeLocationButtonRef={this.changeLocationButtonRef}
          overflowMenuRef={this.overflowMenuRef}
          onClose={this.handleChangeLocationClose}
          viewMode={RoomViewMode}
        />
        <RoomFiltersPageSmall
          isOpen={isFilterModalOpen}
          filterRef={this.filterRef}
          onClose={this.handleOnFilterModalClose}
        />
        {this.state.isOpen && (
          <RoomDetailsPageSmall
            isOpen={isRoomModalOpen}
            onClosePopUp={() => this.onRoomDetailsPopupClose()}
          />
        )}

        {recurrence !== null && (
          <RoomRecurrenceDetailsPageSmall
            onClosePopUp={() => this.onClosePopUp()}
          />
        )}
        <SearchColleague
          isOpen={isSearchColleagueModalOpen}
          onClose={(isColleagueSelected = false) => {
            setSearchColleagueModal(false);
            if (isColleagueSelected !== true) {
              if (!isMobile) {
                if (
                  this.searchColleagueButtonRef &&
                  this.searchColleagueButtonRef.current
                )
                  if (this.searchColleagueButtonRef.current.anchorRef) {
                    setTimeout(() => {
                      this.searchColleagueButtonRef.current.anchorRef.current.focus();
                    }, 1);
                  } else {
                    setTimeout(() => {
                      this.searchColleagueButtonRef.current.focus();
                    }, 1);
                  }
              } else {
                if (this.overflowMenuRef && this.overflowMenuRef.current)
                  setTimeout(() => {
                    this.overflowMenuRef.current.focus();
                  }, 1);
              }
            }
          }}
        />
        {recurrence !== null && (
          <RoomRecurrenceDetailsPageSmall
            onClosePopUp={() => this.onClosePopUp()}
          />
        )}
      </main>
    );
  }

  handleOnFilterModalClose = () => {
    const { setFilterModal } = this.props;
    setFilterModal(false);
    if (!isMobile) {
      if (this.filterRef && this.filterRef.current) {
        setTimeout(() => this.filterRef.current.focus(), 1);
      }
    } else {
      const element = document.querySelector(`.${cssBase}__mobileFilterButton`);
      this.mobileFilterRef = element.children[0];
      if (this.mobileFilterRef)
        setTimeout(() => this.mobileFilterRef.focus(), 1);
    }
  };

  handleChangeLocationClose = () => {
    const { setLocationModal } = this.props;
    setLocationModal(false);
    if (!isMobile) {
      if (
        this.changeLocationButtonRef &&
        this.changeLocationButtonRef.current
      ) {
        setTimeout(() => this.changeLocationButtonRef.current.focus(), 1);
      }
    } else {
      if (this.overflowMenuRef && this.overflowMenuRef.current) {
        setTimeout(() => this.overflowMenuRef.current.focus(), 1);
      }
    }
  };

  handleSearchColleagueClick = (e) => {
    const { setSearchColleagueModal } = this.props;
    e.stopPropagation();
    setSearchColleagueModal(true);
    this.setState({ menuOpen: false });
  };

  onClosePopUp = () => {
    const { setRoomRecurrenceDetailsModal } = this.props;
    setRoomRecurrenceDetailsModal(false);
    if (this.recurrenceLabelLinkRef && this.recurrenceLabelLinkRef.current) {
      setTimeout(() => {
        this.recurrenceLabelLinkRef.current.focus();
      }, 1);
    }
  };

  onBackClick = () => {
    const {
      navigateToSearchByName,
      setFloorFilter,
      floors,
      removeCheckedRooms,
    } = this.props;
    removeCheckedRooms();
    setFloorFilter(floors[0]);
    navigateToSearchByName();
  };

  getExpandShrinkLabel = (isFloorPlanExpanded) => {
    return AppMsg.getMessage(
      isFloorPlanExpanded
        ? AppMsg.BUTTON.BUTTON_SHRINK
        : AppMsg.BUTTON.BUTTON_EXPAND
    );
  };

  renderLocationButton() {
    const { selectedBuilding } = this.props;
    if (isEmpty(selectedBuilding)) {
      return (
        <Button
          className={`${cssBase}__buildingButton`}
          kind="ghost"
          size="small"
          onClick={this.handleAddLocationsClick}
          ref={this.changeLocationButtonRef}
          renderIcon={Enterprise16}
          aria-label={
            this.props.appMessages[AppMsg.RESERVATION_MESSAGE.SELECT_LOCATION]
          }
        >
          {this.props.appMessages[AppMsg.RESERVATION_MESSAGE.SELECT_LOCATION]}
        </Button>
      );
    } else {
      return (
        <LocationFlyoutOptions
          changeLocationButtonRef={this.changeLocationButtonRef}
          selectedBuilding={selectedBuilding}
          onHandleAddLocationsClick={this.handleAddLocationsClick}
          onHandleRemoveBuilding={this.handleRemoveBuilding}
        />
      );
    }
  }

  renderColleagueButton() {
    const { selectedColleague } = this.props;
    if (isNil(selectedColleague)) {
      return (
        <Button
          kind="ghost"
          size="small"
          renderIcon={User16}
          onClick={this.handleSearchColleagueClick}
          ref={this.searchColleagueButtonRef}
          className={`${cssBase}__colleagueReservationBtn`}
        >
          {
            this.props.appMessages[
              AppMsg.RESERVATION_MESSAGE.COLLEAGUE_RESERVATION
            ]
          }
        </Button>
      );
    } else {
      this.colleagueReservationMenu = {
        reservationList: this.props.appMessages[
          AppMsg.RESERVATION_MESSAGE.RESERVATION_LIST_MENU_ITEM
        ],
        changeColleague: this.props.appMessages[
          AppMsg.RESERVATION_MESSAGE.CHANGE_COLLEAGUE_MENU_ITEM
        ],
        clearColleague: this.props.appMessages[
          AppMsg.RESERVATION_MESSAGE.CLEAR_COLLEAGUE_MENU_ITEM
        ],
      };
      const menuList = [
        this.colleagueReservationMenu.reservationList,
        this.colleagueReservationMenu.changeColleague,
        this.colleagueReservationMenu.clearColleague,
      ];

      return (
        <SimpleMenu
          menuList={menuList}
          title={selectedColleague.name}
          toggleIcon={User16}
          ref={this.searchColleagueButtonRef}
          onSelect={(list) => this.handleMenuSelect(list)}
        />
      );
    }
  }

  handleMenuSelect(menuItem) {
    const {
      navigateBack,
      setSearchColleagueModal,
      setSelectedColleague,
      setColleagueDetails,
    } = this.props;

    if (!isNil(menuItem)) {
      switch (menuItem) {
        case this.colleagueReservationMenu.reservationList:
          navigateBack();
          break;
        case this.colleagueReservationMenu.changeColleague:
          setSearchColleagueModal(true);
          break;
        default:
          setSelectedColleague(null);
          setColleagueDetails(null);
          this.reSetReservedRoom();
          break;
      }
    }
  }

  renderSelectedRoomLabel() {
    const { selectedRoomFromSearch } = this.props;
    if (!isEmpty(selectedRoomFromSearch)) {
      return (
        <div className={`${cssBase}__selectedRoomLabel`}>
          <div className={`${cssBase}__searchResult`}>
            {
              this.props.appMessages[
                AppMsg.RESERVATION_MESSAGE.SEARCH_RESULTS_FOR
              ]
            }
            {this.labelText()}
          </div>
          <div className={`${cssBase}__clearButton`}>
            <Tag onClick={this.handleRemoveRoom} filter>
              {this.props.appMessages[AppMsg.RESERVATION_MESSAGE.CLEAR]}
            </Tag>
          </div>
        </div>
      );
    }
  }

  labelText = () => {
    const { selectedRoomFromSearch, searchText } = this.props;
    return selectedRoomFromSearch.length === 1
      ? selectedRoomFromSearch[0].floor +
          ", " +
          selectedRoomFromSearch[0].roomId +
          ", " +
          selectedRoomFromSearch[0].name
      : searchText;
  };

  renderLoading(searchingRooms) {
    if (searchingRooms) {
      return <SkeletonPlaceholder className={`${cssBase}__loading`} />;
    }
    return null;
  }

  renderFloorPlanView(
    searchingRooms,
    searchingMoreRooms,
    roomViewMode,
    rooms,
    selectedRooms,
    isFloorPlanExpanded,
    favoriteRooms,
    addFavoriteRoom,
    removeFavoriteRoom,
    selectedRoom,
    setSelectedRoomOnFloorplan,
    isRecurring,
    labelStyles,
    isException,
    selectedColleague,
    selectedColleagueRoom,
    selectedFloor,
    rememberFloorplanLastPosition
  ) {
    if (
      !searchingRooms &&
      roomViewMode === RoomViewMode.FLOORPLAN &&
      rooms.length > 0
    ) {
      const roomArea =
        selectedColleagueRoom && Number(selectedColleagueRoom.area);
      const floorArea = selectedFloor.area;
      let padding = roomArea;
      let shouldZoom = true;
      const roomFloorPercentage = (roomArea / floorArea) * 100;
      if (roomFloorPercentage > 2.5) {
        shouldZoom = false;
      } else if (roomFloorPercentage > 1) {
        shouldZoom = true;
      } else if (roomFloorPercentage > 0.5) {
        padding = roomArea * 2;
      } else if (roomFloorPercentage > 0.1) {
        padding = roomArea * 4;
      } else {
        padding = roomArea * 6;
      }
      const zoomPadding = shouldZoom ? padding : 0;
      return (
        <FloorPlanView
          className={`${cssBase}__floorPlanView`}
          rooms={rooms}
          selectedRooms={selectedRooms}
          isFloorPlanExpanded={isFloorPlanExpanded}
          onFloorplanViewportChange={this.handleFloorPlanViewportChanged}
          onChange={this.handleListChange}
          onClick={this.handleItemClick}
          favorites={favoriteRooms}
          addFavoriteRoom={addFavoriteRoom}
          removeFavoriteRoom={removeFavoriteRoom}
          setTappedRoomOnFloorplan={(room) => setSelectedRoomOnFloorplan(room)}
          selectedRoom={selectedRoom}
          isRecurring={isException ? false : isRecurring}
          onRecurrenceClick={this.handleRecurrenceClick}
          labelStyles={labelStyles}
          loadingMore={searchingMoreRooms}
          selectedColleague={selectedColleague}
          zoomPadding={zoomPadding}
          setFloorPlanRef={this.setFloorPlanRef}
          enableLastPositionPlugin={rememberFloorplanLastPosition}
          disableSearchArea={this.state.disableSearchArea}
        />
      );
    }
    return null;
  }

  setFloorPlanRef = (ref) => {
    this.floorPlanViewRef = React.createRef();
    this.floorPlanViewRef = ref;
  };

  handleExpandShrink = () => {
    const { isFloorPlanExpanded } = this.state;
    this.setState({ isFloorPlanExpanded: !isFloorPlanExpanded });
    setTimeout(() => this.floorPlanViewRef.floorPlanDidResize(), 100);
    if (this.expandShrinkButtonRef && this.expandShrinkButtonRef.current) {
      setTimeout(() => this.expandShrinkButtonRef.current.focus());
    }
  };

  handleRecurrenceClick = (room, btnRef) => {
    const { setRoomId, setRoomRecurrenceDetailsModal } = this.props;
    this.recurrenceLabelLinkRef = btnRef;
    setRoomId(room._id);
    setRoomRecurrenceDetailsModal(true);
  };

  handleItemClick = (room, ref) => {
    const { setRoomId, setRoomDetailsModal, setRoomDetail } = this.props;
    this.setState({ isOpen: true });
    this.roomRef = ref;
    setRoomId(room._id);
    if (this.state.isOpen) {
      setRoomDetailsModal(true);
    }
    setRoomDetail(room);
  };

  onRoomDetailsPopupClose = () => {
    const { setRoomDetailsModal } = this.props;
    setRoomDetailsModal(false);
    if (this.roomRef) {
      setTimeout(() => {
        this.roomRef.focus();
      }, 1);
    }
  };

  renderFloorDropdown() {
    const {
      selectedFloor,
      setFloorFilter,
      searchingRooms,
      selectedRoomFromSearch,
      setRoomsFilter,
    } = this.props;
    let floors = this.props.floors;
    if (selectedRoomFromSearch && selectedRoomFromSearch.length === 1) {
      floors = floors.filter(
        (f) => f._id === selectedRoomFromSearch[0].floorSystemRecordID
      );
    }
    const { selectedRooms } = this.state;
    return (
      <div className={`${cssBase}__floorSelect`}>
        <Select
          id="floorSelect"
          value={floors.map((f) => f?._id).indexOf(selectedFloor?._id)}
          labelText={
            this.props.appMessages[
              AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_SELECT_FLOOR
            ]
          }
          hideLabel
          onChange={(e) => {
            setFloorFilter(floors[e.target.value]);
            setRoomsFilter([]);
            this.reSetReservedRoom();
          }}
          disabled={isEmpty(floors) || selectedFloor == null || searchingRooms}
        >
          {floors.map((item, index) => {
            const selectedCount = selectedRooms.filter(
              (room) => room.floorSystemRecordID === item._id
            ).length;
            return (
              <SelectItem
                key={item._id}
                text={`${item.name}${
                  selectedCount > 0
                    ? ` (${selectedCount} ${
                        this.props.appMessages[AppMsg.SELECTED]
                      })`
                    : ""
                }`}
                value={index}
              />
            );
          })}
        </Select>
      </div>
    );
  }

  hasMoreResult = () => {
    const {
      hasMoreResults,
      selectedRoomFromSearch,
      hasMoreResultsInSearch,
    } = this.props;
    const moreResults = selectedRoomFromSearch
      ? selectedRoomFromSearch.length === 1
        ? false
        : hasMoreResultsInSearch
      : hasMoreResults;
    return moreResults;
  };

  checkedCount = () => {
    const {
      checkedCount,
      checkedByNameCount,
      selectedRoomFromSearch,
    } = this.props;
    const check = selectedRoomFromSearch
      ? selectedRoomFromSearch.length === 1
        ? 1
        : checkedByNameCount
      : checkedCount;
    return check;
  };

  availableCount = () => {
    const {
      availableCount,
      availableByNameCount,
      selectedRoomFromSearch,
    } = this.props;
    const available = selectedRoomFromSearch
      ? selectedRoomFromSearch.length === 1
        ? selectedRoomFromSearch[0].isAvailable
          ? 1
          : 0
        : availableByNameCount
      : availableCount;
    return available;
  };

  totalSize = () => {
    const { selectedRoomFromSearch, totalSize, totalCount } = this.props;
    const total = selectedRoomFromSearch
      ? selectedRoomFromSearch.length === 1
        ? 1
        : totalCount
      : totalSize;
    return total;
  };

  handleSearchMore = async () => {
    const {
      searchMore,
      selectedRoomFromSearch,
      searchText,
      selectedBuilding,
      searchRoomByName,
    } = this.props;
    if (!isEmpty(selectedRoomFromSearch)) {
      searchRoomByName(searchText, selectedBuilding._id, true, true);
    } else {
      searchMore();
    }
  };

  computeShowSearchArea = () => {
    const {
      roomViewMode,
      rooms,
      selectedColleague,
      selectedColleagueRoom,
      selectedBuilding,
      selectedFloor,
    } = this.props;
    let sameBuildingAndFloor = false;
    if (
      selectedColleague &&
      selectedBuilding?._id === selectedColleagueRoom?.buildingSystemRecordID &&
      selectedFloor?._id === selectedColleagueRoom?.floorSystemRecordID
    )
      sameBuildingAndFloor = true;
    const floorPlanId = this.floorPlanId;
    return (
      roomViewMode === RoomViewMode.FLOORPLAN &&
      !isEmpty(rooms) &&
      !isNil(floorPlanId) &&
      sameBuildingAndFloor
    );
  };

  handleSearchArea = async () => {
    const { getRoomsInFloorplanViewport } = this.props;
    const {
      floorplanViewportData: { x, y, width, height },
    } = this.state;
    this.setState({ disableSearchArea: true });
    const floorPlanId = await this.floorPlanId;
    getRoomsInFloorplanViewport(floorPlanId, x, y, width, height);
  };

  renderRoomResultsCounter(
    formattedDate,
    dir,
    recurrence,
    isRecurring,
    checkedCount,
    availableCount,
    totalSize,
    hasMoreResults,
    searchMore,
    reservationType,
    selectedException,
    isException,
    searchingRooms,
    searchingMoreRooms
  ) {
    if (searchingRooms) return null;
    if (totalSize > 0) {
      return (
        <RoomResultsCounter
          className={`${cssBase}__resultsCounter`}
          formattedDate={
            isException ? selectedException.formattedDate : formattedDate
          }
          dir={dir}
          recurrence={recurrence}
          isRecurring={isException ? false : isRecurring}
          totalSize={this.totalSize()}
          showCheckMore={this.hasMoreResult()}
          searchingMoreRooms={searchingMoreRooms}
          showSearchArea={this.computeShowSearchArea()}
          disableSearchArea={this.state.disableSearchArea}
          checkedCount={this.checkedCount()}
          availableCount={this.availableCount()}
          onCheckMore={this.handleSearchMore}
          onSearchArea={this.handleSearchArea}
          reservationType={reservationType}
        />
      );
    }
    return null;
  }

  renderRoomList(
    searchingRooms,
    searchingMoreRooms,
    rooms,
    selectedRooms,
    isRecurring,
    roomViewMode,
    favoriteRooms,
    addFavoriteRoom,
    removeFavoriteRoom,
    dir,
    reservationType,
    isException
  ) {
    if (
      !searchingRooms &&
      rooms.length > 0 &&
      roomViewMode === RoomViewMode.LIST
    ) {
      return (
        <RoomList
          rooms={rooms}
          selected={selectedRooms}
          favorites={favoriteRooms}
          reservationType={reservationType}
          className={`${cssBase}__list`}
          onChange={this.handleListChange}
          onItemClick={this.handleItemClick}
          isRecurring={isException ? false : isRecurring}
          onRecurrenceClick={this.handleRecurrenceClick}
          addFavoriteRoom={addFavoriteRoom}
          removeFavoriteRoom={removeFavoriteRoom}
          loadingMore={searchingMoreRooms}
          dir={dir}
          isException={isException}
        />
      );
    }
    return null;
  }

  reSetReservedRoom = () => {
    this.props.setColleagueReservedRoom({});
  };

  renderEmptyMessage(searchingRooms, rooms, reservationType) {
    if (!searchingRooms && isEmpty(rooms)) {
      return (
        <div className={`${cssBase}__empty`}>
          <Bee32 className={`${cssBase}__emptyIcon`} />
          <div>
            {
              this.props.appMessages[
                reservationType === ReservationTypes.MEETING ? AppMsg.RESERVATION_MESSAGE.NO_ROOM_FOUND
                : reservationType === ReservationTypes.WORKSPACE ? AppMsg.RESERVATION_MESSAGE.NO_WORKSPACE_FOUND
                : AppMsg.RESERVATION_MESSAGE.NO_OFFICE_FOUND // CISA
              ]
            }
          </div>
        </div>
      );
    }
    return null;
  }

  // Having trouble with this not finding a title to use in all cases.
  /*
  renderShowingFavoritesLabel(selectedBuilding, reservationType, selectedFloor, router) {
    if (isEmpty(selectedBuilding) || isEmpty(selectedFloor)) {
      let title = "";
      if(isEmpty(selectedBuilding) && isEmpty(selectedFloor)){
        title = AppMsg.getMessage(
          reservationType === ReservationTypes.MEETING ? AppMsg.RESERVATION_MESSAGE.STEP_ROOM_NO_LOCATIONS_SELECTED_SEARCH_FAVORITES
          : reservationType === ReservationTypes.WORKSPACE ? AppMsg.RESERVATION_MESSAGE.STEP_WORKSPACE_NO_LOCATIONS_SELECTED_SEARCH_FAVORITES
          : AppMsg.RESERVATION_MESSAGE.STEP_OFFICE_NO_LOCATIONS_SELECTED_SEARCH_FAVORITES  // CISA
        );

      }else if(!isEmpty(selectedBuilding) && isEmpty(selectedFloor) && router && (router.routedFromSummary === false)){
        title = AppMsg.getMessage(
          reservationType === ReservationTypes.MEETING ? AppMsg.RESERVATION_MESSAGE.STEP_ROOM_NO_FLOOR_ROUTED_SELECTED_SEARCH_FAVORITES
          : reservationType === ReservationTypes.WORKSPACE ? AppMsg.RESERVATION_MESSAGE.STEP_WORKSPACE_NO_FLOOR_ROUTED_SELECTED_SEARCH_FAVORITES
          : AppMsg.RESERVATION_MESSAGE.STEP_OFFICE_NO_FLOOR_ROUTED_SELECTED_SEARCH_FAVORITES // CISA
        );

      }else if(!isEmpty(selectedBuilding) && isEmpty(selectedFloor)){
        title = AppMsg.getMessage(
          reservationType === ReservationTypes.MEETING ? AppMsg.RESERVATION_MESSAGE.STEP_ROOM_NO_FLOOR_SELECTED_SEARCH_FAVORITES
          : reservationType === ReservationTypes.WORKSPACE ? AppMsg.RESERVATION_MESSAGE.STEP_WORKSPACE_NO_FLOOR_SELECTED_SEARCH_FAVORITES
          : AppMsg.RESERVATION_MESSAGE.STEP_OFFICE_NO_FLOOR_SELECTED_SEARCH_FAVORITES // CISA
        );

      }
      return (
        <InlineNotification
          className={`${cssBase}__showingFavoritesLabel`}
          kind="info"
          hideCloseButton
          lowContrast
          title={title}
          statusIconDescription={title}
          aria-hidden={true}
        />
      );
    } 
  } */ 

  computeDoneButtonDisabled(selectedRooms, roomsOnHold) {
    return isEmpty(selectedRooms) && isEmpty(roomsOnHold);
  }

  handleListChange = (room, selected) => {
    const { selectedRooms, isException } = this.state;
    const { setSelectedRoom } = this.props;
    let newSelectedRooms = null;
    if (!isException) {
      if (selected) {
        newSelectedRooms = [...selectedRooms, room];
      } else {
        newSelectedRooms = selectedRooms.filter(
          (selected) => selected._id !== room._id
        );
      }
    } else {
      if (selected) {
        newSelectedRooms = [room];
      } else {
        newSelectedRooms = [];
      }
    }
    setSelectedRoom(newSelectedRooms);
    this.setState({ selectedRooms: newSelectedRooms });
  };

  handleFloorPlanViewportChanged = (e) => {
    const { floorplanViewportData, floorViewportChanged } = this.state;
    if (
      isEmpty(floorplanViewportData) ||
      floorplanViewportData.x !== e.x ||
      floorplanViewportData.y !== e.y
    ) {
      this.props.setRememberFloorplanLastPosition(true);
      this.setState({ disableSearchArea: false });
      this.setState({ floorplanViewportData: e });
    }
    if (floorViewportChanged) {
      this.setState({ floorViewportChanged: true });
    }
  };

  onCancelClick = () => {
    const {
      removeCheckedRooms,
      navigateToReservationSummary,
      setSelectedColleague,
      setRoomsFilter,
    } = this.props;
    removeCheckedRooms();
    setSelectedColleague(null);
    setRoomsFilter([]);
    setColleagueDetails(null);
    navigateToReservationSummary(true);
  };

  onDoneClick = async () => {
    const {
      holdRooms,
      navigateToReservationSummary,
      selectedException,
      setSelectedResourceException,
      removeCheckedRooms,
      setSelectedRooms,
    } = this.props;
    const { selectedRooms, isException } = this.state;
    if (isException) {
      const updatedException = {
        ...selectedException,
        room: selectedRooms[0],
      };
      setSelectedResourceException(updatedException);
      setSelectedColleague(null);
      setColleagueDetails(null);
      navigateToReservationSummary();
    } else {
      const holdSuccess = await holdRooms(selectedRooms);
      if (holdSuccess) {
        removeCheckedRooms();
        setSelectedColleague(null);
        setColleagueDetails(null);
        navigateToReservationSummary();
        setSelectedRooms(null);
      }
    }
  };

  handleAddLocationsClick = (e) => {
    const { setSelectedRooms, setLocationModal, setRoomsFilter } = this.props;
    e.persist();
    e.stopPropagation();
    setRoomsFilter([]);
    this.reSetReservedRoom();
    setSelectedRooms(null);
    setLocationModal(true);
  };

  handleFilterButtonClick = (e) => {
    e.stopPropagation();
    this.props.setFilterModal(true);
  };

  handleRemoveBuilding = () => {
    this.props.removeCheckedRooms();
    this.props.setRoomsFilter([]);
    this.props.setSelectedBuilding(null);
    this.props.setSelectedRooms(null);
    this.props.setFloorFilter(null);
    this.props.setZoomToColleague(false);
    this.reSetReservedRoom();
    if (!isMobile) {
      if (
        this.changeLocationButtonRef &&
        this.changeLocationButtonRef.current
      ) {
        setTimeout(() => this.changeLocationButtonRef.current.focus(), 1);
      }
    } else {
      if (this.overflowMenuRef && this.overflowMenuRef.current) {
        setTimeout(() => this.overflowMenuRef.current.focus(), 1);
      }
    }
  };

  handleRemoveRoom = () => {
    this.props.setSelectedRooms(null);
  };

  renderLocationFlyoutOptions() {
    const {
      selectedBuilding,
      selectedColleague,
      navigateBack,
      setSelectedColleague,
      setColleagueDetails,
    } = this.props;
    const { menuOpen } = this.state;
    if (isEmpty(selectedBuilding)) {
      return (
        <OverflowMenu
          flipped={true}
          size="lg"
          ref={this.overflowMenuRef}
          open={menuOpen}
          onClick={() => this.setState({ menuOpen: true })}
          data-testid="overFlowMenu"
        >
          <OverflowMenuItem
            onClick={this.handleAddLocationsClick}
            itemText={
              this.props.appMessages[AppMsg.RESERVATION_MESSAGE.SELECT_LOCATION]
            }
            closeMenu={() => this.setState({ menuOpen: false })}
          />
          {isNil(selectedColleague) && (
            <OverflowMenuItem
              hasDivider
              onClick={this.handleSearchColleagueClick}
              itemText={
                this.props.appMessages[
                  AppMsg.RESERVATION_MESSAGE.COLLEAGUE_RESERVATION
                ]
              }
              closeMenu={() => this.setState({ menuOpen: false })}
            />
          )}
          {!isNil(selectedColleague) && (
            <>
              <OverflowMenuItem
                className={`${cssBase}__disabledMenuItem`}
                hasDivider
                itemText={selectedColleague.name}
                disabled
                requireTitle
                closeMenu={() => this.setState({ menuOpen: false })}
              />
              <OverflowMenuItem
                hasDivider
                onClick={() => navigateBack()}
                itemText={this.colleagueReservationMenu.reservationList}
                closeMenu={() => this.setState({ menuOpen: false })}
              />
              <OverflowMenuItem
                onClick={this.handleSearchColleagueClick}
                itemText={this.colleagueReservationMenu.changeColleague}
                closeMenu={() => this.setState({ menuOpen: false })}
              />
              <OverflowMenuItem
                onClick={() => {
                  setSelectedColleague(null);
                  setColleagueDetails(null);
                }}
                itemText={this.colleagueReservationMenu.clearColleague}
                closeMenu={() => this.setState({ menuOpen: false })}
              />
            </>
          )}
        </OverflowMenu>
      );
    } else {
      return (
        <OverflowMenu
          flipped={true}
          size="lg"
          ref={this.overflowMenuRef}
          open={menuOpen}
          onClick={() => this.setState({ menuOpen: true })}
        >
          <OverflowMenuItem
            itemText={this.computeBuildingNameWithTimezone()}
            disabled
            requireTitle
            closeMenu={() => this.setState({ menuOpen: false })}
          />
          <OverflowMenuItem
            onClick={this.handleAddLocationsClick}
            itemText={
              this.props.appMessages[AppMsg.RESERVATION_MESSAGE.CHANGE_LOCATION]
            }
            closeMenu={() => this.setState({ menuOpen: false })}
          />
          <OverflowMenuItem
            onClick={this.handleRemoveBuilding}
            itemText={
              this.props.appMessages[AppMsg.RESERVATION_MESSAGE.CLEAR_LOCATION]
            }
            closeMenu={() => this.setState({ menuOpen: false })}
          />
          {isNil(selectedColleague) && (
            <OverflowMenuItem
              hasDivider
              onClick={this.handleSearchColleagueClick}
              itemText={
                this.props.appMessages[
                  AppMsg.RESERVATION_MESSAGE.COLLEAGUE_RESERVATION
                ]
              }
              closeMenu={() => this.setState({ menuOpen: false })}
            />
          )}
          {!isNil(selectedColleague) && (
            <>
              <OverflowMenuItem
                className={`${cssBase}__disabledMenuItem`}
                hasDivider
                itemText={selectedColleague.name}
                disabled
                requireTitle
                closeMenu={() => this.setState({ menuOpen: false })}
              />
              <OverflowMenuItem
                hasDivider
                onClick={() => navigateBack()}
                itemText={this.colleagueReservationMenu.reservationList}
                closeMenu={() => this.setState({ menuOpen: false })}
              />
              <OverflowMenuItem
                onClick={this.handleSearchColleagueClick}
                itemText={this.colleagueReservationMenu.changeColleague}
                closeMenu={() => this.setState({ menuOpen: false })}
              />
              <OverflowMenuItem
                onClick={() => {
                  setSelectedColleague(null);
                  setColleagueDetails(null);
                }}
                itemText={this.colleagueReservationMenu.clearColleague}
                closeMenu={() => this.setState({ menuOpen: false })}
              />
            </>
          )}
        </OverflowMenu>
      );
    }
  }

  computeBuildingNameWithTimezone = () => {
    const { selectedBuilding } = this.props;
    return (
      <>
        <div className={`${cssBase}__selectedBuildingName`}>
          {selectedBuilding.name}
        </div>
        <div className={`${cssBase}__buildingTimezone`}>
          {selectedBuilding.timeZone}
        </div>
      </>
    );
  };

  renderMeetingToolbar = () => {
    const {
      selectedBuilding,
      dir,
      filtersCount,
      searchingRooms,
      roomViewMode,
      rooms,
    } = this.props;
    const { isFloorPlanExpanded } = this.state;
    return (
      <div className={`${cssBase}__toolbar`}>
        <div className={`${cssBase}__dropdown`}>
          {this.renderFloorDropdown()}
        </div>
        <div>{this.renderLocationButton()}</div>
        <div>
          {!isEmpty(selectedBuilding) && (
            <TooltipIcon
              direction="bottom"
              align={dir === "rtl" ? "start" : "end"}
              tooltipText={selectedBuilding.timeZone}
              color="danger"
              className={`${cssBase}__timezone`}
            >
              <Information16 />
            </TooltipIcon>
          )}
        </div>
        <div>
          <FilterButton
            className={`${cssBase}__filterBtn`}
            onClick={this.handleFilterButtonClick}
            count={filtersCount}
            filterRef={this.filterRef}
          />
        </div>
        <Button
          className={`${cssBase}__expandShrinkButton`}
          kind="secondary"
          size="small"
          renderIcon={isFloorPlanExpanded ? ShrinkScreen20 : FitToScreen20}
          tooltipAlignment="center"
          tooltipPosition={dir === "ltr" ? "right" : "left"}
          iconDescription={this.getExpandShrinkLabel(isFloorPlanExpanded)}
          onClick={this.handleExpandShrink}
          hidden={
            !(
              !searchingRooms &&
              roomViewMode === RoomViewMode.FLOORPLAN &&
              rooms.length > 0 &&
              this.state.buildingFloorPlanId
            )
          }
          aria-label={this.getExpandShrinkLabel(isFloorPlanExpanded)}
          data-testid="expandShrinkButton"
        />
      </div>
    );
  };
}

const { holdRooms, setSelectedResourceException } = ReservationActions;
const {
  setRoomViewMode,
  setSelectedRoomOnFloorplan,
  searchMore,
  setFloorFilter,
  getRoomsInFloorplanViewport,
  setSelectedRoom,
  removeCheckedRooms,
  setSelectedRooms,
  searchRoomByName,
  setLocationModal,
  setSearchColleagueModal,
  setFilterModal,
  setRoomDetailsModal,
  setRoomRecurrenceDetailsModal,
  setRememberFloorplanLastPosition,
  setRoomsFilter,
} = RoomSearchActions;
const { setSelectedBuilding } = LocationActions;
const {
  navigateToReservationSummary,
  navigateToSearchByName,
  navigateBack,
} = RouteActions;
const { addFavoriteRoom, removeFavoriteRoom } = CurrentUserActions;
const { setRoomId, setRoomDetail } = RoomDetailsActions;
const {
  setSelectedColleague,
  setColleagueDetails,
  setZoomToColleague,
  setColleagueReservedRoom,
} = ColleagueActions;

const mapStateToProps = (state) => {
  return {
    roomsOnHold: ReservationSelectors.roomsSelector(state),
    floors: LocationSelectors.floorsSelector(state),
    selectedFloor: RoomSearchSelectors.floorSelector(state),
    rooms: RoomSearchSelectors.roomsToDisplaySelector(state),
    formattedDate: ReservationSelectors.formattedStartEndDatesSelector(state),
    selectedBuilding: LocationSelectors.selectedBuildingSelector(state),
    selectedColleague: ColleagueSelectors.selectedColleagueSelector(state),
    checkedRooms: RoomSearchSelectors.checkedRoomsSelector(state),
    filtersCount: RoomSearchSelectors.filtersCountSelector(state),
    searchingRooms: LoadingSelectors.searchingRoomsSelector(state),
    searchingMoreRooms: LoadingSelectors.searchingMoreRoomsSelector(state),
    hasMoreResults: RoomSearchSelectors.hasMoreResultsSelector(state),
    dir: LayoutSelectors.dirSelector(state),
    isRecurring: !!ReservationSelectors.recurrenceSelector(state),
    recurrence: ReservationSelectors.recurrenceSelector(state),
    favoriteRooms: CurrentUserSelectors.favoriteRoomsSelector(state),
    roomViewMode: RoomSearchSelectors.roomViewModeSelector(state),
    selectedRoom: RoomSearchSelectors.selectedRoomOnFloorplanSelector(state),
    labelStyles: LabelStylesSelectors.labelStylesSelector(state),
    reservationType: ReservationSelectors.reservationTypeSelector(state),
    checkedCount: RoomSearchSelectors.checkedCountSelector(state),
    availableCount: RoomSearchSelectors.availableCountSelector(state),
    totalSize: RoomSearchSelectors.totalSizeSelector(state),
    selectedException: ReservationSelectors.selectedResourceSelectedExceptionSelector(
      state
    ),
    selectedRoomFromSearch: RoomSearchSelectors.SelectedRoomSearchByNameSelector(
      state
    ),
    router: state.router.location.state,
    searchText: RoomSearchSelectors.searchTextSelector(state),
    RoomsByNameSearch: RoomSearchSelectors.roomSearchByNameSelector(state),
    checkedByNameCount: RoomSearchSelectors.checkedCountByNameSelector(state),
    availableByNameCount: RoomSearchSelectors.availableCountByNameSelector(
      state
    ),
    roomsToDisplay: RoomSearchSelectors.roomsByNameToDisplaySelector(state),
    selectedRoomToDisplay: RoomSearchSelectors.selectedRoomToDisplaySelector(
      state
    ),
    totalCount: RoomSearchSelectors.totalCountSelector(state),
    hasMoreResultsInSearch: RoomSearchSelectors.hasMoreResultsInSearchSelector(
      state
    ),
    isLocationModalOpen: RoomSearchSelectors.locationModalSelector(state),
    isSearchColleagueModalOpen: RoomSearchSelectors.searchColleagueModalSelector(
      state
    ),
    isFilterModalOpen: RoomSearchSelectors.filterModalSelector(state),
    isRoomModalOpen: RoomSearchSelectors.roomModalSelector(state),
    selectedColleagueRoom: ColleagueSelectors.selectedColleagueReservationRoomSelector(
      state
    ),
    colleagueReservedRoom: ColleagueSelectors.colleagueReservedRoomSelector(
      state
    ),
    rememberFloorplanLastPosition: RoomSearchSelectors.rememberFloorplanLastPositionSelector(
      state
    ),
  };
};

export default withTriDictionary(
  connect(mapStateToProps, {
    holdRooms,
    navigateToReservationSummary,
    setSelectedBuilding,
    setSelectedRoom,
    removeCheckedRooms,
    addFavoriteRoom,
    removeFavoriteRoom,
    setRoomViewMode,
    setSelectedRoomOnFloorplan,
    searchMore,
    setFloorFilter,
    getRoomsInFloorplanViewport,
    setSelectedResourceException,
    setSelectedRooms,
    navigateToSearchByName,
    searchRoomByName,
    setLocationModal,
    setSearchColleagueModal,
    setFilterModal,
    setRoomDetailsModal,
    setRoomId,
    setRoomDetail,
    setRoomRecurrenceDetailsModal,
    navigateBack,
    setSelectedColleague,
    setColleagueDetails,
    setColleagueReservedRoom,
    setRememberFloorplanLastPosition,
    setZoomToColleague,
    setRoomsFilter,
  })(RoomSearchPageSmall)
);
