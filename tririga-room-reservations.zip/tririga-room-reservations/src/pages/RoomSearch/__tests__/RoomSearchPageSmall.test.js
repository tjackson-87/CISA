/* IBM Confidential· - OCO Source Materials· - (C) COPYRIGHT IBM CORP. 2023 - The source code for this program is not published or otherwise· divested of its trade secrets, irrespective of what has been· deposited with the U.S. Copyright Office. */

import React from "react";
import { fireEvent, screen } from "@testing-library/react";
import { AppMsg, ReservationTypes } from "../../../utils";
import { getAppStore, RoomSearchActions, RouteActions } from "../../../store";
import RoomSearchPageSmall from "../RoomSearchPageSmall";
import {
  createReservableRoom,
  createReservationParam,
  createResource,
  renderWithReduxAndDictionaryProvider
} from "../../../testUtils";
import { reservationReducer } from "../../../store/reducers/ReservationReducer";

afterEach(() => jest.clearAllMocks());

jest.mock("../../ChangeLocation/ChangeLocationPageSmall", () => {
  return {
    __esModule: true,
    default: () => <div data-testid="changeLocationPageSmall">Change Location</div>,
  };
});

function MockedSearchColleague({ 
  // eslint-disable-next-line react/prop-types
  isOpen,
  // eslint-disable-next-line react/prop-types
  onClose}) {
  if (!isOpen) return null;
  return (
        <div data-testid="searchColleaguePage">
            <button onClick={onClose}>search colleague close</button>
        </div>
  );
}

jest.mock("../../../components/SearchColleague/SearchColleague", () => {
  return MockedSearchColleague;
});

function mockedSimpleMenu({ 
  // eslint-disable-next-line react/prop-types
  menuList = [],
  // eslint-disable-next-line react/prop-types
  title,
  // eslint-disable-next-line react/prop-types
  onSelect,
  // eslint-disable-next-line react/prop-types
  toggleIcon
}) {

  return (
        <div data-testid="simpleMenu">
          <h1>{title}</h1>
          <ul>
            {menuList && menuList.map((item, index) => 
              <li key={index} onClick={onSelect(item)}>
                {item}
              </li>
            )}
          </ul>
        </div>
  );
}

jest.mock("../../../components/SimpleMenu/SimpleMenu", () => {
  return mockedSimpleMenu;
});

jest.mock("../../RoomFilters/RoomFiltersPageSmall", () => {
  return {
    __esModule: true,
    default: () => <div data-testid="roomFiltersPageSmall">Room Filter Page</div>,
  };
});

jest.mock("../../RoomDetails/RoomDetailsPageSmall", () => {
  return {
    __esModule: true,
    default: () => <div data-testid="roomDetailsPageSmall">Room Details Page Small</div>,
  };
});

jest.mock("../../RoomRecurrenceDetails/RoomRecurrenceDetailsPageSmall", () => {
  return {
    __esModule: true,
    default: () => <div data-testid="roomRecurrenceDetailsPageSmall">Room Recurrence Details Page Small</div>,
  };
});

RoomSearchActions.setSearchColleagueModal.mockImplementation(() =>
  jest.fn()
);

RouteActions.navigateBack.mockImplementation(() => jest.fn());

jest.mock("../../../store/actions/CurrentUserActions");
jest.mock("../../../store/actions/ReservationActions");
jest.mock("../../../store/actions/RoomSearchActions");
jest.mock("../../../store/actions/RoomDetailsActions");
jest.mock("../../../store/actions/LocationActions");
jest.mock("../../../store/actions/RouteActions");

describe("RoomSearchPageSmall", () => {
  describe("RoomSearchPageSmall component", () => {
    let props, appMessages, fakeRoom, reservationParam, resource, initialReservationState, initialRoomDetailsState;
    beforeEach(() => {
      fakeRoom = createReservableRoom("Spider-man", "Marvel", 1);
      reservationParam = createReservationParam();
      resource = createResource(fakeRoom);
      appMessages = AppMsg.getAppMessages();
      props = { }
      initialReservationState = {
        ...getAppStore().getState.reservation,
        data: {
          ...reservationParam
        },
        type: ReservationTypes.WORKSPACE,
        selectedResource: resource,
      };

      initialRoomDetailsState = {
        ...getAppStore().getState.roomDetails,
        data: fakeRoom,
        roomId: 1,
        contactRoles: []
      };

      const initialState = {
        ...getAppStore().getState(),
        reservation: initialReservationState,
        roomDetails: initialRoomDetailsState,
        roomSearch: {...getAppStore().getState.roomSearch, isSearchColleagueModalOpen: true}
      };

      renderWithReduxAndDictionaryProvider(
        <RoomSearchPageSmall {...props} />, 
        {
          initialState,
          reducer: reservationReducer
        },
        appMessages
      );
    })

    it("Renders properly", () => {
      const pageTitle = screen.getByText(appMessages.STEP_WORKSPACE_SEARCH_DESCRIPTION);
      expect(pageTitle).toBeInTheDocument();
    })

    it("Should open searchColleague popup when colleague reservation button is clicked", () => {
      const openSearchColleague = screen.getByRole("button", {
        name: appMessages.COLLEAGUE_RESERVATION,
      });
      fireEvent.click(openSearchColleague);
      const searchColleaguePage = screen.getByTestId("searchColleaguePage")
      expect(RoomSearchActions.setSearchColleagueModal).toHaveBeenCalledWith(true);
      expect(searchColleaguePage).toBeInTheDocument();
    })

    it("Should close sarchColleague popup when close button is clicked", () => {
      const openSearchColleague = screen.getByRole("button", {
        name: appMessages.COLLEAGUE_RESERVATION,
      });
      fireEvent.click(openSearchColleague);
      const closeSearchColleague = screen.getByRole("button", {
        name: /search colleague close/,
      });
      jest.useFakeTimers();
      fireEvent.click(closeSearchColleague);
      jest.runAllTimers();
      expect(RoomSearchActions.setSearchColleagueModal).toHaveBeenCalledWith(false);
      jest.useRealTimers();
    })
  })
  describe("RoomSearchPageSmall colleague reservation menu", () => { 
    let props, appMessages, fakeRoom, reservationParam, resource, initialReservationState, initialRoomDetailsState;
    beforeEach(() => {
      fakeRoom = createReservableRoom("Spider-man", "Marvel", 1);
      reservationParam = createReservationParam();
      resource = createResource(fakeRoom);
      appMessages = AppMsg.getAppMessages();
      props = { }
      initialReservationState = {
        ...getAppStore().getState.reservation,
        data: {
          ...reservationParam
        },
        type: ReservationTypes.WORKSPACE,
        selectedResource: resource,
      };

      initialRoomDetailsState = {
        ...getAppStore().getState.roomDetails,
        data: fakeRoom,
        roomId: 1,
        contactRoles: []
      };

      const initialState = {
        ...getAppStore().getState(),
        reservation: initialReservationState,
        roomDetails: initialRoomDetailsState,
        roomSearch: {...getAppStore().getState.roomSearch, isSearchColleagueModalOpen: true},
        colleague: {...getAppStore().getState.colleague, selectedColleague: { name: "shiva", email: "shiva@abc.com"}}
      };

      renderWithReduxAndDictionaryProvider(
        <RoomSearchPageSmall {...props} />, 
        {
          initialState,
          reducer: reservationReducer
        },
        appMessages
      );
    })

    it("Renders menu", () => {
      const menu = screen.getByTestId("simpleMenu");
      expect(menu).toBeInTheDocument();
    })

    it("Selecting reservation list option should navigate to colleague page", () => {
      const option = screen.getByText(appMessages[AppMsg.RESERVATION_MESSAGE.RESERVATION_LIST_MENU_ITEM]);
      fireEvent.click(option);
      expect(RouteActions.navigateBack).toHaveBeenCalled();
    })

    it("Selecting change colleague option should open a modal", () => {
      const option = screen.getByText(appMessages[AppMsg.RESERVATION_MESSAGE.CHANGE_COLLEAGUE_MENU_ITEM]);
      fireEvent.click(option);
      expect(RoomSearchActions.setSearchColleagueModal).toHaveBeenCalledWith(true);
    })
  })
})