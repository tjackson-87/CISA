/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2022 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import {
  Button,
  Tag,
  InlineNotification,
  TooltipIcon,
} from "carbon-components-react";
import debounce from "debounce";
import { RoomSearch, TimezoneStatus } from "../../components";
import isEmpty from "lodash/isEmpty";
import {
  RouteActions,
  LocationActions,
  LayoutSelectors,
  LoadingSelectors,
  RoomSearchActions,
  RoomSearchSelectors,
  CurrentUserSelectors,
  LocationSelectors,
} from "../../store";
import { AppMsg } from "../../utils";
import { Close20 } from "@carbon/icons-react";
import ChangeLocationPageSmall from "../ChangeLocation/ChangeLocationPageSmall";

const cssBase = "RoomSearchByNamePage";

class RoomSearchByNamePage extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    navigateToReservationSearch: PropTypes.func,
    navigateToReservationSummary: PropTypes.func,
    searchRoomByName: PropTypes.func,
    selectedBuilding: PropTypes.object,
    setRoomSearchResult: PropTypes.func,
    setSelectedBuilding: PropTypes.func,
    defaultTimezone: PropTypes.string,
    rooms: PropTypes.array,
    loading: PropTypes.bool,
    loadingMore: PropTypes.bool,
    dir: PropTypes.string,
    setLocationModal: PropTypes.func,
    isLocationModalOpen: PropTypes.bool,
    setSelectedRooms: PropTypes.func,
  };

  state = {
    searchText: "",
    debouncingSearch: false,
  };

  componentDidMount() {
    if (this.changeLocationButtonRef) {
      this.changeLocationButtonRef.current.focus();
    }
  }

  constructor(props) {
    super(props);
    this.changeLocationButtonRef = React.createRef();
  }

  render() {
    const {
      rooms,
      loading,
      loadingMore,
      dir,
      selectedBuilding,
      isLocationModalOpen,
      defaultTimezone,
    } = this.props;

    const { searchText, debouncingSearch } = this.state;

    return (
      <main className={cssBase}>
        <div className={`${cssBase}__stepDescription`}>
          <span>
            {this.props.appMessages[AppMsg.RESERVATION_MESSAGE.SEARCH_BY_NAME]}
          </span>
          <div
            role="button"
            onClick={(e) => this.handleClose()}
            onKeyDown={(e) => (e.key === "Enter" ? this.handleClose() : null)}
            className={`${cssBase}__closeButton`}
          >
            <TooltipIcon
              direction="left"
              align={dir === "ltr" ? "start" : "end"}
              tooltipText={this.props.appMessages[AppMsg.BUTTON.CLOSE]}
              aria-label={this.props.appMessages[AppMsg.BUTTON.CLOSE]}
            >
              <Close20 />
            </TooltipIcon>
          </div>
        </div>
        <div className={`${cssBase}__content`}>
          <div className={`${cssBase}__building`}>
            {!isEmpty(selectedBuilding) && (
              <Tag
                type="cool-gray"
                title={
                  this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE.CLEAR_BUILDING_FILTER
                  ]
                }
                onClick={this.handleRemoveBuilding}
                filter
                className={`${cssBase}__buildingTag`}
              >
                {selectedBuilding.name}
              </Tag>
            )}
            {isEmpty(selectedBuilding) && (
              <span className={`${cssBase}__noLocation`}>
                {
                  this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE.NO_LOCATION_SELECTED
                  ]
                }
              </span>
            )}
            <Button
              className={`${cssBase}__buildingButton`}
              kind="ghost"
              size="small"
              onClick={this.handleAddLocationsClick}
              ref={this.changeLocationButtonRef}
            >
              {
                this.props.appMessages[
                  isEmpty(selectedBuilding)
                    ? AppMsg.RESERVATION_MESSAGE.ADD_LOCATION
                    : AppMsg.RESERVATION_MESSAGE.CHANGE_LOCATION
                ]
              }
            </Button>
          </div>
          {!isEmpty(selectedBuilding) && (
            <TimezoneStatus
              timezone={selectedBuilding.timeZone}
              defaultTimezone={defaultTimezone}
              cssBase={cssBase}
            />
          )}
          {this.renderNoLocationLabel(selectedBuilding)}
          {!isEmpty(selectedBuilding) && (
            <div className={`${cssBase}__search`}>
              <RoomSearch
                searchText={searchText}
                onSearchTextChange={this.handleSearchTextChange}
                onSearchMore={this.handleSearchMore}
                onSelect={this.handleSelectRoom}
                rooms={rooms}
                loading={loading || debouncingSearch}
                loadingMore={loadingMore}
                dir={dir}
              />
            </div>
          )}
          <ChangeLocationPageSmall isOpen={isLocationModalOpen} />
        </div>
      </main>
    );
  }

  handleClose = () => {
    const {
      navigateToReservationSummary,
      setRoomSearchResult,
      setSelectedRooms,
    } = this.props;
    setRoomSearchResult(null);
    setSelectedRooms(null);
    navigateToReservationSummary();
  };

  handleSearchMore = () => {
    const { selectedBuilding, searchRoomByName } = this.props;
    const { searchText } = this.state;
    searchRoomByName(searchText, selectedBuilding._id, true);
  };

  handleSearchTextChange = (searchText) => {
    const { selectedBuilding } = this.props;
    if (selectedBuilding) {
      this.setState({ searchText, debouncingSearch: true });
      this.debouncedSearch(searchText, selectedBuilding._id);
    }
  };

  debouncedSearch = debounce((searchText, buildingId) => {
    this.props.searchRoomByName(searchText, buildingId);
    setTimeout(() => this.setState({ debouncingSearch: false }), 50);
  }, 300);

  handleSelectRoom = (room) => {
    this.props.setRoomSearchResult(room);
    this.props.setSelectedRooms(room);
    this.props.navigateToReservationSearch(false);
  };

  handleRemoveBuilding = () => {
    this.props.setSelectedBuilding(null);
  };

  handleAddLocationsClick = (e) => {
    const { setLocationModal } = this.props;
    e.stopPropagation();
    setLocationModal(true);
  };

  renderNoLocationLabel(selectedBuilding) {
    if (isEmpty(selectedBuilding)) {
      const title = AppMsg.getMessage(
        AppMsg.RESERVATION_MESSAGE.NO_LOCATION_SELECTED
      );
      return (
        <InlineNotification
          className={`${cssBase}__showingNoLocationLabel`}
          kind="info"
          hideCloseButton
          lowContrast
          title={title}
          statusIconDescription={title}
        />
      );
    }
  }
}

const mapStateToProps = (state) => {
  return {
    rooms: RoomSearchSelectors.roomSearchByNameSelector(state),
    loading: LoadingSelectors.searchingBuildingsSelector(state),
    loadingMore: LoadingSelectors.searchingMoreBuildingsSelector(state),
    dir: LayoutSelectors.dirSelector(state),
    selectedBuilding: LocationSelectors.selectedBuildingSelector(state),
    isLocationModalOpen: RoomSearchSelectors.locationModalSelector(state),
    defaultTimezone: CurrentUserSelectors.defaultTimezoneSelector(state),
  };
};

const {
  setLocationModal,
  searchRoomByName,
  setRoomSearchResult,
  setSelectedRooms,
} = RoomSearchActions;

const {
  navigateToReservationSearch,
  navigateToReservationSummary,
} = RouteActions;

const { setSelectedBuilding } = LocationActions;

export default withTriDictionary(
  connect(mapStateToProps, {
    navigateToReservationSearch,
    navigateToReservationSummary,
    setSelectedBuilding,
    searchRoomByName,
    setRoomSearchResult,
    setSelectedRooms,
    setLocationModal,
  })(RoomSearchByNamePage)
);
