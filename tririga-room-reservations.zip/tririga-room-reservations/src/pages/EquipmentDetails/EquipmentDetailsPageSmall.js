/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import { TriImage, withTriDictionary } from "@tririga/tririga-react-components";
import { ComposedModal, ModalHeader } from "carbon-components-react";
import {
  RouteActions,
  EquipmentDetailsSelectors,
  LayoutSelectors,
  EquipmentActions,
} from "../../store";
import { AppMsg } from "../../utils";

const cssBase = "equipmentDetailsPageSmall";

class EquipmentDetailsPageSmall extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    equipment: PropTypes.object,
    setEquipmentDetailModal: PropTypes.func,
    isEquipmentModalOpen: PropTypes.bool,
    onClosePopUp: PropTypes.func,
  };

  render() {
    const {
      equipment,
      setEquipmentDetailModal,
      isEquipmentModalOpen,
      onClosePopUp,
    } = this.props;
    if (equipment == null) {
      return null;
    }

    return (
      <ComposedModal
        open={isEquipmentModalOpen}
        size="md"
        onClose={() =>
          onClosePopUp ? onClosePopUp() : setEquipmentDetailModal(false)
        }
        selectorPrimaryFocus=".bx--modal-close"
        aria-label={this.props.appMessages[AppMsg.BUTTON.CLOSE]}
      >
        <ModalHeader
          title={equipment.name}
          iconDescription={this.props.appMessages[AppMsg.BUTTON.CLOSE]}
        />
        <div className={cssBase}>
          <div className={`${cssBase}__content`}>
            {equipment.image && (
              <TriImage
                value={equipment.image}
                className={`${cssBase}__image`}
              />
            )}
            <div className={`${cssBase}__equipmentDetails-label`}>
              {
                this.props.appMessages[
                  AppMsg.RESERVATION_MESSAGE.STEP_MEETING_EQUIPMENT_DETAILS
                ]
              }
            </div>
            <div className={`${cssBase}__equipmentDetails`}>
              {equipment.description}
            </div>
          </div>
        </div>
      </ComposedModal>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    equipment: EquipmentDetailsSelectors.equipmentDetailsSelector(state),
    dir: LayoutSelectors.dirSelector(state),
    isEquipmentModalOpen: EquipmentDetailsSelectors.equipmentDetailsModalSelector(
      state
    ),
  };
};

export default withTriDictionary(
  connect(mapStateToProps, {
    navigateBackFromEquipmentDetails:
      RouteActions.navigateBackFromEquipmentDetails,
    setEquipmentDetailModal: EquipmentActions.setEquipmentDetailModal,
  })(EquipmentDetailsPageSmall)
);
