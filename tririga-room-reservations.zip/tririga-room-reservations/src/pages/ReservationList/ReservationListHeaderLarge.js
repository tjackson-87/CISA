/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2022 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import classNames from "classnames";
import { Button, TooltipIcon } from "carbon-components-react";
import { Add16, Renew16 } from "@carbon/icons-react";
import { AppMsg, getCurrentDateTime, EventEmitter } from "../../utils";
import moment from "moment";
import { DateInput, UserCard } from "../../components";
import { isEqual } from "lodash";

const cssBase = "reservationListHeaderLarge";

class ReservationListHeaderLarge extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    className: PropTypes.string,
    smallLayout: PropTypes.bool,
    createNewMeeting: PropTypes.func.isRequired,
    createNewWorkspace: PropTypes.func.isRequired,
    createNewOffice: PropTypes.func.isRequired, // CISA
    date: PropTypes.instanceOf(Date),
    timezone: PropTypes.string,
    carbonDateFormat: PropTypes.string,
    carbonLocale: PropTypes.string,
    onDateChange: PropTypes.func,
    onRefresh: PropTypes.func,
    dir: PropTypes.string,
    currentCalendar: PropTypes.object,
    onChangeUserClicked: PropTypes.func,
    showChangeUser: PropTypes.bool,
    changeDelegateRef: PropTypes.any,
  };

  constructor(props) {
    super(props);
    this.createMeetingRef = React.createRef();
    EventEmitter.subscribe("agendaCreateMeetingFocus", (event) =>
      this.focusCreateBtn(event)
    );
  }

  componentDidMount() {
    setTimeout(() => {
      this.createMeetingRef.focus();
    }, 1);
  }

  focusCreateBtn(event) {
    setTimeout(() => {
      if (this.createMeetingRef) this.createMeetingRef.focus();
    }, 1);
  }

  componentWillUnmount() {
    EventEmitter.unsubscribe("agendaCreateMeetingFocus");
  }

  render() {
    const {
      className,
      createNewMeeting,
      createNewWorkspace,
      createNewOffice, // CISA
      smallLayout,
      date,
      carbonLocale,
      carbonDateFormat,
      dir,
      currentCalendar,
      onChangeUserClicked,
      showChangeUser,
      changeDelegateRef,
    } = this.props;
    return (
      <div
        className={classNames(
          cssBase,
          { [`${cssBase}--large`]: smallLayout },
          className
        )}
      >
        {/* CISA-516 add aria heading for 508 */}
        <div role="heading" aria-level="1" className={`${cssBase}__title`}>
          <span>
            {this.props.appMessages[AppMsg.RESERVATION_LIST_PAGE_TITLE]}
          </span>
          <div className={`${cssBase}__buttonContainer`}>
            <div
              onClick={this.handleRefreshClicked}
              onKeyDown={(e) =>
                e.key === "Enter" ? this.handleRefreshClicked : null
              }
              className={`${cssBase}__refreshButton`}
            >
              <TooltipIcon
                direction="left"
                align={dir === "ltr" ? "start" : "end"}
                tooltipText={this.props.appMessages[AppMsg.BUTTON.REFRESH]}
                aria-label={this.props.appMessages[AppMsg.BUTTON.REFRESH]}
              >
                <Renew16 />
              </TooltipIcon>
            </div>
            <Button
              kind="secondary"
              size="field"
              renderIcon={Add16}
              onClick={createNewWorkspace}
              className={`${cssBase}__createWorkspaceButton`}
              aria-label={AppMsg.getMessage(AppMsg.CREATE_NEW_WORKSPACE)}
            >
              {smallLayout
                ? AppMsg.getMessage(AppMsg.WORKSPACE)
                : AppMsg.getMessage(AppMsg.CREATE_NEW_WORKSPACE)}
            </Button>
            <Button
              kind="primary"
              size="field"
              ref={(ref) => {
                this.createMeetingRef = ref;
              }}
              renderIcon={Add16}
              onClick={createNewMeeting}
              className={`${cssBase}__createMeetingButton`}
              aria-label={AppMsg.getMessage(AppMsg.CREATE_NEW_MEETING)}
              onFocus={this.handleMeetingAndTodayButtonsOnFocus}
            >
              {smallLayout
                ? AppMsg.getMessage(AppMsg.MEETING)
                : AppMsg.getMessage(AppMsg.CREATE_NEW_MEETING)}
            </Button>
            <Button
              kind="tertiary"
              size="field"
              renderIcon={Add16}
              onClick={createNewOffice}
              className={`${cssBase}__createOfficeButton`}
            >
              {smallLayout
                ? AppMsg.getMessage(AppMsg.OFFICE)
                : AppMsg.getMessage(AppMsg.CREATE_NEW_OFFICE)}
            </Button>
          </div>
        </div>

        <div className={`${cssBase}__userCard`}>
          <UserCard
            calendar={currentCalendar}
            onChangeUserClicked={onChangeUserClicked}
            showChangeUser={showChangeUser}
            changeDelegateRef={changeDelegateRef}
          />
        </div>

        <div className={`${cssBase}__controls`}>
          <DateInput
            id="startDateInput"
            carbonDateFormat={carbonDateFormat}
            carbonLocale={carbonLocale}
            onValueChange={this.props.onDateChange}
            value={date}
            label=""
            light
          />
          <Button
            kind="ghost"
            size="field"
            onClick={this.handleTodayClicked}
            onFocus={this.handleMeetingAndTodayButtonsOnFocus}
            onKeyUp={(e) =>
              e.key === "Enter"
                ? setTimeout(() => this.handleTodayClicked(), 1)
                : null
            }
          >
            {this.props.appMessages[AppMsg.RESERVATION_MESSAGE.TODAY]}
          </Button>
        </div>
      </div>
    );
  }

  handleRefreshClicked = () => {
    this.props.onRefresh();
  };

  handleTodayClicked = () => {
    const { date, timezone } = this.props;
    const today = moment(getCurrentDateTime(timezone)).toDate();
    if (!isEqual(today, date)) {
      this.props.onDateChange(today);
    }
  };

  handleMeetingAndTodayButtonsOnFocus = () => {
    if (document.getElementsByClassName("flatpickr-calendar") !== null) {
      const ele = document.getElementsByClassName("flatpickr-calendar");
      ele.forEach((e) => {
        e.classList.remove("open");
        e.classList.remove("close");
      });
    }
  };
}

export default withTriDictionary(ReservationListHeaderLarge);
