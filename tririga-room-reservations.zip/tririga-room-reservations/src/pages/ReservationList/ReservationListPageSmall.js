/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import ReservationListHeader from "./ReservationListHeader";
import { ReservationList } from "../../components";
import {
  CheckInActions,
  CurrentUserSelectors,
  LoadingSelectors,
  MyCalendarActions,
  MyCalendarSelectors,
  ReservationActions,
  RouteActions,
  LayoutSelectors,
  ApplicationSettingsSelectors,
  ExchangeSelectors,
  ExchangeActions,
} from "../../store";
import { ReservationTypes, LayoutTypesConstants, AppMsg } from "../../utils";
import ReservationListHeaderLarge from "./ReservationListHeaderLarge";
import DelegateList from "./DelegateList";
import MediaQuery from "react-responsive";

const cssBase = "reservationListPageSmall";

class ReservationListPageSmall extends React.PureComponent {
  static propTypes = {
    initializeNewReservation: PropTypes.func.isRequired,
    loadingEvents: PropTypes.bool,
    loadingMoreEventsBefore: PropTypes.bool,
    loadingMoreEventsAfter: PropTypes.bool,
    calendarEvents: PropTypes.array,
    timezone: PropTypes.string,
    carbonLocale: PropTypes.string,
    carbonDateFormat: PropTypes.string,
    locale: PropTypes.string,
    getMoreCalendarEvents: PropTypes.func,
    navigateToEventDetails: PropTypes.func,
    setMyCalendarDate: PropTypes.func,
    date: PropTypes.instanceOf(Date),
    refreshMyCalendar: PropTypes.func,
    releaseRoom: PropTypes.func,
    checkIn: PropTypes.func,
    releaseRoomEarly: PropTypes.func,
    recheckRoom: PropTypes.func,
    editReservation: PropTypes.func,
    dir: PropTypes.string,
    isExchangeIntegrated: PropTypes.bool,
    updateRoomsCanceled: PropTypes.func,
    delegateCalendars: PropTypes.array,
    currentCalendar: PropTypes.object,
    setCurrentCalendar: PropTypes.func,
    appMessages: PropTypes.object,
    userEmail: PropTypes.string,
  };

  state = {
    preventTriggerScroll: false,
    isDelegateModalOpen: false,
  };

  constructor(props) {
    super(props);
    this.changeDelegateRef = React.createRef();
  }

  componentDidMount(){
    // CISA-520 set page title based on selected page
    document.title = this.props.appMessages[AppMsg.ORG_NAME] + ' ' + this.props.appMessages[AppMsg.RESERVATION_LIST_PAGE_TITLE]

  }

  render() {
    const {
      calendarEvents,
      refreshMyCalendar,
      timezone,
      carbonLocale,
      locale,
      getMoreCalendarEvents,
      loadingEvents,
      loadingMoreEventsBefore,
      loadingMoreEventsAfter,
      navigateToEventDetails,
      date,
      releaseRoom,
      checkIn,
      releaseRoomEarly,
      recheckRoom,
      editReservation,
      carbonDateFormat,
      dir,
      isExchangeIntegrated,
      updateRoomsCanceled,
      delegateCalendars,
      currentCalendar,
      userEmail,
    } = this.props;
    const { isDelegateModalOpen } = this.state;
    const showChangeUser = delegateCalendars
      ? delegateCalendars.length !== 1
      : false;
    return (
      <main className={cssBase}>
        <MediaQuery minWidth={LayoutTypesConstants.MIN_LARGE_SCREEN_WIDTH}>
          <ReservationListHeaderLarge
            smallLayout
            onRefresh={() => {
              this.setState({ preventTriggerScroll: true });
              refreshMyCalendar();
            }}
            createNewMeeting={this.onCreateNewMeeting}
            createNewWorkspace={this.onCreateNewWorkspace}
            createNewOffice={this.onCreateNewOffice} // CISA
            timezone={timezone}
            carbonLocale={carbonLocale}
            carbonDateFormat={carbonDateFormat}
            date={date}
            onDateChange={(date) => {
              this.setState({ preventTriggerScroll: true });
              this.props.setMyCalendarDate(date);
            }}
            currentCalendar={currentCalendar}
            onChangeUserClicked={this.handleChangeUserClicked}
            showChangeUser={showChangeUser}
            dir={dir}
            changeDelegateRef={this.changeDelegateRef}
          />
        </MediaQuery>
        <MediaQuery maxWidth={LayoutTypesConstants.MAX_SMALL_SCREEN_WIDTH}>
          <ReservationListHeader
            smallLayout
            onRefresh={() => {
              this.setState({ preventTriggerScroll: true });
              refreshMyCalendar();
            }}
            createNewMeeting={this.onCreateNewMeeting}
            createNewWorkspace={this.onCreateNewWorkspace}
            createNewOffice={this.onCreateNewOffice} // CISA
            timezone={timezone}
            carbonLocale={carbonLocale}
            carbonDateFormat={carbonDateFormat}
            date={date}
            onDateChange={(date) => {
              this.setState({ preventTriggerScroll: true });
              this.props.setMyCalendarDate(date);
            }}
            currentCalendar={currentCalendar}
            onChangeUserClicked={this.handleChangeUserClicked}
            showChangeUser={showChangeUser}
            dir={dir}
          />
        </MediaQuery>
        <ReservationList
          className={`${cssBase}__list`}
          calendarEvents={calendarEvents}
          date={date}
          timezone={timezone}
          locale={locale}
          loadMore={getMoreCalendarEvents}
          loadingEvents={loadingEvents}
          loadingMoreEventsBefore={loadingMoreEventsBefore}
          loadingMoreEventsAfter={loadingMoreEventsAfter}
          onOpenEvent={navigateToEventDetails}
          onDateChange={(date) => this.props.setMyCalendarDate(date, false)}
          releaseRoom={releaseRoom}
          checkIn={checkIn}
          releaseRoomEarly={releaseRoomEarly}
          recheckRoom={recheckRoom}
          editReservation={editReservation}
          preventTriggerScroll={this.state.preventTriggerScroll}
          onResetPreventTriggerScroll={() =>
            this.setState({ preventTriggerScroll: false })
          }
          isExchangeIntegrated={isExchangeIntegrated}
          updateRoomsCanceled={updateRoomsCanceled}
        />
        {currentCalendar && isDelegateModalOpen && (
          <DelegateList
            isDelegateModalOpen={isDelegateModalOpen}
            calendars={delegateCalendars}
            currentCalendar={currentCalendar}
            userEmail={userEmail}
            headingMessage={this.props.appMessages[AppMsg.CHANGE_USER]}
            onClose={() => {
              this.setState({ isDelegateModalOpen: false });
              setTimeout(() => {
                this.changeDelegateRef.current.focus();
              }, 1);
            }}
            onSelect={this.handleSelectedCalendar}
          />
        )}
      </main>
    );
  }

  onCreateNewMeeting = async () => {
    const { initializeNewReservation, date } = this.props;
    await initializeNewReservation(
      ReservationTypes.MEETING,
      true,
      false,
      date,
      null,
      true
    );
  };

  onCreateNewWorkspace = async () => {
    const { initializeNewReservation, date } = this.props;
    await initializeNewReservation(
      ReservationTypes.WORKSPACE,
      true,
      false,
      date,
      null,
      true
    );
  };
  // CISA
  onCreateNewOffice = async () => {
    const { initializeNewReservation, date } = this.props;
    await initializeNewReservation(
      ReservationTypes.OFFICE,
      true,
      false,
      date,
      null,
      true
    );
  };

  handleChangeUserClicked = () => {
    this.setState({ isDelegateModalOpen: true });
  };

  handleSelectedCalendar = (selectedCalendar) => {
    const { setCurrentCalendar } = this.props;
    this.setState({ preventTriggerScroll: true });
    setCurrentCalendar(selectedCalendar);
    this.setState({ isDelegateModalOpen: false });
  };
}

const mapStateToProps = (state) => {
  return {
    calendarEvents: MyCalendarSelectors.calendarEventsSelector(state),
    timezone: MyCalendarSelectors.timezoneSelector(state),
    carbonLocale: CurrentUserSelectors.carbonLocaleSelector(state),
    carbonDateFormat: CurrentUserSelectors.carbonDateFormatSelector(state),
    locale: CurrentUserSelectors.localeSelector(state),
    loadingEvents: LoadingSelectors.loadingEventsSelector(state),
    loadingMoreEventsBefore: LoadingSelectors.loadingMoreEventsBeforeSelector(
      state
    ),
    loadingMoreEventsAfter: LoadingSelectors.loadingMoreEventsAfterSelector(
      state
    ),
    date: MyCalendarSelectors.dateSelector(state),
    dir: LayoutSelectors.dirSelector(state),
    isExchangeIntegrated: ApplicationSettingsSelectors.isExchangeIntegratedSelector(
      state
    ),
    delegateCalendars: ExchangeSelectors.delegateCalendarsSelector(state),
    currentCalendar: ExchangeSelectors.currentCalendarSelector(state),
    userEmail: CurrentUserSelectors.currentUserEmailSelector(state),
  };
};

const { initializeNewReservation } = ReservationActions;
const {
  getMoreCalendarEvents,
  setMyCalendarDate,
  refreshMyCalendar,
} = MyCalendarActions;
const {
  releaseRoom,
  checkIn,
  releaseRoomEarly,
  recheckRoom,
  updateRoomsCanceled,
} = CheckInActions;
const { navigateToEventDetails, navigateToEditReservation } = RouteActions;
const { setCurrentCalendar } = ExchangeActions;

export default connect(mapStateToProps, {
  initializeNewReservation,
  refreshMyCalendar,
  setMyCalendarDate,
  getMoreCalendarEvents,
  navigateToEventDetails,
  releaseRoom,
  checkIn,
  releaseRoomEarly,
  recheckRoom,
  updateRoomsCanceled,
  editReservation: navigateToEditReservation,
  setCurrentCalendar,
})(withTriDictionary(ReservationListPageSmall));
