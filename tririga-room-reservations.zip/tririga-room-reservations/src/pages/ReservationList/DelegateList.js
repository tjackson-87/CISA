/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import {
  Modal,
  RadioButtonGroup,
  RadioButton,
  ToastNotification,
} from "carbon-components-react";
import { ReserveNotification } from "../../components";

import { AppMsg } from "../../utils";
const cssBase = "delegateList";

class DelegateList extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    isDelegateModalOpen: PropTypes.bool,
    onClose: PropTypes.func,
    onSelect: PropTypes.func,
    calendars: PropTypes.array,
    currentCalendar: PropTypes.object,
    headingMessage: PropTypes.string,
    userEmail: PropTypes.string,
    showEmailDiffNotice: PropTypes.bool,
  };

  state = {
    selectedCalendarMail: "",
  };

  handleChangeSelectedCalendar = () => {
    const { selectedCalendarMail } = this.state;
    const { onSelect, calendars, currentCalendar } = this.props;
    const selectedCalendar = !selectedCalendarMail
      ? currentCalendar
      : calendars.find((calendar) => calendar.email === selectedCalendarMail);

    onSelect(selectedCalendar);
  };

  render() {
    const {
      isDelegateModalOpen,
      onClose,
      calendars,
      currentCalendar,
      headingMessage,
      userEmail,
      showEmailDiffNotice,
    } = this.props;
    const { selectedCalendarMail } = this.state;
    const emailDiff = selectedCalendarMail
      ? selectedCalendarMail !== userEmail
      : currentCalendar && currentCalendar.email !== userEmail;
    const showCalendarNotAvailableMsg =
      calendars && calendars.some((calendar) => !calendar.isValidInTririga);
    return (
      <Modal
        open={isDelegateModalOpen}
        size="sm"
        onRequestClose={() => onClose(false)}
        modalHeading={headingMessage}
        primaryButtonText={this.props.appMessages[AppMsg.BUTTON.DONE]}
        secondaryButtonText={this.props.appMessages[AppMsg.BUTTON.CANCEL]}
        onRequestSubmit={this.handleChangeSelectedCalendar}
        onSecondarySubmit={() => onClose(false)}
        iconDescription={this.props.appMessages[AppMsg.BUTTON.CLOSE]}
        selectorPrimaryFocus=".bx--modal-close"
      >
        <div className={cssBase}>
          {showCalendarNotAvailableMsg && (
            <ToastNotification
              className={`${cssBase}__calendarNotAvailableNotification`}
              lowContrast
              kind="info"
              title={
                this.props.appMessages[
                  AppMsg.RESERVATION_MESSAGE.TITLE_CALENDAR_NOT_AVAILABLE
                ]
              }
              statusIconDescription={
                this.props.appMessages[
                  AppMsg.RESERVATION_MESSAGE.TITLE_CALENDAR_NOT_AVAILABLE
                ]
              }
              subtitle={
                <span>
                  {
                    this.props.appMessages[
                      AppMsg.RESERVATION_MESSAGE
                        .DESCRIPTION_CALENDAR_NOT_AVAILABLE
                    ]
                  }
                </span>
              }
              iconDescription={this.props.appMessages[AppMsg.BUTTON.CLOSE]}
              onClose={() =>
                setTimeout(
                  () => document.querySelector(".bx--radio-button").focus(),
                  1
                )
              }
              aria-label={AppMsg.getMessage(AppMsg.CALENDAR_UNAVAILABLE_NOTE)}
            />
          )}
          <div>
            <RadioButtonGroup
              orientation="vertical"
              name="recurrence-daily-options-group"
              valueSelected={currentCalendar && currentCalendar.email}
              onChange={(value) =>
                this.setState({ selectedCalendarMail: value })
              }
              legendText={AppMsg.getMessage(AppMsg.USER_CALENDAR_LEGEND)}
            >
              {calendars &&
                calendars.map((calendar) => {
                  return (
                    <RadioButton
                      id={calendar.id}
                      key={calendar.id}
                      labelText={`${calendar.name} (${calendar.email})`}
                      value={calendar.email}
                      disabled={!calendar.isValidInTririga}
                    />
                  );
                })}
            </RadioButtonGroup>
            {showEmailDiffNotice && emailDiff && (
              <ReserveNotification
                message={
                  this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE.CHANGE_MEETING_OWNER_MESSAGE
                  ]
                }
                className={`${cssBase}__meetingOwner`}
              />
            )}
          </div>
        </div>
      </Modal>
    );
  }
}

export default withTriDictionary(DelegateList);
