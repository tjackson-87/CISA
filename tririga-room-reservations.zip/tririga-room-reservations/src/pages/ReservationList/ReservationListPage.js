/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import PropTypes from "prop-types";
import ReservationListPageSmall from "./ReservationListPageSmall";

export default class ReservationListPage extends React.PureComponent {
  static propTypes = {
    smallLayout: PropTypes.bool,
  };

  render() {
    return <ReservationListPageSmall {...this.props} />;
  }
}
