/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import ReservationListHeader from "./ReservationListHeader";
import { ReservationList } from "../../components";

const cssBase = "reservationListPageLarge";

export default class ReservationListPageLarge extends React.PureComponent {
  render() {
    return (
      <div className={cssBase}>
        <ReservationListHeader {...this.props} />
        <div className={`${cssBase}__content`}>
          <ReservationList className={`${cssBase}__list`} />
          <div className={`${cssBase}__reservationDetail`} />
        </div>
      </div>
    );
  }
}
