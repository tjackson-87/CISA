/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2022 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import classNames from "classnames";
import { Button, TooltipIcon } from "carbon-components-react";
import { Add16, Renew16 } from "@carbon/icons-react";
import { AppMsg, getCurrentDateTime } from "../../utils";
import moment from "moment";
import { DateInput, UserCard } from "../../components";
import { isEqual } from "lodash";

const cssBase = "reservationListHeader";

class ReservationListHeader extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    className: PropTypes.string,
    smallLayout: PropTypes.bool,
    createNewMeeting: PropTypes.func.isRequired,
    createNewWorkspace: PropTypes.func.isRequired,
    createNewOffice: PropTypes.func.isRequired, // CISA
    date: PropTypes.instanceOf(Date),
    timezone: PropTypes.string,
    carbonDateFormat: PropTypes.string,
    carbonLocale: PropTypes.string,
    onDateChange: PropTypes.func,
    onRefresh: PropTypes.func,
    dir: PropTypes.string,
    currentCalendar: PropTypes.object,
    onChangeUserClicked: PropTypes.func,
    showChangeUser: PropTypes.bool,
  };

  render() {
    const {
      className,
      createNewMeeting,
      createNewWorkspace,
      createNewOffice, // CISA
      smallLayout,
      date,
      carbonLocale,
      carbonDateFormat,
      dir,
      currentCalendar,
      onChangeUserClicked,
      showChangeUser,
    } = this.props;
    return (
      <div
        className={classNames(
          cssBase,
          { [`${cssBase}--small`]: smallLayout },
          className
        )}
      >
         {/* CISA-516 add aria heading for 508 */}
        <div role="heading" aria-level="1" className={`${cssBase}__title`}> 
          <span>
            {this.props.appMessages[AppMsg.RESERVATION_LIST_PAGE_TITLE]}
          </span>
          <div
            onClick={this.handleRefreshClicked}
            onKeyDown={(e) =>
              e.key === "Enter" ? this.handleRefreshClicked : null
            }
            className={`${cssBase}__refreshButton`}
          >
            <TooltipIcon
              direction="left"
              align={dir === "ltr" ? "start" : "end"}
              tooltipText={this.props.appMessages[AppMsg.BUTTON.REFRESH]}
              aria-label={this.props.appMessages[AppMsg.BUTTON.REFRESH]}
            >
              <Renew16 />
            </TooltipIcon>
          </div>
        </div>
        <div className={`${cssBase}__userCard`}>
          <UserCard
            calendar={currentCalendar}
            onChangeUserClicked={onChangeUserClicked}
            showChangeUser={showChangeUser}
          />
        </div>
        <div className={`${cssBase}__buttons`}>
          <Button
            kind="secondary"
            size="field"
            renderIcon={Add16}
            onClick={createNewWorkspace}
            className={`${cssBase}__createWorkspaceButton`}
            aria-label={AppMsg.getMessage(AppMsg.CREATE_NEW_WORKSPACE)}
          >
            {smallLayout
              ? AppMsg.getMessage(AppMsg.WORKSPACE)
              : AppMsg.getMessage(AppMsg.CREATE_NEW_WORKSPACE)}
          </Button>
          <Button
            kind="primary"
            size="field"
            renderIcon={Add16}
            onClick={createNewMeeting}
            aria-label={AppMsg.getMessage(AppMsg.CREATE_NEW_MEETING)}
          >
            {smallLayout
              ? AppMsg.getMessage(AppMsg.MEETING)
              : AppMsg.getMessage(AppMsg.CREATE_NEW_MEETING)}
          </Button>
          <Button
              kind="tertiary"
              size="field"
              renderIcon={Add16}
              onClick={createNewOffice}
              className={`${cssBase}__createOfficeButton`}
            >
              {smallLayout
                ? AppMsg.getMessage(AppMsg.OFFICE)
                : AppMsg.getMessage(AppMsg.CREATE_NEW_OFFICE)}
            </Button>
        </div>
        <div className={`${cssBase}__controls`}>
          <DateInput
            id="startDateInput"
            carbonDateFormat={carbonDateFormat}
            carbonLocale={carbonLocale}
            onValueChange={this.props.onDateChange}
            value={date}
            label=""
            light
          />
          <Button kind="ghost" size="field" onClick={this.handleTodayClicked}>
            {this.props.appMessages[AppMsg.RESERVATION_MESSAGE.TODAY]}
          </Button>
        </div>
      </div>
    );
  }

  handleRefreshClicked = () => {
    this.props.onRefresh();
  };

  handleTodayClicked = () => {
    const { date, timezone } = this.props;
    const today = moment(getCurrentDateTime(timezone)).toDate();
    if (!isEqual(today, date)) {
      this.props.onDateChange(today);
    }
  };
}

export default withTriDictionary(ReservationListHeader);
