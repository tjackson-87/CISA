/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import isEmpty from "lodash/isEmpty";
import classNames from "classnames";
import moment from "moment-timezone";
import {
  Button,
  ComposedModal,
  ModalHeader,
  ModalBody,
  ModalFooter,
} from "carbon-components-react";
import {
  RoomDetailsSelectors,
  CurrentUserSelectors,
  ReservationSelectors,
  LayoutSelectors,
  RoomSearchSelectors,
  RoomSearchActions,
} from "../../store";
import { AppMsg, RoomsUtils } from "../../utils";
import { RoomUnavailableInlineNotification } from "../../components";

const cssBase = "roomRecurrenceDetailsPageSmall";

class RoomRecurrenceDetailsPageSmall extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    room: PropTypes.object,
    recurrence: PropTypes.object,
    timezone: PropTypes.string,
    locale: PropTypes.string,
    formattedDate: PropTypes.string,
    setRoomRecurrenceDetailsModal: PropTypes.func,
    isRoomRecurrenceModalOpen: PropTypes.bool,
    onClosePopUp: PropTypes.func,
  };

  render() {
    const {
      room,
      recurrence,
      formattedDate,
      setRoomRecurrenceDetailsModal,
      isRoomRecurrenceModalOpen,
      onClosePopUp,
    } = this.props;
    if (room == null) return null;
    const unavailableDates = this.getUnavailableDates();
    return (
      <ComposedModal
        open={isRoomRecurrenceModalOpen}
        size="sm"
        onClose={() =>
          onClosePopUp ? onClosePopUp() : setRoomRecurrenceDetailsModal(false)
        }
        aria-label={
          this.props.appMessages[AppMsg.BUTTON.ROOM_OCCURRENCES_DETAIL]
        }
        selectorPrimaryFocus=".bx--modal-close"
      >
        <ModalHeader
          title={room.name}
          iconDescription={this.props.appMessages[AppMsg.BUTTON.CLOSE]}
        />
        <div className={`${cssBase}__content`}>
          <div className={`${cssBase}__date`}>{formattedDate}</div>
          <div className={`${cssBase}__recurrenceLabel`}>
            {recurrence.details.ruleLabel}
          </div>
          <div className={`${cssBase}__occurrencesLabel`}>
            {RoomsUtils.computeOccurrencesLabel(
              room._availCount,
              room._maxOccurrenceCount
            )}
          </div>
          {!isEmpty(unavailableDates) && (
            <>
              <div className={`${cssBase}__unavailableDatesLabel`}>
                {this.props.appMessages[AppMsg.RESERVATION_MESSAGE.UNAVAILABLE]}
                :
              </div>
              <div className={`${cssBase}__unavailableDates`}>
                {unavailableDates}
              </div>
            </>
          )}
          <div className={`${cssBase}__message`}>
            {!room.isAvailable
              ? AppMsg.getMessage(AppMsg.RESERVATION_MESSAGE.ROOM_UNAVAILABLE)
              : !isEmpty(unavailableDates)
              ? AppMsg.getMessage(
                  AppMsg.RESERVATION_MESSAGE.ROOM_HAS_UNAVAILABLE_DATES
                )
              : ""}
          </div>
        </div>
        <ModalBody
          className={classNames(cssBase, {
            [`${cssBase}--unavailable`]: !room.isAvailable,
          })}
        >
          {!room.isAvailable && <RoomUnavailableInlineNotification />}
        </ModalBody>
        <ModalFooter>
          <Button
            kind="primary"
            size="small"
            onClick={() =>
              onClosePopUp
                ? onClosePopUp()
                : setRoomRecurrenceDetailsModal(false)
            }
          >
            {this.props.appMessages[AppMsg.BUTTON.CLOSE]}
          </Button>
        </ModalFooter>
      </ComposedModal>
    );
  }

  getUnavailableDates() {
    const { room, timezone, locale } = this.props;
    return room._occurrenceList
      ?.filter((occurrence) => !occurrence.isAvailable)
      .map((occurrence) =>
        moment(occurrence.start).tz(timezone).locale(locale).format("MMMM DD")
      )
      .join(", ");
  }
}

const mapStateToProps = (state) => {
  return {
    room: RoomDetailsSelectors.roomDetailsSelector(state),
    recurrence: ReservationSelectors.recurrenceSelector(state),
    locale: CurrentUserSelectors.localeSelector(state),
    timezone: ReservationSelectors.timezoneSelector(state),
    formattedDate: ReservationSelectors.formattedStartEndDatesSelector(state),
    dir: LayoutSelectors.dirSelector(state),
    isRoomRecurrenceModalOpen: RoomSearchSelectors.recurrenceRoomModalSelector(
      state
    ),
  };
};

const { setRoomRecurrenceDetailsModal } = RoomSearchActions;

export default withTriDictionary(
  connect(mapStateToProps, {
    setRoomRecurrenceDetailsModal,
  })(RoomRecurrenceDetailsPageSmall)
);
