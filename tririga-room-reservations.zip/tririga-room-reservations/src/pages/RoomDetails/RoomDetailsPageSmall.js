/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { connect } from "react-redux";
import classnames from "classnames";
import PropTypes from "prop-types";
import isEmpty from "lodash/isEmpty";
import { Subject, from } from "rxjs";
import { switchMap } from "rxjs/operators";
import memo from "memoize-one";
import defaultTo from "lodash/defaultTo";
import {
  TriImage,
  TriFloorPlan,
  TriHighlightPlugin,
  TriLabelsPlugin,
  TriPanPlugin,
  TriZoomPlugin,
  withTriDictionary,
} from "@tririga/tririga-react-components";
import { Button, ComposedModal, ModalHeader } from "carbon-components-react";
import {
  Bee32,
  ErrorOutline16,
  FitToScreen20,
  InformationFilled16,
  ShrinkScreen20,
} from "@carbon/icons-react";
import {
  RouteActions,
  RoomDetailsSelectors,
  LabelStylesSelectors,
  ReservationSelectors,
  LayoutSelectors,
  RoomSearchActions,
  RoomSearchSelectors,
  EventDetailsSelectors,
} from "../../store";
import { RoomAmenities, FooterButtons } from "../../components";
import {
  AppMsg,
  ReservationTypes,
  RoomsUtils,
  ReservableSpacesConstants,
  Routes,
} from "../../utils";

const cssBase = "roomDetailsSmallPage";

const {
  RESERVATION_CLASS_PRIVATE,
  RESERVATION_CLASS_REQUESTABLE,
} = ReservableSpacesConstants;
const { EVENT_DETAILS } = Routes;

class RoomDetailsSmallPage extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    room: PropTypes.object,
    labelStyles: PropTypes.array,
    reservationType: PropTypes.string,
    isPrivateRoom: PropTypes.bool,
    dir: PropTypes.string,
    setRoomDetailsModal: PropTypes.func,
    onClosePopUp: PropTypes.func,
    isRoomModalOpen: PropTypes.bool,
    event: PropTypes.object,
    path: PropTypes.string,
    onCloseWorkspaceDetailsModal: PropTypes.func,
    onDelete: PropTypes.func,
    isRoomSearchButton: PropTypes.bool,
  };

  state = {
    floorPlanId: null,
    isFloorPlanExpanded: false,
    loading: true,
  };

  constructor(props) {
    super(props);

    this.room$ = new Subject();
    this.floorPlanId$ = this.room$.pipe(
      switchMap((room) =>
        from(
          RoomsUtils.getFloorplanId(
            room !== null ? room.floorSystemRecordID : 0
          )
        )
      )
    );
    this.floorPlanIdSubscription = this.floorPlanId$.subscribe(
      (floorPlanId) => {
        this.setState({ floorPlanId, loading: false });
      }
    );
  }

  componentDidMount() {
    const { room } = this.props;
    if (room?._id != null) {
      this.room$.next(room);
    }
  }

  componentDidUpdate(prevProps, prevState) {
    const { room } = this.props;

    if (room?._id !== prevProps.room?._id) {
      this.room$.next(room);
    }
    const { isFloorPlanExpanded } = this.state;
    if (
      !isFloorPlanExpanded &&
      isFloorPlanExpanded !== prevState.isFloorPlanExpanded
    ) {
      this.floorPlanContainer.scrollIntoView(true);
    }
  }

  componentWillUnmount() {
    this.floorPlanIdSubscription.unsubscribe();
    this.room$ = null;
    this.floorPlanId$ = null;
    this.floorPlanIdSubscription = null;
  }

  render() {
    const {
      room,
      labelStyles,
      reservationType,
      isPrivateRoom,
      dir,
      setRoomDetailsModal,
      isRoomModalOpen,
      onClosePopUp,
      event,
      path,
      onCloseWorkspaceDetailsModal,
      onDelete,
      isRoomSearchButton,
    } = this.props;
    const { floorPlanId, isFloorPlanExpanded, loading } = this.state;
    const reserveType = path.includes(`${EVENT_DETAILS}`)
      ? event.locationType
      : reservationType;
    if (room == null) {
      return null;
    }

    return (
      <ComposedModal
        open={isRoomModalOpen}
        size="md"
        onClose={() =>
          onClosePopUp
            ? onClosePopUp()
            : onCloseWorkspaceDetailsModal
            ? onCloseWorkspaceDetailsModal()
            : setRoomDetailsModal(false)
        }
        aria-label={this.props.appMessages[AppMsg.BUTTON.OPEN_ROOM_DETAILS]}
        selectorPrimaryFocus=".bx--modal-close"
      >
        <ModalHeader
          title={room.name}
          iconDescription={this.props.appMessages[AppMsg.BUTTON.CLOSE]}
        />
        <div className={cssBase}>
          <div className={`${cssBase}__content`}>
            {!isFloorPlanExpanded && (
              <>
                {(room.image || room.layoutImage) && (
                  <TriImage
                    value={room.layoutImage ? room.layoutImage : room.image}
                    className={`${cssBase}__image`}
                  />
                )}
                {room.reservationClassNameENUS ===
                  RESERVATION_CLASS_REQUESTABLE && (
                  <div className={`${cssBase}__section`}>
                    <InformationFilled16
                      className={`${cssBase}__requestableIcon`}
                    />
                    <div className={`${cssBase}__reservationClassInfo`}>
                      {
                        this.props.appMessages[
                          reserveType === ReservationTypes.MEETING
                            ? AppMsg.RESERVATION_MESSAGE.ROOM_REQUESTABLE
                            : AppMsg.RESERVATION_MESSAGE.WORKSPACE_REQUESTABLE
                        ]
                      }
                    </div>
                  </div>
                )}
                {room.reservationClassNameENUS ===
                  RESERVATION_CLASS_PRIVATE && (
                  <div className={`${cssBase}__section`}>
                    <ErrorOutline16 className={`${cssBase}__privateIcon`} />
                    <div className={`${cssBase}__reservationClassInfo`}>
                      {isPrivateRoom && (
                        <span>
                          {
                            this.props.appMessages[
                              reserveType === ReservationTypes.MEETING
                                ? AppMsg.RESERVATION_MESSAGE.ROOM_PRIVATE_OWNER
                                : AppMsg.RESERVATION_MESSAGE
                                    .WORKSPACE_PRIVATE_OWNER
                            ]
                          }
                        </span>
                      )}
                      {!isPrivateRoom && (
                        <span>
                          {
                            this.props.appMessages[
                              reserveType === ReservationTypes.MEETING
                                ? AppMsg.RESERVATION_MESSAGE.ROOM_PRIVATE
                                : AppMsg.RESERVATION_MESSAGE.WORKSPACE_PRIVATE
                            ]
                          }
                        </span>
                      )}
                    </div>
                  </div>
                )}
                <div className={`${cssBase}__section`}>
                  <div className={`${cssBase}__roomDetails`}>
                    {
                      this.props.appMessages[
                        AppMsg.RESERVATION_MESSAGE.STEP_ROOM_DETAIL_LOCATION
                      ]
                    }
                  </div>
                  <div className={`${cssBase}__roomDetails`}>
                    {this.getAddress(room)}
                  </div>
                </div>
                <div className={`${cssBase}__section`}>
                  <div className={`${cssBase}__roomDetails`}>
                    {
                      this.props.appMessages[
                        AppMsg.RESERVATION_MESSAGE
                          .STEP_ROOM_SEARCH_FILTER_COLLATERAL_LABEL
                      ]
                    }
                  </div>
                  <div className={`${cssBase}__roomDetails`}>
                    {room.collateralType}
                  </div>
                </div>
                {room.isMeetingSpace && (
                  <>
                    <div className={`${cssBase}__section`}>
                      <div className={`${cssBase}__roomDetails`}>
                        {
                          this.props.appMessages[
                            AppMsg.RESERVATION_MESSAGE
                              .STEP_ROOM_SEARCH_FILTER_CAPACITY
                          ]
                        }
                      </div>
                      <div className={`${cssBase}__roomDetails`}>
                        {room.capacity}
                      </div>
                    </div>
                    <div className={`${cssBase}__section`}>
                      <div className={`${cssBase}__roomDetails`}>
                        {
                          this.props.appMessages[
                            AppMsg.RESERVATION_MESSAGE
                              .STEP_ROOM_SEARCH_FILTER_SPACE_DETAILS
                          ]
                        }
                      </div>
                      <div className={`${cssBase}__roomDetails`}>
                        {room.spaceDetails}
                      </div>
                    </div>
                  </>
                )}
                {this.hasAmenities(room, reserveType) && (
                  <div className={`${cssBase}__section`}>
                    <div className={`${cssBase}__roomDetails`}>
                      {
                        this.props.appMessages[
                          AppMsg.RESERVATION_MESSAGE
                            .STEP_ROOM_SEARCH_FILTER_AMENITIES
                        ]
                      }
                    </div>
                    <div className={`${cssBase}__roomDetails`}>
                      {this.displayAmenities(room, reserveType)}
                    </div>
                  </div>
                )}
                {room.usageCost && (
                  <div className={`${cssBase}__section`}>
                    <div className={`${cssBase}__roomDetails`}>
                      {
                        this.props.appMessages[
                          AppMsg.RESERVATION_MESSAGE.STEP_ROOM_DETAIL_COST
                        ]
                      }
                    </div>
                    <div className={`${cssBase}__roomDetails`}>
                      {room.usageCost} {room.currency}/{room.usageUnit}
                    </div>
                  </div>
                )}
              </>
            )}
            {!isFloorPlanExpanded && (
              <div className={`${cssBase}__section`}>
                <div className={`${cssBase}__floorPlanLabel`}>
                  {
                    this.props.appMessages[
                      AppMsg.RESERVATION_MESSAGE.STEP_ROOM_DETAIL_FLOOR_PLAN
                    ]
                  }
                </div>
              </div>
            )}
            {floorPlanId !== null && (
              <>
                <div
                  className={classnames({
                    [`${cssBase}__floorPlan`]: true,
                    [`${cssBase}__floorPlan--expanded`]: isFloorPlanExpanded,
                  })}
                  ref={(floorPlanContainer) => {
                    this.floorPlanContainer = floorPlanContainer;
                  }}
                >
                  <TriFloorPlan
                    floorPlanId={defaultTo(floorPlanId, null)}
                    ref={(triFloorPlan) => (this.triFloorPlan = triFloorPlan)}
                    plugins={[
                      {
                        type: TriHighlightPlugin.type,
                        id: "highlightPlugin",
                        highlighted: this.getHighligthedRoom(room),
                        className: `${cssBase}__roomHighlighted`,
                        useInteractiveLayer: false,
                      },
                      {
                        type: TriLabelsPlugin.type,
                        id: "labelsPlugin",
                        labelId: labelStyles ? labelStyles[0]._id : "",
                      },
                      { type: TriZoomPlugin.type, id: "zoomPlugin" },
                      { type: TriPanPlugin.type, id: "panPlugin" },
                    ]}
                  />
                  <Button
                    className={`${cssBase}__expandShrinkButton`}
                    kind="secondary"
                    size="small"
                    hasIconOnly
                    renderIcon={this.getExpandShrinkIcon(isFloorPlanExpanded)}
                    tooltipAlignment="center"
                    tooltipPosition={dir === "ltr" ? "left" : "right"}
                    iconDescription={this.getExpandShrinkLabel(
                      isFloorPlanExpanded
                    )}
                    aria-label={this.getExpandShrinkLabel(isFloorPlanExpanded)}
                    onClick={() => this.handleFloorPlanExpanded()}
                    onKeyDown={(e) =>
                      e.key === "Enter" ? this.handleFloorPlanExpanded() : null
                    }
                  />
                </div>
              </>
            )}
            {this.renderNoFloorPlanMessage(floorPlanId, loading)}
          </div>
        </div>
        {isRoomSearchButton && (
          <div>
            <FooterButtons
              secondaryLabel={this.props.appMessages[AppMsg.BUTTON.CANCEL]}
              secondaryClickedHandler={onClosePopUp}
              tertiaryLabel={
                this.props.appMessages[AppMsg.BUTTON.BUTTON_REMOVE]
              }
              tertiaryClickedHandler={onDelete}
              isRoomSearchButton={isRoomSearchButton}
            />
          </div>
        )}
      </ComposedModal>
    );
  }

  renderNoFloorPlanMessage = (floorPlanId, loading) => {
    if (floorPlanId === null && !loading)
      return (
        <div className={`${cssBase}__emptyFloorplan`}>
          <Bee32 />
          <div>
            {
              this.props.appMessages[
                AppMsg.RESERVATION_MESSAGE.STEP_ROOM_DETAIL_NO_FLOOR_PLAN
              ]
            }
          </div>
        </div>
      );
    return null;
  };

  getExpandShrinkIcon = (isFloorPlanExpanded) => {
    return isFloorPlanExpanded ? ShrinkScreen20 : FitToScreen20;
  };

  getExpandShrinkLabel = (isFloorPlanExpanded) => {
    return AppMsg.getMessage(
      isFloorPlanExpanded
        ? AppMsg.BUTTON.BUTTON_SHRINK
        : AppMsg.BUTTON.BUTTON_EXPAND
    );
  };

  handleFloorPlanExpanded = () => {
    const { isFloorPlanExpanded } = this.state;
    this.setState({ isFloorPlanExpanded: !isFloorPlanExpanded }, () =>
      setTimeout(() => this.triFloorPlan.floorPlanDidResize(), 100)
    );
  };

  getAddress = (room) => {
    const address = [];
    if (room.city) address.push(room.city);
    if (room.state) address.push(room.state);
    if (room.country) address.push(room.country);
    return (
      <>
        <div>{room.floor}</div>
        <div>{room.building}</div>
        {address.join(", ")}
      </>
    );
  };

  hasAmenities = (room, reservationType) => {
    const amenities = RoomsUtils.getAmenitiesByRoom(room, reservationType);
    return amenities.length > 0;
  };

  displayAmenities = (room, reservationType) => {
    const amenities = RoomsUtils.getAmenitiesByRoom(room, reservationType);
    if (isEmpty(amenities)) {
      return null;
    }
    return <RoomAmenities amenities={amenities} />;
  };

  getHighligthedRoom = memo((room) => ({
    [TriHighlightPlugin.SPACE_ID]: room.spaceRecordId
      ? room.spaceRecordId
      : room._id,
  }));
}

const mapStateToProps = (state) => {
  return {
    room: RoomDetailsSelectors.roomDetailsSelector(state),
    labelStyles: LabelStylesSelectors.labelStylesSelector(state),
    reservationType: ReservationSelectors.reservationTypeSelector(state),
    isPrivateRoom: RoomDetailsSelectors.isPrivateRoomSelector(state),
    dir: LayoutSelectors.dirSelector(state),
    isRoomModalOpen: RoomSearchSelectors.roomModalSelector(state),
    event: EventDetailsSelectors.eventDetailsSelector(state),
    path: state.router.location.pathname,
  };
};

const { navigateBackFromRoomDetails } = RouteActions;
const { setRoomDetailsModal } = RoomSearchActions;

export default withTriDictionary(
  connect(mapStateToProps, {
    navigateBackFromRoomDetails,
    setRoomDetailsModal,
  })(RoomDetailsSmallPage)
);
