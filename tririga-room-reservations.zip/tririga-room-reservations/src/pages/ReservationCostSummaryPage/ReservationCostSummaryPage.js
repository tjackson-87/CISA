/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2022-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import classNames from "classnames";
import { Link, ToastNotification, Loading } from "carbon-components-react";
import {
  Group16,
  Document16,
  Location16,
  User16,
  Printer16,
  Cafe16,
  Enterprise16,
  Purchase16,
  Time16,
  Laptop16,
} from "@carbon/icons-react";
import { isNil, isEmpty } from "lodash";
import { TriNote, withTriDictionary } from "@tririga/tririga-react-components";
import { AppMsg } from "../../utils";
import {
  RouteActions,
  MyCalendarActions,
  ReservationActions,
  CurrentUserSelectors,
  CurrenciesSelectors,
  ReservationSelectors,
  SavedReservationSelectors,
  ExchangeSelectors,
  EventDetailsSelectors,
  RoomSearchActions,
  RoomDetailsActions,
} from "../../store";

import {
  TimezoneStatus,
  ReservationCostSummaryFooterButtons,
} from "../../components";
import CostSummary from "../../components/CostSummary/CostSummary";
import RoomDetailsPageSmall from "../RoomDetails/RoomDetailsPageSmall";

const cssBase = "reservationCostSummaryPage";

class ReservationCostSummaryPage extends React.PureComponent {
  static propTypes = {
    event: PropTypes.object,
    appMessages: PropTypes.object,
    subject: PropTypes.string,
    additionalLocationInfo: PropTypes.string,
    description: PropTypes.string,
    formattedDate: PropTypes.string,
    resources: PropTypes.array,
    attendees: PropTypes.array,
    currentCalendar: PropTypes.object,
    costSummary: PropTypes.object,
    onlineMeetingInfo: PropTypes.object,
    currentUserLocale: PropTypes.string,
    currencies: PropTypes.array,
    navigateBackToHomePage: PropTypes.func.isRequired,
    submitReservation: PropTypes.func.isRequired,
    handleAccountCodeChanged: PropTypes.func.isRequired,
    handleAccountCodeChangedInSavedReservation: PropTypes.func.isRequired,
    editMode: PropTypes.string,
    deleteEvent: PropTypes.func,
    editReservation: PropTypes.func,
    closePage: PropTypes.func,
    exchangeEventId: PropTypes.string,
    defaultTimezone: PropTypes.string,
    savedReservationLoaded: PropTypes.bool,
    setSavedReservationLoadedFlag: PropTypes.func.isRequired,
    setRoomDetailsModal: PropTypes.func,
    setRoomId: PropTypes.func,
  };

  render() {
    const {
      formattedDate,
      subject,
      currentCalendar,
      resources,
      savedReservationLoaded,
    } = this.props;
    return (
      <main className={cssBase}>
        <Loading active={!savedReservationLoaded} withOverlay />
        <div className={`${cssBase}__subject`}>{subject}</div>
        <div className={`${cssBase}__content`}>
          <div className={`${cssBase}__section`}>
            <div className={`${cssBase}__sectionHeader`}>
              <User16 className={`${cssBase}__sectionHeaderIcon`} />
              <div className={`${cssBase}__sectionHeaderText`}>
                {
                  this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE.MEETING_OWNER
                  ]
                }
              </div>
            </div>
            <div className={`${cssBase}__sectionContent`}>
              {currentCalendar && currentCalendar.name}
            </div>
          </div>
          <div className={`${cssBase}__section`}>
            <div className={`${cssBase}__sectionHeader`}>
              <Group16 className={`${cssBase}__sectionHeaderIcon`} />
              <div className={`${cssBase}__sectionHeaderText`}>
                {
                  this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE.STEP_MEETING_ATTENDEES
                  ]
                }
              </div>
            </div>
            <div className={`${cssBase}__sectionContent`}>
              {this.renderAttendees()}
            </div>
          </div>
          <div
            className={`${cssBase}__section`}
            style={{ borderBottom: "0px" }}
          >
            <div className={`${cssBase}__sectionHeader`}>
              <Time16 className={`${cssBase}__sectionHeaderIcon`} />
              <div className={`${cssBase}__sectionHeaderText`}>
                {
                  this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE.STEP_TIME_DESCRIPTION
                  ]
                }
              </div>
            </div>
            <div className={`${cssBase}__sectionContent`}>
              <span className={`${cssBase}__dateAndTime`}>{formattedDate}</span>
            </div>
          </div>
          <div className={`${cssBase}__section`}>
            <div
              className={classNames(`${cssBase}__sectionHeader`, {
                [`${cssBase}__sectionHeader--withRooms`]: !isEmpty(resources),
              })}
            >
              <Location16 className={`${cssBase}__sectionHeaderIcon`} />
              <div className={`${cssBase}__sectionHeaderText`}>
                {
                  this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE.STEP_ROOM_DETAIL_LOCATION
                  ]
                }
              </div>
            </div>
            <div className={`${cssBase}__sectionHeader`}>
              <>
                <Enterprise16 className={`${cssBase}__sectionHeaderIcon`} />

                <div className={`${cssBase}__sectionHeaderText`}>
                  {
                    this.props.appMessages[
                      AppMsg.RESERVATION_MESSAGE.STEP_LOCATION_DESCRIPTION
                    ]
                  }
                </div>
              </>
            </div>
            <div
              className={classNames(`${cssBase}__sectionContent`, {
                [`${cssBase}__sectionContent--withRooms`]: !isEmpty(resources),
              })}
            >
              {this.renderLocation()}
            </div>
          </div>
          <div className={`${cssBase}__section`}>
            <div className={`${cssBase}__sectionHeader`}>
              <Purchase16 className={`${cssBase}__sectionHeaderIcon`} />
              <div className={`${cssBase}__sectionHeaderText`}>
                {
                  this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE.STEP_MEETING_COST_SUMMARY
                  ]
                }
              </div>
            </div>
            <div id="costSummary" className={`${cssBase}__sectionContent`}>
              {this.renderCostSummary()}
            </div>
          </div>

          <div className={`${cssBase}__section`}>
            <div className={`${cssBase}__sectionHeader`}>
              <Laptop16 className={`${cssBase}__sectionHeaderIcon`} />
              <div className={`${cssBase}__sectionHeaderText`}>
                {
                  this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE.STEP_MEETING_ONLINE_MEETING
                  ]
                }
              </div>
            </div>
            <div
              className={classNames(
                `${cssBase}__sectionContent`,
                `${cssBase}__sectionContent--withOnlineMeeting`
              )}
            >
              {this.renderOnlineMeeting()}
            </div>
          </div>

          <div className={`${cssBase}__section`}>
            <div className={`${cssBase}__sectionHeader`}>
              <Location16 className={`${cssBase}__sectionHeaderIcon`} />
              <div className={`${cssBase}__sectionHeaderText`}>
                {
                  this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE
                      .STEP_MEETING_ADDITIONAL_LOCATION_INFO
                  ]
                }
              </div>
            </div>
            <div className={`${cssBase}__sectionContent`}>
              {this.renderAdditionalLocationInfo()}
            </div>
          </div>

          <div className={`${cssBase}__section`}>
            <div className={`${cssBase}__sectionHeader`}>
              <Document16 className={`${cssBase}__sectionHeaderIcon`} />
              <div className={`${cssBase}__sectionHeaderText`}>
                {
                  this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE.STEP_MEETING_DETAILS
                  ]
                }
              </div>
            </div>
            <div className={`${cssBase}__sectionContent`}>
              {this.renderDescription()}
            </div>
          </div>
        </div>
        <div id="footerBtn">
          <ReservationCostSummaryFooterButtons
            tertiaryLabel={this.props.appMessages[AppMsg.BUTTON.BUTTON_DELETE]}
            tertiaryClickedHandler={this.onDeleteClick}
            secondaryLabel={this.props.appMessages[AppMsg.BUTTON.BUTTON_EDIT]}
            secondaryClickedHandler={this.onEditClick}
            primaryLabel={this.props.appMessages[AppMsg.BUTTON.BUTTON_OK]}
            primaryClickedHandler={this.onCreateClick}
            primaryDisabled={false}
          />
        </div>
        <RoomDetailsPageSmall onClosePopUp={() => this.onClosePopUp()} />
      </main>
    );
  }

  componentDidMount() {
    document.getElementById("costSummary").scrollIntoView();
  }

  onEditClick = async () => {
    const {
      editReservation,
      event,
      editMode,
      setSavedReservationLoadedFlag,
    } = this.props;
    setSavedReservationLoadedFlag(false);
    editReservation(event, editMode);
  };

  onDeleteClick = async () => {
    const {
      deleteEvent,
      event,
      editMode,
      closePage,
      exchangeEventId,
    } = this.props;
    if (
      editMode === "Series" &&
      (isEmpty(event.seriesMasterId) || isNil(event.seriesMasterId))
    ) {
      await deleteEvent(
        { ...event, seriesMasterId: exchangeEventId },
        editMode
      );
    } else {
      await deleteEvent(event, editMode);
    }
    closePage();
  };

  onCreateClick = async () => {
    const { navigateBackToHomePage, submitReservation } = this.props;
    const reservation = await submitReservation();

    if (reservation != null) {
      navigateBackToHomePage();
    }
  };

  renderLocation() {
    const { defaultTimezone, resources } = this.props;
    if (resources) {
      return (
        <>
          {resources.map((resource) => (
            <div
              className={classNames(`${cssBase}__room`)}
              key={resource.room._id}
            >
              <TimezoneStatus
                timezone={resource.room.timezone}
                defaultTimezone={defaultTimezone}
                cssBase={cssBase}
              />
              <div
                className={`${cssBase}__roomName`}
                onClick={() => this.handleItemClick(resource.room)}
              >
                <span
                  tabIndex={0}
                  ref={(ref) => {
                    this.setRef(ref, resource.room._id);
                  }}
                  role="link"
                  onKeyDown={(e) =>
                    e.key === "Enter"
                      ? this.handleItemClick(resource.room)
                      : false
                  }
                >
                  {resource.room.roomId}
                  {", "}
                  {resource.room.name}
                </span>
              </div>
              <div className={`${cssBase}__roomLocation`}>
                <div className={`${cssBase}__roomFloor`}>
                  {resource.room.floor}
                </div>
                <div className={`${cssBase}__roomBuilding`}>
                  <Location16 className={`${cssBase}__roomBuildingIcon`} />
                  <span>{resource.room.building}</span>
                </div>
              </div>
              {resource.selectedEquipment &&
                !isEmpty(resource.selectedEquipment) && (
                  <div className={`${cssBase}__cateringSummary`}>
                    <div className={`${cssBase}__cateringContent`}>
                      <div className={`${cssBase}__cateringHeader`}>
                        <Printer16
                          className={`${cssBase}__cateringHeaderIcon`}
                        />
                        <div className={`${cssBase}__cateringHeaderName`}>
                          {
                            this.props.appMessages[
                              AppMsg.RESERVATION_MESSAGE.STEP_MEETING_EQUIPMENT
                            ]
                          }
                        </div>
                      </div>
                      <div className={`${cssBase}__cateringChildren`}>
                        {resource.selectedEquipment.map((e, index) => (
                          <span className={`${cssBase}__equipment`} key={e._id}>
                            {e.actionType !== "delete" &&
                              `${e.name}${
                                e.quantity > 1 ? " (" + e.quantity + ")" : ""
                              }${
                                index < resource.selectedEquipment.length - 1
                                  ? "; "
                                  : ""
                              }`}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              {resource.selectedCatering && (
                <div className={`${cssBase}__cateringSummary`}>
                  <div className={`${cssBase}__cateringContent`}>
                    <div className={`${cssBase}__cateringHeader`}>
                      <Cafe16 className={`${cssBase}__cateringHeaderIcon`} />
                      <div className={`${cssBase}__cateringHeaderName`}>
                        {
                          this.props.appMessages[
                            AppMsg.RESERVATION_MESSAGE.STEP_MEETING_CATERING
                          ]
                        }
                      </div>
                    </div>
                    <div className={`${cssBase}__cateringChildren`}>
                      {resource.selectedCatering.map((e, index) => (
                        <span key={`item-${index}`}>
                          {`
                                    ${
                                      e.additionalInformation.orderName ||
                                      AppMsg.getMessage(
                                        AppMsg.RESERVATION_MESSAGE.FOOD_ORDER
                                      )
                                    } 
                                    ${e.additionalInformation.deliveryTime} 
                                    ${
                                      e.additionalInformation.deliveryTimePeriod
                                    }
                                  `}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          ))}
        </>
      );
    }
  }

  setRef(ref, roomId) {
    if (ref && roomId) {
      this[roomId] = React.createRef();
      this[roomId] = ref;
    }
  }

  handleItemClick = (room) => {
    const { setRoomId, setRoomDetailsModal } = this.props;
    this.roomRef = room._id;
    this.setState({
      roomDetailModal: null,
    });
    setRoomId(room.spaceRecordId);
    setRoomDetailsModal(true);
  };

  onClosePopUp = () => {
    const { setRoomDetailsModal } = this.props;
    setRoomDetailsModal(false);
    if (this[this.roomRef]) {
      setTimeout(() => {
        this[this.roomRef].focus();
      }, 1);
    } else {
      this.setState({
        roomDetailModal: true,
      });
    }
  };

  renderOnlineMeeting() {
    const { onlineMeetingInfo } = this.props;
    if (isNil(onlineMeetingInfo)) return null;
    return (
      <>
        <div className={classNames(`${cssBase}___onlineMeetingInfoHeader`)}>
          {this.props.appMessages[AppMsg.RESERVATION_MESSAGE.MEETING_NAME]}
        </div>
        <div className={classNames(`${cssBase}___onlineMeetingInfo`)}>
          {onlineMeetingInfo.name}
        </div>
        <div className={classNames(`${cssBase}___onlineMeetingInfoHeader`)}>
          {this.props.appMessages[AppMsg.RESERVATION_MESSAGE.MEETING_URL]}
        </div>
        <div className={classNames(`${cssBase}___onlineMeetingInfo`)}>
          <Link href={onlineMeetingInfo.url} target="_blank">
            {onlineMeetingInfo.url}
          </Link>
        </div>
        {!isEmpty(onlineMeetingInfo.callInInformation) && (
          <>
            <div className={classNames(`${cssBase}___onlineMeetingInfoHeader`)}>
              {
                this.props.appMessages[
                  AppMsg.RESERVATION_MESSAGE.MEETING_CALL_IN_INFO
                ]
              }
            </div>
            <div className={classNames(`${cssBase}___onlineMeetingInfo`)}>
              {onlineMeetingInfo.callInInformation}
            </div>
          </>
        )}
      </>
    );
  }

  renderAdditionalLocationInfo() {
    const { additionalLocationInfo } = this.props;
    return (
      <div className={classNames(`${cssBase}___additionalLocationInfo`)}>
        {additionalLocationInfo}
      </div>
    );
  }

  renderCostSummary() {
    const {
      costSummary,
      currencies,
      currentUserLocale,
      appMessages,
    } = this.props;
    if (!isNil(costSummary)) {
      return (
        <div>
          <ToastNotification
            className={`${cssBase}__notification`}
            kind="info"
            lowContrast
            hideCloseButton={true}
            title={
              this.props.appMessages[
                AppMsg.RESERVATION_MESSAGE.COST_SUMMARY_NOTIFICATION_TITLE
              ]
            }
            statusIconDescription={
              this.props.appMessages[
                AppMsg.RESERVATION_MESSAGE.COST_SUMMARY_NOTIFICATION_TITLE
              ]
            }
            subtitle={
              <span>
                {
                  this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE.COST_SUMMARY_NOTIFICATION_TEXT
                  ]
                }
              </span>
            }
          />
          <CostSummary
            data={costSummary}
            currentUserLocale={currentUserLocale}
            appMessages={appMessages}
            currencies={currencies}
            editMode={true}
            onCostCodeValueChanged={this.handleAccountCode}
          />
        </div>
      );
    }
  }

  handleAccountCode = (accountCodeName, value) => {
    this.props.handleAccountCodeChanged(accountCodeName, value);
    this.props.handleAccountCodeChangedInSavedReservation(
      accountCodeName,
      value
    );
  };

  renderDescription() {
    const { description } = this.props;
    if (isEmpty(description)) {
      return null;
    }
    return (
      <div className={`${cssBase}__description`}>
        <TriNote value={description} readonly autoHeight />
      </div>
    );
  }

  renderAttendees() {
    const { attendees } = this.props;
    if (isEmpty(attendees)) {
      return AppMsg.getMessage(AppMsg.RESERVATION_MESSAGE.NO_ATTENDEES);
    }
    return (
      <div className={`${cssBase}__attendees`}>
        {attendees.map((item, index) => (
          <span
            key={`attendee-${index}`}
            className={`${cssBase}__attendeeName`}
          >
            {item &&
              `${item.displayName}${index < attendees.length - 1 ? ", " : ""}`}
          </span>
        ))}
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    event: EventDetailsSelectors.eventDetailsSelector(state),
    subject: SavedReservationSelectors.subjectSelector(state),
    resources: SavedReservationSelectors.orderedResourcesSelector(state),
    attendees: ReservationSelectors.attendeesSelector(state),
    onlineMeetingInfo: SavedReservationSelectors.onlineMeetingSelector(state),
    additionalLocationInfo: SavedReservationSelectors.additionalLocationInfoSelector(
      state
    ),
    exchangeEventId: ReservationSelectors.exchangeEventIdSelector(state),
    description: SavedReservationSelectors.descriptionSelector(state),
    savedReservationLoaded: SavedReservationSelectors.savedReservationLoadedSelector(
      state
    ),
    formattedDate: ReservationSelectors.formattedStartEndDatesSelector(state),
    costSummary: ReservationSelectors.costSummaryAccountCodesSelector(state),
    editMode: ReservationSelectors.editModeSelector(state),
    defaultTimezone: CurrentUserSelectors.defaultTimezoneSelector(state),
    currentUserLocale: CurrentUserSelectors.localeSelector(state),
    currencies: CurrenciesSelectors.currenciesSelector(state),
    currentCalendar: ExchangeSelectors.currentCalendarSelector(state),
  };
};

export default withTriDictionary(
  connect(mapStateToProps, {
    closePage: RouteActions.navigateToHomePage,
    handleAccountCodeChanged: ReservationActions.handleAccountCodeChanged,
    handleAccountCodeChangedInSavedReservation:
      ReservationActions.handleAccountCodeChangedInSavedReservation,
    submitReservation: ReservationActions.submitReservation,
    navigateBackToHomePage: RouteActions.navigateBackToHomePage,
    editReservation: RouteActions.navigateToEditReservation,
    deleteEvent: MyCalendarActions.deleteEvent,
    setSavedReservationLoadedFlag:
      ReservationActions.setSavedReservationLoadedFlag,
    setRoomDetailsModal: RoomSearchActions.setRoomDetailsModal,
    setRoomId: RoomDetailsActions.setRoomId,
  })(ReservationCostSummaryPage)
);
