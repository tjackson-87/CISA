/* IBM Confidential· - OCO Source Materials· - (C) COPYRIGHT IBM CORP. 2023 - The source code for this program is not published or otherwise· divested of its trade secrets, irrespective of what has been· deposited with the U.S. Copyright Office. */

import React from "react";
import { screen, fireEvent } from "@testing-library/react";
import { AppMsg } from "../../../utils";
import {
  getAppStore,
  ReservationActions,
  RouteActions,
  EquipmentActions,
} from "../../../store";
import { reservationReducer } from "../../../store/reducers/ReservationReducer";
import { roomDetailsReducer } from "../../../store/reducers/RoomDetailsReducer";

import EquipmentListPageSmall from "../EquipmentListPageSmall";
import {
  createException,
  createReservableRoom,
  createReservationParam,
  createResource,
  renderWithReduxAndDictionaryProvider,
} from "../../../testUtils";
import { Button, TextInput } from "carbon-addons-iot-react";

afterEach(() => jest.clearAllMocks());

function MockedFooterButtons({
  // eslint-disable-next-line react/prop-types
  secondaryClickedHandler,
  // eslint-disable-next-line react/prop-types
  primaryClickedHandler,
}) {
  return (
    <>
      <Button onClick={secondaryClickedHandler} aria-label="cancel" />
      <Button onClick={primaryClickedHandler} aria-label="done" />
    </>
  );
}

function MockedEquipmentList({
  // eslint-disable-next-line react/prop-types
  onClick,
  // eslint-disable-next-line react/prop-types
  onChange,
  // eslint-disable-next-line react/prop-types
  equipImageModalDomRef,
}) {
  const obj = {
    _id: 1,
    quantity: 2,
    instructions: {},
  };
  const myRef = { current: { focus: jest.fn() } };

  function click() {
    equipImageModalDomRef(myRef);
    onClick();
  }

  return (
    <>
      <div data-testid="equipmentListItem" onClick={() => click()}>
        Equipment List Page
      </div>
      <TextInput
        id="quantity"
        onChange={(e) => {
          e.target.value === "1" ? onChange(obj, true) : onChange(obj, false);
        }}
        labelText="Equipment Quantity"
      />
    </>
  );
}

function MockedEquipmentDetailsPage({
  // eslint-disable-next-line react/prop-types
  onClosePopUp,
}) {
  return (
    <div data-testid="equipmentDetailsPage" onClick={onClosePopUp}>
      Equipment List Page
    </div>
  );
}

jest.mock("../../../components/HoldCountDown/HoldCountDown", () => {
  return {
    __esModule: true,
    default: () => <div data-testid="holdCountDown">Hold count down</div>,
  };
});

jest.mock("../../../components/FooterButtons/FooterButtons", () => {
  return MockedFooterButtons;
});

jest.mock("../../../components/Equipment/EquipmentListItem", () => {
  return MockedEquipmentList;
});

jest.mock("../../EquipmentDetails/EquipmentDetailsPageSmall", () => {
  return MockedEquipmentDetailsPage;
});

EquipmentActions.setEquipmentId.mockImplementation(() => jest.fn());
EquipmentActions.setEquipmentDetailModal.mockImplementation(() => jest.fn());

ReservationActions.setResourceAddedEquipment.mockImplementation(() =>
  jest.fn()
);

ReservationActions.setResourceSelectedEquipment.mockImplementation(() =>
  jest.fn()
);

RouteActions.navigateBackFromEquipment.mockImplementation(() => jest.fn());

jest.mock("../../../store/actions/EquipmentActions");
jest.mock("../../../store/actions/ReservationActions");
jest.mock("../../../store/actions/RouteActions");

describe("EquipmentListPageSmall", () => {
  let props, appMessages, fakeRoom, reservationParam, resource;

  const selectedEquipment = [
    {
      image: "//Company-1/file1494353447515.jpeg",
      equipment: "Desk",
      equipmentDescription: null,
      equipmentId: "10922574",
      quantity: 2,
      instructions: {},
      _id: 1,
      roomId: 1,
      orderId: 101,
      resource: {
        id: 12384739,
        value: "Bane Room",
      },
    },
  ];
  const availableEquipment = [
    {
      image: "//Company-1/file1494353447515.jpeg",
      equipment: "Desk",
      equipmentDescription: null,
      equipmentId: "10922574",
      quantity: 5,
      instructions: {},
      _id: 1,
      roomId: 1,
      resource: {
        id: 12384739,
        value: "Bane Room",
      },
    },
  ];

  beforeEach(() => {
    fakeRoom = createReservableRoom("Spider-man", "Marvel", 1);
    reservationParam = createReservationParam();
    resource = createResource(fakeRoom, [createException()]);
    appMessages = AppMsg.getAppMessages();
    props = {};
  });

  it("Should not render if room not available", () => {
    const initialState = {
      ...getAppStore().getState(),
      reservation: { ...getAppStore().getState.reservation },
    };

    renderWithReduxAndDictionaryProvider(
      <EquipmentListPageSmall {...props} />,
      {
        initialState,
        reducer: roomDetailsReducer,
      },
      appMessages
    );

    const pageTitle = screen.queryByText(appMessages.STEP_MEETING_EQUIPMENT);
    expect(pageTitle).not.toBeInTheDocument();
  });

  it("Renders properly", () => {
    const initialReservationState = {
      ...getAppStore().getState.reservation,
      data: {
        ...reservationParam,
        holdTimeEnd: "1000",
      },
      selectedResource: resource,
    };

    const initialRoomDetailsState = {
      ...getAppStore().getState.roomDetails,
      data: fakeRoom,
      roomId: 1,
      contactRoles: [],
    };

    const initialState = {
      ...getAppStore().getState(),
      reservation: initialReservationState,
      roomDetails: initialRoomDetailsState,
    };

    renderWithReduxAndDictionaryProvider(
      <EquipmentListPageSmall {...props} />,
      {
        initialState,
        reducer: roomDetailsReducer,
      },
      appMessages
    );

    const pageTitle = screen.getByText(appMessages.STEP_MEETING_EQUIPMENT);
    const closeButton = screen.getByRole("button", {
      name: appMessages.BUTTON_CLOSE,
    });
    const roomName = screen.getByText("Spider-man");
    const holdCountDown = screen.getByTestId("holdCountDown");

    expect(pageTitle).toBeInTheDocument();
    expect(closeButton).toBeInTheDocument();
    expect(roomName).toBeInTheDocument();
    expect(holdCountDown).toBeInTheDocument();
  });

  describe("Test Create/Update/Delete actions when equipments are added/modified", () => {
    it("Should create when new equipments are added", () => {
      resource = createResource(fakeRoom, [], [], [], availableEquipment);
      const initialReservationState = {
        ...getAppStore().getState.reservation,
        data: {
          ...reservationParam,
          resources: [resource],
        },
        selectedResource: resource,
      };

      const initialRoomDetailsState = {
        ...getAppStore().getState.roomDetails,
        data: fakeRoom,
        roomId: 1,
        contactRoles: [],
      };

      const initialState = {
        ...getAppStore().getState(),
        reservation: initialReservationState,
        roomDetails: initialRoomDetailsState,
      };

      renderWithReduxAndDictionaryProvider(
        <EquipmentListPageSmall {...props} />,
        {
          initialState,
          reducer: roomDetailsReducer,
        },
        appMessages
      );

      const expectedObj = {
        _id: 1,
        quantity: 2,
        instructions: {},
        roomId: 1,
        actionType: "create",
        orderId: null,
      };

      const tb = screen.getByRole("textbox");
      fireEvent.change(tb, { target: { value: "1" } });
      expect(ReservationActions.setResourceAddedEquipment).toHaveBeenCalledWith(
        [expectedObj],
        1
      );
    });

    it("Should create equipment when orderId is null", () => {
      const se = { ...selectedEquipment[0], orderId: null };
      resource = createResource(fakeRoom, [], [], [se], availableEquipment);
      const initialReservationState = {
        ...getAppStore().getState.reservation,
        data: {
          ...reservationParam,
          resources: [resource],
        },
        selectedResource: resource,
      };

      const initialRoomDetailsState = {
        ...getAppStore().getState.roomDetails,
        data: fakeRoom,
        roomId: 1,
        contactRoles: [],
      };

      const initialState = {
        ...getAppStore().getState(),
        reservation: initialReservationState,
        roomDetails: initialRoomDetailsState,
      };

      renderWithReduxAndDictionaryProvider(
        <EquipmentListPageSmall {...props} />,
        {
          initialState,
          reducer: roomDetailsReducer,
        },
        appMessages
      );

      const expectedObj = {
        ...se,
        actionType: "create",
        orderId: null,
      };

      const tb = screen.getByRole("textbox");
      fireEvent.change(tb, { target: { value: "1" } });
      expect(ReservationActions.setResourceAddedEquipment).toHaveBeenCalledWith(
        [expectedObj],
        1
      );
    });

    it("Should update the equipment", () => {
      resource = createResource(
        fakeRoom,
        [],
        [],
        selectedEquipment,
        availableEquipment
      );
      const initialReservationState = {
        ...getAppStore().getState.reservation,
        data: {
          ...reservationParam,
          resources: [resource],
        },
        selectedResource: resource,
      };

      const initialRoomDetailsState = {
        ...getAppStore().getState.roomDetails,
        data: fakeRoom,
        roomId: 1,
        contactRoles: [],
      };

      const initialState = {
        ...getAppStore().getState(),
        reservation: initialReservationState,
        roomDetails: initialRoomDetailsState,
      };

      renderWithReduxAndDictionaryProvider(
        <EquipmentListPageSmall {...props} />,
        {
          initialState,
          reducer: roomDetailsReducer,
        },
        appMessages
      );

      const expectedObj = {
        ...selectedEquipment[0],
        actionType: "update",
      };

      const tb = screen.getByRole("textbox");
      fireEvent.change(tb, { target: { value: "1" } });
      expect(ReservationActions.setResourceAddedEquipment).toHaveBeenCalledWith(
        [expectedObj],
        1
      );
    });

    it("Should delete the equipment", () => {
      const se = { ...selectedEquipment[0], orderId: 101 };
      resource = createResource(fakeRoom, [], [], [se], availableEquipment);
      const initialReservationState = {
        ...getAppStore().getState.reservation,
        data: {
          ...reservationParam,
          resources: [resource],
        },
        selectedResource: resource,
      };

      const initialRoomDetailsState = {
        ...getAppStore().getState.roomDetails,
        data: fakeRoom,
        roomId: 1,
        contactRoles: [],
      };

      const initialState = {
        ...getAppStore().getState(),
        reservation: initialReservationState,
        roomDetails: initialRoomDetailsState,
      };

      renderWithReduxAndDictionaryProvider(
        <EquipmentListPageSmall {...props} />,
        {
          initialState,
          reducer: roomDetailsReducer,
        },
        appMessages
      );

      const expectedObj = {
        ...se,
        actionType: "delete",
      };

      const tb = screen.getByRole("textbox");
      fireEvent.change(tb, { target: { value: "0" } });
      expect(ReservationActions.setResourceAddedEquipment).toHaveBeenCalledWith(
        [expectedObj],
        1
      );
    });
  });

  describe("Non Readonly tests", () => {
    beforeEach(() => {
      resource = createResource(
        fakeRoom,
        [],
        [],
        selectedEquipment,
        availableEquipment
      );
      const initialReservationState = {
        ...getAppStore().getState.reservation,
        data: {
          ...reservationParam,
          resources: [resource],
        },
        selectedResource: resource,
      };

      const initialRoomDetailsState = {
        ...getAppStore().getState.roomDetails,
        data: fakeRoom,
        roomId: 1,
        contactRoles: [],
      };

      const initialState = {
        ...getAppStore().getState(),
        reservation: initialReservationState,
        roomDetails: initialRoomDetailsState,
      };

      renderWithReduxAndDictionaryProvider(
        <EquipmentListPageSmall {...props} />,
        {
          initialState,
          reducer: roomDetailsReducer,
        },
        appMessages
      );
    });

    it("Should open a modal when equipment is clicked", () => {
      const equipment = screen.getByTestId("equipmentListItem");
      expect(equipment).toBeInTheDocument();
      fireEvent.click(equipment);
      expect(EquipmentActions.setEquipmentId).toHaveBeenCalled();
      expect(EquipmentActions.setEquipmentDetailModal).toHaveBeenCalled();
    });

    it("Should navigate back when close button is clicked", () => {
      const closeBtn = screen.getByRole("button", { name: /Close/i });
      fireEvent.click(closeBtn);
      fireEvent.keyDown(closeBtn, { key: "Enter" });
      expect(
        ReservationActions.setResourceSelectedEquipment
      ).toHaveBeenCalled();
      expect(RouteActions.navigateBackFromEquipment).toHaveBeenCalled();
    });

    it("Should navigate back when cancel is clicked in footer", () => {
      const cancelBtn = screen.getByRole("button", { name: /cancel/i });
      fireEvent.click(cancelBtn);
      expect(
        ReservationActions.setResourceSelectedEquipment
      ).toHaveBeenCalled();
      expect(RouteActions.navigateBackFromEquipment).toHaveBeenCalled();
    });

    it("Should save and navigate when done is clicked in footer", () => {
      const doneBtn = screen.getByRole("button", { name: /done/i });
      fireEvent.click(doneBtn);
      expect(
        ReservationActions.setResourceSelectedEquipment
      ).toHaveBeenCalled();
      expect(RouteActions.navigateBackFromEquipment).toHaveBeenCalled();
    });

    it("Should close equipmentDetailsPage", () => {
      const equipment = screen.getByTestId("equipmentListItem");
      fireEvent.click(equipment);
      const btn = screen.getByTestId("equipmentDetailsPage");
      fireEvent.click(btn);
      expect(EquipmentActions.setEquipmentDetailModal).toHaveBeenCalled();
    });
  });

  it("For readonly state, only readonly footer should render", () => {
    resource = createResource(fakeRoom, [], [], [], []);
    const initialReservationState = {
      ...getAppStore().getState.reservation,
      data: {
        ...reservationParam,
        resources: [resource],
      },
      selectedResource: resource,
    };

    const initialEventDetailsState = {
      ...getAppStore().getState.eventDetails,
      event: {
        rooms: [
          {
            _id: 1,
            availableEquipments: availableEquipment,
            equipment: selectedEquipment,
          },
        ],
      },
    };

    const initialRoomDetailsState = {
      ...getAppStore().getState.roomDetails,
      data: { ...fakeRoom, _id: 1 },
      roomId: 1,
      contactRoles: [],
    };

    const initialState = {
      ...getAppStore().getState(),
      reservation: initialReservationState,
      roomDetails: initialRoomDetailsState,
      eventDetails: initialEventDetailsState,
      router: { location: { state: { routedFromEventDetailPage: true } } },
    };

    renderWithReduxAndDictionaryProvider(
      <EquipmentListPageSmall {...props} />,
      {
        initialState,
        reducer: reservationReducer,
      },
      appMessages
    );
    const backBtn = screen.getByRole("button", { name: /Back/i });
    expect(backBtn).toBeInTheDocument();
    const equipment = screen.getByTestId("equipmentListItem");
    fireEvent.click(equipment);
    expect(EquipmentActions.setEquipmentId).toHaveBeenCalled();
  });
});
