/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import { connect } from "react-redux";
import classnames from "classnames";
import PropTypes from "prop-types";
import { isEmpty, defaultTo } from "lodash";
import { Button } from "carbon-components-react";
import { Close20, Location16 } from "@carbon/icons-react";
import {
  FooterButtons,
  HoldCountDown,
  EquipmentListItem,
} from "../../components";
import {
  RouteActions,
  ReservationActions,
  RoomDetailsSelectors,
  ReservationSelectors,
  LayoutSelectors,
  EquipmentActions,
} from "../../store";
import { AppMsg, computeAddress } from "../../utils";
import EquipmentDetailsPageSmall from "../EquipmentDetails/EquipmentDetailsPageSmall";

const cssBase = "equipmentListPageSmall";

class EquipmentListPageSmall extends React.PureComponent {
  constructor(props) {
    super(props);
    this.closeButton = React.createRef();
  }

  static propTypes = {
    appMessages: PropTypes.object,
    className: PropTypes.string,
    room: PropTypes.object,
    holdTimeEnd: PropTypes.string,
    reservationType: PropTypes.string,
    navigateBackFromEquipment: PropTypes.func,
    setResourceSelectedEquipment: PropTypes.func,
    setResourceAddedEquipment: PropTypes.func,
    availableEquipment: PropTypes.array,
    selectedEquipment: PropTypes.array,
    addedEquipments: PropTypes.array,
    addedEquipmentsSaved: PropTypes.bool,
    renewHold: PropTypes.func.isRequired,
    isCreate: PropTypes.bool,
    dir: PropTypes.string,
    isReadOnly: PropTypes.bool,
    setEquipmentDetailModal: PropTypes.func,
    setEquipmentId: PropTypes.func,
  };

  state = {
    addedEquipment: [],
    hasEquipmentChange: false,
    equipImageRef: null,
  };

  static getDerivedStateFromProps(props, state) {
    if (!props.addedEquipmentsSaved && state.hasEquipmentChange) {
      return {
        addedEquipment: defaultTo(props.addedEquipments, []),
        hasEquipmentChange: true,
      };
    } else if (props.selectedEquipment && !state.hasEquipmentChange) {
      return {
        addedEquipment: defaultTo(props.selectedEquipment, []),
        hasEquipmentChange: false,
      };
    }
    return null;
  }

  render() {
    const {
      className,
      room,
      holdTimeEnd,
      reservationType,
      navigateBackFromEquipment,
      availableEquipment,
      renewHold,
      isCreate,
      dir,
      isReadOnly,
      selectedEquipment,
    } = this.props;
    const { hasEquipmentChange } = this.state;
    if (isEmpty(room)) {
      return null;
    }

    return (
      <main className={cssBase}>
        <div className={classnames(cssBase, className)}>
          <div className={`${cssBase}__title`}>
            <span>
              {
                this.props.appMessages[
                  AppMsg.RESERVATION_MESSAGE.STEP_MEETING_EQUIPMENT
                ]
              }
            </span>
            <Button
              className={`${cssBase}__closeButton`}
              kind="ghost"
              hasIconOnly
              aria-label={this.props.appMessages[AppMsg.BUTTON.CLOSE]}
              renderIcon={Close20}
              tooltipAlignment="center"
              tooltipPosition={dir === "ltr" ? "left" : "right"}
              iconDescription={this.props.appMessages[AppMsg.BUTTON.CLOSE]}
              onKeyDown={(e) => (e.key === "Enter" ? this.handleOnClick : null)}
              onClick={this.handleOnClick}
              autoFocus={true}
            />
          </div>
          <div className={`${cssBase}__content`}>
            {holdTimeEnd != null && !isReadOnly && (
              <HoldCountDown
                holdTimeEnd={holdTimeEnd}
                onRenewHoldTime={renewHold}
                reservationType={reservationType}
              />
            )}
            <div className={`${cssBase}__roomDetails`}>
              <div className={`${cssBase}__selectedRoom_label`}>
                {
                  this.props.appMessages[
                    isReadOnly
                      ? AppMsg.RESERVATION_MESSAGE.ROOM
                      : AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SELECTED_ROOM
                  ]
                }
                :
              </div>
              <div className={`${cssBase}__location`}>
                <Location16 className={`${cssBase}__locationIcon`} />
                <div className={`${cssBase}__room`}>{room.name}</div>
              </div>
              <div className={`${cssBase}__address`}>
                {computeAddress(room)}
              </div>
            </div>

            <div className={`${cssBase}__equipmentDetails`}>
              {!isEmpty(availableEquipment) && (
                <>
                  {!isReadOnly && (
                    <div className={`${cssBase}__equipment_label`}>
                      {
                        this.props.appMessages[
                          AppMsg.RESERVATION_MESSAGE
                            .STEP_ROOM_EQUIPMENT_AVAILABLE
                        ]
                      }
                    </div>
                  )}
                  <div className={`${cssBase}__equipment_list`}>
                    {isReadOnly && !isEmpty(selectedEquipment)
                      ? selectedEquipment.map((equipment) => (
                          <EquipmentListItem
                            isReadOnly={isReadOnly}
                            key={equipment._id}
                            item={equipment}
                            quantity={equipment.quantity}
                            instructions={equipment.instructions}
                            onClick={() => this.handleClick(equipment, room)}
                            equipImageModalDomRef={(ref) =>
                              this.setState({ equipImageRef: ref })
                            }
                          />
                        ))
                      : availableEquipment.map((equipment) => (
                          <EquipmentListItem
                            isReadOnly={isReadOnly}
                            key={equipment._id}
                            item={equipment}
                            quantity={this.getEquipmentQuantity(equipment)}
                            instructions={this.getEquipmentInstrutions(
                              equipment
                            )}
                            onChange={this.handleListChange}
                            onClick={() => this.handleClick(equipment, room)}
                            equipImageModalDomRef={(ref) => {
                              this.setState({ equipImageRef: ref });
                            }}
                          />
                        ))}
                  </div>
                </>
              )}
            </div>
          </div>
          {isReadOnly && this.renderReadonlyFooter()}

          {!isReadOnly && (
            <FooterButtons
              className={`${cssBase}__footerButtons`}
              secondaryLabel={this.props.appMessages[AppMsg.BUTTON.CANCEL]}
              secondaryClickedHandler={() => {
                this.props.setResourceSelectedEquipment(
                  this.props.selectedEquipment,
                  this.props.room._id
                );
                navigateBackFromEquipment();
              }}
              primaryLabel={this.props.appMessages[AppMsg.BUTTON.DONE]}
              primaryClickedHandler={this.onDoneClick}
              primaryDisabled={this.handleDisable(isCreate, hasEquipmentChange)}
            />
          )}
          <EquipmentDetailsPageSmall
            onClosePopUp={() => this.onEquipPopupClose()}
          />
        </div>
      </main>
    );
  }

  handleOnClick = (e) => {
    const { isReadOnly } = this.props;
    if (!isReadOnly) {
      this.props.setResourceSelectedEquipment(
        this.props.selectedEquipment,
        this.props.room._id
      );
    }
    this.props.navigateBackFromEquipment({ routedFromEquipment: true });
  };

  handleClick = (equipment, room) => {
    const { setEquipmentDetailModal, setEquipmentId } = this.props;
    setEquipmentId(equipment._id);
    setEquipmentDetailModal(true);
  };

  onEquipPopupClose = () => {
    const { setEquipmentDetailModal } = this.props;
    const { equipImageRef } = this.state;

    setEquipmentDetailModal(false);

    if (equipImageRef && equipImageRef.current) {
      setTimeout(() => {
        equipImageRef.current.focus();
      }, 1);
    }
  };

  handleDisable = (isCreate, hasEquipmentChange) => {
    return !isCreate && !hasEquipmentChange;
  };

  getEquipmentInstrutions = (equipment) => {
    const { addedEquipment } = this.state;
    if (isEmpty(addedEquipment)) return "";
    const index = this.getSelectedEquipIndex(equipment, addedEquipment);
    return index !== -1 ? addedEquipment[index].instructions : "";
  };

  getEquipmentQuantity = (equipment) => {
    const { addedEquipment } = this.state;
    if (isEmpty(addedEquipment)) return 0;
    const index = this.getSelectedEquipIndex(equipment, addedEquipment);
    return index !== -1 ? addedEquipment[index].quantity : 0;
  };

  getSelectedEquipIndex = (equipment, selectedEquipment) => {
    return selectedEquipment.findIndex(
      (selected) => selected._id === equipment._id
    );
  };

  handleListChange = (item, selected) => {
    const { room, isCreate } = this.props;
    const newAddedEquips = [...this.state.addedEquipment];
    const ind = newAddedEquips.findIndex(
      (s) => s.roomId === room._id && s._id === item._id
    );
    if (selected) {
      if (ind !== -1) {
        if (newAddedEquips[ind].orderId != null)
          newAddedEquips[ind] = {
            ...newAddedEquips[ind],
            ...item,
            actionType: "update",
          };
        else
          newAddedEquips[ind] = {
            ...newAddedEquips[ind],
            ...item,
            actionType: "create",
          };
      } else {
        newAddedEquips.push({
          ...item,
          roomId: room._id,
          actionType: "create",
          orderId: null,
        });
      }
    } else {
      if (isCreate && item.quantity === 0) {
        newAddedEquips.splice(ind, 1);
      } else {
        newAddedEquips[ind] = {
          ...newAddedEquips[ind],
          ...item,
          actionType: "delete",
        };
      }
    }

    this.props.setResourceAddedEquipment(newAddedEquips, this.props.room._id);

    this.setState({
      addedEquipment: newAddedEquips,
      hasEquipmentChange: true,
    });
  };

  onDoneClick = () => {
    this.props.setResourceSelectedEquipment(
      this.state.addedEquipment,
      this.props.room._id
    );
    this.props.navigateBackFromEquipment({ routedFromEquipment: true });
  };

  renderReadonlyFooter = () => {
    const { navigateBackFromEquipment } = this.props;
    return (
      <div className={`${cssBase}__readonlyFooterContainer`}>
        <Button
          className={`${cssBase}__readonlyFooterButton`}
          kind="secondary"
          onClick={navigateBackFromEquipment}
          aria-label={AppMsg.getMessage(AppMsg.BUTTON.BUTTON_BACK)}
        >
          {AppMsg.getMessage(AppMsg.BUTTON.BUTTON_BACK)}
        </Button>
      </div>
    );
  };
}

const {
  holdTimeEndSelector,
  reservationTypeSelector,
  availableEquipmentSelector,
  selectedEquipmentSelector,
  addedEquipmentSelector,
  addedEquipmentSavedSelector,
  isCreateSelector,
  detailPageRouteSelector,
} = ReservationSelectors;

const mapStateToProps = (state) => {
  return {
    room: RoomDetailsSelectors.roomDetailsSelector(state),
    holdTimeEnd: holdTimeEndSelector(state),
    reservationType: reservationTypeSelector(state),
    availableEquipment: availableEquipmentSelector(state),
    selectedEquipment: selectedEquipmentSelector(state),
    addedEquipments: addedEquipmentSelector(state),
    addedEquipmentsSaved: addedEquipmentSavedSelector(state),
    isCreate: isCreateSelector(state),
    dir: LayoutSelectors.dirSelector(state),
    isReadOnly: detailPageRouteSelector(state),
  };
};

const { navigateBackFromEquipment } = RouteActions;
const { setEquipmentId, setEquipmentDetailModal } = EquipmentActions;

export default withTriDictionary(
  connect(mapStateToProps, {
    navigateBackFromEquipment,
    setResourceSelectedEquipment:
      ReservationActions.setResourceSelectedEquipment,
    setResourceAddedEquipment: ReservationActions.setResourceAddedEquipment,
    renewHold: ReservationActions.renewHold,
    setEquipmentDetailModal,
    setEquipmentId,
  })(EquipmentListPageSmall)
);
