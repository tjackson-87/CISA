/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import PropTypes from "prop-types";
import { Route, Switch } from "react-router-dom";
import OfficeSummarySmall from "./OfficeSummarySmall";
import OfficeTimeStepSmall from "./OfficeTimeStepSmall";
import AvailabilitySmall from "../../Availability/AvailabilitySmall";
import RecurrencePageSmall from "../../Recurrence/RecurrencePageSmall";
import RoomSearchPageSmall from "../../RoomSearch/RoomSearchPageSmall";
import ChangeLocationPageSmall from "../../ChangeLocation/ChangeLocationPageSmall";
import RoomFiltersPageSmall from "../../RoomFilters/RoomFiltersPageSmall";
import RoomDetailsPageSmall from "../../RoomDetails/RoomDetailsPageSmall";
import RoomRecurrenceDetailsPageSmall from "../../RoomRecurrenceDetails/RoomRecurrenceDetailsPageSmall";
import RoomScanPage from "../../RoomScan/RoomScanPage";
import OccurrenceExceptionsPageSmall from "../../OccurrenceExceptions/OccurrenceExceptionsPageSmall";
import { Routes } from "../../../utils";

export default class OfficeReservationPageSmall extends React.PureComponent {
  static propTypes = {
    match: PropTypes.object.isRequired,
  };

  render() {
    const { path } = this.props.match;
    return (
      <Switch>
        <Route exact path={path}>
          <OfficeSummarySmall />
        </Route>
        <Route exact path={`${path}${Routes.TIME}`}>
          <OfficeTimeStepSmall />
        </Route>
        <Route exact path={`${path}${Routes.TIME}${Routes.AVAILABILITY}`}>
          <AvailabilitySmall />
        </Route>
        <Route exact path={`${path}${Routes.TIME}${Routes.RECURRENCE}`}>
          <RecurrencePageSmall />
        </Route>
        <Route exact path={`${path}${Routes.SEARCH}`}>
          <RoomSearchPageSmall />
        </Route>
        <Route exact path={`${path}${Routes.SEARCH}${Routes.LOCATION}`}>
          <ChangeLocationPageSmall />
        </Route>
        <Route exact path={`${path}${Routes.SEARCH}${Routes.SEARCH_FILTER}`}>
          <RoomFiltersPageSmall />
        </Route>
        <Route exact path={`${path}${Routes.SPACE_DETAILS}/:roomId`}>
          <RoomDetailsPageSmall />
        </Route>
        <Route exact path={`${path}${Routes.ROOM_RECURRENCE_DETAILS}/:roomId`}>
          <RoomRecurrenceDetailsPageSmall />
        </Route>
        <Route exact path={`${path}${Routes.SCAN}`}>
          <RoomScanPage />
        </Route>
        <Route exact path={`${path}${Routes.EXCEPTION}/:resourceId`}>
          {({ match }) => <OccurrenceExceptionsPageSmall match={match} />}
        </Route>
      </Switch>
    );
  }
}
