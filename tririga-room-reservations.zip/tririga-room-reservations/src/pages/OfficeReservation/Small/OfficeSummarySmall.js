/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import isEmpty from "lodash/isEmpty";
import {
  Building16,
  Time16,
  QrCode16,
  Add16,
  Search16,
} from "@carbon/icons-react";
import { InlineNotification } from "carbon-components-react";
import {
  ReservationActions,
  RouteActions,
  CurrentUserActions,
  ReservationSelectors,
  CurrentUserSelectors,
  LayoutSelectors,
  RoomSearchActions,
  RoomDetailsActions,
  ColleagueActions,
} from "../../../store";
import {
  ReservationStepLink,
  FooterButtons,
  ReservationRoomList,
  HoldCountDown,
} from "../../../components";
import {
  AppMsg,
  Barcode,
  CodeScannerConstants,
  ReservationUtils,
} from "../../../utils";
import RoomDetailsPageSmall from "../../RoomDetails/RoomDetailsPageSmall";

const { QR, BAR } = CodeScannerConstants;
const cssBase = "officeSummarySmall";

class OfficeSummarySmall extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    isReservationValid: PropTypes.bool,
    formattedDate: PropTypes.string,
    resources: PropTypes.array,
    holdTimeEnd: PropTypes.string,
    holdTimeExpired: PropTypes.bool,
    cancelReservation: PropTypes.func.isRequired,
    submitReservation: PropTypes.func.isRequired,
    removeRoom: PropTypes.func.isRequired,
    renewHold: PropTypes.func.isRequired,
    navigateBackToHomePage: PropTypes.func.isRequired,
    navigateToTime: PropTypes.func.isRequired,
    navigateToReservationSearch: PropTypes.func.isRequired,
    navigateToRoomScanPage: PropTypes.func,
    recurrence: PropTypes.object,
    reservationType: PropTypes.string,
    dir: PropTypes.string,
    favoriteRooms: PropTypes.array,
    addFavoriteRoom: PropTypes.func.isRequired,
    removeFavoriteRoom: PropTypes.func.isRequired,
    isCreate: PropTypes.bool,
    isRecurring: PropTypes.bool,
    haveUnresolvedExceptions: PropTypes.bool,
    navigateToOccurrenceExceptionsPage: PropTypes.func,
    setSelectedResource: PropTypes.func.isRequired,
    defaultTimezone: PropTypes.string,
    setRoomDetailsModal: PropTypes.func,
    setRoomId: PropTypes.func,
    initUpdatedData: PropTypes.object,
    setUserSelectedScan: PropTypes.func,
    defaultscanType: PropTypes.string,
    setSelectedColleague: PropTypes.func,
    setZoomToColleague: PropTypes.func,
    setRoomsFilter: PropTypes.func,
  };

  constructor(props) {
    super(props);
    this.workspaceDetailsRef = "";
    this.barCodeRef = React.createRef();
    this.qrCodeRef = React.createRef();
  }

  componentDidMount() {
    // CISA-520 set page title based on selected page
    document.title = this.props.appMessages[AppMsg.ORG_NAME] + ' ' + this.props.appMessages[AppMsg.CREATE_NEW_OFFICE]
    if (this.props.defaultscanType === BAR) {
      if (this.barCodeRef) setTimeout(() => this.barCodeRef.current.focus(), 1);
    } else {
      if (this.qrCodeRef) setTimeout(() => this.qrCodeRef.current.focus(), 1);
    }
  }

  render() {
    const {
      isReservationValid,
      formattedDate,
      holdTimeEnd,
      holdTimeExpired,
      removeRoom,
      renewHold,
      navigateToTime,
      navigateToReservationSearch,
      //navigateToRoomScanPage, // linter says this is an unused var
      recurrence,
      reservationType,
      dir,
      favoriteRooms,
      addFavoriteRoom,
      removeFavoriteRoom,
      isCreate,
      isRecurring,
      haveUnresolvedExceptions,
      defaultTimezone,
      setSelectedResource,
      initUpdatedData,
    } = this.props;
    const resources = ReservationUtils.getAvailableResources(
      this.props.resources
    );
    const isUnavailable = resources[0] ? resources[0].isUnavailable : false;
    const unavailableMessage = isEmpty(resources[0]?.data.userMessage)
      ? AppMsg.getMessage(AppMsg.RESERVATION_MESSAGE.OFFICE_UNAVAILABLE)
      : resources[0].data.userMessage;

    return (
      <main className={cssBase}>
        <div className={`${cssBase}__header`}>
          {/* CISA-516 add aria heading for 508 */}
          <div role="heading" aria-level="1" className={`${cssBase}__title`}>
            {this.props.appMessages[AppMsg.CREATE_NEW_OFFICE]}
          </div>

          <div>
            <Barcode
              className={`${cssBase}__header-icon`}
              onClick={() => this.handleScannerClick(BAR)}
              tabIndex={0}
              aria-labelledby="Barcode"
              onKeyDown={(e) =>
                e.key === "Enter" ? this.handleScannerClick(BAR) : null
              }
              role="link"
              ref={this.barCodeRef}
            />
            <span id="Barcode" hidden>
              {AppMsg.getMessage(AppMsg.SEARCH_LOCATION.BAR_CODE_TITLE)}
            </span>
            <span role="link">
              <QrCode16
                className={`${cssBase}__header-icon`}
                onClick={() => this.handleScannerClick(QR)}
                tabIndex="0"
                aria-label={AppMsg.getMessage(
                  AppMsg.SEARCH_LOCATION.QR_CODE_TITLE
                )}
                onKeyDown={(e) =>
                  e.key === "Enter" ? this.handleScannerClick(QR) : null
                }
                ref={this.qrCodeRef}
              />
            </span>
          </div>
        </div>
        <div className={`${cssBase}__content`}>
          <ReservationStepLink
            stepIcon={Time16}
            name={
              this.props.appMessages[
                AppMsg.RESERVATION_MESSAGE.STEP_TIME_DESCRIPTION
              ]
            }
            ariaLabel={
              this.props.appMessages[
                AppMsg.RESERVATION_MESSAGE.STEP_TIME_DESCRIPTION
              ] +
              ", " +
              formattedDate +
              `${
                !isEmpty(recurrence) && !isEmpty(recurrence.details)
                  ? ", " + recurrence.details.ruleLabel
                  : ""
              }`
            }
            children={
              isEmpty(formattedDate) ? null : (
                <div className={`${cssBase}__dateAndTime`}>
                  <div className={`${cssBase}__date`}>{formattedDate}</div>
                  {!isEmpty(recurrence) && !isEmpty(recurrence.details) && (
                    <div>{recurrence.details.ruleLabel}</div>
                  )}
                </div>
              )
            }
            className={`${cssBase}__stepLink`}
            onClick={() => navigateToTime()}
            onKeyDown={(e) =>
              e.key === "Enter" ? setTimeout(() => navigateToTime(), 1) : null
            }
          />

          <ReservationStepLink
            stepIcon={Building16}
            addIcon={resources.length > 0 ? Add16 : Search16}
            name={
              this.props.appMessages[
                AppMsg.RESERVATION_MESSAGE.STEP_OFFICE_DESCRIPTION
              ]
            }
            className={`${cssBase}__stepLink  ${cssBase}__locationLink`}
            onClick={() => {
              setSelectedResource(null);
              navigateToReservationSearch();
            }}
            onKeyDown={(e) =>
              e.key === "Enter"
                ? setTimeout(() => {
                    setSelectedResource(null);
                    navigateToReservationSearch();
                  }, 1)
                : null
            }
          />
          {holdTimeEnd != null && (
            <HoldCountDown
              holdTimeEnd={holdTimeEnd}
              onRenewHoldTime={renewHold}
              reservationType={reservationType}
            />
          )}
          {isUnavailable && (
            <InlineNotification
              className={`${cssBase}__unavailable`}
              kind="error"
              hideCloseButton
              lowContrast
              title={unavailableMessage}
              statusIconDescription={unavailableMessage}
            />
          )}
          {haveUnresolvedExceptions && (
            <div className={`${cssBase}__exceptionWarning`}>
              <InlineNotification
                kind="warning"
                hideCloseButton
                lowContrast
                title={
                  this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE
                      .STEP_ROOM_UNRESOLVED_EXCEPTIONS_WARNING_TITLE
                  ]
                }
                subtitle={
                  this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE
                      .STEP_ROOM_UNRESOLVED_EXCEPTIONS_WARNING_DESCRIPTION
                  ]
                }
                statusIconDescription={
                  this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE
                      .STEP_ROOM_UNRESOLVED_EXCEPTIONS_WARNING_TITLE
                  ]
                }
              />
            </div>
          )}
          <ReservationRoomList
            className={`${cssBase}__reservationList`}
            dir={dir}
            holdTimeExpired={holdTimeExpired}
            reservationType={reservationType}
            resources={resources}
            favorites={favoriteRooms}
            addFavoriteRoom={addFavoriteRoom}
            removeFavoriteRoom={removeFavoriteRoom}
            onRemove={removeRoom}
            isRecurring={isRecurring}
            navigateToOccurrenceExceptionsPage={(resourceId) =>
              this.handleNavigateToOccurrenceExceptionPage(resourceId)
            }
            onItemClick={this.handleItemClick}
            defaultTimezone={defaultTimezone}
            initUpdatedData={initUpdatedData}
            recurrence={recurrence}
            setRef={this.setRef}
          />
        </div>
        <FooterButtons
          secondaryLabel={this.props.appMessages[AppMsg.BUTTON.CANCEL]}
          secondaryClickedHandler={this.onCancelClick}
          primaryLabel={
            this.props.appMessages[
              isCreate ? AppMsg.BUTTON.CREATE : AppMsg.BUTTON.UPDATE
            ]
          }
          primaryClickedHandler={this.onCreateClick}
          primaryDisabled={!isReservationValid}
        />
        <RoomDetailsPageSmall
          onCloseWorkspaceDetailsModal={() =>
            this.onCloseWorkspaceDetailsModal()
          }
          isRoomSearchButton={false}
        />
      </main>
    );
  }

  handleScannerClick = (scannerType) => {
    const { navigateToRoomScanPage, setUserSelectedScan } = this.props;
    if (scannerType === QR) {
      setUserSelectedScan(QR);
      navigateToRoomScanPage(QR);
    } else {
      setUserSelectedScan(BAR);
      navigateToRoomScanPage(BAR);
    }
  };

  handleItemClick = (resource) => {
    const { setRoomId, setRoomDetailsModal } = this.props;
    this.workspaceDetailsRef = resource.data._id;
    setRoomId(resource.data.roomId);
    setRoomDetailsModal(true);
  };

  onCancelClick = async () => {
    const { navigateBackToHomePage, cancelReservation } = this.props;
    await cancelReservation();
    navigateBackToHomePage();
  };

  onCreateClick = async () => {
    const {
      navigateBackToHomePage,
      submitReservation,
      setZoomToColleague,
      setRoomsFilter,
      setSelectedColleague,
    } = this.props;
    const reservation = await submitReservation();
    if (reservation != null) {
      setSelectedColleague(null);
      setRoomsFilter([]);
      setZoomToColleague(false);
      navigateBackToHomePage();
    }
  };

  handleNavigateToOccurrenceExceptionPage(resourceId) {
    const {
      resources,
      setSelectedResource,
      navigateToOccurrenceExceptionsPage,
    } = this.props;
    const resource = resources.find((r) => r.data._id === resourceId);
    setSelectedResource(resource);
    navigateToOccurrenceExceptionsPage(resourceId);
  }

  setRef = (ref, roomId) => {
    if (ref && roomId) {
      this[roomId] = React.createRef();
      this[roomId] = ref;
    }
  };

  onCloseWorkspaceDetailsModal = () => {
    const { setRoomDetailsModal } = this.props;
    setRoomDetailsModal(false);
    if (this[this.workspaceDetailsRef]) {
      setTimeout(() => {
        this[this.workspaceDetailsRef].focus();
      }, 1);
    }
  };
}

const {
  isReservationValidSelector,
  formattedStartEndDatesSelector,
  orderedResourcesSelector,
  holdTimeEndSelector,
  holdTimeExpiredSelector,
  recurrenceSelector,
  reservationTypeSelector,
  isCreateSelector,
  unresolvedExceptionsCheckSelector,
  initUpdatedDataSelector,
} = ReservationSelectors;

const mapStateToProps = (state) => {
  return {
    dir: LayoutSelectors.dirSelector(state),
    isReservationValid: isReservationValidSelector(state),
    formattedDate: formattedStartEndDatesSelector(state),
    resources: orderedResourcesSelector(state),
    holdTimeEnd: holdTimeEndSelector(state),
    holdTimeExpired: holdTimeExpiredSelector(state),
    recurrence: recurrenceSelector(state),
    reservationType: reservationTypeSelector(state),
    favoriteRooms: CurrentUserSelectors.favoriteRoomsSelector(state),
    isCreate: isCreateSelector(state),
    isRecurring: !!recurrenceSelector(state),
    haveUnresolvedExceptions: unresolvedExceptionsCheckSelector(state),
    defaultTimezone: CurrentUserSelectors.defaultTimezoneSelector(state),
    initUpdatedData: initUpdatedDataSelector(state),
    defaultscanType: CurrentUserSelectors.scanTypeSelector(state),
  };
};

export default withTriDictionary(
  connect(mapStateToProps, {
    cancelReservation: ReservationActions.cancelNewReservation,
    submitReservation: ReservationActions.submitReservation,
    removeRoom: ReservationActions.removeRoom,
    renewHold: ReservationActions.renewHold,
    addFavoriteRoom: CurrentUserActions.addFavoriteRoom,
    removeFavoriteRoom: CurrentUserActions.removeFavoriteRoom,
    navigateBackToHomePage: RouteActions.navigateBackToHomePage,
    navigateToTime: RouteActions.navigateToTime,
    navigateToReservationSearch: RouteActions.navigateToReservationSearch,
    navigateToRoomScanPage: RouteActions.navigateToRoomScanPage,
    navigateToOccurrenceExceptionsPage:
      RouteActions.navigateToOccurrenceExceptionsPage,
    setSelectedResource: ReservationActions.setSelectedResource,
    setRoomDetailsModal: RoomSearchActions.setRoomDetailsModal,
    setRoomId: RoomDetailsActions.setRoomId,
    setUserSelectedScan: CurrentUserActions.setUserSelectedScan,
    setSelectedColleague: ColleagueActions.setSelectedColleague,
    setZoomToColleague: ColleagueActions.setZoomToColleague,
    setRoomsFilter: RoomSearchActions.setRoomsFilter,
  })(OfficeSummarySmall)
);
