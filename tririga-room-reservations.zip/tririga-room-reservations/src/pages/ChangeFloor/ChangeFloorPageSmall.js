/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import { ComposedModal, ModalHeader } from "carbon-components-react";
import { FloorSearch, RoomViewMode} from "../../components";
import {
  LocationSelectors,
  LayoutSelectors,
  LoadingSelectors,
  RoomSearchActions,
  //RoomSearchSelectors
} from "../../store";
import { AppMsg } from "../../utils";

const cssBase = "changeFloorPageSmall";

class ChangeFloorPageSmall extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    setFloorFilter: PropTypes.func,
    setSelectedRooms: PropTypes.func,
    removeCheckedRooms: PropTypes.func,
    loading: PropTypes.bool,
    dir: PropTypes.string,
    isOpen: PropTypes.bool,
    setFloorModal: PropTypes.func,
    floors: PropTypes.array,
    //floorDataResults: PropTypes.array,
    setRoomViewMode: PropTypes.func
  };

  state = {
  };

  render() {
    // Floor availability revert
    // Add floorDataResults to floors={}
    const {
      floors,
      loading,
      dir,
      isOpen,
      setFloorModal,
      //floorDataResults
    } = this.props;

    return (
      <ComposedModal open={isOpen} onClose={() => setFloorModal(false)}>
        <ModalHeader
          title={
            this.props.appMessages[
              AppMsg.RESERVATION_MESSAGE.CHANGE_FLOOR_DESCRIPTION
            ]
          }
          iconDescription={this.props.appMessages[AppMsg.BUTTON.CLOSE]}
        />
        <div className={cssBase}>
          <div className={`${cssBase}__content`}>
            <FloorSearch
              onSelect={this.handleSelectFloor}
              floors={floors}
              loading={loading}
              dir={dir}
              isModalOpen={isOpen}
            />
          </div>
        </div>
      </ComposedModal>
    );
  }

  handleSelectFloor = (floor) => {
    const { setFloorFilter, setFloorModal, removeCheckedRooms, setRoomViewMode} = this.props;
    //Clearing props
    removeCheckedRooms();
    setFloorFilter(floor);
    setFloorModal(false);
    setRoomViewMode(RoomViewMode.FLOORPLAN)
  };
}

// Floor availability revert
const mapStateToProps = (state) => {
  return {
    //floorDataResults: RoomSearchSelectors.floorDataSelector(state),
    floors: LocationSelectors.floorsSelector(state),
    loading: LoadingSelectors.searchingFloorsSelector(state),
    dir: LayoutSelectors.dirSelector(state),
  };
};

export default withTriDictionary(
  connect(mapStateToProps, {
    setRoomViewMode: RoomSearchActions.setRoomViewMode,
    setFloorFilter: RoomSearchActions.setFloorFilter,
    setFloorModal: RoomSearchActions.setFloorModal,
    removeCheckedRooms: RoomSearchActions.removeCheckedRooms,
    setSelectedRooms: RoomSearchActions.setSelectedRooms
  })(ChangeFloorPageSmall)
);
