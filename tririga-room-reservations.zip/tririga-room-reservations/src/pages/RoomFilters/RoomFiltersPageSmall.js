/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import { connect } from "react-redux";
import { AppMsg, DefaultValues, ReservationTypes } from "../../utils";
import {
  AmenitiesFilter,
  ShowCollateralTypeDropdown,
  ShowUnavailableToggle,
  ShowFavoritesToggle,
  ShowRequestableToggle,
 // ShowPrivateRoomsToggle, // hidden for CISA
 // LayoutSelectInput, // hidden for CISA
} from "../../components";
import {
  NumberInput,
  Button,
  ComposedModal,
  ModalHeader,
  ModalFooter,
  ModalBody,
} from "carbon-components-react";
import PropTypes from "prop-types";
import {
  RoomSearchActions,
  RouteActions,
  RoomSearchSelectors,
  ReservationSelectors,
  LayoutSelectors,
  LayoutTypesSelectors,
} from "../../store";
import { 
  isEmpty, 
  isEqual,
  isNull
} from "lodash";

const cssBase = "roomFiltersPageSmall";

class RoomFiltersPageSmall extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    attendees: PropTypes.array,
    filters: PropTypes.object,
    setFilters: PropTypes.func.isRequired,
    layoutTypes: PropTypes.array,
    isSearchingOnlyFavorites: PropTypes.bool,
    reservationType: PropTypes.string,
    isOpen: PropTypes.bool,
    setFilterModal: PropTypes.func,
    filterRef: PropTypes.any,
    onClose: PropTypes.func,
  };

  static getDerivedStateFromProps({ filters }, { prevFilters }) {
    if (!isEmpty(filters) && !isEqual(filters, prevFilters)) {
      return {
        ...filters,
        prevFilters: filters,
      };
    }
    return null;
  }

  state = {
    capacity: DefaultValues.CAPACITY,
    layoutType: DefaultValues.LAYOUT_TYPE,
    amenities: DefaultValues.AMENITIES,
    showCollateralTypeOnly: DefaultValues.SHOW_COLLATERAL_TYPE_ROOMS, // CISA
    showUnavailable: DefaultValues.SHOW_UNAVAILABLE_ROOMS,
    showFavoritesOnly: DefaultValues.SHOW_FAVORITES_ONLY,
    showRequestableRooms: DefaultValues.SHOW_REQUESTABLE_ROOMS,
    showPrivateRooms: DefaultValues.SHOW_PRIVATE_ROOMS,
  };

  render() {
    
    const {
     // layoutTypes, // hidden for CISA
      isSearchingOnlyFavorites,
      isSearchingCollateralType, // CISA
      reservationType,
      isOpen,
      setFilterModal,
      filterRef,
      onClose,
    } = this.props;
    const {
      capacity,
      //layoutType, // hidden for CISA
      amenities,
      showCollateralTypeOnly, // CISA
      showUnavailable,
      showFavoritesOnly,
      showRequestableRooms,
      //showPrivateRooms, // hidden for CISA
    } = this.state;

    return (
      <main aria-labelledby="roomFiltersModal">
        <ComposedModal
          id="roomFiltersModal"
          open={isOpen}
          size="sm"
          onClose={() => onClose()}
          selectorPrimaryFocus=".bx--modal-close"
          aria-label={AppMsg.getMessage(AppMsg.FILTERS_LABEL)}
        >
          <ModalHeader
            title={
              this.props.appMessages[
                AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_DESCRIPTION
              ]
            }
            iconDescription={this.props.appMessages[AppMsg.BUTTON.CLOSE]}
          >
            <Button
              className={`${cssBase}__clearAll`}
              onClick={this.handleClearAllClick}
              kind="ghost"
            >
              {this.props.appMessages[AppMsg.BUTTON.CLEAR_ALL]}
            </Button>
          </ModalHeader>
          <div className={cssBase}>
            <ModalBody
              tabIndex={-1}
              hasScrollingContent
              className={`${cssBase}__content`}
              aria-label={AppMsg.getMessage(AppMsg.ADD_FILTERS)}
            >
             <ShowCollateralTypeDropdown
              id="show-collateral-type-toggle"
              className={`${cssBase}__filterToggle`}
              selected={showCollateralTypeOnly}
              disabled={isSearchingCollateralType} 
              onChange={this.handleShowCollateralTypeDropdown}
              />
              <ShowFavoritesToggle
                id="show-favorites-only-toggle"
                className={`${cssBase}__filterToggle`}
                toggled={isSearchingOnlyFavorites ? true : showFavoritesOnly}
                disabled={isSearchingOnlyFavorites}
                onToggle={this.handleShowFavoritesToggle}
              />
              <ShowUnavailableToggle
                id="show-unavailable-rooms-toggle"
                className={`${cssBase}__filterToggle`}
                toggled={showUnavailable}
                onToggle={this.handleShowUnavailableToggle}
                reservationType={reservationType}
              />
              <ShowRequestableToggle
                id="show-requestable-rooms-toggle"
                className={`${cssBase}__filterToggle`}
                toggled={showRequestableRooms}
                onToggle={this.handleShowRequestableRoomsToggle}
                reservationType={reservationType}
              />
              {/* Hidden for CISA
              <ShowPrivateRoomsToggle
                id="show-private-rooms-toggle"
                className={`${cssBase}__filterToggle`}
                toggled={showPrivateRooms}
                onToggle={this.handleShowPrivateRoomsToggle}
                reservationType={reservationType}
              />
              */}
              {reservationType === ReservationTypes.MEETING && (
                <div>
                  <NumberInput
                    id="capacity-input"
                    className={`${cssBase}__capacityInput`}
                    label={
                      this.props.appMessages[
                        AppMsg.RESERVATION_MESSAGE
                          .STEP_ROOM_SEARCH_FILTER_CAPACITY
                      ]
                    }
                    invalidText={
                      this.props.appMessages[AppMsg.NUMBER_IS_NOT_VALID]
                    }
                    min={DefaultValues.CAPACITY_MIN}
                    max={DefaultValues.CAPACITY_MAX}
                    value={capacity}
                    step={DefaultValues.CAPACITY_STEP}
                    onChange={this.handleCapacityChanged}
                  />
                  {/* Hidden for CISA
                  <LayoutSelectInput
                    id="layoutSelect"
                    className={`${cssBase}__layoutSelect`}
                    value={layoutType.internalValue}
                    labelText={
                      this.props.appMessages[
                        AppMsg.RESERVATION_MESSAGE
                          .STEP_ROOM_SEARCH_FILTER_LAYOUT_LABEL
                      ]
                    }
                    onChange={this.handleLayoutChanged}
                    layoutTypes={layoutTypes}
                  />
                  */}
                </div>
              )}
              <AmenitiesFilter
                amenities={amenities}
                onChange={this.handleAmenitiesChanged}
                reservationType={reservationType}
                aria-label={AppMsg.getMessage(AppMsg.AMENITIES)}
              />
            </ModalBody>
            <ModalFooter>
              <Button
                kind="secondary"
                onClick={() => {
                  setFilterModal(false);
                  setTimeout(() => filterRef.current.focus(), 1);
                }}
              >
                {this.props.appMessages[AppMsg.BUTTON.CANCEL]}
              </Button>
              <Button
                kind="primary"
                onClick={() => {
                  this.onApplyClick();
                  setTimeout(() => filterRef.current.focus(), 1);
                }}
              >
                {this.props.appMessages[AppMsg.BUTTON.APPLY]}
              </Button>
            </ModalFooter>
          </div>
        </ComposedModal>
      </main>
    );
  }

  onApplyClick = () => {
    const {
      capacity,
      layoutType,
      amenities,
      showCollateralTypeOnly, // CISA
      showUnavailable,
      showFavoritesOnly,
      showRequestableRooms,
      showPrivateRooms,
    } = this.state;
    this.props.setFilters({
      capacity,
      layoutType,
      amenities,
      showCollateralTypeOnly, // CISA
      showFavoritesOnly,
      showUnavailable,
      showRequestableRooms,
      showPrivateRooms,
    });
    this.props.setFilterModal(false);
  };

  handleCapacityChanged = (e) => {
    const capacityInputValue = e.imaginaryTarget.value;
    if (!isEmpty(capacityInputValue)) {
      this.setState({ capacity: parseInt(capacityInputValue) });
    }
  };
// CISA
  handleShowCollateralTypeDropdown = (e) => {
    const showCollateralTypeOnly = e.selectedItem;
    if(!isNull(showCollateralTypeOnly) && !isEmpty(showCollateralTypeOnly)){
      this.setState({ showCollateralTypeOnly: showCollateralTypeOnly });
    } 
  };

  handleShowUnavailableToggle = () => {
    const { showUnavailable } = this.state;
    this.setState({ showUnavailable: !showUnavailable });
  };

  handleShowFavoritesToggle = () => {
    const { showFavoritesOnly } = this.state;
    this.setState({ showFavoritesOnly: !showFavoritesOnly });
  };

  handleShowRequestableRoomsToggle = () => {
    const { showRequestableRooms } = this.state;
    this.setState({ showRequestableRooms: !showRequestableRooms });
  };

  handleShowPrivateRoomsToggle = () => {
    const { showPrivateRooms } = this.state;
    this.setState({ showPrivateRooms: !showPrivateRooms });
  };

  handleLayoutChanged = (e) => {
    const layoutTypeInternalValue = e.target.value;
    if (!isEmpty(layoutTypeInternalValue)) {
      this.setState({ layoutType: { internalValue: layoutTypeInternalValue } });
    }
  };

  handleAmenitiesChanged = (amenities) => {
    this.setState({ amenities });
  };

  handleClearAllClick = (e) => {
    this.setState({
      capacity: DefaultValues.CAPACITY + this.props.attendees.length,
      layoutType: DefaultValues.LAYOUT_TYPE,
      amenities: DefaultValues.AMENITIES,
      showCollateralTypeOnly: DefaultValues.SHOW_NONCOLLATERAL_ROOMS, // CISA
      showUnavailable: DefaultValues.SHOW_UNAVAILABLE_ROOMS,
      showFavoritesOnly: DefaultValues.SHOW_FAVORITES_ONLY,
      showRequestableRooms: DefaultValues.SHOW_REQUESTABLE_ROOMS,
      showPrivateRooms: DefaultValues.SHOW_PRIVATE_ROOMS,
    });
  };
}

const mapStateToProps = (state) => {
  return {
    filters: RoomSearchSelectors.filtersSelector(state),
    layoutTypes: LayoutTypesSelectors.meetingLayoutTypesSelector(state),
    isSearchingOnlyFavorites: RoomSearchSelectors.isSearchingOnlyFavoritesSelector(
      state
    ),
    reservationType: ReservationSelectors.reservationTypeSelector(state),
    attendees: ReservationSelectors.attendeesSelector(state),
    dir: LayoutSelectors.dirSelector(state),
  };
};

const { setFilters, setFilterModal } = RoomSearchActions;
const { navigateBackToReservationSearch } = RouteActions;

export default withTriDictionary(
  connect(mapStateToProps, {
    navigateBackToReservationSearch,
    setFilters,
    setFilterModal,
  })(RoomFiltersPageSmall)
);
