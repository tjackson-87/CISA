/* IBM Confidential· - OCO Source Materials· - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise· divested of its trade secrets, irrespective of what has been· deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import classNames from "classnames";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import moment from "moment-timezone";
import {
  AppMsg,
  computeAddress,
  CateringUtils,
  cateringActionType,
  getMomentFrom,
  isValidDate,
} from "../../utils";
import { Location16, Close20 } from "@carbon/icons-react";
import { TooltipIcon } from "carbon-components-react";
import {
  CancelFoodDetailsModal,
  DiscardChangesModal,
  HoldCountDown,
} from "../../components";
import { cloneDeep, isEmpty, isEqual } from "lodash";
import {
  RouteActions,
  RoomDetailsSelectors,
  ReservationSelectors,
  ReservationActions,
  CurrenciesSelectors,
  CurrentUserSelectors,
  LayoutSelectors,
  EventDetailsSelectors,
} from "../../store";
import CateringList from "../../components/Catering/CateringList";
import CateringFooter from "../../components/Catering/CateringFooter";
import Order from "../../components/Order/Order";
import OrderList from "../../components/Order/OrderList";
import OrderFoodDetail from "../../components/Order/OrderFoodDetail";

const cssBase = "cateringListPageSmall";
class CateringListPageSmall extends React.PureComponent {
  constructor(props) {
    super(props);
    this.closeButton = React.createRef();
    this.cateringListItemRef = "";
    this.orderSummaryListRef = "";
  }

  static propTypes = {
    appMessages: PropTypes.object,
    className: PropTypes.string,
    holdTimeEnd: PropTypes.string,
    reservationType: PropTypes.string,
    room: PropTypes.object,
    navigateBackFromCatering: PropTypes.func,
    availableCatering: PropTypes.object,
    setResourceSelectedCatering: PropTypes.func,
    currencies: PropTypes.array,
    currentUserLocale: PropTypes.string,
    dateAndTime: PropTypes.object,
    renewHold: PropTypes.func.isRequired,
    selectedCatering: PropTypes.array,
    setResourceToBeUpdatedCatering: PropTypes.func,
    orderedCatering: PropTypes.array,
    toBeUpdatedCatering: PropTypes.array,
    isCreate: PropTypes.bool,
    dir: PropTypes.string,
    isReadOnly: PropTypes.bool,
    eventDetails: PropTypes.object,
  };

  state = {
    addedCatering: [],
    additionalInformation: {
      orderName: null,
      instructions: null,
      deliveryDate: null,
      deliveryTime: null,
      deliveryTimePeriod: null,
      isAllDayEvent: null,
    },
    viewOrder: false,
    viewAdditionalInformation: true,
    viewAddAnotherOrder: false,
    viewReadOnlyOrderList: this.props.isReadOnly,
    onlyOneOrderReadOnly: false,
    prevOrderIndex: "",
    currentOrderFoodDetail: null,
    viewOrderFoodDetail: false,
    currentSelectedOrderId: "",
    previousSelectedCatering: null,
    initialSelectedCatering: null,
    initialToBeUpdatedCatering: null,
    viewCancelOrderModal: false,
    viewOrderFoodDetailFromCateringList: false,
    viewDiscardChangeModal: false,
    initCurrentOrderFoodDetail: null,
  };

  static getDerivedStateFromProps(
    { dateAndTime, selectedCatering, isReadOnly },
    { prevDateAndTime, previousSelectedCatering }
  ) {
    if (dateAndTime !== prevDateAndTime) {
      const {
        startDate,
        startTime,
        startTimePeriod,
        timezone,
        locale,
      } = dateAndTime;
      const deliveryDate = getMomentFrom(
        startDate,
        startTime,
        startTimePeriod,
        timezone
      ).format();
      moment.locale(locale);
      return {
        additionalInformation: {
          deliveryDate: startDate,
          deliveryTime: isValidDate(deliveryDate)
            ? moment(deliveryDate).format("hh:mm")
            : null,
          deliveryTimePeriod: isValidDate(deliveryDate)
            ? moment(deliveryDate).format("A")
            : null,
          isAllDayEvent: dateAndTime.allDayEvent,
        },
        prevDateAndTime: dateAndTime,
      };
    }
    if (
      !isEmpty(selectedCatering) &&
      !isEqual(selectedCatering, previousSelectedCatering)
    ) {
      if (isReadOnly && selectedCatering.length === 1) {
        const order = selectedCatering ? selectedCatering[0] : null;

        if (order) {
          return {
            viewOrder: true,
            viewAddAnotherOrder: !isReadOnly,
            previousSelectedCatering: [...selectedCatering],
            onlyOneOrderReadOnly: isReadOnly && selectedCatering.length === 1,
            viewReadOnlyOrderList: false,
            currentSelectedOrderId: order.items.orderId,
            addedCatering: order.items,
            additionalInformation: order.additionalInformation,
          };
        }
      }
      return {
        viewAddAnotherOrder: !isReadOnly,
        previousSelectedCatering: [...selectedCatering],
        onlyOneOrderReadOnly: isReadOnly && selectedCatering.length === 1,
      };
    }
    return null;
  }

  render() {
    const {
      className,
      holdTimeEnd,
      reservationType,
      room,
      renewHold,
      dir,
      isReadOnly,
    } = this.props;
    const {
      addedCatering,
      viewOrder,
      viewAddAnotherOrder,
      viewOrderFoodDetail,
      currentOrderFoodDetail,
      viewOrderFoodDetailFromCateringList,
      viewReadOnlyOrderList,
      onlyOneOrderReadOnly,
      initCurrentOrderFoodDetail,
    } = this.state;

    if (room == null) return null;
    return (
      <main className={classNames(cssBase, className)}>
        <>
          <div className={`${cssBase}__title`}>
            <span>
              {
                this.props.appMessages[
                  AppMsg.RESERVATION_MESSAGE.STEP_MEETING_CATERING
                ]
              }
            </span>
            <div
              onClick={this.handleCloseEditCatering}
              onKeyDown={(e) =>
                e.key === "Enter"
                  ? setTimeout(() => this.handleCloseEditCatering(), 1)
                  : null
              }
              className={`${cssBase}__closeButton`}
            >
              <TooltipIcon
                direction="left"
                align={dir === "ltr" ? "start" : "end"}
                tooltipText={this.props.appMessages[AppMsg.BUTTON.CLOSE]}
                aria-label={this.props.appMessages[AppMsg.BUTTON.CLOSE]}
              >
                <Close20 />
              </TooltipIcon>
            </div>
          </div>
          <div className={`${cssBase}__content`}>
            {!isReadOnly && holdTimeEnd != null && (
              <HoldCountDown
                holdTimeEnd={holdTimeEnd}
                onRenewHoldTime={renewHold}
                reservationType={reservationType}
              />
            )}
            <div className={`${cssBase}__roomDetails`}>
              <div className={`${cssBase}__selectedRoom_label`}>
                {
                  this.props.appMessages[
                    isReadOnly
                      ? AppMsg.RESERVATION_MESSAGE.ROOM
                      : AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SELECTED_ROOM
                  ]
                }
                :
              </div>
              <div className={`${cssBase}__location`}>
                <Location16 className={`${cssBase}__locationIcon`} />
                <div className={`${cssBase}__room`}>{room.name}</div>
              </div>
              <div className={`${cssBase}__address`}>
                {computeAddress(room)}
              </div>
            </div>
            <div className={`${cssBase}__cateringDetails`}>
              {/* Read only calls */}
              {isReadOnly &&
                !onlyOneOrderReadOnly &&
                viewReadOnlyOrderList &&
                this.renderOrderList()}
              {(onlyOneOrderReadOnly ||
                (viewOrder &&
                  isReadOnly &&
                  !viewReadOnlyOrderList &&
                  !viewAddAnotherOrder)) &&
                this.renderOrder()}
              {/* Edit and Create calls */}
              {!isReadOnly &&
                viewAddAnotherOrder &&
                !viewOrder &&
                this.renderOrderList()}
              {!viewOrder &&
                !isReadOnly &&
                !viewAddAnotherOrder &&
                this.renderCateringList()}
              {viewOrder &&
                !isReadOnly &&
                !viewAddAnotherOrder &&
                this.renderOrder()}
            </div>
          </div>
        </>
        {(viewOrderFoodDetail || viewOrderFoodDetailFromCateringList) && (
          <OrderFoodDetail
            currentOrderFoodDetail={currentOrderFoodDetail}
            viewOrderFoodDetailFromCateringList={
              viewOrderFoodDetailFromCateringList
            }
            isReadOnly={isReadOnly}
            onCurrentFoodDetail={this.handleCurrentFoodDetail}
            onRemoveItem={(menu) => this.handleRemoveOrderItem(menu)}
            primaryDisabled={isEqual(
              initCurrentOrderFoodDetail,
              currentOrderFoodDetail
            )}
            primaryButtonLabel={AppMsg.getMessage(AppMsg.BUTTON.UPDATE)}
            onClickPrimaryButton={() =>
              this.handleAddToOrder(this.state.currentOrderFoodDetail)
            }
            secondaryButtonLabel={
              viewOrderFoodDetail ? AppMsg.getMessage(AppMsg.BUTTON.CANCEL) : ""
            }
            onClickSecondaryButton={
              isReadOnly
                ? this.handleCloseOrderFoodDetailModal
                : viewOrderFoodDetailFromCateringList
                ? this.handleToggleViewCateringList
                : () => this.handleDirtyUpdateFoodOrderDetail()
            }
            onClose={
              viewOrderFoodDetailFromCateringList
                ? this.handleToggleViewCateringList
                : this.handleCloseOrderFoodDetailModal
            }
          />
        )}
        {this.renderCancelPopup()}
        {this.renderDiscardPopup()}
        {(addedCatering ||
          viewAddAnotherOrder ||
          viewOrderFoodDetailFromCateringList ||
          viewReadOnlyOrderList) &&
          this.renderFooter()}
      </main>
    );
  }

  handleCloseEditCatering = () => {
    const { addedCatering, prevOrderIndex } = this.state;
    const { selectedCatering, isReadOnly } = this.props;
    if (isReadOnly) {
      this.onDoneClickForReadOnly();
    } else {
      if (!isEmpty(addedCatering)) {
        if (prevOrderIndex !== "") {
          if (!isEqual(selectedCatering[prevOrderIndex].items, addedCatering)) {
            this.setState({ viewDiscardChangeModal: true });
          } else {
            this.closeFoodOrder();
          }
        } else {
          this.setState({ viewDiscardChangeModal: true });
        }
      } else if (isEmpty(addedCatering) && prevOrderIndex !== "") {
        this.setState({ viewDiscardChangeModal: true });
      } else {
        this.closeFoodOrder();
      }
    }
  };

  closeFoodOrder() {
    if (this.closeButton) this.closeButton.blur();
    const { viewOrderFoodDetail } = this.state;
    if (viewOrderFoodDetail) this.handleToggleViewOrder();
    else this.props.navigateBackFromCatering();
  }

  renderOrderList = () => {
    const {
      selectedCatering,
      dir,
      dateAndTime,
      isReadOnly,
      eventDetails,
    } = this.props;
    return (
      <div className={`${cssBase}__catering_list`}>
        <OrderList
          selectedCatering={selectedCatering}
          dateAndTime={dateAndTime}
          onRemoveOrder={this.handleRemoveOrder}
          onEditOrder={this.handleEditOrder}
          dir={dir}
          isReadOnly={isReadOnly}
          eventStart={eventDetails?.start}
        />
      </div>
    );
  };

  renderFooter = () => {
    const {
      currencies,
      currentUserLocale,
      selectedCatering,
      isReadOnly,
    } = this.props;
    const {
      addedCatering,
      viewOrder,
      viewAddAnotherOrder,
      viewOrderFoodDetail,
      currentOrderFoodDetail,
      initCurrentOrderFoodDetail,
      viewOrderFoodDetailFromCateringList,
      viewReadOnlyOrderList,
      onlyOneOrderReadOnly,
    } = this.state;
    return (
      <CateringFooter
        className={`${cssBase}__footerButtons`}
        primaryLabel={this.computePrimaryLabel(this.state)}
        primaryClickedHandler={this.computePrimaryClickedHandler(this.state)}
        primaryDisabled={!!isEmpty(addedCatering) && !viewAddAnotherOrder}
        addedCatering={addedCatering}
        viewReadOnlyOrderList={viewReadOnlyOrderList}
        viewOrder={viewOrder}
        viewOrderFoodDetailFromCateringList={
          viewOrderFoodDetailFromCateringList
        }
        onlyOneOrderReadOnly={onlyOneOrderReadOnly}
        secondaryLabel={
          isReadOnly
            ? viewReadOnlyOrderList && !onlyOneOrderReadOnly
              ? AppMsg.getMessage(AppMsg.BUTTON.DONE)
              : AppMsg.getMessage(AppMsg.BUTTON.BUTTON_BACK)
            : AppMsg.getMessage(AppMsg.BUTTON.CANCEL_ORDER)
        }
        secondaryClickedHandler={
          viewOrderFoodDetail
            ? viewOrderFoodDetailFromCateringList
              ? this.handleToggleViewCateringList
              : () => this.handleDirtyUpdateFoodOrderDetail()
            : isReadOnly
            ? viewReadOnlyOrderList && !onlyOneOrderReadOnly
              ? this.onDoneClickForReadOnly
              : this.handleReadOnlyBackBtn
            : this.onCancelOrder
        }
        currency={
          !viewAddAnotherOrder && !viewReadOnlyOrderList
            ? CateringUtils.getCurrency(
                currencies,
                addedCatering[0] ||
                  currentOrderFoodDetail ||
                  this.getCurrencyOfAnyFoodItem()
              )
            : ""
        }
        viewAddAnotherOrder={viewAddAnotherOrder}
        currentUserLocale={currentUserLocale}
        viewOrderFoodDetail={viewOrderFoodDetail}
        currentOrderFoodDetail={currentOrderFoodDetail}
        initCurrentOrderFoodDetail={initCurrentOrderFoodDetail}
        onCurrentFoodDetail={this.handleCurrentFoodDetail}
        onRemoveItem={(menu) => this.handleRemoveOrderItem(menu)}
        showViewOrderDoneButton={
          viewAddAnotherOrder && selectedCatering && selectedCatering.length > 0
        }
        onViewOrderDoneClick={() => this.closeFoodOrder()}
        isReadOnly={isReadOnly}
      />
    );
  };

  computePrimaryLabel = ({
    viewOrder,
    viewAddAnotherOrder,
    viewOrderFoodDetail,
  }) =>
    viewOrder || viewOrderFoodDetail
      ? AppMsg.getMessage(AppMsg.BUTTON.COMPLETE_ORDER)
      : !viewAddAnotherOrder
      ? AppMsg.getMessage(AppMsg.BUTTON.VIEW_ORDER_SUMMARY)
      : AppMsg.getMessage(AppMsg.BUTTON.ADD_ANOTHER_ORDER);

  computePrimaryClickedHandler = ({ viewOrder, viewAddAnotherOrder }) =>
    viewOrder
      ? this.onConfirmOrder
      : !viewAddAnotherOrder
      ? this.handleToggleViewOrder
      : this.onAddAnotherOrder;

  renderOrder = () => {
    const {
      currencies,
      currentUserLocale,
      dir,
      isReadOnly,
      dateAndTime,
      eventDetails,
    } = this.props;
    const {
      addedCatering,
      viewAdditionalInformation,
      additionalInformation,
    } = this.state;
    const { startDate, startTime, startTimePeriod, timezone } = dateAndTime;
    const { endDate, endTime, endTimePeriod, locale } = dateAndTime;
    const deliveryDate = getMomentFrom(
      startDate,
      startTime,
      startTimePeriod,
      timezone
    ).format();
    moment.locale(locale);
    const deliveryEndDate = getMomentFrom(
      endDate,
      endTime,
      endTimePeriod,
      timezone
    ).format();
    moment.locale(locale);
    return (
      <Order
        orders={addedCatering}
        onAddItems={this.handleToggleViewOrder}
        viewAdditionalInformation={viewAdditionalInformation}
        onDisplayAdditionalInformation={
          this.handleToggleViewAdditionalInformation
        }
        handleQtyChanged={(e) => this.handleListChange(e)}
        onAdditionalInformation={this.handleAdditionalInformation}
        additionalInformation={additionalInformation}
        dateAndTime={dateAndTime}
        cateringStartTime={
          isValidDate(deliveryDate)
            ? moment(deliveryDate).format("hh:mm")
            : null
        }
        cateringStartTimePeriod={
          isValidDate(deliveryDate) ? moment(deliveryDate).format("A") : null
        }
        cateringEndTime={
          isValidDate(deliveryEndDate)
            ? moment(deliveryEndDate).format("hh:mm")
            : null
        }
        cateringEndTimePeriod={
          isValidDate(deliveryEndDate)
            ? moment(deliveryEndDate).format("A")
            : null
        }
        currencies={currencies}
        currentUserLocale={currentUserLocale}
        onOrderFoodDetail={this.handleOrderFoodDetail}
        dir={dir}
        isReadOnly={isReadOnly}
        eventStart={eventDetails?.start}
        setOrderRef={this.setOrderRef}
        removeOrderRef={this.closeButton}
      />
    );
  };

  renderCateringList = () => {
    const { availableCatering, currencies, currentUserLocale } = this.props;
    const { addedCatering } = this.state;
    return (
      <>
        <div className={`${cssBase}__catering_label`}>
          {
            this.props.appMessages[
              AppMsg.RESERVATION_MESSAGE.STEP_ROOM_CATERING_AVAILABLE
            ]
          }
        </div>
        <div className={`${cssBase}__catering_list`}>
          <CateringList
            availableCatering={availableCatering}
            addedCatering={addedCatering}
            handleListChange={(e) => this.handleListChange(e)}
            currencies={currencies}
            currentUserLocale={currentUserLocale}
            onOrderFoodDetail={this.handleOrderFoodDetail}
            setMenuItemRef={this.setMenuItemRef}
          />
        </div>
      </>
    );
  };

  setMenuItemRef = (ref, menuId) => {
    this[menuId] = React.createRef();
    this[menuId] = ref;
  };

  setOrderRef = (ref, orderId) => {
    this[orderId] = React.createRef();
    this[orderId] = ref;
  };

  onDoneClickForReadOnly = () => {
    this.props.navigateBackFromCatering();
  };

  handleOrderFoodDetail = (order) => {
    if (!this.state.viewOrder) {
      this.setState({
        viewOrderFoodDetailFromCateringList: true,
        currentOrderFoodDetail: order,
      });
      this.cateringListItemRef = order._id;
    } else {
      this.setState({
        currentOrderFoodDetail: order,
        viewOrderFoodDetail: true,
        viewOrder: true,
        initCurrentOrderFoodDetail: { ...order },
      });
      this.orderSummaryListRef = order._id;
    }
  };

  handleCurrentFoodDetail = (currentOrderFoodDetail) => {
    this.setState({ currentOrderFoodDetail });
  };

  handleAddToOrder = async (currentOrderFoodDetail) => {
    await this.handleListChange(currentOrderFoodDetail);
    this.setState({
      viewOrderFoodDetail: false,
    });
    if (this.orderSummaryListRef.current)
      setTimeout(() => this.orderSummaryListRef.current.focus(), 1);
  };

  handleToggleViewOrder = () => {
    this.setState({
      viewOrder: !this.state.viewOrder,
      viewOrderFoodDetail: false,
    });
    if (this.closeButton) this.closeButton.focus();
  };

  handleCloseOrderFoodDetailModal = () => {
    this.setState({
      viewOrder: true,
      viewOrderFoodDetail: false,
    });
    if (this[this.orderSummaryListRef]) {
      setTimeout(() => {
        this[this.orderSummaryListRef].focus();
      }, 1);
    }
  };

  handleToggleViewCateringList = () => {
    this.setState({
      viewOrderFoodDetail: false,
      viewOrderFoodDetailFromCateringList: !this.state
        .viewOrderFoodDetailFromCateringList,
    });
    if (
      this.state.viewOrderFoodDetailFromCateringList &&
      this[this.cateringListItemRef]
    ) {
      setTimeout(() => {
        this[this.cateringListItemRef].focus();
      }, 1);
    }
  };

  onAddAnotherOrder = () => {
    const { additionalInformation } = this.state;
    this.setState({
      viewAddAnotherOrder: false,
      prevOrderIndex: "",
      currentSelectedOrderId: "",
      addedCatering: [],
      additionalInformation: {
        ...additionalInformation,
        orderName: "",
      },
    });
    if (this.closeButton) this.closeButton.focus();
  };

  handleToggleViewAdditionalInformation = () => {
    this.setState({
      viewAdditionalInformation: !this.state.viewAdditionalInformation,
    });
  };

  handleReadOnlyBackBtn = () => {
    this.setState({
      viewOrder: false,
      viewReadOnlyOrderList: true,
      onlyOneOrderReadOnly: false,
    });
  };

  handleRemoveOrder = (index) => {
    this.setState({
      viewCancelOrderModal: !this.state.viewCancelOrderModal,
      prevOrderIndex: index,
    });
  };

  handleCancelOrder = (index) => {
    const {
      room,
      selectedCatering,
      toBeUpdatedCatering,
      setResourceToBeUpdatedCatering,
      setResourceSelectedCatering,
      isCreate,
    } = this.props;
    const updateSelectedCatering = [...selectedCatering];
    const [removedCatering] = updateSelectedCatering.splice(index, 1);
    const removedIndex = toBeUpdatedCatering.findIndex(
      (c) => c.items[0].orderId === removedCatering.items[0].orderId
    );

    const updateOrderedCatering = cloneDeep(toBeUpdatedCatering);
    isCreate
      ? updateOrderedCatering.splice(removedIndex, 1)
      : (updateOrderedCatering[removedIndex] = {
          ...updateOrderedCatering[removedIndex],
          actionType: cateringActionType.REMOVE,
        });
    if (isCreate) {
      const spliceUpdateOrderedCatering = updateOrderedCatering.splice(
        removedIndex,
        removedIndex >= 1
          ? updateOrderedCatering.length - 1
          : updateOrderedCatering.length
      );
      const resultedCatering = spliceUpdateOrderedCatering.map((catering) => ({
        ...catering,
        items: catering.items.map((item) => ({
          ...item,
          orderId: item.orderId - 1,
        })),
      }));
      const finalToBeUpdatedCatering = [
        ...updateOrderedCatering,
        ...resultedCatering,
      ];
      setResourceToBeUpdatedCatering(finalToBeUpdatedCatering, room._id);
      const updatedSelectedCatering = updateSelectedCatering.splice(
        removedIndex,
        removedIndex >= 1
          ? updateSelectedCatering.length - 1
          : updateSelectedCatering.length
      );
      const newCatering = updatedSelectedCatering.map((catering) => ({
        ...catering,
        items: catering.items.map((item) => ({
          ...item,
          orderId: item.orderId - 1,
        })),
      }));
      const finalSelectedCatering = [...updateSelectedCatering, ...newCatering];
      setResourceSelectedCatering(finalSelectedCatering, room._id);
    } else {
      setResourceToBeUpdatedCatering(updateOrderedCatering, room._id);
      setResourceSelectedCatering([...updateSelectedCatering], room._id);
    }
  };

  onCancelOrder = () => {
    this.setState({ viewCancelOrderModal: !this.state.viewCancelOrderModal });
  };

  renderCancelPopup = () => {
    const { viewCancelOrderModal } = this.state;
    const header = AppMsg.getMessage(
      AppMsg.RESERVATION_MESSAGE.DELETE_CATERING_ORDER
    );
    return (
      <CancelFoodDetailsModal
        header={header}
        viewCancelOrderModal={viewCancelOrderModal}
        handleModalCancelClick={this.onHandleModalCancelClick}
        onClose={this.handleCloseFoodDetaildModel}
        cssBase={cssBase}
      />
    );
  };

  getCurrencyOfAnyFoodItem = () => {
    const { availableCatering } = this.props;
    const firstKey = Object.keys(availableCatering)[0];
    const result = availableCatering[firstKey][0];
    return result;
  };

  handleCloseFoodDetaildModel = () => {
    this.setState({ viewCancelOrderModal: false });
    if (this.closeButton) setTimeout(() => this.closeButton.focus(), 1);
  };

  onHandleModalCancelClick = () => {
    const { prevOrderIndex } = this.state;
    const { selectedCatering } = this.props;
    this.setState({ viewCancelOrderModal: false });
    if (prevOrderIndex !== "") {
      this.handleCancelOrder(prevOrderIndex);
      this.setState({ viewOrder: false });
      if (prevOrderIndex >= 1) {
        this.setState({ prevOrderIndex: prevOrderIndex - 1 });
      }
    }
    if (prevOrderIndex === "" || selectedCatering.length === 1)
      this.props.navigateBackFromCatering({ routedFromCatering: true });
    else {
      if (this.closeButton) setTimeout(() => this.closeButton.focus(), 1);
    }
  };

  handleEditOrder = (order, key) => {
    const orderId = order.items[0].orderId;
    this.setState({
      viewAddAnotherOrder: false,
      prevOrderIndex: key,
      currentSelectedOrderId: orderId,
      addedCatering: [...order.items],
      additionalInformation: order.additionalInformation,
    });
    if (this.props.isReadOnly) {
      this.setState({
        viewOrder: true,
        viewReadOnlyOrderList: false,
      });
    }
    if (this.closeButton) this.closeButton.focus();
  };

  handleAdditionalInformation = (value, key) => {
    const additionalInformation = {
      [key]: value,
    };
    this.setState({
      additionalInformation: {
        ...this.state.additionalInformation,
        ...additionalInformation,
      },
    });
  };

  handleUpdateItemsInToBeUpdatedCatering = (
    toBeReplaced,
    newCatering,
    originalItemProdIds,
    hasOrdered
  ) => {
    const updateItems = newCatering.items.filter((item) =>
      originalItemProdIds.includes(item._id)
    );
    toBeReplaced.items.forEach((item, index) => {
      updateItems.forEach((upItem) => {
        if (upItem._id === item._id) {
          const actionType = hasOrdered
            ? cateringActionType.UPDATE
            : cateringActionType.ADD;
          toBeReplaced.items[index] = { ...upItem, actionType };
        }
      });
    });
  };

  handleRemoveItemsInToBeUpdatedCatering = (toBeReplaced, newItemProdIds) => {
    toBeReplaced.items.filter((item) => !newItemProdIds.includes(item._id));
    toBeReplaced.items.forEach((item, index) => {
      if (!newItemProdIds.includes(item._id)) {
        toBeReplaced.items[index] = {
          ...toBeReplaced.items[index],
          actionType: cateringActionType.REMOVE,
        };
      }
    });
  };

  handlAddItemsInToBeUpdatedCatering = (
    toBeReplaced,
    newCatering,
    originalItemProdIds,
    newCateringOrderId
  ) => {
    const addItems = newCatering.items.filter(
      (item) => !originalItemProdIds.includes(item._id)
    );
    if (addItems?.length)
      toBeReplaced.items.push(
        ...addItems.map((item) => ({
          ...item,
          orderId: newCateringOrderId,
          actionType: cateringActionType.ADD,
        }))
      );
  };

  mapSelectedCateringToToBeUpdatedCatering(
    toBeUpdatedCateringOrders,
    newCatering,
    orderedCatering
  ) {
    const newCateringOrderId = newCatering.items[0].orderId;
    const toBeReplaced = toBeUpdatedCateringOrders.find(
      (order) => order.items[0].orderId === newCateringOrderId
    );

    if (toBeReplaced) {
      const originalItemProdIds = toBeReplaced.items.map((p) => p._id);
      const newItemProdIds = newCatering.items.map((p) => p._id);

      const hasOrdered =
        orderedCatering?.length &&
        orderedCatering.some(
          (cOrder) => cOrder.items[0].orderId === newCateringOrderId
        );
      toBeReplaced.actionType = hasOrdered
        ? cateringActionType.UPDATE
        : cateringActionType.ADD;
      toBeReplaced.additionalInformation = {
        ...newCatering.additionalInformation,
      };

      this.handleUpdateItemsInToBeUpdatedCatering(
        toBeReplaced,
        newCatering,
        originalItemProdIds,
        hasOrdered
      );

      this.handleRemoveItemsInToBeUpdatedCatering(toBeReplaced, newItemProdIds);

      this.handlAddItemsInToBeUpdatedCatering(
        toBeReplaced,
        newCatering,
        originalItemProdIds,
        newCateringOrderId
      );
    }
  }

  onConfirmOrder = () => {
    const { addedCatering, additionalInformation, prevOrderIndex } = this.state;
    const {
      selectedCatering,
      room,
      orderedCatering,
      toBeUpdatedCatering,
    } = this.props;
    let newCatering = { items: addedCatering, additionalInformation };
    let toBeUpdatedCateringOrders = cloneDeep(toBeUpdatedCatering);
    if (prevOrderIndex !== "") {
      selectedCatering[prevOrderIndex] = newCatering;
      this.mapSelectedCateringToToBeUpdatedCatering(
        toBeUpdatedCateringOrders,
        newCatering,
        orderedCatering
      );
      newCatering = selectedCatering;
    } else {
      if (!isEmpty(selectedCatering)) {
        const tempOrderId = `${toBeUpdatedCateringOrders.length}`;
        toBeUpdatedCateringOrders = [
          ...toBeUpdatedCateringOrders,
          {
            ...newCatering,
            items: newCatering.items.map((item) => ({
              ...item,
              orderId: tempOrderId,
              actionType: cateringActionType.ADD,
            })),
            actionType: cateringActionType.ADD,
          },
        ];
        newCatering = [
          ...selectedCatering,
          {
            ...newCatering,
            items: newCatering.items.map((item) => ({
              ...item,
              orderId: tempOrderId,
            })),
          },
        ];
      } else {
        toBeUpdatedCateringOrders = [
          ...(toBeUpdatedCateringOrders || []),
          {
            ...newCatering,
            actionType: cateringActionType.ADD,
            items: newCatering.items.map((i) => ({
              ...i,
              actionType: cateringActionType.ADD,
            })),
          },
        ];
        newCatering = [newCatering];
      }
    }
    this.props.setResourceSelectedCatering(newCatering, room._id);
    this.props.setResourceToBeUpdatedCatering(
      toBeUpdatedCateringOrders,
      room._id
    );
    this.props.navigateBackFromCatering({ routedFromCatering: true });
  };

  handleListChange = (menu) => {
    const {
      addedCatering,
      viewOrder,
      viewAdditionalInformation,
      currentSelectedOrderId,
    } = this.state;
    const { room } = this.props;
    let newCatering = null;
    if (menu.qty > 0) {
      const index = addedCatering.findIndex(
        (s) => s.roomId === room._id && s._id === menu._id
      );
      if (index !== -1) {
        addedCatering[index] = {
          ...addedCatering[index],
          ...menu,
        };
        newCatering = [...addedCatering];
      } else {
        newCatering = [
          ...addedCatering,
          { ...menu, orderId: currentSelectedOrderId, roomId: room._id },
        ];
      }
    } else {
      newCatering = addedCatering.filter((s) => s._id !== menu._id);
    }
    this.setState({
      addedCatering: newCatering,
      viewOrder: !isEmpty(newCatering) ? viewOrder : false,
      viewAdditionalInformation: !isEmpty(newCatering)
        ? viewAdditionalInformation
        : false,
    });
  };

  handleRemoveOrderItem(menu) {
    const { addedCatering } = this.state;
    const newCatering = addedCatering.filter((s) => s._id !== menu._id);
    this.setState(() => ({
      addedCatering: newCatering,
      viewOrderFoodDetail: false,
      viewOrder: !isEmpty(newCatering),
    }));
    if (this.closeButton) setTimeout(() => this.closeButton.focus(), 1);
  }

  renderDiscardPopup() {
    const { viewDiscardChangeModal } = this.state;
    const header = AppMsg.getMessage(
      AppMsg.RESERVATION_MESSAGE.DISCARD_CHANGES
    );
    const content = AppMsg.getMessage(
      AppMsg.RESERVATION_MESSAGE.DISCARD_CATERING_MESSAGE
    );
    return (
      <DiscardChangesModal
        header={header}
        content={content}
        viewDiscardChangeModal={viewDiscardChangeModal}
        onClose={this.handleOnDiscardModalClose}
        handleDiscard={this.onHandleDiscard}
      />
    );
  }

  handleOnDiscardModalClose = () => {
    this.setState({ viewDiscardChangeModal: false });
    if (this.closeButton) setTimeout(() => this.closeButton.focus(), 1);
  };

  handleDirtyUpdateFoodOrderDetail() {
    const { initCurrentOrderFoodDetail, currentOrderFoodDetail } = this.state;
    if (isEqual(initCurrentOrderFoodDetail, currentOrderFoodDetail)) {
      this.handleCloseOrderFoodDetailModal();
    } else {
      this.setState({ viewDiscardChangeModal: true });
    }
  }

  onHandleDiscard = () => {
    const {
      viewOrderFoodDetail,
      initialSelectedCatering,
      initialToBeUpdatedCatering,
    } = this.state;
    if (viewOrderFoodDetail) {
      this.handleCloseOrderFoodDetailModal();
      this.setState({ viewDiscardChangeModal: false });
    } else {
      this.closeFoodOrder();
      const {
        room,
        setResourceToBeUpdatedCatering,
        setResourceSelectedCatering,
      } = this.props;
      setResourceToBeUpdatedCatering(initialToBeUpdatedCatering, room._id);
      setResourceSelectedCatering(initialSelectedCatering, room._id);
    }
  };

  handleCloseDirtyPopup() {
    this.setState({ viewDiscardChangeModal: false });
  }

  componentDidMount() {
    const { selectedCatering, toBeUpdatedCatering, isReadOnly } = this.props;
    if (!isEmpty(selectedCatering)) {
      this.setState({
        viewAddAnotherOrder: !isReadOnly,
      });
      if (isReadOnly && selectedCatering.length === 1) {
        const order = selectedCatering ? selectedCatering[0] : null;
        if (order) {
          this.setState({
            viewOrder: true,
            onlyOneOrderReadOnly: isReadOnly && selectedCatering.length === 1,
            viewReadOnlyOrderList: false,
            currentSelectedOrderId: order.items.orderId,
            addedCatering: order.items,
            additionalInformation: order.additionalInformation,
          });
        }
      }
    }
    if (selectedCatering && selectedCatering.length) {
      this.setState({
        previousSelectedCatering: cloneDeep(selectedCatering),
        initialSelectedCatering: cloneDeep(selectedCatering),
        initialToBeUpdatedCatering: cloneDeep(toBeUpdatedCatering),
      });
    }

    setTimeout(() => {
      const element = document.querySelector(".bx--tooltip__trigger");
      this.closeButton = element;
      if (this.closeButton) this.closeButton.focus();
    }, 1000);
  }
}

const {
  holdTimeEndSelector,
  reservationTypeSelector,
  availableCateringSelector,
  selectedCateringsSelector,
  orderedCateringsSelector,
  toBeUpdatedCateringsSelector,
  detailPageRouteSelector,
} = ReservationSelectors;

const mapStateToProps = (state) => {
  return {
    room: RoomDetailsSelectors.roomDetailsSelector(state),
    holdTimeEnd: holdTimeEndSelector(state),
    reservationType: reservationTypeSelector(state),
    availableCatering: availableCateringSelector(state),
    currencies: CurrenciesSelectors.currenciesSelector(state),
    currentUserLocale: CurrentUserSelectors.localeSelector(state),
    selectedCatering: selectedCateringsSelector(state),
    orderedCatering: orderedCateringsSelector(state),
    dateAndTime: ReservationSelectors.timeStepTempDateAndTimeSelector(state),
    isCreate: ReservationSelectors.isCreateSelector(state),
    toBeUpdatedCatering: toBeUpdatedCateringsSelector(state),
    dir: LayoutSelectors.dirSelector(state),
    isReadOnly: detailPageRouteSelector(state),
    eventDetails: EventDetailsSelectors.eventDetailsSelector(state),
  };
};

const { navigateBackFromCatering } = RouteActions;

export default withTriDictionary(
  connect(mapStateToProps, {
    navigateBackFromCatering,
    setResourceSelectedCatering: ReservationActions.setResourceSelectedCatering,
    setResourceToBeUpdatedCatering:
      ReservationActions.setResourceToBeUpdatedCatering,
    renewHold: ReservationActions.renewHold,
  })(CateringListPageSmall)
);
