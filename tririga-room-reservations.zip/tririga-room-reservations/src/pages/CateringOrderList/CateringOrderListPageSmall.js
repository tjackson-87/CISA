/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import { connect } from "react-redux";
import moment from "moment-timezone";
import {
  AppMsg,
  DefaultValues,
  computeAddress,
  cateringActionType,
} from "../../utils";
import { TrashCan16, Location16 } from "@carbon/icons-react";
import { cloneDeep, isNil } from "lodash";

import {
  TooltipIcon,
  ComposedModal,
  ModalHeader,
  ModalBody,
  ToastNotification,
} from "carbon-components-react";
import PropTypes from "prop-types";
import {
  LayoutSelectors,
  RoomDetailsSelectors,
  ReservationSelectors,
  ReservationActions,
} from "../../store";

const cssBase = "cateringOrderListPageSmall";

class CateringOrderListPageSmall extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    isOpen: PropTypes.bool,
    onClosePopUp: PropTypes.func,
    room: PropTypes.object,
    selectedCatering: PropTypes.array,
    dir: PropTypes.string,
    setResourceSelectedCatering: PropTypes.func,
    setResourceToBeUpdatedCatering: PropTypes.func,
    isCreate: PropTypes.bool,
    toBeUpdatedCatering: PropTypes.array,
  };

  renderOrderList = () => {
    const { selectedCatering, room, dir } = this.props;
    if (!room) return null;
    return (
      <div className={`${cssBase}__content`}>
        {selectedCatering &&
          selectedCatering.map((order, key) => (
            <div className={`${cssBase}__details`} key={key}>
              <div className={`${cssBase}__order`}>
                <div className={`${cssBase}__title`}>
                  {order.additionalInformation.orderName ||
                    AppMsg.getMessage(AppMsg.RESERVATION_MESSAGE.FOOD_ORDER)}
                </div>
                <div className={`${cssBase}__date`}>
                  {`${moment(order.additionalInformation.deliveryDate).format(
                    DefaultValues.CATERING_DATE_FORMAT
                  )}, ${order.additionalInformation.deliveryTime} ${
                    order.additionalInformation.deliveryTimePeriod
                  }`}
                </div>
              </div>
              <TooltipIcon
                direction="left"
                align={dir === "ltr" ? "start" : "end"}
                tooltipText={
                  this.props.appMessages[AppMsg.BUTTON.BUTTON_DELETE]
                }
                aria-label={this.getDeleteBtnAreaLabel(order)}
                onClick={() => this.handleCancelOrder(key)}
              >
                <TrashCan16 />
              </TooltipIcon>
            </div>
          ))}
      </div>
    );
  };

  getDeleteBtnAreaLabel = (order) => {
    if (
      order &&
      order.additionalInformation &&
      !isNil(order.additionalInformation.orderName)
    ) {
      return `${this.props.appMessages[AppMsg.BUTTON.BUTTON_DELETE]} ${
        order.additionalInformation.orderName
      } ${AppMsg.getMessage(AppMsg.RESERVATION_MESSAGE.FOOD_ORDER)}`;
    }
    return `${
      this.props.appMessages[AppMsg.BUTTON.BUTTON_DELETE]
    } ${AppMsg.getMessage(AppMsg.RESERVATION_MESSAGE.FOOD_ORDER)}`;
  };

  handleCancelOrder = (index) => {
    const {
      room,
      selectedCatering,
      toBeUpdatedCatering,
      setResourceToBeUpdatedCatering,
      setResourceSelectedCatering,
      isCreate,
    } = this.props;
    const updateSelectedCatering = [...selectedCatering];
    const [removedCatering] = updateSelectedCatering.splice(index, 1);
    const removedIndex = toBeUpdatedCatering.findIndex(
      (c) => c.items[0].orderId === removedCatering.items[0].orderId
    );

    const updateOrderedCatering = cloneDeep(toBeUpdatedCatering);
    isCreate
      ? updateOrderedCatering.splice(removedIndex, 1)
      : (updateOrderedCatering[removedIndex] = {
          ...updateOrderedCatering[index],
          actionType: cateringActionType.REMOVE,
        });
    if (isCreate) {
      const spliceUpdateOrderedCatering = updateOrderedCatering.splice(
        removedIndex,
        removedIndex >= 1
          ? updateOrderedCatering.length - 1
          : updateOrderedCatering.length
      );
      const resultedCatering = spliceUpdateOrderedCatering.map((catering) => ({
        ...catering,
        items: catering.items.map((item) => ({
          ...item,
          orderId: item.orderId - 1,
        })),
      }));
      const finalToBeUpdatedCatering = [
        ...updateOrderedCatering,
        ...resultedCatering,
      ];
      setResourceToBeUpdatedCatering(finalToBeUpdatedCatering, room._id);
      const updatedSelectedCatering = updateSelectedCatering.splice(
        removedIndex,
        removedIndex >= 1
          ? updateSelectedCatering.length - 1
          : updateSelectedCatering.length
      );
      const newCatering = updatedSelectedCatering.map((catering) => ({
        ...catering,
        items: catering.items.map((item) => ({
          ...item,
          orderId: item.orderId - 1,
        })),
      }));
      const finalSelectedCatering = [...updateSelectedCatering, ...newCatering];
      setResourceSelectedCatering(finalSelectedCatering, room._id);
    } else {
      setResourceToBeUpdatedCatering(updateOrderedCatering, room._id);
      setResourceSelectedCatering([...updateSelectedCatering], room._id);
    }
  };

  render() {
    const { isOpen, onClosePopUp, room } = this.props;

    return (
      <main aria-labelledby="cateringModal">
        <ComposedModal
          id="cateringModal"
          open={isOpen}
          size="sm"
          onClose={() => {
            onClosePopUp();
          }}
          selectorPrimaryFocus=".bx--modal-close"
          aria-label={
            this.props.appMessages[
              AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_CATERING
            ]
          }
        >
          <ModalHeader
            title={
              this.props.appMessages[
                AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_CATERING
              ]
            }
            iconDescription={this.props.appMessages[AppMsg.BUTTON.CLOSE]}
          />
          <div className={cssBase}>
            <ModalBody
              tabIndex={-1}
              hasScrollingContent
              className={`${cssBase}__modalContent`}
              aria-label={
                this.props.appMessages[
                  AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_CATERING
                ]
              }
            >
              <div className={`${cssBase}__notificationHeader`}>
                <ToastNotification
                  className={`${cssBase}__notification`}
                  tabIndex={0}
                  kind="info"
                  lowContrast
                  hideCloseButton={true}
                  notificationType="toast"
                  title={
                    this.props.appMessages[
                      AppMsg.RESERVATION_MESSAGE
                        .CATERING_WARNING_MESSAGE_FOR_PAST_START_DATE_TITLE
                    ]
                  }
                  subtitle={
                    <span>
                      {
                        this.props.appMessages[
                          AppMsg.RESERVATION_MESSAGE
                            .CATERING_WARNING_MESSAGE_FOR_PAST_START_DATE
                        ]
                      }
                    </span>
                  }
                />
              </div>
              <div>
                <div className={`${cssBase}__roomDetails`}>
                  <div className={`${cssBase}__selectedRoom_label`}>
                    {
                      this.props.appMessages[
                        AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SELECTED_ROOM
                      ]
                    }
                    :
                  </div>
                  <div className={`${cssBase}__location`}>
                    <Location16 className={`${cssBase}__locationIcon`} />
                    <div className={`${cssBase}__room`}>
                      {room && room.name}
                    </div>
                  </div>
                  <div className={`${cssBase}__address`}>
                    {room && computeAddress(room)}
                  </div>
                </div>
                {this.renderOrderList()}
              </div>
            </ModalBody>
          </div>
        </ComposedModal>
      </main>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    dir: LayoutSelectors.dirSelector(state),
    room: RoomDetailsSelectors.roomDetailsSelector(state),
    selectedCatering: ReservationSelectors.selectedCateringsSelector(state),
    isCreate: ReservationSelectors.isCreateSelector(state),
    toBeUpdatedCatering: ReservationSelectors.toBeUpdatedCateringsSelector(
      state
    ),
  };
};

export default withTriDictionary(
  connect(mapStateToProps, {
    setResourceSelectedCatering: ReservationActions.setResourceSelectedCatering,
    setResourceToBeUpdatedCatering:
      ReservationActions.setResourceToBeUpdatedCatering,
  })(CateringOrderListPageSmall)
);
