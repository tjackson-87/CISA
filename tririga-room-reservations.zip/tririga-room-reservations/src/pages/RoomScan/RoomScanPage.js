/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import { isEmpty, isEqual } from "lodash";

import {
  ReservationSelectors,
  RoomSearchSelectors,
  RoomSearchActions,
  ReservationActions,
  RouteActions,
  LayoutSelectors,
} from "../../store";
import { CodeScanner } from "../../components";
import { CodeScannerConstants } from "../../utils";

const cssBase = "roomScanPage";
const { CAPTURE_TIME, TIME_OUT } = CodeScannerConstants;
let lastRecurrence = null;
class RoomScanPage extends React.PureComponent {
  static propTypes = {
    holdRooms: PropTypes.func.isRequired,
    searchRoomByCode: PropTypes.func.isRequired,
    setScannerType: PropTypes.func.isRequired,
    navigateToReservationSummary: PropTypes.func.isRequired,
    scannedResult: PropTypes.object,
    resources: PropTypes.array,
    scannerType: PropTypes.string,
    dir: PropTypes.string,
    rooms: PropTypes.array,
    recurrence: PropTypes.object,
  };

  static defaultProps = {
    resources: [],
    scannedResult: {},
    scannerType: "",
  };

  state = {
    scanning: false,
    found: false,
    isNotAvailable: false,
    detected: false,
    play: null,
    isTimeout: false,
    addedRoom: false,
  };

  render() {
    const {
      found,
      isNotAvailable,
      scanning,
      detected,
      isTimeout,
      addedRoom,
    } = this.state;
    const { scannerType } = this.props;
    return scannerType ? (
      <div className={cssBase}>
        <CodeScanner
          scannerType={scannerType}
          scanning={scanning}
          found={found}
          isNotAvailable={isNotAvailable}
          detected={detected}
          isTimeout={isTimeout}
          addedRoom={addedRoom}
          onScan={(code) => this.handleScannedCode(code)}
          onClose={() => this.close()}
          onSelectAnyway={() => this.handleSelectAnyway()}
          onScanAnother={() => this.handleScanAgain()}
          onResume={(play) => this.setState({ play })}
          onTryAgain={() => this.handleScanAgain()}
          dir={this.props.dir}
        />
      </div>
    ) : null;
  }

  async handleScannedCode(code) {
    const {
      resources,
      searchRoomByCode,
      scannedResult,
      recurrence,
    } = this.props;
    if (!code) return;
    const addedRoom =
      resources &&
      resources.length &&
      resources.some((resource) => resource.room?.barcode === code);
    this.setState({ scanning: true });

    if (scannedResult && scannedResult.barcode === code && !addedRoom) {
      this.setState({ detected: true });
      if (!isEmpty(recurrence) && !isEqual(recurrence, lastRecurrence)) {
        lastRecurrence = recurrence;
      } else {
        this.handleResult(scannedResult);
        return;
      }
    }

    if (addedRoom) {
      this.setState({
        scanning: false,
        found: true,
        detected: true,
        addedRoom,
      });
      clearTimeout(this.timeout);
      return;
    }
    await searchRoomByCode(code);
    this.setState({ detected: true });
  }

  async handleResult(scannedResult) {
    if (isEmpty(scannedResult)) {
      this.handleNotFound();
    } else {
      await this.handleFound(scannedResult);
    }
  }

  async handleFound(reservableRoom) {
    const { rooms, holdRooms } = this.props;
    const { isAvailable } = reservableRoom;
    this.setState({ scanning: false, found: true });
    const newRooms = rooms.filter((r) => r.roomId !== reservableRoom.roomId);
    if (isAvailable) {
      await holdRooms([...newRooms, reservableRoom]);
      setTimeout(() => {
        this.close();
      }, CAPTURE_TIME);
    } else {
      this.setState({ isNotAvailable: true });
      clearTimeout(this.timeout);
    }
  }

  handleNotFound() {
    this.setState({ found: false, scanning: false });
    clearTimeout(this.timeout);
  }

  async handleSelectAnyway() {
    const { holdRooms, rooms, scannedResult } = this.props;
    await holdRooms([...rooms, scannedResult]);
    await this.state.play();
    this.close();
  }

  async handleScanAgain() {
    this.reset();
    await this.state.play();
  }

  componentDidMount() {
    if (this.props.scannerType) {
      this.resetTimeOut();
    } else {
      this.props.navigateToReservationSummary();
    }
  }

  resetTimeOut() {
    if (this.timeout) {
      clearTimeout(this.timeout);
      this.setState({ isTimeout: false });
    }
    this.timeout = setTimeout(() => {
      this.setState({ isTimeout: true });
    }, TIME_OUT);
  }

  close() {
    this.reset();
    clearTimeout(this.timeout);
    this.setState({ scannerType: "" });
    this.props.setScannerType("");
    this.props.navigateToReservationSummary();
  }

  reset() {
    this.setState({
      isNotAvailable: false,
      scanning: false,
      found: false,
      detected: false,
      addedRoom: false,
    });
    this.resetTimeOut();
  }

  async componentDidUpdate({ scannedResult }, { detected }) {
    if (
      (this.state.detected !== detected &&
        this.state.detected &&
        isEmpty(this.props.scannedResult)) ||
      !isEqual(this.props.scannedResult, scannedResult)
    ) {
      await this.handleResult(this.props.scannedResult);
    }
  }
}

const mapStateToProps = (state) => {
  return {
    resources: ReservationSelectors.orderedResourcesSelector(state),
    scannedResult: RoomSearchSelectors.roomSearchScannedResultSelector(state),
    scannerType: RoomSearchSelectors.scannerTypeSelector(state),
    dir: LayoutSelectors.dirSelector(state),
    rooms: ReservationSelectors.roomsSelector(state),
    recurrence: ReservationSelectors.recurrenceSelector(state),
  };
};

export default connect(mapStateToProps, {
  holdRooms: ReservationActions.holdRooms,
  searchRoomByCode: RoomSearchActions.searchRoomByCode,
  setScannerType: RoomSearchActions.setScannerType,
  navigateToReservationSummary: RouteActions.navigateToReservationSummary,
})(RoomScanPage);
