/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import { Breadcrumb, BreadcrumbItem } from "carbon-components-react";
import { ReservationProgressIndicator } from "../../../components";
import DefineMeetingStepLarge from "./DefineMeetingStepLarge";
import { AppMsg } from "../../../utils";

const cssBase = "meetingReservationPageLarge";

const STEP_DETAILS = "details";
const STEP_TIME = "time";
const STEP_ROOM = "room";
const STEP_CONFIRMATION = "confirmation";

class MeetingReservationPageLarge extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
  };

  state = {
    currentIndex: 0,
    steps: [
      {
        key: STEP_DETAILS,
        label: AppMsg.getMessage(AppMsg.RESERVATION_MESSAGE.STEP_DETAILS),
        secondaryLabel: AppMsg.getMessage(AppMsg.RESERVATION_MESSAGE.OPTIONAL),
      },
      {
        key: STEP_TIME,
        label: AppMsg.getMessage(AppMsg.RESERVATION_MESSAGE.STEP_TIME),
      },
      {
        key: STEP_ROOM,
        label: AppMsg.getMessage(AppMsg.RESERVATION_MESSAGE.STEP_ROOM),
      },
      {
        key: STEP_CONFIRMATION,
        label: AppMsg.getMessage(AppMsg.RESERVATION_MESSAGE.STEP_CONFIRMATION),
      },
    ],
  };

  render() {
    const { currentIndex, steps } = this.state;

    let stepSection;

    switch (steps[currentIndex].key) {
      case STEP_DETAILS:
        stepSection = <DefineMeetingStepLarge />;
        break;
      default:
        break;
    }

    return (
      <div className={cssBase}>
        <Breadcrumb>
          <BreadcrumbItem>
            <a href="/">Home</a>
          </BreadcrumbItem>
          <BreadcrumbItem href="#" isCurrentPage>
            Reservation
          </BreadcrumbItem>
        </Breadcrumb>
        <div className={`${cssBase}__pageTitle`}>
          {this.props.appMessages[AppMsg.CREATE_NEW_RESERVATION]}
        </div>
        <ReservationProgressIndicator
          currentIndex={currentIndex}
          steps={steps}
          className={`${cssBase}__progressIndicator`}
          stepClassName={`${cssBase}__progressStep`}
          onChange={this.handleProgressIndicatorOnChange}
          smallLayout={false}
        />
        {stepSection}
      </div>
    );
  }

  handleProgressIndicatorOnChange = (currentIndex) => {
    this.setState({
      currentIndex,
    });
  };
}

export default withTriDictionary(MeetingReservationPageLarge);
