/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";

const cssBase = "defineMeetingStepLarge";

export default class DefineMeetingStepLarge extends React.PureComponent {
  render() {
    return <div className={cssBase}>Define Meeting Step Large</div>;
  }
}
