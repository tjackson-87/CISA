/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/

import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { Button } from "carbon-components-react";
import {
  FooterButtons,
  ReservationTime,
  AttendeesStatus,
} from "../../../components";
import { Time16 } from "@carbon/icons-react";
import {
  ReservationActions,
  RouteActions,
  ReservationSelectors,
  AvailabilityActions,
  AvailabilitySelectors,
  ApplicationSettingsSelectors,
  TimezonesSelectors,
  CurrentUserSelectors,
  RoomSearchActions,
  RoomSearchSelectors,
} from "../../../store";
import {
  AppMsg,
  computeMomentStartAndEndDates,
  RecurrenceConstants,
  getMomentFrom,
  isStartAndEndWithinOneDayAndValid,
  getResourceTimezones,
} from "../../../utils";
import isEmpty from "lodash/isEmpty";
import RecurrencePageSmall from "../../Recurrence/RecurrencePageSmall";

const cssBase = "meetingTimeStepSmall";

class MeetingTimeStepSmall extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    navigateToReservationSummary: PropTypes.func.isRequired,
    dateAndTime: PropTypes.object,
    timezones: PropTypes.array,
    updateDateAndTime: PropTypes.func.isRequired,
    updateTimeStepTempDateAndTime: PropTypes.func,
    getTimeStepTempRecurrenceDetails: PropTypes.func.isRequired,
    navigateToAvailability: PropTypes.func,
    isExchangeIntegrated: PropTypes.bool,
    attendeesSchedule: PropTypes.array,
    resources: PropTypes.array,
    exchangeAttendees: PropTypes.array,
    exchangeAttendeesAvailable: PropTypes.number,
    nonExchangeAttendees: PropTypes.array,
    getAttendeesSchedule: PropTypes.func,
    isEditingSeriesOccurrence: PropTypes.bool,
    defaultTimezone: PropTypes.string,
    setRecurrenceModal: PropTypes.func,
    isRecurrenceModalOpen: PropTypes.bool,
  };

  state = {
    setRecurrenceFlag: false,
  };

  render() {
    const {
      navigateToReservationSummary,
      navigateToAvailability,
      dateAndTime,
      isExchangeIntegrated,
      attendeesSchedule,
      resources,
      exchangeAttendees,
      exchangeAttendeesAvailable,
      nonExchangeAttendees,
      timezones,
      isEditingSeriesOccurrence,
      defaultTimezone,
    } = this.props;

    const { recurrence, allDayEvent } = dateAndTime;

    const recurrenceMessage =
      recurrence &&
      recurrence.type !== RecurrenceConstants.RECUR_TYPE_VALUES.NONE &&
      recurrence.details
        ? recurrence.details.ruleLabel
        : AppMsg.getMessage(
            AppMsg.RESERVATION_MESSAGE.STEP_TIME_MEETING_NO_RECURRENCES
          );

    return (
      <main className={cssBase}>
        <div className={`${cssBase}__stepDescription`}>
          {
            this.props.appMessages[
              AppMsg.RESERVATION_MESSAGE.STEP_TIME_DESCRIPTION
            ]
          }
        </div>
        <section className={`${cssBase}__content`}>
          <ReservationTime
            meetingTimeStep
            dateAndTime={dateAndTime}
            recurrenceMessage={recurrenceMessage}
            timezones={timezones}
            onRecurrenceClick={() => this.setRecurrence()}
            onChange={this.handleReservationTimeChange}
            hideRecurrence={isEditingSeriesOccurrence}
            defaultTimezone={defaultTimezone}
            focusRecurrence={
              this.state.setRecurrenceFlag && !this.props.isRecurrenceModalOpen
            }
            resourcesTimezoneDetails={getResourceTimezones(
              resources,
              timezones
            )}
          />
          <div className="page__section">
            {!allDayEvent && (
              <Button
                className={`${cssBase}__attendeeButton`}
                kind="tertiary"
                size="small"
                renderIcon={Time16}
                onClick={navigateToAvailability}
                disabled={this.computeAttendeeButtonDisabled(
                  isExchangeIntegrated,
                  attendeesSchedule,
                  resources,
                  dateAndTime
                )}
              >
                {
                  this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE.STEP_TIME_VIEW_AVAILABLE_TIME
                  ]
                }
              </Button>
            )}
            <AttendeesStatus
              isExchangeIntegrated={isExchangeIntegrated}
              exchangeAttendeesAvailable={exchangeAttendeesAvailable}
              exchangeAttendees={exchangeAttendees}
              nonExchangeAttendees={nonExchangeAttendees}
            />
          </div>
        </section>
        <FooterButtons
          secondaryLabel={this.props.appMessages[AppMsg.BUTTON.CANCEL]}
          secondaryClickedHandler={navigateToReservationSummary}
          primaryLabel={this.props.appMessages[AppMsg.BUTTON.DONE]}
          primaryClickedHandler={this.onDoneClick}
          primaryDisabled={this.computeDoneButtonDisabled()}
        />
        <RecurrencePageSmall onClose={() => this.onClose()} />
      </main>
    );
  }

  setRecurrence() {
    this.setState({ setRecurrenceFlag: true });
    this.props.setRecurrenceModal(true);
  }

  onClose = () => {
    this.props.setRecurrenceModal(false);
  };

  handleReservationTimeChange = (key, value, computedEndDate) => {
    const { updateTimeStepTempDateAndTime, getAttendeesSchedule } = this.props;
    updateTimeStepTempDateAndTime({
      [key]: value,
      ...computedEndDate,
    });
    getAttendeesSchedule();
    this.setState({ setRecurrenceFlag: false });
  };

  onDoneClick = async () => {
    await this.props.getTimeStepTempRecurrenceDetails();
    this.props.updateDateAndTime(this.props.dateAndTime);
    this.props.navigateToReservationSummary();
  };

  computeDoneButtonDisabled = () => {
    const { dateAndTime } = this.props;
    const { startDateTime, endDateTime } = computeMomentStartAndEndDates(
      dateAndTime
    );
    return dateAndTime.allDayEvent
      ? endDateTime.isBefore(startDateTime)
      : endDateTime.isSameOrBefore(startDateTime);
  };

  computeAttendeeButtonDisabled = (
    isExchangeIntegrated,
    attendees,
    rooms,
    dateAndTime
  ) => {
    const {
      startDate,
      startTime,
      startTimePeriod,
      endDate,
      endTime,
      endTimePeriod,
      timezone,
      allDayEvent,
    } = dateAndTime;
    const startMoment = getMomentFrom(
      startDate,
      startTime,
      startTimePeriod,
      timezone
    );
    const endMoment = getMomentFrom(endDate, endTime, endTimePeriod, timezone);
    if (!isStartAndEndWithinOneDayAndValid(startMoment, endMoment, allDayEvent))
      return true;
    return isExchangeIntegrated ? false : isEmpty(attendees) && isEmpty(rooms);
  };
}

const mapStateToProps = (state) => {
  return {
    dateAndTime: ReservationSelectors.timeStepTempDateAndTimeSelector(state),
    isExchangeIntegrated: ApplicationSettingsSelectors.isExchangeIntegratedSelector(
      state
    ),
    attendeesSchedule: AvailabilitySelectors.attendeesScheduleSelector(state),
    resources: ReservationSelectors.orderedResourcesSelector(state),
    exchangeAttendees: ReservationSelectors.exchangeAttendeesSelector(state),
    exchangeAttendeesAvailable: AvailabilitySelectors.exchangeAttendeesAvailableSelector(
      state
    ),
    nonExchangeAttendees: ReservationSelectors.nonExchangeAttendeesSelector(
      state
    ),
    timezones: TimezonesSelectors.timezonesSelector(state),
    isEditingSeriesOccurrence: ReservationSelectors.isEditingSeriesOccurrenceSelector(
      state
    ),
    isRecurrenceModalOpen: RoomSearchSelectors.recurrenceModalSelector(state),
    defaultTimezone: CurrentUserSelectors.defaultTimezoneSelector(state),
  };
};

const { setRecurrenceModal } = RoomSearchActions;

export default withTriDictionary(
  connect(mapStateToProps, {
    updateDateAndTime: ReservationActions.updateDateAndTime,
    updateTimeStepTempDateAndTime:
      ReservationActions.updateTimeStepTempDateAndTime,
    getTimeStepTempRecurrenceDetails:
      ReservationActions.getTimeStepTempRecurrenceDetails,
    getAttendeesSchedule: AvailabilityActions.getAttendeesSchedule,
    navigateToReservationSummary: RouteActions.navigateToReservationSummary,
    navigateToAvailability: RouteActions.navigateToAvailability,
    setRecurrenceModal,
  })(MeetingTimeStepSmall)
);
