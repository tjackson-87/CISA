/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import moment from "moment-timezone";
import React from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import isEmpty from "lodash/isEmpty";
import Popper from "@material-ui/core/Popper";
import classnames from "classnames";
import ClickAwayListener from "@material-ui/core/ClickAwayListener";
import { TriNote, withTriDictionary } from "@tririga/tririga-react-components";
import {
  Document16,
  Location16,
  Time16,
  Group16,
  Enterprise16,
  Laptop16,
  Search16,
  User16,
  //Purchase16, // hidden for CISA
} from "@carbon/icons-react";
import {
  SkeletonPlaceholder,
  ToastNotification,
  InlineNotification,
} from "carbon-components-react";
import {
  ReservationActions,
  RouteActions,
  CurrentUserActions,
  ReservationSelectors,
  LayoutSelectors,
  LoadingSelectors,
  CurrentUserSelectors,
  RoomSearchActions,
  RoomDetailsActions,
  ExchangeSelectors,
  ExchangeActions,
  CurrenciesSelectors,
} from "../../../store";
import {
  ReservationStepLink,
  FooterButtons,
  ReservationRoomList,
  HoldCountDown,
  SubjectInput,
  AdditionalLocationInfoInput,
  OnlineMeetingToggle // CISA
} from "../../../components";
import {
  AppMsg,
  ReservationUtils,
  ReservationEditMode,
  trapFocus,
} from "../../../utils";
import { isStartDateInvalid } from "../../../utils/reservation/ReservationUtils";
import RoomDetailsPageSmall from "../../RoomDetails/RoomDetailsPageSmall";
import CateringOrderListPageSmall from "../../CateringOrderList/CateringOrderListPageSmall";
import DelegateList from "../../ReservationList/DelegateList";
import CostSummary from "../../../components/CostSummary/CostSummary";
import { isNil } from "lodash";

const cssBase = "meetingSummarySmall";

class MeetingSummarySmall extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    isReservationValid: PropTypes.bool,
    subject: PropTypes.string,
    additionalLocationInfo: PropTypes.string,
    updateSubject: PropTypes.func.isRequired,
    updateOnlineTeamsMeeting: PropTypes.func.isRequired, // CISA
    updateResourceShowMore: PropTypes.func,
    updateAdditionalLocationInfo: PropTypes.func.isRequired,
    description: PropTypes.string,
    formattedDate: PropTypes.string,
    resources: PropTypes.array,
    dateAndTime: PropTypes.object,
    attendees: PropTypes.array,
    holdTimeEnd: PropTypes.string,
    holdTimeExpired: PropTypes.bool,
    defaultTimezone: PropTypes.string,
    cancelNewReservation: PropTypes.func.isRequired,
    submitReservation: PropTypes.func.isRequired,
    removeRoom: PropTypes.func.isRequired,
    renewHold: PropTypes.func.isRequired,
    navigateBackToHomePage: PropTypes.func.isRequired,
    navigateToReservationCostSummaryPage: PropTypes.func.isRequired,
    navigateToMeetingAttendees: PropTypes.func.isRequired,
    navigateToTime: PropTypes.func.isRequired,
    navigateToOnlineMeeting: PropTypes.func.isRequired,
    navigateToReservationSearch: PropTypes.func.isRequired,
    navigateToSearchByName: PropTypes.func.isRequired,
    navigateToMeetingDetails: PropTypes.func.isRequired,
    navigateToEquipmentList: PropTypes.func,
    recurrence: PropTypes.object,
    reservationType: PropTypes.string,
    dir: PropTypes.string,
    navigateToCateringList: PropTypes.func,
    isCreate: PropTypes.bool,
    loadingReservationAttendees: PropTypes.bool,
    onlineMeeting: PropTypes.oneOfType([PropTypes.string, PropTypes.object]),
    favoriteRooms: PropTypes.array,
    addFavoriteRoom: PropTypes.func.isRequired,
    removeFavoriteRoom: PropTypes.func.isRequired,
    navigateToOccurrenceExceptionsPage: PropTypes.func.isRequired,
    isRecurring: PropTypes.bool,
    haveUnresolvedExceptions: PropTypes.bool,
    setSelectedResource: PropTypes.func.isRequired,
    setSelectedRooms: PropTypes.func,
    initUpdatedData: PropTypes.object,
    setRoomDetailsModal: PropTypes.func,
    setRoomId: PropTypes.func,
    delegateCalendars: PropTypes.array,
    currentCalendar: PropTypes.object,
    setCurrentCalendar: PropTypes.func,
    userEmail: PropTypes.string,
    currentUserLocale: PropTypes.string,
    currencies: PropTypes.array,
    costSummary: PropTypes.object,
    handleAccountCodeChanged: PropTypes.func.isRequired,
    editMode: PropTypes.string,
    startAndEnd: PropTypes.object,
    startDateTimeAndEndDateTime: PropTypes.object,
    hasReservationCost: PropTypes.bool,
    tempStartAndEnd: PropTypes.object,
    allResolvedExceptions: PropTypes.array,
    allSelectedEquipment: PropTypes.array,
    allSelectedCaterings: PropTypes.array,
    isReservationExchangeOnly: PropTypes.bool,
    onlineMeetingBL: PropTypes.bool,
    isExchangeIntegrated: PropTypes.bool
  };

  renderTitle(readonlySubject, subject) {
    return (
      <div className={`${cssBase}__subjectText`}>
        <div className={`${cssBase}__header`}>
          <Document16 className={`${cssBase}__headerIcon`} />
          <div className={`${cssBase}__headerName`}>
            {
              this.props.appMessages[
                AppMsg.RESERVATION_MESSAGE.STEP_MEETING_SUBJECT
              ]
            }
          </div>
        </div>

        <SubjectInput
          id="subject"
          className={`${cssBase}__textInput`}
          aria-required="true"
          labelText={
            this.props.appMessages[
              AppMsg.RESERVATION_MESSAGE.STEP_MEETING_SUBJECT
            ]
          }
          hideLabel={true}
          onValueChanged={this.handleUpdateSubject}
          onFocus={this.handleSubjectClick}
          onBlur={this.handleSubjectBlur}
          value={subject}
          readOnly={readonlySubject}
          readOnlyClassName={`${cssBase}__titleReadonly`}
          placeholder={
            this.props.appMessages[
              AppMsg.RESERVATION_MESSAGE.STEP_MEETING_SUBJECT
            ]
          }
          textInputReference={(ref) => this.setState({ textInputDom: ref })}
        />
      </div>
    );
  }
  renderOnlineMeeting(onlineMeetingBL) {
    return (
      <div
        className={`${cssBase}__additionalLocationInfoDetails ${cssBase}__stepLink`}
        onClick={this.handleAdditionalLocationInfoClick}
      >
        <div className={`${cssBase}__header`}>
          <Laptop16 className={`${cssBase}__locationIcon`} />
          <div className={`${cssBase}__additionalLocationInfoHeader`}>
            {
              this.props.appMessages[
                AppMsg.RESERVATION_MESSAGE
                  .STEP_MEETING_ONLINE_MEETING
              ]
            }
          </div>
        </div>
        <OnlineMeetingToggle
              id="online-meeting-toggle"
              className={`${cssBase}__filterToggle`}
              toggled={onlineMeetingBL}
              onToggle={this.handleOnlineToggle}
            />
      </div>
    );
  }
  
  renderAdditionalInfo(readonlyAdditionalLocationInfo, additionalLocationInfo) {
    return (
      <div
        className={`${cssBase}__additionalLocationInfoDetails ${cssBase}__stepLink`}
        onClick={this.handleAdditionalLocationInfoClick}
        onKeyDown={(e) =>
          e.key === "Enter" ? this.handleAdditionalLocationInfoClick() : null
        }
        tabIndex={0}
        role="link"
      >
        <div className={`${cssBase}__header`}>
          <Location16 className={`${cssBase}__locationIcon`} />
          <div className={`${cssBase}__additionalLocationInfoHeader`}>
            {
              this.props.appMessages[
                AppMsg.RESERVATION_MESSAGE
                  .STEP_MEETING_ADDITIONAL_LOCATION_INFO_OPTIONAL
              ]
            }
          </div>
        </div>
        {readonlyAdditionalLocationInfo ? (
          <div className={`${cssBase}__additionalLocationInfoTitle`}>
            {additionalLocationInfo}
          </div>
        ) : (
          <>
            <AdditionalLocationInfoInput
              id="additionalLocationInfo"
              className={`${cssBase}__textInput`}
              labelText={
                this.props.appMessages[
                  AppMsg.RESERVATION_MESSAGE
                    .STEP_MEETING_ADDITIONAL_LOCATION_INFO
                ]
              }
              hideLabel
              onValueChanged={(value) =>
                this.handleUpdateAdditionalLocationInfo(value)
              }
              onBlur={this.handleAdditionalLocationInfoBlur}
              value={additionalLocationInfo}
              placeholder={
                this.props.appMessages[
                  AppMsg.RESERVATION_MESSAGE
                    .STEP_MEETING_ADDITIONAL_LOCATION_INFO
                ]
              }
            />
          </>
        )}
      </div>
    );
  }

  state = {
    readonlySubject: false,
    readonlyAdditionalLocationInfo: true,
    showSearchOptions: false,
    showDelegateList: false,
    textInputDom: null,
    meetingOwnerDom: null,
    roomLinkDom: null,
    activeMeetingRoomDom: null,
    cateringLinkDom: null,
    openCateringOrderListModal: false,
  };

  popperModifiers = {
    sameWidth: {
      enabled: true,
      order: 840,
      fn: (data) => {
        data.offsets.popper.width = data.styles.width =
          data.offsets.reference.width < 673
            ? Math.round(data.offsets.reference.width - 32)
            : data.offsets.reference.width < 988
            ? Math.round(data.offsets.reference.width - 80)
            : 908;
        data.offsets.popper.left =
          data.offsets.reference.width < 673 ||
          data.originalPlacement === "top-end"
            ? data.offsets.reference.left + 16
            : data.offsets.reference.left + 64;
        data.offsets.popper.top = Math.round(
          data.offsets.reference.bottom - data.offsets.popper.height - 16
        );
        return data;
      },
    },
  };

  componentDidMount() {
        // CISA-520 set page title based on selected page
        document.title = this.props.appMessages[AppMsg.ORG_NAME] + ' ' + this.props.appMessages[AppMsg.CREATE_NEW_MEETING]
    const { currentCalendar, isCreate } = this.props;
    if (!isEmpty(currentCalendar) && isCreate) {
      setTimeout(() => {
        if (this.state.meetingOwnerDom) {
          this.state.meetingOwnerDom.current.focus();
        }
      }, 1000);
    } else {
      setTimeout(() => {
        if (this.state.textInputDom) {
          this.state.textInputDom.current.focus();
        }
      }, 1000);
    }
  }

  render() {
    const { readonlySubject, readonlyAdditionalLocationInfo } = this.state;
    const {
      isReservationValid,
      subject,
      additionalLocationInfo,
      description,
      formattedDate,
      resources,
      dateAndTime,
      holdTimeEnd,
      holdTimeExpired,
      removeRoom,
      renewHold,
      attendees,
      navigateToMeetingAttendees,
      navigateToTime,
      navigateToOnlineMeeting,
      navigateToMeetingDetails,
      recurrence,
      reservationType,
      dir,
      updateResourceShowMore,
      isCreate,
      loadingReservationAttendees,
      favoriteRooms,
      addFavoriteRoom,
      removeFavoriteRoom,
      isRecurring,
      haveUnresolvedExceptions,
      //setSelectedResource,
      defaultTimezone,
      initUpdatedData,
      delegateCalendars,
      currentCalendar,
      userEmail,
      hasReservationCost,
      allResolvedExceptions,
      allSelectedEquipment,
      allSelectedCaterings,
      isReservationExchangeOnly,
      isExchangeIntegrated,
      onlineMeetingBL,
    } = this.props;
    const { showDelegateList } = this.state;
    return (
      <main className={cssBase} ref={(e) => (this.anchorEl = e)} tabIndex={0}>
        {/* CISA-516 add aria heading for 508 */}
        <div role="heading" aria-level="1" className={`${cssBase}__title`}>
          {this.props.appMessages[AppMsg.RESERVATION_MESSAGE.SUMMARY_TITLE]}
        </div>
        <div className={`${cssBase}__content`}>
          <span>
            {!isEmpty(currentCalendar) &&
              isCreate &&
              this.renderMeetingOwner(dir, currentCalendar)}
          </span>
          {this.renderTitle(readonlySubject, subject)}
          {loadingReservationAttendees ? (
            <SkeletonPlaceholder
              className={`${cssBase}__attendeesPlaceHolder`}
            />
          ) : (
            <ReservationStepLink
              stepIcon={Group16}
              name={
                this.props.appMessages[
                  AppMsg.RESERVATION_MESSAGE.STEP_MEETING_ATTENDEES
                ]
              }
              children={this.renderAttendees(attendees)}
              ariaLabel={this.renderAttendees(attendees, "label")}
              className={`${cssBase}__stepLink`}
              onClick={navigateToMeetingAttendees}
              onKeyDown={(e) =>
                e.key === "Enter" ? navigateToMeetingAttendees() : null
              }
              dir={dir}
            />
          )}
          <ReservationStepLink
            stepIcon={Time16}
            name={
              this.props.appMessages[
                AppMsg.RESERVATION_MESSAGE.STEP_TIME_DESCRIPTION
              ]
            }
            children={
              isEmpty(formattedDate) ? null : (
                <div className={`${cssBase}__dateAndTime`}>
                  <div className={`${cssBase}__date`}>{formattedDate}</div>
                  {!isEmpty(recurrence) && !isEmpty(recurrence.details) && (
                    <div>{recurrence.details.ruleLabel}</div>
                  )}
                </div>
              )
            }
            ariaLabel={
              this.props.appMessages[
                AppMsg.RESERVATION_MESSAGE.STEP_TIME_DESCRIPTION
              ] +
              ", " +
              formattedDate +
              `${
                !isEmpty(recurrence) && !isEmpty(recurrence.details)
                  ? ", " + recurrence.details.ruleLabel
                  : ""
              }`
            }
            className={`${cssBase}__stepLink`}
            onClick={() => navigateToTime()}
            onKeyDown={(e) => (e.key === "Enter" ? navigateToTime() : null)}
            dir={dir}
          />
          <div className={`${cssBase}__locationHeader`}>
            {/* CISA-516 add aria heading for 508 */}
            <div role="heading" aria-level="2" className={`${cssBase}__locationLabel`}>
              {
                this.props.appMessages[
                  AppMsg.RESERVATION_MESSAGE.STEP_ROOM_DETAIL_LOCATION
                ]
              }
            </div>
          </div>
          <ReservationStepLink
            role="button"
            stepIcon={Enterprise16}
            name={
              this.props.appMessages[
                AppMsg.RESERVATION_MESSAGE.STEP_LOCATION_DESCRIPTION
              ]
            }
            className={`${cssBase}__roomLink`}
            onClick={() => {
              this.handleRoomClick();
            }}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                this.handleRoomClick();
              }
            }}
            dir={dir}
            addIcon={Search16}
            hideStepIcon
            stepLinkReference={(ref) => this.setState({ roomLinkDom: ref })}
          />
          {this.renderSearchOptions()}
          {this.renderOverlay()}
          {holdTimeEnd != null && (
            <div className={`${cssBase}__warningContent`}>
              <div className={`${cssBase}__exceptionWarning`}>
                <HoldCountDown
                  holdTimeEnd={holdTimeEnd}
                  onRenewHoldTime={renewHold}
                  reservationType={reservationType}
                />
              </div>
            </div>
          )}
          {!isEmpty(allResolvedExceptions) &&
            isRecurring &&
            (allSelectedEquipment.length > 0 ||
              allSelectedCaterings.length > 0) && (
              <div className={`${cssBase}__exceptionContent`}>
                <div className={`${cssBase}__exceptionWarning`}>
                  <InlineNotification
                    kind="warning"
                    hideCloseButton={false}
                    lowContrast={true}
                    title={
                      this.props.appMessages[
                        AppMsg.RESERVATION_MESSAGE
                          .RECURRING_ROOM_EXCEPTION_WARNING_TITLE
                      ]
                    }
                    subtitle={
                      this.props.appMessages[
                        AppMsg.RESERVATION_MESSAGE
                          .RECURRING_ROOM_EXCEPTION_WARNING_DESCRIPTION
                      ]
                    }
                    statusIconDescription={
                      this.props.appMessages[
                        AppMsg.RESERVATION_MESSAGE
                          .RECURRING_ROOM_EXCEPTION_WARNING_TITLE
                      ]
                    }
                  />
                </div>
              </div>
            )}
          {haveUnresolvedExceptions && isRecurring && !holdTimeExpired && (
            <div className={`${cssBase}__warningContent`}>
              <div className={`${cssBase}__exceptionWarning`} tabIndex={0}>
                <ToastNotification
                  kind="warning"
                  hideCloseButton
                  lowContrast
                  title={
                    this.props.appMessages[
                      AppMsg.RESERVATION_MESSAGE
                        .STEP_ROOM_UNRESOLVED_EXCEPTIONS_WARNING_TITLE
                    ]
                  }
                  subtitle={
                    this.props.appMessages[
                      AppMsg.RESERVATION_MESSAGE
                        .STEP_ROOM_UNRESOLVED_EXCEPTIONS_WARNING_DESCRIPTION
                    ]
                  }
                  statusIconDescription={
                    this.props.appMessages[
                      AppMsg.RESERVATION_MESSAGE
                        .STEP_ROOM_UNRESOLVED_EXCEPTIONS_WARNING_TITLE
                    ]
                  }
                />
              </div>
            </div>
          )}
          <ReservationRoomList
            className={`${cssBase}__reservationList`}
            dir={dir}
            holdTimeExpired={holdTimeExpired}
            reservationType={reservationType}
            resources={ReservationUtils.getAvailableResources(resources)}
            dateAndTime={dateAndTime}
            favorites={favoriteRooms}
            defaultTimezone={defaultTimezone}
            addFavoriteRoom={addFavoriteRoom}
            removeFavoriteRoom={removeFavoriteRoom}
            navigateToOccurrenceExceptionsPage={(resourceId) =>
              this.handleNavigateToOccurrenceExceptionPage(resourceId)
            }
            isRecurring={isRecurring}
            onRemove={removeRoom}
            onItemClick={this.handleItemClick}
            onEquipmentClick={this.handleEquipmentClick}
            onMoreOptionsClick={updateResourceShowMore}
            initUpdatedData={initUpdatedData}
            recurrence={recurrence}
            onCateringClick={this.handleCateringClick}
            stepLinkReference={(ref) => this.setState({ cateringLinkDom: ref })}
          />
          {/* Hidden for CISA          
          <div className={`${cssBase}__costSummaryDetails`}>
            <div className={`${cssBase}__header`}>
              <Purchase16 className={`${cssBase}__locationIcon`} />
              <div className={`${cssBase}__additionalLocationInfoHeader`}>
                {
                  this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE.STEP_MEETING_COST_SUMMARY
                  ]
                }
              </div>
            </div>
            <div className={`${cssBase}__costSummaryContent`}>
              {isCreate && this.renderInitialCostSummary()}
              {!isCreate && this.renderCostSummary()}
            </div>
          </div>
          */}
          <ReservationStepLink
            stepIcon={Laptop16}
            name={
              this.props.appMessages[
                AppMsg.RESERVATION_MESSAGE.STEP_MEETING_ONLINE_MEETING
              ]
            }
            children={this.renderSelectedOnlineMeeting()}
            ariaLabel={this.renderSelectedOnlineMeeting("label")}
            className={`${cssBase}__locationDetails`}
            onClick={() => navigateToOnlineMeeting()}
            onKeyDown={(e) =>
              e.key === "Enter" ? navigateToOnlineMeeting() : null
            }
            dir={dir}
          />
          {isExchangeIntegrated && (this.renderOnlineMeeting(
            onlineMeetingBL
          ))}
          {this.renderAdditionalInfo(
            readonlyAdditionalLocationInfo,
            additionalLocationInfo
          )}
          <div className={`${cssBase}__description`}>
            <ReservationStepLink
              stepIcon={Document16}
              name={
                this.props.appMessages[
                  AppMsg.RESERVATION_MESSAGE.STEP_MEETING_DETAILS_OPTIONAL
                ]
              }
              ariaLabel={this.getDescriptionLabel()}
              children={
                isEmpty(description) ? null : (
                  <div
                    aria-hidden="true"
                    tabIndex={-1}
                    className={`${cssBase}__descriptionLinkText`}
                  >
                    <TriNote value={description} readonly autoHeight />
                  </div>
                )
              }
              className={`${cssBase}__stepLink`}
              onClick={navigateToMeetingDetails}
              onKeyDown={(e) =>
                e.key === "Enter"
                  ? setTimeout(() => navigateToMeetingDetails(), 1)
                  : null
              }
              dir={dir}
            />
          </div>
          {showDelegateList && (
            <DelegateList
              showEmailDiffNotice
              isDelegateModalOpen={showDelegateList}
              calendars={delegateCalendars}
              currentCalendar={currentCalendar}
              userEmail={userEmail}
              headingMessage={
                this.props.appMessages[AppMsg.RESERVATION_MESSAGE.MEETING_OWNER]
              }
              onClose={() => {
                this.setState({ showDelegateList: false }, () => {
                  if (this.state.meetingOwnerDom) {
                    this.state.meetingOwnerDom.current.focus();
                  }
                });
              }}
              onSelect={this.handleSelectedCalendar}
            />
          )}
        </div>
        <div id="footerBtn">
          <FooterButtons
            secondaryLabel={this.props.appMessages[AppMsg.BUTTON.CANCEL]}
            secondaryClickedHandler={this.onCancelClick}
            primaryLabel={
              this.props.appMessages[
                isCreate
                  ? hasReservationCost
                    ? AppMsg.BUTTON.CREATE_REVIEW
                    : AppMsg.BUTTON.CREATE
                  : hasReservationCost && !isReservationExchangeOnly // CISA
                  ? AppMsg.BUTTON.UPDATE_REVIEW
                  : AppMsg.BUTTON.UPDATE
              ]
            }
            primaryClickedHandler={this.onCreateClick}
            primaryDisabled={!isReservationValid}
          />
        </div>
        <CateringOrderListPageSmall
          isOpen={this.state.openCateringOrderListModal}
          onClosePopUp={() => this.onCloseCateringPopUp()}
        />
        <RoomDetailsPageSmall onClosePopUp={() => this.onClosePopUp()} />
      </main>
    );
  }

  getDescriptionLabel() {
    const { description } = this.props;
    const label = this.props.appMessages[
      AppMsg.RESERVATION_MESSAGE.STEP_MEETING_DETAILS_OPTIONAL
    ];
    try {
      if (!isNil(description)) {
        const parser = new DOMParser();
        const document = parser.parseFromString(description, "text/html");
        if(!isNil(document) && document.body) {
          const parsedText = document.body.textContent;
          return `${label} ${parsedText}`
        }
      }
    } catch (error) {
      console.log(error);
    }
    return label;
  }

  renderInitialCostSummary() {
    const { hasReservationCost } = this.props;
    if (hasReservationCost) {
      return (
        <div>
          <ToastNotification
            className={`${cssBase}__notification`}
            kind="info"
            lowContrast
            hideCloseButton={true}
            title={
              this.props.appMessages[
                AppMsg.RESERVATION_MESSAGE.COST_SUMMARY_NOTIFICATION_TITLE
              ]
            }
            statusIconDescription={
              this.props.appMessages[
                AppMsg.RESERVATION_MESSAGE.COST_SUMMARY_NOTIFICATION_TITLE
              ]
            }
            subtitle={
              <span>
                {
                  this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE
                      .COST_SUMMARY_NOTIFICATION_CREATE_REVIEW_TEXT
                  ]
                }
              </span>
            }
          />
        </div>
      );
    } else {
      return (
        <div className={`${cssBase}__noCostSummary`}>
          {
            this.props.appMessages[
              AppMsg.RESERVATION_MESSAGE.NO_COST_RESERVATION
            ]
          }
        </div>
      );
    }
  }

  renderCostSummary() {
    const {
      costSummary,
      currencies,
      currentUserLocale,
      appMessages,
      hasReservationCost,
      isReservationExchangeOnly,
    } = this.props;
    if (costSummary && hasReservationCost && !isReservationExchangeOnly) {
      const costSummaryData = {
        accountCodeRoom: costSummary.accountCodeRoom,
        accountCodeFood: costSummary.accountCodeFood,
        accountCodeEquipment: costSummary.accountCodeEquipment,
        estimatedCostResource: costSummary.estimatedCostResource,
        estimatedCostFood: costSummary.estimatedCostFood,
        estimatedCostEquipment: costSummary.estimatedCostEquipment,
      };
      return (
        <div>
          <ToastNotification
            className={`${cssBase}__notification`}
            kind="warning"
            lowContrast
            hideCloseButton={true}
            title={
              this.props.appMessages[
                AppMsg.RESERVATION_MESSAGE.COST_SUMMARY_NOTIFICATION_TITLE
              ]
            }
            statusIconDescription={
              this.props.appMessages[
                AppMsg.RESERVATION_MESSAGE
                  .COST_SUMMARY_NOTIFICATION_UPDATE_REVIEW_TITLE
              ]
            }
            subtitle={
              <span>
                {
                  this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE
                      .COST_SUMMARY_NOTIFICATION_UPDATE_REVIEW_TEXT
                  ]
                }
              </span>
            }
          />
          <CostSummary
            data={costSummaryData}
            currentUserLocale={currentUserLocale}
            appMessages={appMessages}
            currencies={currencies}
            editMode={true}
            onCostCodeValueChanged={this.props.handleAccountCodeChanged}
          />
        </div>
      );
    }
    return (
      <div className={`${cssBase}__noCostSummary`}>
        {this.props.appMessages[AppMsg.RESERVATION_MESSAGE.NO_COST_RESERVATION]}
      </div>
    );
  }

  handleItemClick = (resource, roomListItemRef) => {
    const { setRoomId, setRoomDetailsModal } = this.props;
    this.setState({ activeMeetingRoomDom: roomListItemRef });
    setRoomId(resource.data.roomId);
    setRoomDetailsModal(true);
  };

  handleEquipmentClick = (roomId) => {
    const { setRoomId, navigateToEquipmentList } = this.props;
    setRoomId(roomId);
    navigateToEquipmentList(roomId, {
      routedFromSummary: true,
    });
  };

  handleCateringClick = (roomId) => {
    const { setRoomId, navigateToCateringList, dateAndTime } = this.props;
    const invalidStartDate = isStartDateInvalid(dateAndTime);
    if (invalidStartDate) {
      setRoomId(roomId);
      this.setState({ openCateringOrderListModal: true });
    } else {
      setRoomId(roomId);
      navigateToCateringList(roomId, {
        routedFromSummary: true,
      });
    }
  };

  renderOverlay() {
    const { showSearchOptions } = this.state;
    return (
      <div
        className={classnames(`${cssBase}__overlay`, {
          [`${cssBase}__overlay--visible`]: showSearchOptions,
        })}
      />
    );
  }

  handleBuildingSearch = () => {
    const { navigateToReservationSearch, setSelectedRooms } = this.props;
    setSelectedRooms(null);
    navigateToReservationSearch();
  };

  renderSearchOptions = () => {
    const { dir, navigateToSearchByName } = this.props;
    const { showSearchOptions } = this.state;
    return (
      <Popper
        className={`${cssBase}__responseOptions`}
        open={showSearchOptions}
        anchorEl={this.anchorEl}
        transition
        placement={dir === "rtl" ? "top-end" : "top-start"}
        dir={dir}
        modifiers={this.popperModifiers}
      >
        <ClickAwayListener onClickAway={this.handleClickAway}>
          <div
            role="dialog"
            aria-labelledby="roomSearch"
            id="roomSearchOptionsPopup"
            className={`${cssBase}__responseList`}
            tabIndex={-1}
          >
            <div id="roomSearch" className={`${cssBase}__responseHeader`}>
              {
                this.props.appMessages[
                  AppMsg.RESERVATION_MESSAGE.STEP_LOCATION_DESCRIPTION
                ]
              }
            </div>
            <div
              className={`${cssBase}__option`}
              onClick={this.handleBuildingSearch}
              onKeyDown={(e) =>
                e.key === "Enter" ? this.handleBuildingSearch() : null
              }
              role="button"
              aria-label={
                this.props.appMessages[
                  AppMsg.RESERVATION_MESSAGE.FIND_AVAILABLE_ROOMS
                ]
              }
              tabIndex={0}
            >
              {
                this.props.appMessages[
                  AppMsg.RESERVATION_MESSAGE.FIND_AVAILABLE_ROOMS
                ]
              }
            </div>
            <div
              className={`${cssBase}__option`}
              onClick={() => navigateToSearchByName()}
              onKeyDown={(e) =>
                e.key === "Enter" ? navigateToSearchByName() : null
              }
              role="button"
              aria-label={
                this.props.appMessages[
                  AppMsg.RESERVATION_MESSAGE.SEARCH_BY_NAME
                ]
              }
              tabIndex={0}
            >
              {
                this.props.appMessages[
                  AppMsg.RESERVATION_MESSAGE.SEARCH_BY_NAME
                ]
              }
            </div>
            <div
              className={`${cssBase}__cancelButton`}
              onClick={() => this.handleClickAway()}
              onKeyDown={(e) =>
                e.key === "Enter" ? this.handleClickAway() : null
              }
              role="button"
              aria-label={this.props.appMessages[AppMsg.BUTTON.CANCEL]}
              tabIndex={0}
            >
              {this.props.appMessages[AppMsg.BUTTON.CANCEL]}
            </div>
          </div>
        </ClickAwayListener>
      </Popper>
    );
  };

  onClosePopUp = () => {
    const { setRoomDetailsModal } = this.props;

    if (this.state.activeMeetingRoomDom) {
      setTimeout(() => {
        this.state.activeMeetingRoomDom.current.focus();
      }, 1);
    }
    setRoomDetailsModal(false);
  };

  onCloseCateringPopUp = () => {
    this.setState({ openCateringOrderListModal: false }, () => {
      if (this.state.cateringLinkDom) {
        this.state.cateringLinkDom.current.focus();
      }
    });
  };

  handleRoomClick = () => {
    const { setSelectedResource } = this.props;
    setSelectedResource(null);
    document.getElementById("footerBtn").scrollIntoView();
    this.setState({ showSearchOptions: true }, () => {
      setTimeout(() => {
        const popup = document.getElementById("roomSearchOptionsPopup");
        if (!isNil(popup)) {
          popup.focus();
          trapFocus(popup);
        }
      }, 1);
    });
  };

  handleClickAway = () => {
    this.setState(
      {
        showSearchOptions: false,
      },
      () => {
        if (this.state.roomLinkDom) {
          this.state.roomLinkDom.current.focus();
        }
      }
    );
  };

  handleSubjectClick = () => {
    this.setState({ readonlySubject: false });
  };

  handleSubjectBlur = () => {
    this.setState({ readonlySubject: true });
  };

  handleAdditionalLocationInfoClick = () => {
    this.setState({ readonlyAdditionalLocationInfo: false });
  };

  handleAdditionalLocationInfoBlur = () => {
    this.setState({ readonlyAdditionalLocationInfo: true });
  };

  handleUpdateSubject = (e) => {
    const subject = e.target.value;
    this.props.updateSubject(subject);
  };

  handleUpdateAdditionalLocationInfo = (value) => {
    this.props.updateAdditionalLocationInfo(value);
  };

  handleOnlineToggle = (value) => {
    this.props.updateOnlineTeamsMeeting(value);
  };

  handleNavigateToOccurrenceExceptionPage(resourceId) {
    const {
      resources,
      setSelectedResource,
      navigateToOccurrenceExceptionsPage,
    } = this.props;
    const resource = resources.find((r) => r.data._id === resourceId);
    setSelectedResource(resource);
    navigateToOccurrenceExceptionsPage(resourceId);
  }

  renderAttendees(attendees, label = "") {
    if (isEmpty(attendees)) {
      return null;
    }
    if (label) {
      const attendeeLabel = attendees.map((item, index) => {
        return `${item.displayName}${index < attendees.length - 1 ? ", " : ""}`;
      });
      return (
        this.props.appMessages[
          AppMsg.RESERVATION_MESSAGE.STEP_MEETING_ATTENDEES
        ] +
        ", " +
        attendeeLabel.join("")
      );
    }
    return isEmpty(attendees) ? null : (
      <div className={`${cssBase}__attendees`}>
        {attendees.map((item, index) => (
          <span
            key={`attendee-${index}`}
            className={`${cssBase}__attendeeName`}
          >{`${item.displayName}${
            index < attendees.length - 1 ? ", " : ""
          }`}</span>
        ))}
      </div>
    );
  }

  renderSelectedOnlineMeeting(label = "") {
    const { onlineMeeting } = this.props;
    if (isEmpty(onlineMeeting)) return null;
    if (label) {
      return (
        this.props.appMessages[
          AppMsg.RESERVATION_MESSAGE.STEP_MEETING_ONLINE_MEETING
        ] +
        ", " +
        onlineMeeting.name
      );
    }
    return (
      <div className={`${cssBase}__meetingDetails`}>
        <div className={`${cssBase}__meetingName`}>
          <span>{isEmpty(onlineMeeting) ? "" : onlineMeeting.name}</span>
        </div>
      </div>
    );
  }

  onCancelClick = async () => {
    const { navigateBackToHomePage, cancelNewReservation } = this.props;
    await cancelNewReservation();
    navigateBackToHomePage();
  };

  onCreateClick = async () => {
    const {
      navigateToReservationCostSummaryPage,
      submitReservation,
      isCreate,
      editMode,
      startAndEnd,
      defaultTimezone,
      navigateBackToHomePage,
      hasReservationCost,
      tempStartAndEnd,
      isReservationExchangeOnly,
    } = this.props;
    let startDateTime = tempStartAndEnd.startDate;
    let endDateTime = tempStartAndEnd.endDate;
    if (isCreate) {
      startDateTime = startAndEnd.start
        ? moment.tz(startAndEnd.start, defaultTimezone).toISOString(true)
        : null;
      endDateTime = startAndEnd.end
        ? moment.tz(startAndEnd.end, defaultTimezone).toISOString(true)
        : null;
    }
    let editModeSelected = this.props.isRecurring
      ? ReservationEditMode.SERIES
      : ReservationEditMode.OCCURRENCE;
    if (!isCreate && !isNil(editMode)) {
      editModeSelected = editMode;
    }
    const reservation = await submitReservation();
    if (reservation != null) {
      if (hasReservationCost && !isReservationExchangeOnly) {
        navigateToReservationCostSummaryPage(
          reservation._id,
          editModeSelected,
          startDateTime,
          endDateTime
        );
      } else {
        navigateBackToHomePage();
      }
    }
  };

  renderMeetingOwner(dir, currentCalendar) {
    return (
      <ReservationStepLink
        stepIcon={User16}
        name={this.props.appMessages[AppMsg.RESERVATION_MESSAGE.MEETING_OWNER]}
        className={`${cssBase}__stepLink`}
        ariaLabel={
          this.props.appMessages[AppMsg.RESERVATION_MESSAGE.MEETING_OWNER] +
          ", " +
          currentCalendar.name
        }
        children={<div>{currentCalendar.name}</div>}
        onClick={() => this.setState({ showDelegateList: true })}
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            setTimeout(() => {
              this.setState({ showDelegateList: true });
            }, 10);
          }
        }}
        dir={dir}
        stepLinkReference={(ref) => this.setState({ meetingOwnerDom: ref })}
      />
    );
  }

  handleSelectedCalendar = (selectedCalendar) => {
    const { setCurrentCalendar } = this.props;
    setCurrentCalendar(selectedCalendar);
    this.setState({ showDelegateList: false }, () => {
      if (this.state.meetingOwnerDom) {
        this.state.meetingOwnerDom.current.focus();
      }
    });
  };
}

const {
  isReservationValidSelector,
  formattedStartEndDatesSelector,
  subjectSelector,
  generateOnlineMeetingSelector,
  additionalLocationInfoSelector,
  onlineMeetingSelector,
  descriptionSelector,
  orderedResourcesSelector,
  holdTimeEndSelector,
  holdTimeExpiredSelector,
  attendeesSelector,
  recurrenceSelector,
  reservationTypeSelector,
  isCreateSelector,
  unresolvedExceptionsCheckSelector,
  initUpdatedDataSelector,
  costSummaryAccountCodesSelector,
  editModeSelector,
  hasReservationCostSelector,
  allResolvedExceptionsSelector,
  allSelectedEquipmentSelector,
  allSelectedCateringSelector,
} = ReservationSelectors;

const mapStateToProps = (state) => {
  return {
    dir: LayoutSelectors.dirSelector(state),
    isReservationValid: isReservationValidSelector(state),
    subject: subjectSelector(state),
    onlineMeetingBL: generateOnlineMeetingSelector(state),
    additionalLocationInfo: additionalLocationInfoSelector(state),
    description: descriptionSelector(state),
    formattedDate: formattedStartEndDatesSelector(state),
    resources: orderedResourcesSelector(state),
    dateAndTime: ReservationSelectors.timeStepTempDateAndTimeSelector(state),
    holdTimeEnd: holdTimeEndSelector(state),
    holdTimeExpired: holdTimeExpiredSelector(state),
    attendees: attendeesSelector(state),
    recurrence: recurrenceSelector(state),
    reservationType: reservationTypeSelector(state),
    isCreate: isCreateSelector(state),
    loadingReservationAttendees: LoadingSelectors.loadingReservationAttendeesSelector(
      state
    ),
    onlineMeeting: onlineMeetingSelector(state),
    favoriteRooms: CurrentUserSelectors.favoriteRoomsSelector(state),
    isRecurring: !!ReservationSelectors.recurrenceSelector(state),
    haveUnresolvedExceptions: unresolvedExceptionsCheckSelector(state),
    editMode: editModeSelector(state),
    startAndEnd: ReservationSelectors.eventStartandEndSelector(state),
    defaultTimezone: CurrentUserSelectors.defaultTimezoneSelector(state),
    initUpdatedData: initUpdatedDataSelector(state),
    delegateCalendars: ExchangeSelectors.delegateCalendarsSelector(state),
    currentCalendar: ExchangeSelectors.currentCalendarSelector(state),
    userEmail: CurrentUserSelectors.currentUserEmailSelector(state),
    currentUserLocale: CurrentUserSelectors.localeSelector(state),
    currencies: CurrenciesSelectors.currenciesSelector(state),
    costSummary: costSummaryAccountCodesSelector(state),
    hasReservationCost: hasReservationCostSelector(state),
    tempStartAndEnd: ReservationSelectors.timeStepTempStartAndEndDateSelector(
      state
    ),
    allResolvedExceptions: allResolvedExceptionsSelector(state),
    allSelectedEquipment: allSelectedEquipmentSelector(state),
    allSelectedCaterings: allSelectedCateringSelector(state),
  };
};

export default withTriDictionary(
  connect(mapStateToProps, {
    cancelNewReservation: ReservationActions.cancelNewReservation,
    submitReservation: ReservationActions.submitReservation,
    removeRoom: ReservationActions.removeRoom,
    updateSubject: ReservationActions.updateSubject,
    updateOnlineTeamsMeeting: ReservationActions.updateOnlineTeamsMeeting,
    updateAdditionalLocationInfo:
      ReservationActions.updateAdditionalLocationInfo,
    renewHold: ReservationActions.renewHold,
    updateResourceShowMore: ReservationActions.updateResourceShowMore,
    addFavoriteRoom: CurrentUserActions.addFavoriteRoom,
    removeFavoriteRoom: CurrentUserActions.removeFavoriteRoom,
    navigateBackToHomePage: RouteActions.navigateBackToHomePage,
    navigateToReservationCostSummaryPage:
      RouteActions.navigateToReservationCostSummaryPage,
    navigateToMeetingAttendees: RouteActions.navigateToMeetingAttendees,
    navigateToTime: RouteActions.navigateToTime,
    navigateToOnlineMeeting: RouteActions.navigateToOnlineMeeting,
    navigateToReservationSearch: RouteActions.navigateToReservationSearch,
    navigateToSearchByName: RouteActions.navigateToSearchByName,
    navigateToEquipmentList: RouteActions.navigateToEquipmentList,
    navigateToMeetingDetails: RouteActions.navigateToMeetingDetails,
    navigateToCateringList: RouteActions.navigateToCateringList,
    navigateToOccurrenceExceptionsPage:
      RouteActions.navigateToOccurrenceExceptionsPage,
    setSelectedResource: ReservationActions.setSelectedResource,
    setSelectedRooms: RoomSearchActions.setSelectedRooms,
    setRoomDetailsModal: RoomSearchActions.setRoomDetailsModal,
    setRoomId: RoomDetailsActions.setRoomId,
    setCurrentCalendar: ExchangeActions.setCurrentCalendar,
    handleAccountCodeChanged: ReservationActions.handleAccountCodeChanged,
  })(MeetingSummarySmall)
);
