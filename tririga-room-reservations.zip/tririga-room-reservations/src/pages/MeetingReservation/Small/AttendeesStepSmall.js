/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import defaultTo from "lodash/defaultTo";
import isEmpty from "lodash/isEmpty";
import flatten from "lodash/flatten";
import debounce from "debounce";
import { from } from "rxjs";
import { mergeMap, toArray } from "rxjs/operators";
import {
  FooterButtons,
  AttendeesSearch,
  AttendeeTags,
} from "../../../components";
import {
  RouteActions,
  ExchangeActions,
  ReservationActions,
  ReservationSelectors,
  ExchangeSelectors,
  LayoutSelectors,
  ApplicationSettingsSelectors,
  LoadingSelectors,
  RoomSearchActions,
} from "../../../store";
import { AppMsg, DefaultValues } from "../../../utils";
import { NON_EXCHANGE_TYPE } from "../../../model/exchange/ExchangePeople";

const cssBase = "attendessStepSmall";

class AttendeesStepSmall extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    attendees: PropTypes.array,
    peopleList: PropTypes.array,
    hasMore: PropTypes.bool,
    loading: PropTypes.bool,
    loadingMore: PropTypes.bool,
    dir: PropTypes.string,
    isExchangeIntegrated: PropTypes.bool,
    getInitialPeopleList: PropTypes.func,
    getNextPagePeopleList: PropTypes.func,
    getPhoto: PropTypes.func,
    clearPeopleList: PropTypes.func,
    navigateToReservationSummary: PropTypes.func,
    setAttendees: PropTypes.func,
    userExchangeProfile: PropTypes.object,
    getExchangePerson: PropTypes.func,
    setCapacityFilters: PropTypes.func,
    currentCalendar: PropTypes.object,
  };

  static getDerivedStateFromProps({ attendees }, { prevAttendees }) {
    if (prevAttendees !== attendees) {
      return {
        prevAttendees: attendees,
        attendees: defaultTo(attendees, []),
        searchText: "",
        debouncingSearch: false,
      };
    }
    return null;
  }

  state = {};

  render() {
    const {
      navigateToReservationSummary,
      peopleList,
      hasMore,
      loading,
      loadingMore,
      dir,
      getPhoto,
      isExchangeIntegrated,
    } = this.props;
    const { searchText, debouncingSearch, attendees } = this.state;
    return (
      <main className={cssBase}>
        <div className={`${cssBase}__stepDescription`}>
          {
            this.props.appMessages[
              AppMsg.RESERVATION_MESSAGE.STEP_MEETING_ATTENDEES
            ]
          }
        </div>
        <div className={`${cssBase}__content`}>
          <AttendeesSearch
            ref={(element) => {
              this.attendeesSearch = element;
            }}
            searchText={searchText}
            attendees={
              isEmpty(peopleList) || isEmpty(attendees)
                ? peopleList
                : this.getFilteredPeopleList(peopleList, attendees)
            }
            hasMore={hasMore}
            loading={loading || debouncingSearch}
            loadingMore={loadingMore}
            dir={dir}
            disableSearch={!isExchangeIntegrated}
            getPhoto={getPhoto}
            onSearchTextChange={this.handleSearchTextChange}
            onLoadMore={this.handleLoadMore}
            onSelect={this.handleOnSelect}
          />
          <AttendeeTags
            className={`${cssBase}__tags`}
            attendees={this.state.attendees}
            onRemove={this.handleAttendeeRemove}
          />
        </div>

        <FooterButtons
          secondaryLabel={this.props.appMessages[AppMsg.BUTTON.CANCEL]}
          secondaryClickedHandler={navigateToReservationSummary}
          primaryLabel={this.props.appMessages[AppMsg.BUTTON.DONE]}
          primaryClickedHandler={this.onDoneClick}
        />
      </main>
    );
  }

  handleSearchTextChange = (searchText) => {
    this.setState({ searchText, debouncingSearch: true });
    if (this.props.isExchangeIntegrated) {
      this.getInitialPeopleList(searchText);
    }
  };

  getInitialPeopleList = debounce((searchText) => {
    this.props.getInitialPeopleList(searchText);
    setTimeout(() => this.setState({ debouncingSearch: false }), 50);
  }, 300);

  handleLoadMore = () => {
    this.props.getNextPagePeopleList();
  };

  handleOnSelect = async (attendeeList) => {
    const {
      isExchangeIntegrated,
      userExchangeProfile,
      currentCalendar,
    } = this.props;
    const { attendees } = this.state;
    const filteredAttendeesList =
      isExchangeIntegrated && !isEmpty(attendeeList)
        ? attendeeList.filter((item) => {
            const filterEmail =
              userExchangeProfile.email !== currentCalendar.email
                ? currentCalendar.email
                : userExchangeProfile.email;
            return item.email !== filterEmail;
          })
        : attendeeList;
    const emailsToBeAdded = this.getUniqueEmails(
      attendees,
      filteredAttendeesList
    );

    if (isExchangeIntegrated) {
      await this.processEmailsToBeAdded(emailsToBeAdded);
    }
    this.setState({
      searchText: "",
      attendees: [...this.state.attendees, ...emailsToBeAdded],
    });
    this.props.clearPeopleList();
  };

  processEmailsToBeAdded = async (emailsToBeAdded) => {
    const attendeesToCheck = emailsToBeAdded.filter(
      (item) => item.type === NON_EXCHANGE_TYPE
    );
    let exchangeProfiles = await from(attendeesToCheck)
      .pipe(
        mergeMap((attendee) => this.props.getExchangePerson(attendee.email)),
        toArray()
      )
      .toPromise();

    exchangeProfiles = flatten(exchangeProfiles);
    if (!isEmpty(exchangeProfiles)) {
      for (const profile of exchangeProfiles) {
        const email = emailsToBeAdded.find(
          (item) => item.email.toLowerCase() === profile.email.toLowerCase()
        );
        if (email) {
          email.type = profile.type;
          email.firstName = profile.firstName;
          email.lastName = profile.lastName;
          email.name = profile.name;
        }
      }
    }
  };

  handleAttendeeRemove = (attendee) => {
    const attendees = this.state.attendees.filter(
      (item) => item.email !== attendee.email
    );
    this.setState({
      attendees,
    });
  };

  onDoneClick = () => {
    const { attendees, searchText } = this.state;
    if (searchText && searchText !== "") {
      this.handleValidEmailAddition(attendees);
    } else {
      this.props.setAttendees(attendees);
      this.updateDefaultCapacity(attendees);
      this.props.navigateToReservationSummary();
    }
  };

  updateDefaultCapacity = (attendees) => {
    this.props.setCapacityFilters(DefaultValues.CAPACITY + attendees.length);
  };

  handleValidEmailAddition = async (attendees) => {
    const {
      validEmails,
      invalidInput,
    } = this.attendeesSearch.getAttendeesFromInput();
    const { isExchangeIntegrated, userExchangeProfile } = this.props;
    const filteredValidEmails =
      isExchangeIntegrated && !invalidInput
        ? validEmails.filter((item) => item.email !== userExchangeProfile.email)
        : validEmails;
    if (!invalidInput) {
      const emailsToBeAdded = this.getUniqueEmails(
        attendees,
        filteredValidEmails
      );

      if (isExchangeIntegrated) {
        await this.processEmailsToBeAdded(emailsToBeAdded);
      }
      this.props.setAttendees([...attendees, ...emailsToBeAdded]);
      this.updateDefaultCapacity(attendees);
      this.props.navigateToReservationSummary();
    }
  };

  getUniqueEmails = (attendees, validEmails) => {
    const emailsToBeAdded = [];
    validEmails.forEach((item) => {
      if (
        attendees.map((attendee) => attendee.email).indexOf(item.email) === -1
      ) {
        emailsToBeAdded.push(item);
      }
    });
    return emailsToBeAdded;
  };

  getFilteredPeopleList = (peopleList, attendees) =>
    peopleList.filter(
      (people) => !attendees.some((attendee) => people.email === attendee.email)
    );
}

const mapStateToProps = (state) => {
  const { data: peopleList, hasMore } = ExchangeSelectors.peopleListSelector(
    state
  );
  return {
    peopleList,
    hasMore,
    loading: LoadingSelectors.loadingPeopleSelector(state),
    loadingMore: LoadingSelectors.loadingMorePeopleSelector(state),
    dir: LayoutSelectors.dirSelector(state),
    attendees: ReservationSelectors.attendeesSelector(state),
    isExchangeIntegrated: ApplicationSettingsSelectors.isExchangeIntegratedSelector(
      state
    ),
    userExchangeProfile: ExchangeSelectors.userExchangeProfileSelector(state),
    currentCalendar: ExchangeSelectors.currentCalendarSelector(state),
  };
};

const { navigateToReservationSummary } = RouteActions;
const {
  getPhoto,
  getInitialPeopleList,
  getNextPagePeopleList,
  clearPeopleList,
  getExchangePerson,
} = ExchangeActions;
const { setAttendees } = ReservationActions;
const { setCapacityFilters } = RoomSearchActions;

export default withTriDictionary(
  connect(mapStateToProps, {
    navigateToReservationSummary,
    getPhoto,
    getInitialPeopleList,
    getNextPagePeopleList,
    clearPeopleList,
    setAttendees,
    setCapacityFilters,
    getExchangePerson,
  })(AttendeesStepSmall)
);
