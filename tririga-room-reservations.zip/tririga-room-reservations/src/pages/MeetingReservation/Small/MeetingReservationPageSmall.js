/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import React from "react";
import PropTypes from "prop-types";
import { Route, Switch } from "react-router-dom";
import MeetingSummarySmall from "./MeetingSummarySmall";
import RoomSearchPageSmall from "../../RoomSearch/RoomSearchPageSmall";
import RoomFiltersPageSmall from "../../RoomFilters/RoomFiltersPageSmall";
import MeetingTimeStepSmall from "./MeetingTimeStepSmall";
import OnlineMeetingStepSmall from "./OnlineMeetingStepSmall";
import DetailsStepSmall from "./DetailsStepSmall";
import ChangeLocationPageSmall from "../../ChangeLocation/ChangeLocationPageSmall";
import AttendeesStepSmall from "./AttendeesStepSmall";
import RecurrencePageSmall from "../../Recurrence/RecurrencePageSmall";
import AvailabilitySmall from "../../Availability/AvailabilitySmall";
import RoomDetailsPageSmall from "../../RoomDetails/RoomDetailsPageSmall";
import RoomRecurrenceDetailsPageSmall from "../../RoomRecurrenceDetails/RoomRecurrenceDetailsPageSmall";
import CateringListPageSmall from "../../CateringList/CateringListPageSmall";
import EquipmentListPageSmall from "../../EquipmentList/EquipmentListPageSmall";
import EquipmentDetailsPageSmall from "../../EquipmentDetails/EquipmentDetailsPageSmall";
import OccurrenceExceptionsPageSmall from "../../OccurrenceExceptions/OccurrenceExceptionsPageSmall";
import { Routes } from "../../../utils";
import RoomSearchByNamePage from "../../RoomSearchByName/RoomSearchByNamePage";
export default class MeetingReservationPageSmall extends React.PureComponent {
  static propTypes = {
    match: PropTypes.object.isRequired,
  };

  render() {
    const { path } = this.props.match;
    return (
      <Switch>
        <Route exact path={path}>
          <MeetingSummarySmall />
        </Route>
        <Route exact path={`${path}${Routes.ATTENDEES}`}>
          <AttendeesStepSmall />
        </Route>
        <Route exact path={`${path}${Routes.TIME}`}>
          <MeetingTimeStepSmall />
        </Route>
        <Route exact path={`${path}${Routes.ONLINE_MEETING}`}>
          <OnlineMeetingStepSmall />
        </Route>
        <Route exact path={`${path}${Routes.TIME}${Routes.RECURRENCE}`}>
          <RecurrencePageSmall />
        </Route>
        <Route exact path={`${path}${Routes.TIME}${Routes.AVAILABILITY}`}>
          <AvailabilitySmall />
        </Route>
        <Route exact path={`${path}${Routes.SEARCH}`}>
          <RoomSearchPageSmall />
        </Route>
        <Route exact path={`${path}${Routes.DETAILS}`}>
          <DetailsStepSmall />
        </Route>
        <Route
          exact
          path={`${path}${Routes.SPACE_DETAILS}/:roomId${Routes.CATERING}`}
        >
          <CateringListPageSmall />
        </Route>
        <Route
          exact
          path={`${path}${Routes.SPACE_DETAILS}/:roomId${Routes.EQUIPMENT}`}
        >
          <EquipmentListPageSmall />
        </Route>
        <Route exact path={`${path}${Routes.SEARCH}${Routes.LOCATION}`}>
          <ChangeLocationPageSmall />
        </Route>
        <Route exact path={`${path}${Routes.SEARCH}${Routes.ROOMSEARCH}`}>
          <RoomSearchByNamePage />
        </Route>
        <Route exact path={`${path}${Routes.SEARCH}${Routes.SEARCH_FILTER}`}>
          <RoomFiltersPageSmall />
        </Route>
        <Route exact path={`${path}${Routes.SPACE_DETAILS}/:roomId`}>
          <RoomDetailsPageSmall />
        </Route>
        <Route exact path={`${path}${Routes.ROOM_RECURRENCE_DETAILS}/:roomId`}>
          <RoomRecurrenceDetailsPageSmall />
        </Route>
        <Route
          exact
          path={`${path}${Routes.SPACE_DETAILS}/:roomId${Routes.EQUIPMENT}/:equipmentId`}
        >
          <EquipmentDetailsPageSmall />
        </Route>
        <Route exact path={`${path}${Routes.EXCEPTION}/:resourceId`}>
          <OccurrenceExceptionsPageSmall />
        </Route>
      </Switch>
    );
  }
}
