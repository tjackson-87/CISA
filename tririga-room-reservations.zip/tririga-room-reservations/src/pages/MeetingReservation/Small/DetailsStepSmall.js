/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import { connect } from "react-redux";
import defaultTo from "lodash/defaultTo";
import PropTypes from "prop-types";
import { FooterButtons, DescriptionInput } from "../../../components";
import {
  ReservationActions,
  RouteActions,
  ReservationSelectors,
  CurrentUserSelectors,
  LayoutSelectors,
} from "../../../store";
import { AppMsg } from "../../../utils";
import { Information20 } from "@carbon/icons-react";
import {
  ComposedModal,
  ModalHeader,
  ModalBody,
  DataTable,
  Table,
  TableHead,
  TableRow,
  TableHeader,
  TableBody,
  TableCell,
  TooltipIcon,
} from "carbon-components-react";

const cssBase = "detailsStepSmall";
const EXTRA_TEXT_TO_REMOVE = "<p></p>";

class DetailsStepSmall extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    navigateToReservationSummary: PropTypes.func.isRequired,
    updateDescription: PropTypes.func.isRequired,
    description: PropTypes.string,
    dir: PropTypes.string,
    language: PropTypes.string,
  };

  constructor(props) {
    super(props);
    this.descriptionRef = React.createRef();
  }

  componentDidMount() {
    const element = document.getElementsByClassName("bx--tooltip__trigger");
    this.descriptionRef = element[0];
    if (this.descriptionRef) {
      this.descriptionRef.focus();
    }
  }

  static getDerivedStateFromProps({ description }, { prevDescription }) {
    if (prevDescription !== description) {
      return {
        prevDescription: description,
        description: defaultTo(description, ""),
      };
    }
    return null;
  }

  state = {
    viewInformationModal: false,
  };

  render() {
    const { navigateToReservationSummary, dir, language } = this.props;
    const { description, viewInformationModal } = this.state;
    const rows = [
      {
        id: "a",
        task: [
          this.props.appMessages[AppMsg.ACCESSIBILITY_MESSAGES.MENU_BAR_FOCUS],
        ],
        pc: "Alt+F9",
        macOS: "Option+F9",
      },
      {
        id: "b",
        task: [
          this.props.appMessages[AppMsg.ACCESSIBILITY_MESSAGES.TOOL_BAR_FOCUS],
        ],
        pc: "Alt+F10",
        macOS: "Option+F10",
      },
      {
        id: "c",
        task: [
          this.props.appMessages[
            AppMsg.ACCESSIBILITY_MESSAGES.ELEMENT_PATH_FOCUS
          ],
        ],
        pc: "Alt+F11",
        macOS: "Option+F11",
      },
      {
        id: "d",
        task: [
          this.props.appMessages[
            AppMsg.ACCESSIBILITY_MESSAGES.CLOSE_SUBMENU_DIALOG
          ],
        ],
        pc: "Esc",
        macOS: "Esc",
      },
      {
        id: "e",
        task: [
          this.props.appMessages[
            AppMsg.ACCESSIBILITY_MESSAGES.RETURN_EDITOR_AREA
          ],
        ],
        pc: "Esc",
        macOS: "Esc",
      },
      {
        id: "f",
        task: [
          this.props.appMessages[
            AppMsg.ACCESSIBILITY_MESSAGES.NAVIGATE_LEFT_RIGHT
          ],
        ],
        pc: [
          this.props.appMessages[
            AppMsg.ACCESSIBILITY_MESSAGES.TAB_AND_ARROW_KEYS
          ],
        ],
        macOS: [
          this.props.appMessages[
            AppMsg.ACCESSIBILITY_MESSAGES.TAB_AND_ARROW_KEYS
          ],
        ],
      },
    ];
    const headers = [
      {
        key: "task",
        header: [this.props.appMessages[AppMsg.ACCESSIBILITY_MESSAGES.TASK]],
      },
      {
        key: "pc",
        header: [this.props.appMessages[AppMsg.ACCESSIBILITY_MESSAGES.DESKTOP]],
      },
      {
        key: "macOS",
        header: [this.props.appMessages[AppMsg.ACCESSIBILITY_MESSAGES.MACOS]],
      },
    ];
    return (
      <main className={cssBase}>
        <div className={`${cssBase}__stepDescription`}>
          {
            this.props.appMessages[
              AppMsg.RESERVATION_MESSAGE.STEP_MEETING_DETAILS
            ]
          }
          <span onClick={this.handleOnInformationClick}>
            <TooltipIcon
              direction="left"
              align={dir === "ltr" ? "start" : "end"}
              tooltipText="Information Icon"
              className={`${cssBase}__toolTip`}
            >
              <Information20 />
            </TooltipIcon>
          </span>
        </div>
        <div className={`${cssBase}__content`}>
          <DescriptionInput
            onChange={this.handleDescriptionChanged}
            className={`${cssBase}__descriptionInput`}
            value={description}
            dir={dir}
            language={language}
          />
        </div>

        <FooterButtons
          secondaryLabel={this.props.appMessages[AppMsg.BUTTON.CANCEL]}
          secondaryClickedHandler={navigateToReservationSummary}
          primaryLabel={this.props.appMessages[AppMsg.BUTTON.DONE]}
          primaryClickedHandler={this.onDoneClick}
        />

        {viewInformationModal && (
          <ComposedModal
            preventCloseOnClickOutside
            open={viewInformationModal}
            onClose={() => {
              this.setState({ viewInformationModal: false });
              setTimeout(() => {
                this.descriptionRef.focus();
              }, 1);
            }}
            size="sm"
            selectorPrimaryFocus=".bx--modal-close"
            aria-label={
              this.props.appMessages[
                AppMsg.RESERVATION_MESSAGE.COMMAND_CONTROLS_INFORMATION
              ]
            }
          >
            <ModalHeader>
              <h4>
                {
                  this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE.COMMAND_CONTROLS_INFORMATION
                  ]
                }
              </h4>
            </ModalHeader>
            <ModalBody tabIndex={0}>
              <DataTable rows={rows} headers={headers}>
                {({
                  rows,
                  headers,
                  getTableProps,
                  getHeaderProps,
                  getRowProps,
                }) => (
                  <Table {...getTableProps()}>
                    <TableHead>
                      <TableRow>
                        {headers.map((header) => (
                          <TableHeader
                            key={header.key}
                            {...getHeaderProps({ header })}
                          >
                            {header.header}
                          </TableHeader>
                        ))}
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {rows.map((row) => (
                        <TableRow key={row.id} {...getRowProps({ row })}>
                          {row.cells.map((cell) => (
                            <TableCell key={cell.id}>{cell.value}</TableCell>
                          ))}
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </DataTable>
            </ModalBody>
          </ComposedModal>
        )}
      </main>
    );
  }

  onDoneClick = () => {
    const { description } = this.state;
    this.props.updateDescription(description.replace(EXTRA_TEXT_TO_REMOVE, ""));
    this.props.navigateToReservationSummary();
  };

  handleDescriptionChanged = (value) => {
    this.setState({
      description: value,
    });
  };

  handleOnInformationClick = () => {
    this.setState({ viewInformationModal: true });
  };
}

const mapStateToProps = (state) => {
  return {
    description: ReservationSelectors.descriptionSelector(state),
    language: CurrentUserSelectors.languageSelector(state),
    dir: LayoutSelectors.dirSelector(state),
  };
};

const { updateDescription } = ReservationActions;
const { navigateToReservationSummary } = RouteActions;

export default withTriDictionary(
  connect(mapStateToProps, {
    navigateToReservationSummary,
    updateDescription,
  })(DetailsStepSmall)
);
