/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import { connect } from "react-redux";
import { Button } from "carbon-components-react";
import { Edit16, TrashCan16 } from "@carbon/icons-react";
import PropTypes from "prop-types";
import isEmpty from "lodash/isEmpty";
import {
  FooterButtons,
  OnlineMeetingInput,
  DisplayMeetingInfo,
  AddEditMeetingInfo,
} from "../../../components";
import {
  AppMsg,
  OnlineMeetingConstants,
  LayoutTypesConstants,
} from "../../../utils";
import {
  OnlineMeetingActions,
  RouteActions,
  OnlineMeetingSelectors,
} from "../../../store";
import MediaQuery from "react-responsive";

const cssBase = "onlineMeetingStepSmall";

class OnlineMeetingStepSmall extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    navigateToReservationSummary: PropTypes.func,
    onlineMeetings: PropTypes.array,
    updateRecord: PropTypes.func,
    setSelectedOnlineMeeting: PropTypes.func.isRequired,
    setOnlineMeetingEditFlag: PropTypes.func,
    submitOnlineMeeting: PropTypes.func,
    deleteOnlineMeeting: PropTypes.func,
    record: PropTypes.object,
    selectedId: PropTypes.string,
    edit: PropTypes.bool,
  };

  render() {
    const { onlineMeetings, record, selectedId, edit } = this.props;

    return (
      <main className={cssBase}>
        <div className={`${cssBase}__stepDescription`}>
          {
            this.props.appMessages[
              AppMsg.RESERVATION_MESSAGE.STEP_MEETING_ONLINE_MEETING
            ]
          }
        </div>
        <div className={`${cssBase}__content`}>
          <div className={`${cssBase}__meetingName`}>
            <OnlineMeetingInput
              selectedId={selectedId}
              onlineMeetings={onlineMeetings}
              onOnlineMeetingChange={this.handleChange}
            />
          </div>
          <div className={`${cssBase}__marginBorder page__section`}>
            <MediaQuery minWidth={LayoutTypesConstants.MIN_LARGE_SCREEN_WIDTH}>
              {!edit && !isEmpty(record?._id) && (
                <div className={`${cssBase}__onlineMeetingHeader`}>
                  <div className={`${cssBase}__onlineMeetingNameSection`}>
                    <div className={`${cssBase}__onlineMeetingName`}>
                      {
                        this.props.appMessages[
                          AppMsg.RESERVATION_MESSAGE.MEETING_NAME
                        ]
                      }
                    </div>
                    <div className={`${cssBase}__onlineMeetingLabel`}>
                      {record.name}
                    </div>
                  </div>
                  <div className={`${cssBase}__editDeleteSectionLarge`}>
                    <Button
                      kind="ghost"
                      size="small"
                      className={`${cssBase}__editButton`}
                      renderIcon={Edit16}
                      onClick={this.handleEditMeeting}
                    >
                      {this.props.appMessages[AppMsg.BUTTON.BUTTON_EDIT]}
                    </Button>
                    <Button
                      kind="ghost"
                      size="small"
                      renderIcon={TrashCan16}
                      onClick={this.handleDeleteMeeting}
                    >
                      {this.props.appMessages[AppMsg.BUTTON.BUTTON_DELETE]}
                    </Button>
                  </div>
                </div>
              )}
            </MediaQuery>
            <MediaQuery maxWidth={LayoutTypesConstants.MAX_SMALL_SCREEN_WIDTH}>
              {!edit && !isEmpty(record?._id) && (
                <div className={`${cssBase}__editDeleteSection`}>
                  <div className={`${cssBase}__editDeleteItems`}>
                    <Button
                      kind="ghost"
                      size="small"
                      className={`${cssBase}__editButton`}
                      renderIcon={Edit16}
                      onClick={this.handleEditMeeting}
                    >
                      {this.props.appMessages[AppMsg.BUTTON.BUTTON_EDIT]}
                    </Button>
                    <Button
                      kind="ghost"
                      size="small"
                      renderIcon={TrashCan16}
                      onClick={this.handleDeleteMeeting}
                    >
                      {this.props.appMessages[AppMsg.BUTTON.BUTTON_DELETE]}
                    </Button>
                  </div>
                </div>
              )}
            </MediaQuery>

            {!edit && <DisplayMeetingInfo meetingInfo={record} />}

            {edit && (
              <AddEditMeetingInfo
                meetingInfo={record}
                onChange={this.handleUpdateRecordChange}
              />
            )}
          </div>
        </div>
        <FooterButtons
          secondaryLabel={this.props.appMessages[AppMsg.BUTTON.CANCEL]}
          secondaryClickedHandler={this.onCancelClick}
          primaryLabel={this.props.appMessages[AppMsg.BUTTON.DONE]}
          primaryClickedHandler={this.onDoneClick}
          primaryDisabled={!this.isRecordValid()}
        />
      </main>
    );
  }

  handleChange = (selectedId) => {
    this.props.setSelectedOnlineMeeting(selectedId);
  };

  handleEditMeeting = () => {
    this.props.setOnlineMeetingEditFlag(true);
  };

  handleDeleteMeeting = () => {
    const { record, deleteOnlineMeeting } = this.props;
    deleteOnlineMeeting(record._id);
  };

  handleUpdateRecordChange = (key, value) => {
    this.props.updateRecord(key, value);
  };

  isRecordValid = () => {
    const { record, selectedId } = this.props;
    if (
      selectedId === OnlineMeetingConstants.NO_SELECTED_MEETING_KEY ||
      (!isEmpty(record?.name) && !isEmpty(record?.url))
    ) {
      return true;
    }
  };

  onCancelClick = () => {
    if (this.props.edit) {
      this.props.setOnlineMeetingEditFlag(false);
    } else {
      this.props.navigateToReservationSummary();
    }
  };

  onDoneClick = () => {
    this.props.submitOnlineMeeting();
  };
}

const mapStateToProps = (state) => {
  return {
    onlineMeetings: OnlineMeetingSelectors.onlineMeetingsSelector(state),
    record: OnlineMeetingSelectors.selectedRecordSelector(state),
    edit: OnlineMeetingSelectors.editRecordSelector(state),
    selectedId: OnlineMeetingSelectors.selectedIdSelector(state),
  };
};

const { navigateToReservationSummary, navigateBackToHomePage } = RouteActions;

export default withTriDictionary(
  connect(mapStateToProps, {
    navigateToReservationSummary,
    navigateBackToHomePage,
    setSelectedOnlineMeeting: OnlineMeetingActions.setSelectedOnlineMeeting,
    updateRecord: OnlineMeetingActions.updateRecord,
    setOnlineMeetingEditFlag: OnlineMeetingActions.setOnlineMeetingEditFlag,
    submitOnlineMeeting: OnlineMeetingActions.submitOnlineMeeting,
    deleteOnlineMeeting: OnlineMeetingActions.deleteOnlineMeeting,
  })(OnlineMeetingStepSmall)
);
