/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name:  Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import { Modal } from "carbon-components-react";
import {
  CurrentUserSelectors,
  ReservationActions,
  ReservationSelectors,
  LayoutSelectors,
  RoomSearchSelectors,
  RoomSearchActions,
} from "../../store";
import { Recurrence } from "../../components";
import { AppMsg, RecurrenceConstants, getRecurrenceInitial } from "../../utils";
import defaultTo from "lodash/defaultTo";
import { isNil } from "lodash";

const cssBase = "recurrencePageSmall";

class RecurrencePageSmall extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    updateTimeStepTempDateAndTime: PropTypes.func,
    getTimeStepTempRecurrenceDetails: PropTypes.func,
    dateFormats: PropTypes.object,
    dateAndTime: PropTypes.object,
    recurrence: PropTypes.object,
    isRecurrenceModalOpen: PropTypes.bool,
    setRecurrenceModal: PropTypes.func,
    onClose: PropTypes.func,
  };

  static getDerivedStateFromProps = (
    { recurrence, dateAndTime },
    { prevRecurrence }
  ) => {
    if (recurrence !== prevRecurrence) {
      return {
        recurrence: defaultTo(recurrence, getRecurrenceInitial(dateAndTime)),
        prevRecurrence: recurrence,
      };
    }

    return null;
  };

  state = {};

  render() {
    const { dateFormats, isRecurrenceModalOpen } = this.props;
    const { recurrence } = this.state;
    return (
      <Modal
        open={isRecurrenceModalOpen}
        size="sm"
        onRequestClose={() => this.onModalClose()}
        selectorPrimaryFocus=".bx--modal-close"
        modalHeading={
          this.props.appMessages[
            AppMsg.RESERVATION_MESSAGE
              .STEP_TIME_MEETING_CHANGE_MEETING_RECURRENCE
          ]
        }
        primaryButtonText={this.props.appMessages[AppMsg.BUTTON.APPLY]}
        secondaryButtonText={this.props.appMessages[AppMsg.BUTTON.CANCEL]}
        onRequestSubmit={() => {
          this.onApplyClick();
        }}
        onSecondarySubmit={() => this.onModalClose()}
        iconDescription={this.props.appMessages[AppMsg.BUTTON.CLOSE]}
      >
        <div className={cssBase}>
          <div className={`${cssBase}__content`}>
            <Recurrence
              recurrence={recurrence}
              onRecurrenceChange={this.handleRecurrenceChange}
              dateFormats={dateFormats}
            />
          </div>
        </div>
      </Modal>
    );
  }

  onModalClose = () => {
    const { onClose, setRecurrenceModal } = this.props;
    if (!isNil(onClose)) {
      onClose();
    }
    setRecurrenceModal(false);
  };

  onApplyClick = () => {
    const {
      updateTimeStepTempDateAndTime,
      getTimeStepTempRecurrenceDetails,
      setRecurrenceModal,
    } = this.props;
    updateTimeStepTempDateAndTime({
      recurrence: this.state.recurrence,
    });
    getTimeStepTempRecurrenceDetails();
    setRecurrenceModal(false);
  };

  handleRecurrenceChange = (value, key) => {
    const newRecurrence = { ...this.state.recurrence };
    newRecurrence[key] = value;
    this.setState({ recurrence: newRecurrence });
  };

  computePrimaryDisable = (recurrence) => {
    return (
      (recurrence?.end?.type ===
        RecurrenceConstants.RECUR_END_VALUES.END_DATE &&
        !recurrence.end.endDate) ||
      (recurrence?.type === RecurrenceConstants.RECUR_TYPE_VALUES.WEEKLY &&
        !recurrence.weeklyProperties.weeklyDays.some((day) => day))
    );
  };
}

const mapStateToProps = (state) => {
  return {
    dateFormats: {
      carbonDateFormat: CurrentUserSelectors.carbonDateFormatSelector(state),
      dateFormat: CurrentUserSelectors.dateFormatSelector(state),
      carbonLocale: CurrentUserSelectors.carbonLocaleSelector(state),
    },
    recurrence: ReservationSelectors.timeStepTempRecurrenceSelector(state),
    dateAndTime: ReservationSelectors.timeStepTempDateAndTimeSelector(state),
    dir: LayoutSelectors.dirSelector(state),
    isRecurrenceModalOpen: RoomSearchSelectors.recurrenceModalSelector(state),
  };
};

const { setRecurrenceModal } = RoomSearchActions;

export default withTriDictionary(
  connect(mapStateToProps, {
    updateTimeStepTempDateAndTime:
      ReservationActions.updateTimeStepTempDateAndTime,
    getTimeStepTempRecurrenceDetails:
      ReservationActions.getTimeStepTempRecurrenceDetails,
    setRecurrenceModal,
  })(RecurrencePageSmall)
);
