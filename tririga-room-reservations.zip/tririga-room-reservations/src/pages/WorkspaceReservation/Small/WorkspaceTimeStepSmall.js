/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { withTriDictionary } from "@tririga/tririga-react-components";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { RadioButtonGroup, RadioButton } from "carbon-components-react";
import {
  DateTimeViewSwitcher,
  FooterButtons,
  ReservationTime,
} from "../../../components";
import {
  ReservationActions,
  RouteActions,
  ReservationSelectors,
  TimezonesSelectors,
  CurrentUserSelectors,
  RoomSearchActions,
  RoomSearchSelectors,
} from "../../../store";
import {
  AppMsg,
  computeMomentStartAndEndDates,
  RecurrenceConstants,
  DateTimeConstants,
  getResourceTimezones,
} from "../../../utils";
import { defaultTo } from "lodash";
import RecurrencePageSmall from "../../Recurrence/RecurrencePageSmall";

const cssBase = "workspaceTimeStepSmall";
const ID_PREFIX = "workspace-";
const RADIO_BUTTON_GROUP_DAY_LEGEND_NAME = "Recurrence Type Group Legend";
const RADIO_BUTTON_GROUP_TIME_LEGEND_NAME = "Recurrence Type Group Legend";

const {
  DateTimeViewMode,
  WORKSPACE_DAY,
  WORKSPACE_TIME,
  WORKSPACE_ALL_DAY_START,
  WORKSPACE_ALL_DAY_MID,
  WORKSPACE_ALL_DAY_END,
} = DateTimeConstants;

const DayOptions = Object.keys(WORKSPACE_DAY).map((key) => {
  return {
    messageKey: AppMsg.RESERVATION_MESSAGE[key],
    value: WORKSPACE_DAY[key],
  };
});
const TimeOptions = Object.keys(WORKSPACE_TIME).map((key) => {
  return {
    messageKey: AppMsg.RESERVATION_MESSAGE[key],
    value: WORKSPACE_TIME[key],
  };
});

class WorkspaceTimeStepSmall extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    dateAndTime: PropTypes.object,
    timezones: PropTypes.array,
    navigateToReservationSummary: PropTypes.func.isRequired,
    updateDateAndTime: PropTypes.func.isRequired,
    getTimeStepTempRecurrenceDetails: PropTypes.func.isRequired,
    updateTimeStepTempDateAndTime: PropTypes.func,
    dateTimeViewMode: PropTypes.string,
    updateDateTimeViewMode: PropTypes.func,
    isEditingSeriesOccurrence: PropTypes.bool,
    defaultTimezone: PropTypes.string,
    resources: PropTypes.array,
    setRecurrenceModal: PropTypes.func,
    isRecurrenceModalOpen: PropTypes.bool,
  };

  state = {
    setRecurrenceFlag: false,
  };

  render() {
    const {
      dateAndTime,
      timezones,
      navigateToReservationSummary,
      updateDateTimeViewMode,
     // isEditingSeriesOccurrence,
      defaultTimezone,
      resources,
    } = this.props;

    const { recurrence, dayType, timeType, dateTimeViewMode } = dateAndTime;

    const recurrenceMessage =
      recurrence &&
      recurrence.type !== RecurrenceConstants.RECUR_TYPE_VALUES.NONE &&
      recurrence.details
        ? recurrence.details.ruleLabel
        : AppMsg.getMessage(
            AppMsg.RESERVATION_MESSAGE.STEP_TIME_WORKSPACE_NO_RECURRENCES
          );

    return (
      <main className={cssBase}>
        <div className={`${cssBase}__stepDescription`}>
          {
            this.props.appMessages[
              AppMsg.RESERVATION_MESSAGE.STEP_TIME_DESCRIPTION
            ]
          }
        </div>
        <div className={`${cssBase}__content`}>
          <DateTimeViewSwitcher
            onChange={(mode) => {
              updateDateTimeViewMode(dateAndTime, mode);
            }}
            mode={defaultTo(dateTimeViewMode, DateTimeViewMode.SIMPLE)}
            className={`${cssBase}__viewSwitcher`}
          />
          {dateTimeViewMode === DateTimeViewMode.ADVANCED && (
            <ReservationTime
              dateAndTime={dateAndTime}
              recurrenceMessage={recurrenceMessage}
              timezones={timezones}
              onRecurrenceClick={() => this.setRecurrence()}
              focusRecurrence={
                this.state.setRecurrenceFlag &&
                !this.props.isRecurrenceModalOpen
              }
              onChange={this.handleReservationTimeChange}
              // hideRecurrence={isEditingSeriesOccurrence} // OOB
              hideRecurrence={true} // CISA
              defaultTimezone={defaultTimezone}
              resourcesTimezoneDetails={getResourceTimezones(
                resources,
                timezones
              )}
            />
          )}
          {dateTimeViewMode === DateTimeViewMode.SIMPLE && (
            <>
              <RadioButtonGroup
                orientation="vertical"
                legend={RADIO_BUTTON_GROUP_DAY_LEGEND_NAME}
                name="workspace-day-group"
                valueSelected={dayType}
                onChange={this.handleDayType}
                legendText={
                  this.props.appMessages[AppMsg.RESERVATION_MESSAGE.DAY_HEADING]
                }
              >
                {DayOptions.map((option) => (
                  <RadioButton
                    id={`${ID_PREFIX}${option.value}`}
                    key={`${ID_PREFIX}${option.value}`}
                    labelText={this.props.appMessages[option.messageKey]}
                    value={option.value}
                  />
                ))}
              </RadioButtonGroup>

              <RadioButtonGroup
                orientation="vertical"
                legend={RADIO_BUTTON_GROUP_TIME_LEGEND_NAME}
                name="workspace-time-group"
                valueSelected={timeType}
                onChange={this.handleTimeType}
                legendText={
                  this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE.TIME_HEADING
                  ]
                }
              >
                {TimeOptions.map((option) => (
                  <RadioButton
                    id={`${ID_PREFIX}${option.value}`}
                    key={`${ID_PREFIX}${option.value}`}
                    labelText={this.props.appMessages[option.messageKey]}
                    value={option.value}
                  />
                ))}
              </RadioButtonGroup>
            </>
          )}
        </div>

        <FooterButtons
          secondaryLabel={this.props.appMessages[AppMsg.BUTTON.CANCEL]}
          secondaryClickedHandler={navigateToReservationSummary}
          primaryLabel={this.props.appMessages[AppMsg.BUTTON.DONE]}
          primaryClickedHandler={this.onDoneClick}
          primaryDisabled={this.computeDoneButtonDisabled()}
        />
        <RecurrencePageSmall onClose={() => this.onClose()} />
      </main>
    );
  }

  setRecurrence() {
    this.setState({ setRecurrenceFlag: true });
    this.props.setRecurrenceModal(true);
  }

  onClose = () => {
    this.props.setRecurrenceModal(false);
  };

  handleReservationTimeChange = (key, value, computedEndDate) => {
    this.props.updateTimeStepTempDateAndTime({
      [key]: value,
      ...computedEndDate,
    });
    this.setState({ setRecurrenceFlag: false });
  };

  handleDayType = (valueSelected) => {
    const { dateAndTime, updateTimeStepTempDateAndTime } = this.props;
    const newDate = new Date(dateAndTime.startDate);
    if (valueSelected === WORKSPACE_DAY.TOMORROW) {
      newDate.setDate(newDate.getDate() + 1);
    } else {
      newDate.setDate(newDate.getDate() - 1);
    }
    updateTimeStepTempDateAndTime({
      ...dateAndTime,
      startDate: newDate,
      endDate: newDate,
      dayType: valueSelected,
    });
  };

  handleTimeType = (valueSelected) => {
    const { dateAndTime, updateTimeStepTempDateAndTime } = this.props;
    let timeObject;
    if (valueSelected === WORKSPACE_TIME.MORNING) {
      timeObject = this.getTimeObj(
        WORKSPACE_ALL_DAY_START,
        "AM",
        WORKSPACE_ALL_DAY_MID,
        "PM"
      );
    } else if (valueSelected === WORKSPACE_TIME.AFTERNOON) {
      timeObject = this.getTimeObj(
        WORKSPACE_ALL_DAY_MID,
        "PM",
        WORKSPACE_ALL_DAY_END,
        "PM"
      );
    } else {
      timeObject = this.getTimeObj(
        WORKSPACE_ALL_DAY_START,
        "AM",
        WORKSPACE_ALL_DAY_END,
        "PM"
      );
    }
    updateTimeStepTempDateAndTime({
      ...dateAndTime,
      ...timeObject,
      timeType: valueSelected,
    });
  };

  getTimeObj = (startTime, startTimePeriod, endTime, endTimePeriod) => {
    return {
      startTime,
      startTimePeriod,
      endTime,
      endTimePeriod,
    };
  };

  onDoneClick = async () => {
    await this.props.getTimeStepTempRecurrenceDetails();
    this.props.updateDateAndTime(this.props.dateAndTime);
    this.props.navigateToReservationSummary();
  };

  computeDoneButtonDisabled = () => {
    const { dateAndTime } = this.props;
    const { startDateTime, endDateTime } = computeMomentStartAndEndDates(
      dateAndTime
    );
    return dateAndTime.allDayEvent
      ? endDateTime.isBefore(startDateTime)
      : endDateTime.isSameOrBefore(startDateTime);
  };
}

const mapStateToProps = (state) => {
  return {
    dateAndTime: ReservationSelectors.timeStepTempDateAndTimeSelector(state),
    exchangeAttendees: ReservationSelectors.exchangeAttendeesSelector(state),
    timezones: TimezonesSelectors.timezonesSelector(state),
    isEditingSeriesOccurrence: ReservationSelectors.isEditingSeriesOccurrenceSelector(
      state
    ),
    defaultTimezone: CurrentUserSelectors.defaultTimezoneSelector(state),
    resources: ReservationSelectors.orderedResourcesSelector(state),
    isRecurrenceModalOpen: RoomSearchSelectors.recurrenceModalSelector(state),
  };
};

const { setRecurrenceModal } = RoomSearchActions;

export default withTriDictionary(
  connect(mapStateToProps, {
    updateDateAndTime: ReservationActions.updateDateAndTime,
    updateDateTimeViewMode: ReservationActions.updateDateTimeViewMode,
    updateTimeStepTempDateAndTime:
      ReservationActions.updateTimeStepTempDateAndTime,
    getTimeStepTempRecurrenceDetails:
      ReservationActions.getTimeStepTempRecurrenceDetails,
    navigateToReservationSummary: RouteActions.navigateToReservationSummary,
    setRecurrenceModal,
  })(WorkspaceTimeStepSmall)
);
