/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2022-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import classNames from "classnames";
import {
  SkeletonText,
  Link,
  Accordion,
  AccordionItem,
  ToastNotification,
  TooltipIcon,
} from "carbon-components-react";
import {
  Close20,
  Time16,
  Group16,
  Document16,
  Location16,
  CheckmarkOutline16,
  Unknown16,
  Undefined16,
  User16,
  Printer16,
  Cafe16,
  MisuseOutline16,
  UserAvatarFilled16,
  Information16,
  Enterprise16,
  Building16,
  Purchase16,
} from "@carbon/icons-react";
import { isNil, isEmpty } from "lodash";
import { TriNote, withTriDictionary } from "@tririga/tririga-react-components";
import {
  AppMsg,
  ReservationTypes,
  ReservableSpacesConstants,
  ContactRolesConstants,
  Status,
  ReservationUtils,
  isNow,
  TimezoneUtils,
} from "../../utils";
import {
  RouteActions,
  EventDetailsSelectors,
  LoadingSelectors,
  LayoutSelectors,
  ExchangeActions,
  MyCalendarActions,
  MyCalendarSelectors,
  CheckInActions,
  ApplicationSettingsSelectors,
  LocationActions,
  CurrentUserSelectors,
  RoomSearchActions,
  RoomDetailsActions,
  CurrenciesSelectors,
  ExchangeSelectors,
  SyncWithOutlookActions,
} from "../../store";
import { Exchange } from "../../model";
import {
  CateringSummary,
  CheckInStatusButtons,
  EquipmentDetails,
  EventFooterButtons,
  TimezoneStatus,
  ReserveNotification,
} from "../../components";
import {
  hasDeclinedRooms,
  hasPendingRooms,
} from "../../utils/reservation/ReservationUtils";
import RoomDetailsPageSmall from "../RoomDetails/RoomDetailsPageSmall";
import WorkspaceListReadOnly from "../../components/RoomList/WorkspaceListReadOnly";
import CostSummary from "../../components/CostSummary/CostSummary";
import { EmptyState } from "carbon-addons-iot-react";

const cssBase = "eventDetailsPageSmall";

const { RESERVATION_CLASS_REQUESTABLE } = ReservableSpacesConstants;

const { RESOURCE_OWNER } = ContactRolesConstants;

class EventDetailsPageSmall extends React.PureComponent {
  static propTypes = {
    appMessages: PropTypes.object,
    event: PropTypes.object,
    formattedDate: PropTypes.string,
    attendees: PropTypes.array,
    costSummary: PropTypes.object,
    description: PropTypes.string,
    loadingAttendeesAndDescription: PropTypes.bool,
    dir: PropTypes.string,
    updateResponse: PropTypes.func,
    editReservation: PropTypes.func,
    navigateToCateringPage: PropTypes.func,
    navigateToEquipmentPage: PropTypes.func,
    deleteEvent: PropTypes.func,
    onlineMeetingInfo: PropTypes.object,
    cateringGroupByRoomIdAndOrderId: PropTypes.object,
    timezone: PropTypes.string,
    releaseRoom: PropTypes.func,
    checkIn: PropTypes.func,
    releaseRoomEarly: PropTypes.func,
    recheckRoom: PropTypes.func,
    loadingReleaseRoom: PropTypes.bool,
    loadingCheckIn: PropTypes.bool,
    loadingReleaseRoomEarly: PropTypes.bool,
    loadingReCheckRoom: PropTypes.bool,
    isExchangeIntegrated: PropTypes.bool,
    updateRoomsCanceled: PropTypes.func,
    browserTimezoneEventTime: PropTypes.string,
    defaultTimezone: PropTypes.string,
    setPrevSelectedBuilding: PropTypes.func,
    setLastMeetingSearchFilters: PropTypes.func,
    setRoomDetailsModal: PropTypes.func,
    setRoomId: PropTypes.func,
    closePage: PropTypes.func,
    eventExtension: PropTypes.object,
    currentUserLocale: PropTypes.string,
    currencies: PropTypes.array,
    currentCalendar: PropTypes.object,
    delegateCalendar: PropTypes.array,
    setCurrentCalendar: PropTypes.func,
    setIsSyncingWithOutlook: PropTypes.func,
  };

  static defaultProps = {
    loadingAttendeesAndDescription: false,
  };

  state = {
    timerDuration: null,
    statusCheck: null,
    roomDetailModal: null,
  };

  constructor(props) {
    super(props);
    this.roomRef = "";
  }

  isDelegatedUser = (event) => {
    return (
      !isNil(event.requestedBy) &&
      !isNil(event.requestedFor) &&
      !isEmpty(event.requestedBy) &&
      !isEmpty(event.requestedFor) &&
      event.requestedBy !== event.requestedFor
    );
  };

  render() {
    const {
      event,
      dir,
      formattedDate,
      onlineMeetingInfo,
      updateResponse,
      editReservation,
      deleteEvent,
      setIsSyncingWithOutlook,
      isExchangeIntegrated,
      browserTimezoneEventTime,
      setPrevSelectedBuilding,
      setLastMeetingSearchFilters,
      defaultTimezone,
      closePage,
      eventExtension,
      costSummary,
    } = this.props;

    if (!event)
      return (
        <EmptyState
          icon="not-authorized"
          title={this.props.appMessages[AppMsg.ERRORS.NOT_AUTHORIZED]}
          body={this.props.appMessages[AppMsg.ERRORS.NO_PERMISSION]}
          className={`${cssBase}__notAuthorized`}
          action={{
            label: this.props.appMessages[AppMsg.BUTTON.CLOSE_PAGE],
            onClick: () => closePage(),
          }}
        />
      );

    const isAttendee = !event?.isOrganizer && !isEmpty(event?.organizer);
    return (
      <main className={cssBase}>
        <div
          onClick={closePage}
          onKeyDown={(e) => (e.key === "Enter" ? closePage : null)}
          className={`${cssBase}__closeButton`}
        >
          <TooltipIcon
            direction="left"
            align={dir === "ltr" ? "start" : "end"}
            tooltipText={this.props.appMessages[AppMsg.BUTTON.CLOSE]}
            aria-label={this.props.appMessages[AppMsg.BUTTON.CLOSE]}
          >
            <Close20 />
          </TooltipIcon>
        </div>
        <div className={`${cssBase}__subject`}>{event.subject}</div>
        <div className={`${cssBase}__content`}>
          {!event.isOrganizer &&
            !isEmpty(event.organizer) &&
            event.locationType !== ReservationTypes.WORKSPACE && 
            event.locationType !== ReservationTypes.OFFICE && (
              <>
                {this.renderResponseStatus(event)}
                <div className={`${cssBase}__section`}>
                  <div className={`${cssBase}__sectionHeader`}>
                    <User16 className={`${cssBase}__sectionHeaderIcon`} />
                    <div className={`${cssBase}__sectionHeaderText`}>
                      {
                        this.props.appMessages[
                          AppMsg.RESERVATION_MESSAGE.MEETING_OWNER
                        ]
                      }
                    </div>
                  </div>
                  <div className={`${cssBase}__sectionContent`}>
                    {event.organizer.emailAddress.name}
                  </div>
                </div>
              </>
            )}
          {event.isRoomOnly &&
            isExchangeIntegrated &&
            event.locationType !== ReservationTypes.WORKSPACE && 
            event.locationType !== ReservationTypes.OFFICE && (
              <ToastNotification
                className={`${cssBase}__roomOnlyNotification`}
                kind="info"
                lowContrast
                title={
                  this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE.ROOM_ONLY_NOTIFICATION_TITLE
                  ]
                }
                statusIconDescription="Room"
                subtitle={
                  <span>
                    {
                      this.props.appMessages[
                        AppMsg.RESERVATION_MESSAGE.ROOM_ONLY_NOTIFICATION_TEXT
                      ]
                    }
                  </span>
                }
                iconDescription={this.props.appMessages[AppMsg.BUTTON.CLOSE]}
              />
            )}
          {event.isOrganizer &&
            event.hasSomeButNotEveryResourceInSeriesOccurrences &&
            isExchangeIntegrated &&
            event.locationType !== ReservationTypes.WORKSPACE &&
            event.locationType !== ReservationTypes.OFFICE && // CISA
            this.allOccurrenceHasResourceInfo()}
          {event.locationType !== ReservationTypes.WORKSPACE &&
            event.locationType !== ReservationTypes.OFFICE && // CISA
            !this.isDelegatedUser(event) &&
            (event.isOrganizer || event.isRoomOnly ? (
              <div
                className={classNames(
                  `${cssBase}__section`,
                  `${cssBase}__isOrganizerSection`
                )}
              >
                <div className={`${cssBase}__sectionHeader`}>
                  <UserAvatarFilled16
                    className={`${cssBase}__sectionHeaderIcon`}
                  />
                  <span className={`${cssBase}__isOrganizerText`}>
                    {
                      this.props.appMessages[
                        AppMsg.RESERVATION_MESSAGE
                          .EVENT_DETAIL_PAGE_ORGANIZER_TEXT
                      ]
                    }
                  </span>
                </div>
              </div>
            ) : null)}
          {event.locationType !== ReservationTypes.WORKSPACE &&
            this.isDelegatedUser(event) &&
            (event.isOrganizer || event.isRoomOnly ? (
              <div className={`${cssBase}__section`}>
                <div className={`${cssBase}__sectionHeader`}>
                  <User16 className={`${cssBase}__sectionHeaderIcon`} />
                  <div className={`${cssBase}__sectionHeaderText`}>
                    {
                      this.props.appMessages[
                        AppMsg.RESERVATION_MESSAGE.MEETING_OWNER
                      ]
                    }
                  </div>
                </div>
                <div className={`${cssBase}__sectionContent`}>
                  {this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE.OWNER_SENT_BY_DELEGATE
                  ]
                    .replace(
                      "{0}",
                      event.organizer
                        ? event.organizer.emailAddress.name
                        : event.requestedFor
                    )
                    .replace("{1}", event.requestedBy)}
                </div>
              </div>
            ) : null)}
          {event.locationType !== ReservationTypes.WORKSPACE && (
            <div className={`${cssBase}__section`}>
              <div className={`${cssBase}__sectionHeader`}>
                <Group16 className={`${cssBase}__sectionHeaderIcon`} />
                <div className={`${cssBase}__sectionHeaderText`}>
                  {
                    this.props.appMessages[
                      AppMsg.RESERVATION_MESSAGE.STEP_MEETING_ATTENDEES
                    ]
                  }
                </div>
              </div>
              <div className={`${cssBase}__sectionContent`}>
                {this.renderAttendees()}
              </div>
            </div>
          )}
          <div
            className={`${cssBase}__section`}
            style={{ borderBottom: "0px" }}
          >
            <div className={`${cssBase}__sectionHeader`}>
              <Time16 className={`${cssBase}__sectionHeaderIcon`} />
              <div className={`${cssBase}__sectionHeaderText`}>
                {
                  this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE.STEP_TIME_DESCRIPTION
                  ]
                }
              </div>
            </div>
            <div className={`${cssBase}__sectionContent`}>
              <span className={`${cssBase}__dateAndTime`}>{formattedDate}</span>
              {!event.isAllDay &&
                TimezoneUtils.areTimezonesDifferent(
                  event.reservationTimezone,
                  defaultTimezone
                ) && (
                  <ReserveNotification
                    message={`${browserTimezoneEventTime} ${
                      this.props.appMessages[AppMsg.RESERVATION_MESSAGE.LOCAL]
                    }`}
                  />
                )}
            </div>
          </div>
          <div className={`${cssBase}__section`}>
            <div
              className={classNames(`${cssBase}__sectionHeader`, {
                [`${cssBase}__sectionHeader--withRooms`]: !isEmpty(event.rooms),
              })}
            >
              <Location16 className={`${cssBase}__sectionHeaderIcon`} />
              <div className={`${cssBase}__sectionHeaderText`}>
                {
                  this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE.STEP_ROOM_DETAIL_LOCATION
                  ]
                }
              </div>
            </div>
            <div className={`${cssBase}__sectionHeader`}>
              {event.locationType !== ReservationTypes.WORKSPACE ? (
                <>
                  <Enterprise16 className={`${cssBase}__sectionHeaderIcon`} />

                  <div className={`${cssBase}__sectionHeaderText`}>
                    {
                      this.props.appMessages[
                        AppMsg.RESERVATION_MESSAGE.STEP_LOCATION_DESCRIPTION
                      ]
                    }
                  </div>
                </>
              ) : (
                <>
                  <Building16 className={`${cssBase}__sectionHeaderIcon`} />

                  <div className={`${cssBase}__sectionHeaderText`}>
                    {
                      this.props.appMessages[
                        AppMsg.RESERVATION_MESSAGE.STEP_WORKSPACES_DESCRIPTION
                      ]
                    }
                  </div>
                </>
              )}
            </div>
            <div
              className={classNames(`${cssBase}__sectionContent`, {
                [`${cssBase}__sectionContent--withRooms`]: !isEmpty(
                  event.rooms
                ),
              })}
            >
              {this.renderLocation()}
            </div>
          </div>
          {!isAttendee && event.locationType !== ReservationTypes.WORKSPACE && (
            <div className={`${cssBase}__section`}>
              <div className={`${cssBase}__sectionHeader`}>
                <Purchase16 className={`${cssBase}__sectionHeaderIcon`} />
                <div className={`${cssBase}__sectionHeaderText`}>
                  {
                    this.props.appMessages[
                      AppMsg.RESERVATION_MESSAGE.STEP_MEETING_COST_SUMMARY
                    ]
                  }
                </div>
              </div>
              <div className={`${cssBase}__sectionContent`}>
                {costSummary && this.renderCostSummary()}
              </div>
            </div>
          )}
          <div className={`${cssBase}__section`}>
            {!isEmpty(onlineMeetingInfo) && this.renderOnlineMeeting()}
          </div>
          {event.locationType !== ReservationTypes.WORKSPACE && event.locationType !== ReservationTypes.OFFICE && // CISA
            (!isEmpty(event.additionalLocationInfo) ||
              !isEmpty(eventExtension.additionalLocationInfo)) && (
              <div className={`${cssBase}__section`}>
                <div className={`${cssBase}__sectionHeader`}>
                  <Location16 className={`${cssBase}__sectionHeaderIcon`} />
                  <div className={`${cssBase}__sectionHeaderText`}>
                    {
                      this.props.appMessages[
                        AppMsg.RESERVATION_MESSAGE
                          .STEP_MEETING_ADDITIONAL_LOCATION_INFO
                      ]
                    }
                  </div>
                </div>
                <div className={`${cssBase}__sectionContent`}>
                  {this.renderAdditionalLocationInfo()}
                </div>
              </div>
            )}
          {event.locationType !== ReservationTypes.WORKSPACE && event.locationType !== ReservationTypes.OFFICE && ( // CISA
            <div className={`${cssBase}__section`}>
              <div className={`${cssBase}__sectionHeader`}>
                <Document16 className={`${cssBase}__sectionHeaderIcon`} />
                <div className={`${cssBase}__sectionHeaderText`}>
                  {
                    this.props.appMessages[
                      AppMsg.RESERVATION_MESSAGE.STEP_MEETING_DETAILS
                    ]
                  }
                </div>
              </div>
              <div className={`${cssBase}__sectionContent`}>
                {this.renderDescription()}
              </div>
            </div>
          )}
        </div>
        <EventFooterButtons
          event={event}
          dir={dir}
          isExchangeIntegrated={isExchangeIntegrated}
          onEditReservation={(event, editMode) => {
            setPrevSelectedBuilding(null);
            setLastMeetingSearchFilters(null);
            editReservation(event, editMode);
          }}
          onUpdateResponse={async (eventId, responseStatus) => {
            await updateResponse(eventId, responseStatus);
            closePage();
          }}
          onDeleteEvent={async (event, editMode) => {
            await deleteEvent(event, editMode);
            closePage();
          }}
          onSyncWithOutlook={() => setIsSyncingWithOutlook(true)}
        />
        <RoomDetailsPageSmall onClosePopUp={() => this.onClosePopUp()} />
      </main>
    );
  }

  renderResponseStatus = (event) => {
    const isAccepted =
      event.responseStatus === Exchange.ResponseStatus.ACCEPTED;
    const isTentativelyAccepted =
      event.responseStatus === Exchange.ResponseStatus.TENTATIVELY_ACCEPTED;
    const isNotResponded =
      event.responseStatus === Exchange.ResponseStatus.NOT_RESPONDED;

    return (
      <div className={`${cssBase}__responseStatus`}>
        {isAccepted && (
          <CheckmarkOutline16 className={`${cssBase}__acceptedIcon`} />
        )}
        {isTentativelyAccepted && (
          <Unknown16 className={`${cssBase}__tentativelyAcceptedIcon`} />
        )}
        {isNotResponded && (
          <Undefined16 className={`${cssBase}__notRespondedIcon`} />
        )}
        <div className={`${cssBase}__statusMessage`}>
          {this.props.appMessages[
            AppMsg.RESERVATION_MESSAGE.RESPONSE_STATUS_MESSAGE
          ].replace("{1}", this.getStatus(event.responseStatus))}
        </div>
      </div>
    );
  };

  getStatus = (status) => {
    if (status === Exchange.ResponseStatus.TENTATIVELY_ACCEPTED)
      return AppMsg.getMessage(AppMsg.RESERVATION_MESSAGE.TENTATIVELY_ACCEPTED);
    else if (status === Exchange.ResponseStatus.NOT_RESPONDED)
      return AppMsg.getMessage(AppMsg.RESERVATION_MESSAGE.NOT_RESPONDED);
    return status;
  };

  renderWorkspace = (resource) => {
    const { event, dir, defaultTimezone } = this.props;

    return (
      (resource.resourceInstanceRecordId ||
        resource.statusENUS === Status.REVIEW_IN_PROGRESS ||
        resource.statusENUS === Status.DECLINED ||
        resource.statusENUS === Status.ACCEPTED) && (
        <WorkspaceListReadOnly
          key={resource._id}
          dir={dir}
          resource={resource}
          roomDetailModal={this.state.roomDetailModal}
          onClick={() => this.handleItemClick(resource)}
          defaultTimezone={defaultTimezone}
          reservationType={event.locationType}
        />
      )
    );
  };

  renderLocation() {
    const {
      event,
      timezone,
      cateringGroupByRoomIdAndOrderId,
      releaseRoom,
      checkIn,
      releaseRoomEarly,
      recheckRoom,
      editReservation,
      loadingReleaseRoom,
      loadingCheckIn,
      loadingReleaseRoomEarly,
      loadingReCheckRoom,
      updateRoomsCanceled,
      defaultTimezone,
      dir,
    } = this.props;
    const { timerDuration, statusCheck } = this.state;
    if (event.rooms) {
      return (
        <>
          {event.locationType === ReservationTypes.WORKSPACE
            ? event.rooms.map(this.renderWorkspace)
            : event.rooms.map(
                (room) =>
                  (room.resourceInstanceRecordId ||
                    room.statusENUS === Status.REVIEW_IN_PROGRESS ||
                    room.statusENUS === Status.DECLINED ||
                    room.statusENUS === Status.ACCEPTED ||
                    !event.isOrganizer) && (
                    <div
                      className={classNames(
                        `${cssBase}__room`,
                        this.computeIndicatorColor(room.status)
                      )}
                      key={room._id}
                    >
                      <TimezoneStatus
                        timezone={room.timezone}
                        defaultTimezone={defaultTimezone}
                        cssBase={cssBase}
                      />
                      <div
                        className={`${cssBase}__roomName`}
                        onClick={() => this.handleItemClick(room)}
                      >
                        <span
                          tabIndex={0}
                          ref={(ref) => {
                            this.setRef(ref, room._id);
                          }}
                          role="link"
                          onKeyDown={(e) =>
                            e.key === "Enter"
                              ? this.handleItemClick(room)
                              : false
                          }
                          style={
                            room.status === Status.CANCELED ||
                            statusCheck === Status.COMPLETED
                              ? {
                                  textDecoration: "line-through",
                                }
                              : {}
                          }
                        >
                          {room.roomId}
                          {", "}
                          {room.name}
                        </span>
                      </div>
                      <div className={`${cssBase}__roomLocation`}>
                        <div className={`${cssBase}__roomFloor`}>
                          {room.floor}
                        </div>
                        <div className={`${cssBase}__roomBuilding`}>
                          <Location16
                            className={`${cssBase}__roomBuildingIcon`}
                          />
                          <span>{room.building}</span>
                        </div>
                        {this.renderRoomStatus(room)}
                      </div>

                      {!isEmpty(room.equipment) && (
                        <EquipmentDetails
                          dir={dir}
                          className={`${cssBase}__equipmentContent`}
                          stepIcon={Printer16}
                          name={
                            this.props.appMessages[
                              AppMsg.RESERVATION_MESSAGE.STEP_MEETING_EQUIPMENT
                            ]
                          }
                          equipment={room.equipment}
                          onEquipmentClick={() => {
                            this.handleEquipmentClick(room, {
                              routedFromEventDetailPage: true,
                              forEquipment: true,
                              eventId: event.id,
                            });
                          }}
                        />
                      )}
                      {!isEmpty(room.catering) && (
                        <CateringSummary
                          dir={dir}
                          className={`${cssBase}__equipmentContent`}
                          icon={Cafe16}
                          name={
                            this.props.appMessages[
                              AppMsg.RESERVATION_MESSAGE.STEP_MEETING_CATERING
                            ]
                          }
                          items={cateringGroupByRoomIdAndOrderId[room._id]}
                          onCateringClick={() =>
                            this.handleCateringClick(room, {
                              routedFromEventDetailPage: true,
                              eventId: event.id,
                            })
                          }
                        />
                      )}
                    </div>
                  )
              )}
          {!event.isOrganizer && (
            <div className={classNames(`${cssBase}___additionalLocationInfo`)}>
              {event.location}
            </div>
          )}
          {!hasDeclinedRooms(event.rooms) && !hasPendingRooms(event.rooms) && (
            <CheckInStatusButtons
              reservation={event}
              timezone={timezone}
              releaseRoom={releaseRoom}
              checkIn={checkIn}
              releaseRoomEarly={releaseRoomEarly}
              recheckRoom={recheckRoom}
              editReservation={editReservation}
              loadingReleaseRoom={loadingReleaseRoom}
              loadingCheckIn={loadingCheckIn}
              loadingReleaseRoomEarly={loadingReleaseRoomEarly}
              loadingReCheckRoom={loadingReCheckRoom}
              timerEndDuration={timerDuration}
              updateRoomsCanceled={updateRoomsCanceled}
            />
          )}
        </>
      );
    } else {
      return event.location;
    }
  }

  setRef(ref, roomId) {
    if (ref && roomId) {
      this[roomId] = React.createRef();
      this[roomId] = ref;
    }
  }

  handleItemClick = (room) => {
    const { setRoomId, setRoomDetailsModal } = this.props;
    this.roomRef = room._id;
    this.setState({
      roomDetailModal: null,
    });
    setRoomId(room.spaceRecordId);
    setRoomDetailsModal(true);
  };

  onClosePopUp = () => {
    const { setRoomDetailsModal } = this.props;
    setRoomDetailsModal(false);
    if (this[this.roomRef]) {
      setTimeout(() => {
        this[this.roomRef].focus();
      }, 1);
    } else {
      this.setState({
        roomDetailModal: true,
      });
    }
  };

  handleCateringClick = (room, data) => {
    const { setRoomId, navigateToCateringPage } = this.props;
    setRoomId(room.spaceRecordId);
    navigateToCateringPage(room.spaceRecordId, data);
  };

  handleEquipmentClick = (room, data) => {
    const { setRoomId, navigateToEquipmentPage } = this.props;
    setRoomId(room.spaceRecordId);
    navigateToEquipmentPage(room.spaceRecordId, data);
  };

  renderRoomStatus = (room) => {
    const ownerDetails =
      room.contactRoles !== undefined
        ? room.contactRoles.find(
            (contactRole) => contactRole.roleENUS === RESOURCE_OWNER
          )
        : null;
    switch (room.statusENUS) {
      case Status.ACCEPTED:
        return room.reservationClassNameENUS ===
          RESERVATION_CLASS_REQUESTABLE ? (
          <div className={`${cssBase}__roomStatus`}>
            <CheckmarkOutline16 className={`${cssBase}__approvedIcon`} />
            <span>
              {this.props.appMessages[AppMsg.RESERVATION_MESSAGE.ROOM_APPROVED]}
            </span>
          </div>
        ) : null;
      case Status.DECLINED:
        return (
          <div className={`${cssBase}__roomStatus`}>
            <MisuseOutline16 className={`${cssBase}__declinedIcon`} />
            <span>
              {this.props.appMessages[AppMsg.RESERVATION_MESSAGE.ROOM_DECLINED]}
            </span>
          </div>
        );
      case Status.REVIEW_IN_PROGRESS:
        return room.reservationClassNameENUS ===
          RESERVATION_CLASS_REQUESTABLE ? (
          <Accordion className={`${cssBase}__pending`}>
            <AccordionItem
              title={
                <div className={`${cssBase}__roomStatus`}>
                  <Information16 className={`${cssBase}__pendingIcon`} />
                  <span>
                    {
                      this.props.appMessages[
                        AppMsg.RESERVATION_MESSAGE.ROOM_PENDING
                      ]
                    }
                  </span>
                </div>
              }
            >
              {!isEmpty(ownerDetails) ? (
                <div className={`${cssBase}__ownersDetails`}>
                  {!isEmpty(ownerDetails.name) && (
                    <>
                      <span>
                        <span className={`${cssBase}__ownersLabel`}>
                          {
                            this.props.appMessages[
                              AppMsg.RESERVATION_MESSAGE.OWNERS_LABEL
                            ]
                          }
                        </span>
                        {ownerDetails.name}
                      </span>
                      <br />
                    </>
                  )}
                  {!isEmpty(ownerDetails.workPhone) && (
                    <>
                      <span>{ownerDetails.workPhone}</span>
                      <br />
                    </>
                  )}
                  {!isEmpty(ownerDetails.email) && (
                    <>
                      <span>{ownerDetails.email}</span>
                      <br />
                    </>
                  )}
                </div>
              ) : (
                <span>
                  {
                    this.props.appMessages[
                      AppMsg.RESERVATION_MESSAGE.OWNERS_LABEL
                    ]
                  }
                </span>
              )}
            </AccordionItem>
          </Accordion>
        ) : null;
      default:
        return null;
    }
  };

  computeIndicatorColor(roomStatus) {
    if (roomStatus === Status.DECLINED) {
      return `${cssBase}__roomStatusColor_declined`;
    } else if (roomStatus === Status.REVIEW_IN_PROGRESS) {
      return `${cssBase}__roomStatusColor_reviewInProgress`;
    } else {
      return null;
    }
  }

  renderOnlineMeeting() {
    const { onlineMeetingInfo } = this.props;
    return (
      <>
        <div
          className={classNames(
            `${cssBase}__sectionContent`,
            `${cssBase}__sectionContent--withOnlineMeeting`
          )}
        >
          <div className={`${cssBase}__onlineMeetingTitle`}>
            {
              this.props.appMessages[
                AppMsg.RESERVATION_MESSAGE.STEP_MEETING_ONLINE_MEETING
              ]
            }
          </div>
          <div className={classNames(`${cssBase}___onlineMeetingInfoHeader`)}>
            {this.props.appMessages[AppMsg.RESERVATION_MESSAGE.MEETING_NAME]}
          </div>
          <div className={classNames(`${cssBase}___onlineMeetingInfo`)}>
            {onlineMeetingInfo.name}
          </div>
          <div className={classNames(`${cssBase}___onlineMeetingInfoHeader`)}>
            {this.props.appMessages[AppMsg.RESERVATION_MESSAGE.MEETING_URL]}
          </div>
          <div className={classNames(`${cssBase}___onlineMeetingInfo`)}>
            <Link
              href={onlineMeetingInfo.url}
              target="_blank"
              aria-label={
                this.props.appMessages[AppMsg.BUTTON.ONLINE_MEETING_LINK] +
                " " +
                onlineMeetingInfo.url
              }
            >
              {onlineMeetingInfo.url}
            </Link>
          </div>
          {!isEmpty(onlineMeetingInfo.callInInformation) && (
            <>
              <div
                className={classNames(`${cssBase}___onlineMeetingInfoHeader`)}
              >
                {
                  this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE.MEETING_CALL_IN_INFO
                  ]
                }
              </div>
              <div className={classNames(`${cssBase}___onlineMeetingInfo`)}>
                {onlineMeetingInfo.callInInformation}
              </div>
            </>
          )}
        </div>
      </>
    );
  }

  renderAdditionalLocationInfo() {
    const { event, eventExtension } = this.props;
    const additionalLocationInfo = !isEmpty(event.additionalLocationInfo)
      ? event.additionalLocationInfo
      : eventExtension.additionalLocationInfo;
    return (
      <div className={classNames(`${cssBase}___additionalLocationInfo`)}>
        {additionalLocationInfo}
      </div>
    );
  }

  hasReservationCost() {
    const { costSummary } = this.props;
    const {
      estimatedCostResource,
      estimatedCostFood,
      estimatedCostEquipment,
    } = costSummary;
    let sum = 0;
    if (!isNil(estimatedCostResource)) {
      sum = sum + estimatedCostResource.value;
    }
    if (!isNil(estimatedCostFood)) {
      sum = sum + estimatedCostFood.value;
    }
    if (!isNil(estimatedCostEquipment)) {
      sum = sum + estimatedCostEquipment.value;
    }
    return sum > 0;
  }

  renderCostSummary() {
    const {
      costSummary,
      currencies,
      currentUserLocale,
      appMessages,
    } = this.props;
    if (!isNil(costSummary) && this.hasReservationCost()) {
      return (
        <div>
          <ToastNotification
            className={`${cssBase}__notification`}
            kind="info"
            lowContrast
            hideCloseButton={true}
            title={
              this.props.appMessages[
                AppMsg.RESERVATION_MESSAGE.COST_SUMMARY_NOTIFICATION_TITLE
              ]
            }
            statusIconDescription={
              this.props.appMessages[
                AppMsg.RESERVATION_MESSAGE.COST_SUMMARY_NOTIFICATION_TITLE
              ]
            }
            subtitle={
              <span>
                {
                  this.props.appMessages[
                    AppMsg.RESERVATION_MESSAGE.COST_SUMMARY_NOTIFICATION_TEXT
                  ]
                }
              </span>
            }
          />
          <CostSummary
            data={costSummary}
            currentUserLocale={currentUserLocale}
            appMessages={appMessages}
            currencies={currencies}
          />
        </div>
      );
    }
    return (
      <div>
        {this.props.appMessages[AppMsg.RESERVATION_MESSAGE.NO_COST_RESERVATION]}
      </div>
    );
  }

  renderDescription() {
    const { description, loadingAttendeesAndDescription } = this.props;
    if (loadingAttendeesAndDescription) {
      return <SkeletonText />;
    }
    if (isEmpty(description)) {
      return null;
    }
    return (
      <div className={`${cssBase}__description`}>
        <TriNote value={description} readonly autoHeight role="article" />
      </div>
    );
  }

  renderAttendees() {
    const { attendees, loadingAttendeesAndDescription } = this.props;
    if (loadingAttendeesAndDescription) {
      return <SkeletonText />;
    }
    if (isEmpty(attendees)) {
      return AppMsg.getMessage(AppMsg.RESERVATION_MESSAGE.NO_ATTENDEES);
    }
    return (
      <div className={`${cssBase}__attendees`}>
        {attendees.map((item, index) => (
          <span
            key={`attendee-${index}`}
            className={`${cssBase}__attendeeName`}
          >{`${item.emailAddress.name}${
            index < attendees.length - 1 ? ", " : ""
          }`}</span>
        ))}
      </div>
    );
  }

  allOccurrenceHasResourceInfo() {
    return (
      <ToastNotification
        className={`${cssBase}__hasSomeButNotEveryResourceInSeriesOccurrencesInfo`}
        kind="info"
        lowContrast
        statusIconDescription="Room"
        title=""
        subtitle={
          <span>
            {
              this.props.appMessages[
                AppMsg.RESERVATION_MESSAGE.ALL_OCCURRENCE_HAS_RESOURCE_INFO
              ]
            }
          </span>
        }
        iconDescription={this.props.appMessages[AppMsg.BUTTON.CLOSE]}
      />
    );
  }

  eventInstanceStatusCheck = (event) => {
    if (event && event.instance) {
      const instanceStatusCheck = event.instance.statusENUS;
      this.setState({
        statusCheck: instanceStatusCheck,
      });
    }
  };

  componentDidMount() {
    const { event } = this.props;
    if (
      event &&
      event.instance &&
      isNow(event.instance.checkInReminderDateTime || event.start, event.end)
    ) {
      this.eventInstanceStatusCheck(event);
      this.runTimer(event.end);
    }
  }

  componentDidUpdate() {
    const { event } = this.props;
    this.eventInstanceStatusCheck(event);
    this.setCurrentCalendar();
  }

  componentWillUnmount() {
    this.clearTimer();
  }

  clearTimer() {
    if (this.intervalId != null) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
  }

  runTimer(endTime) {
    this.clearTimer();
    if (endTime != null) {
      this.computeDurationToEnd(endTime);
      this.intervalId = setInterval(
        () => this.computeDurationToEnd(endTime),
        1000
      );
    }
  }

  computeDurationToEnd(endTime) {
    const timerDuration = ReservationUtils.computeTimeDifferenceDuration(
      endTime
    );
    this.setState({
      timerDuration,
    });
    if (timerDuration === 0) {
      this.clearTimer();
    }
  }

  setCurrentCalendar = () => {
    const {
      currentCalendar,
      delegateCalendar,
      setCurrentCalendar,
      event,
    } = this.props;
    const selectedCalendar = delegateCalendar?.find(
      (calendar) => calendar.email === event?.organizer?.emailAddress.address
    );

    if (
      event &&
      event.isOrganizer &&
      currentCalendar?.email !== selectedCalendar?.email
    ) {
      setCurrentCalendar(selectedCalendar);
    }
  };
}

const mapStateToProps = (state) => {
  return {
    event: EventDetailsSelectors.eventDetailsSelector(state),
    attendees: EventDetailsSelectors.attendeesSelector(state),
    description: EventDetailsSelectors.descriptionSelector(state),
    costSummary: EventDetailsSelectors.costSummarySelector(state),
    onlineMeetingInfo: EventDetailsSelectors.onlineMeetingInfoSelector(state),
    loadingAttendeesAndDescription: LoadingSelectors.loadingEventDescriptionAndAttendeesSelector(
      state
    ),
    dir: LayoutSelectors.dirSelector(state),
    formattedDate: EventDetailsSelectors.formattedStartEndDatesSelector(state),
    browserTimezoneEventTime: EventDetailsSelectors.timeConvertedToReservationTimezoneDetailsSelector(
      state
    ),
    cateringGroupByRoomIdAndOrderId: EventDetailsSelectors.eventDetailsCateringGroupByRoomIdAndOrderIdSelector(
      state
    ),
    timezone: MyCalendarSelectors.timezoneSelector(state),
    defaultTimezone: CurrentUserSelectors.defaultTimezoneSelector(state),
    isExchangeIntegrated: ApplicationSettingsSelectors.isExchangeIntegratedSelector(
      state
    ),
    eventExtension: EventDetailsSelectors.eventExtensionSelector(state),
    currentUserLocale: CurrentUserSelectors.localeSelector(state),
    currencies: CurrenciesSelectors.currenciesSelector(state),
    currentCalendar: ExchangeSelectors.currentCalendarSelector(state),
    delegateCalendar: ExchangeSelectors.delegateCalendarsSelector(state),
  };
};

const {
  releaseRoom,
  checkIn,
  releaseRoomEarly,
  recheckRoom,
  updateRoomsCanceled,
} = CheckInActions;

const {
  setPrevSelectedBuilding,
  setLastMeetingSearchFilters,
} = LocationActions;

export default withTriDictionary(
  connect(mapStateToProps, {
    closePage: RouteActions.navigateToHomePage,
    updateResponse: ExchangeActions.updateResponse,
    editReservation: RouteActions.navigateToEditReservation,
    deleteEvent: MyCalendarActions.deleteEvent,
    navigateToCateringPage: RouteActions.navigateToCateringListFromEventDetails,
    navigateToEquipmentPage:
      RouteActions.navigateToEquipmentPageFromEventDetails,
    releaseRoom,
    checkIn,
    releaseRoomEarly,
    recheckRoom,
    updateRoomsCanceled,
    setLastMeetingSearchFilters,
    setPrevSelectedBuilding,
    setRoomDetailsModal: RoomSearchActions.setRoomDetailsModal,
    setRoomId: RoomDetailsActions.setRoomId,
    setCurrentCalendar: ExchangeActions.setCurrentCalendar,
    setIsSyncingWithOutlook: SyncWithOutlookActions.setIsSyncingWithOutlook,
  })(EventDetailsPageSmall)
);
