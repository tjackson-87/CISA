/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import React from "react";
import ReactDOM from "react-dom";
import { Provider } from "react-redux";
import { ConnectedRouter } from "connected-react-router";
import {
  standardTririgaLogin,
  fetchTriAppConfig,
  getTriAppConfig,
  getAuthCheckerForCurrentApp,
  TriFaviconHandler,
  TriDictionaryProvider,
  TriUnauthorizedPage,
} from "@tririga/tririga-react-components";
import "./index.scss";
import { TririgaRoomReservationApp, AppErrorHandlers } from "./app";
import { AppMsg, getAppHistory, Routes } from "./utils";
import { createAppModel, Exchange } from "./model";
import {
  getAppStore,
  LayoutActions,
  ApplicationSettingsActions,
} from "./store";

import * as serviceWorker from "./serviceWorker";

async function initApp() {
  await fetchTriAppConfig();
  const currentUser = await standardTririgaLogin();
  if (currentUser != null) {
    const authChecker = await getAuthCheckerForCurrentApp();
    if (authChecker.hasMinimumAppPermission()) {
      createAppModel(AppErrorHandlers.handleModelErrors);
      if (window.location.pathname.indexOf(Routes.OAUTH) >= 0) {
        Exchange.receiveAuthorizationCodeOnPopup();
      } else {
        renderApp(currentUser);
      }
    } else {
      renderUnauthorizedAccess(currentUser);
    }
  }
}

async function renderUnauthorizedAccess(currentUser) {
  const rootElement = document.getElementById("root");
  rootElement.dir = currentUser.userDirection;
  await AppMsg.initMessages(currentUser.languageId);
  ReactDOM.render(
    <TriDictionaryProvider appMessages={AppMsg.getAppMessages()}>
      <TriUnauthorizedPage />
    </TriDictionaryProvider>,
    rootElement
  );
}

async function renderApp(currentUser) {
  const appHistory = getAppHistory();
  const appStore = getAppStore();
  const rootElement = document.getElementById("root");
  rootElement.dir = currentUser.userDirection;
  document.documentElement.dir = currentUser.userDirection;
  appStore.dispatch(LayoutActions.setUserDir(currentUser.userDirection));
  appStore.dispatch(LayoutActions.computeAppLayout());
  new TriFaviconHandler().handle();
  await AppMsg.initMessages(currentUser.languageId);
  await getAppStore().dispatch(
    ApplicationSettingsActions.getApplicationSettings()
  );
  ReactDOM.render(
    <Provider store={appStore}>
      <ConnectedRouter history={appHistory}>
        <TriDictionaryProvider appMessages={AppMsg.getAppMessages()}>
          <TririgaRoomReservationApp />
        </TriDictionaryProvider>
      </ConnectedRouter>
    </Provider>,
    rootElement
  );
  serviceWorker.register({ appPath: getTriAppConfig().appPath });
}

initApp();
