/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2022 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/

export const TIME_FORMAT = "hh:mm";
export const TIME_FORMAT_12H_WITH_PERIOD = "hh:mm A";
export const TIME_FORMAT_MONTH_AND_DAY = "MMM DD";
export const TIME_FORMAT_24H = "HH:mm";
export const AM_PM_FORMAT = "A";
export const AM = "AM";
export const PM = "PM";
export const MINUTE_INTERVAL = 15;
export const MIN_MINUTE_INTERVAL = 5;
export const DEFAULT_DURATION_MINUTES = 60;
export const WORKSPACE_ALL_DAY_START = "08:00";
export const WORKSPACE_ALL_DAY_MID = "12:00";
export const WORKSPACE_ALL_DAY_END = "05:00";
export const HOLDTIME_TIMER_IN_SECONDS = 60000;
export const WORKSPACE_DAY = {
  TODAY: "TODAY",
  TOMORROW: "TOMORROW",
};
export const WORKSPACE_TIME = {
  ALLDAY: "ALLDAY",
  MORNING: "MORNING",
  AFTERNOON: "AFTERNOON",
};
export const DateTimeViewMode = {
  SIMPLE: "Simple",
  ADVANCED: "Advanced",
};
