// Collateral type dropdown values CISA

/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/

export const COLLATERAL_TYPE_DROPDOWN = [
    { 
        id: 'collateral-na', 
        text: 'Non-Collateral' 
    },
    { 
        id: 'collateral-0', 
        text: 'Collateral' 
    },
    { 
        id: 'collateral-1', 
        text: 'Collateral - 1' 
    },
    { 
        id: 'collateral-2', 
        text: 'Collateral - 2' 
    }
]