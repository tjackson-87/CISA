/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

export const AVAILABILTY_TYPES = {
  FREE: 0,
  TENTATIVE: 1,
  BUSY: 2,
  OUT_OF_OFFICE: 3,
  WORKING_ELSEWHERE: 4,
};

export const GET_SCHEDULE_MAX_DAYS_WINDOW = 42;

export const ROOM_LINKS_KEY_ON_EVENT_BODY = "TRIRIGA_ROOM_LINKS";
export const ONLINE_MEETING_KEY_ON_EVENT_BODY = "TRIRIGA_ONLINE_MEETING";
export const LINE_BREAK_ON_EVENT_BODY = "TRIRIGA_LINE_BREAK";
