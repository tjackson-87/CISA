export const QR = "qr";
export const BAR = "barcode";
export const CAPTURE_TIME = 2000;
export const TIME_OUT = 30000;
