/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

export const TENTATIVE = "Tentative";
export const ACCEPTED = "Accepted";
export const ACTIVE = "Active";
export const PROCESSING = "Processing";
export const DECLINED = "Declined";
export const REVIEW_IN_PROGRESS = "Review In Progress";
export const CANCELED = "Cancelled";
export const COMPLETED = "Completed";
