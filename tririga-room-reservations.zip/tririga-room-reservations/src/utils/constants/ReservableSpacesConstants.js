/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/

export const RESERVATION_CLASS_PRIVATE = "Private";
export const RESERVATION_CLASS_REQUESTABLE = "Requestable";
export const RESERVATION_CLASS_RESERVABLE = "Reservable";
export const RESERVATION_CLASS_COLLATERAL = "Collateral"; // Collateral added CISA
