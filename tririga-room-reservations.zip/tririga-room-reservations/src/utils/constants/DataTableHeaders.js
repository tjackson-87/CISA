// Table headers for CISA

/*
  Reviewed for upgrade 7/29/24
  Name: Mike Tremblay
*/

export const LOCATION_TABLE_HEADERS = [
    {
      key: 'gsaRegion',
      header: 'CISA Region',
    },
    {
      key: 'name',
      header: 'Name',
    },
    {
        key: 'city',
        header: 'City',
    },
    {
        key: 'state',
        header: 'State',
    },
];

export const LOCATION_TABLE_HEADERS_LOADING = [
    {
      key: 'CISA Region'
    },
    {
        key: 'Name'
    },
    {
        key: 'City'
    },
    {
        key: 'State'
    },
];

export const FLOOR_TABLE_HEADERS = [
    {
      key: 'level',
      header: 'Level',
    },
    {
      key: 'name',
      header: 'Name',
    }
];

export const FLOOR_TABLE_HEADERS_LOADING = [
    {
      key: 'Level'
    },
    {
      key: 'Name'
    }
];
