/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/

export const HOME = "/";
export const MEETING = "/meeting";
export const WORKSPACE = "/workspace";
export const OFFICE = "/office"; // Office added CISA
export const ATTENDEES = "/attendees";
export const LOCATION = "/location";
export const TIME = "/time";
export const ONLINE_MEETING = "/onlineMeeting";
export const RECURRENCE = "/recurrence";
export const SEARCH = "/search";
export const EQUIPMENT = "/equipment";
export const DETAILS = "/details";
export const OAUTH = "/oauth";
export const SEARCH_FILTER = "/filter";
export const ROOM_LOCATE_APP = "/p/web/locate#!/room/{roomId}/location/min";
export const SPACE_DETAILS = "/spaceDetails";
export const ROOM_RECURRENCE_DETAILS = "/roomRecurrenceDetails";
export const AVAILABILITY = "/availability";
export const NEW_RESERVATION_INTEGRATION = "/new";
export const CATERING = "/catering";
export const EVENT_DETAILS = "/eventDetails";
export const EDIT_RESERVATION = "/editReservation";
export const EDIT_EVENT = "/editEvent";
export const SCAN = "/scan";
export const EXCEPTION = "/exception";
export const ROOMSEARCH = "/roomsearch";
export const COST_SUMMARY = "/costSummary";
export const COLLEAGUE_RESERVATION = "/colleagueReservation";