/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2022 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
export const CURRENT_USER_DS_NAME = "currentUser";
export const RESERVABLE_SPACES_CONTACT_ROLES_DS_NAME = "contactRoles";
export const CURRENT_PERSON_DS_NAME = "currentPerson";
export const RESERVATION_DS_NAME = "reservation";
export const LAYOUT_TYPES_DS_NAME = "layoutTypes";
export const MY_PRIMARY_BUILDING_DS_NAME = "myPrimaryBuilding";
export const RESERVABLE_SPACES_DS_NAME = "reservableSpaces";
export const RESERVABLE_SPACES_WITHOUT_ROLES_DS_NAME =
  "reservableSpacesWithoutRoles";
export const FLOORS_EXCHANGE_MEETING_SPACES_DS_NAME =
  "floorsExchangeMeetingSpaces";
export const FLOORS_MEETING_SPACES_DS_NAME = "floorsMeetingSpaces";
export const FLOORS_WORKSPACES_DS_NAME = "floorsWorkspaces";
export const BUILDINGS_DS_NAME = "buildings";
export const ONLINE_MEETING_DS_NAME = "onlineMeeting";
export const TEAMS_MEETING_DS_NAME = "teamsMeeting"; // Teams meeting support CISA
export const RESERVATION_ONLINE_MEETING_INFO_DS_NAME = "reservationOnlineMeeting";
export const APPLICATION_SETTINGS_DS_NAME = "applicationSettings";
export const TIMEZONES_DS_NAME = "timezones";
export const LABELSTYLES_DS_NAME = "labelStyles";
export const FAVORITE_ROOMS_DS_NAME = "favoriteRooms";
export const RESERVABLE_SPACE_TYPE_DS_NAME = "reservableSpaceType";
export const MY_FUNCTIONAL_ROLE_DS_NAME = "myFunctionalRole";
export const MY_CALENDAR_DS_NAME = "myCalendar";
export const RESERVATION_SPACES_DS_NAME = "reservationSpaces";
export const EVENTS_DS_NAME = "events";
export const SPACE_DS_NAME = "space";
export const PRIVATE_ROOMS_DS_NAME = "privateRooms";
export const MENU_ITEMS_DS_NAME = "menuItems";
export const EQUIPMENT_DS_NAME = "equipment";
export const RESERVABLE_ASSETS_DS_NAME = "reservableAssets";
export const EQUIPMENT_ORDERS_DS_NAME = "equipmentOrders";
export const CURRENCY_DS_NAME = "currencies";
export const FOOD_ORDER_ITEMS_DS_NAME = "foodOrderItems";
export const PURCHASE_ORDERS_DS_NAME = "purchaseOrders";
export const RESERVE_EVENT_TYPES_DS_NAME = "reserveEventTypes";
export const RESERVATION_INSTANCES_DS_NAME = "reservationInstances";
export const RECURRENCE_DS_NAME = "recurrence";
export const ACTIVE_USERS_DS_NAME = "activeUsers";
export const DELEGATE_FOR_DS_NAME = "delegateFor";
export const ALL_PROFILE_DS_NAME = "allUserProfile";
export const ALL_USERS_DS_NAME = "allUsers";
export const RESERVED_SPACES_BY_EXCHANGE_MAILBOX =
  "reservedSpacesByExchangeMailbox";
export const DELEGATE_USER_CALENDAR = "delegateUserCalendar";
export const RESERVATION_EXCEPTIONS = "reservationExceptions";
export const OAUTH_PROFILE_DS_NAME = "oauthProfile";
