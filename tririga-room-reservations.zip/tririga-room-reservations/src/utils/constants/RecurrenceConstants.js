/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/

import printf from "printf";
import { AppMsg } from "..";

export const RECUR_OCCURRENCES_DEFAULT = "1";

export const RECUR_TYPE_VALUES = {
  NONE: "NONE",
  DAILY: "DAILY",
  WEEKLY: "WEEKLY",
  MONTHLY: "MONTHLY",
  YEARLY: "YEARLY",
};

export const RECUR_DAILY_VALUES = {
  DAY: "Every [x] day(s)",
  WEEKDAY: "Every weekday",
  WEEKEND_DAY: "Every weekend day",
};

export const WEEK_DAYS = [
  "Sunday",
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
];

export const RECUR_MONTH_VALUES = {
  DAY_OF_EVERY_MONTH: "Day [x] of every [x] month(s)",
  WEEK_OF_EVERY_MONTH: "The [First] [Monday] of every [x] month(s)",
};

export const RECUR_YEAR_VALUES = {
  DAY_OF_MONTH: "Every [May] [1]",
  WEEK_OF_MONTH: "The [First] [Monday] of [May]",
};

export const RECUR_WEEK_OF_VALUES = {
  DAY: "day",
  WEEK_OF_FIRST: "First",
  WEEK_OF_SECOND: "Second",
  WEEK_OF_THIRD: "Third",
  WEEK_OF_FOURTH: "Fourth",
  WEEK_OF_LAST: "Last",
};

export const WEEK_OF_OPTIONS = Object.keys(RECUR_WEEK_OF_VALUES).map((key) => {
  return {
    messageKey: AppMsg.RECURRENCE[key],
    value: RECUR_WEEK_OF_VALUES[key],
  };
});

export const RECUR_DAY_OF_WEEK_VALUES = {
  DAY: "day",
  WEEKDAY: "weekday",
  WEEKEND_DAY: "weekend day",
  SUNDAY: "Sunday",
  MONDAY: "Monday",
  TUESDAY: "Tuesday",
  WEDNESDAY: "Wednesday",
  THURSDAY: "Thursday",
  FRIDAY: "Friday",
  SATURDAY: "Saturday",
};

export const DAY_OF_WEEK_OPTIONS = Object.keys(RECUR_DAY_OF_WEEK_VALUES).map(
  (key) => {
    return {
      messageKey: AppMsg.RECURRENCE[key],
      value: RECUR_DAY_OF_WEEK_VALUES[key],
    };
  }
);

export const MONTHS = {
  JANUARY: "January",
  FEBRUARY: "February",
  MARCH: "March",
  APRIL: "April",
  MAY: "May",
  JUNE: "June",
  JULY: "July",
  AUGUST: "August",
  SEPTEMBER: "September",
  OCTOBER: "October",
  NOVEMBER: "November",
  DECEMBER: "December",
};

export const MONTH_OPTIONS = Object.keys(MONTHS).map((key) => {
  return {
    messageKey: AppMsg.RECURRENCE[key],
    value: MONTHS[key],
  };
});

export const MONTH_DAYS = [];

for (let i = 1; i <= 31; i++) {
  MONTH_DAYS.push(`${printf("%d", i)}`);
}

export const RECUR_OCCURENCES_LIST = [];

// Recurrance options modified CISA
for (let i = 1; i < 6; i++) {
  RECUR_OCCURENCES_LIST.push(`${printf("%d", i)}`);
}

export const RECUR_END_VALUES = {
  END_AFTER: "End After",
  END_DATE: "End Date",
  NO_END_DATE: "No End Date",
};

export const EXCHANGE_TYPE_VALUES = {
  DAILY: "daily",
  WEEKLY: "weekly",
  ABSOLUTE_MONTHLY: "absoluteMonthly",
  RELATIVE_MONTHLY: "relativeMonthly",
  ABSOLUTE_YEARLY: "absoluteYearly",
  RELATIVE_YEARLY: "relativeYearly",
};

export const EXCHANGE_END_VALUES = {
  END_AFTER: "numbered",
  END_DATE: "endDate",
  NO_END_DATE: "noEnd",
};

export const EXCHANGE_WEEKDAYS = [
  "monday",
  "tuesday",
  "wednesday",
  "thursday",
  "friday",
];

export const EXCHANGE_WEEKEND_DAYS = ["sunday", "saturday"];

export const EXCHANGE_DAYS_OF_WEEK = [
  "sunday",
  "monday",
  "tuesday",
  "wednesday",
  "thursday",
  "friday",
  "saturday",
];

export const EXCHANGE_WEEK_OF_MONTH_VALUES = {
  FIRST_WEEK: "first",
  SECOND_WEEK: "second",
  THIRD_WEEK: "third",
  FOURTH_WEEK: "fourth",
  LAST_WEEK: "last",
};
