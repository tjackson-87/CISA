/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/

export const CARBON_DATE_FORMAT = "m/d/Y";
export const DATE_FORMAT = "mm/dd/YYYY";
export const DATE_OBJECT_FORMAT = "YYYY-MM-DD";
export const CARBON_LOCALE = navigator.language.slice(0, 2);
export const LOCALE = navigator.language;
export const TIME_PERIOD = "AM";
export const TIME_PERIOD_PM = "PM";
export const TIME = "00:00";
export const USER_DIR = "ltr";
export const CAPACITY = 1;
export const CAPACITY_MIN = 1;
export const CAPACITY_MAX = 999;
export const CAPACITY_STEP = 1;
export const QUANTITY_MIN = 0;
export const QUANTITY_MAX = 20;
export const LAYOUT_TYPE = { internalValue: "Any" };
export const TIMEZONE = "Greenwich";
export const AMENITIES = {
  cateringAvailable: false,
  adaAvailable: false,
  networkConnection: false,
  inRoomProjector: false,
  telephoneConference: false,
  videoConferenceRoom: false,
  whiteboard: false,
  adjustableHeightDesk: false,
  ipPhone: false,
  naturalLight: false,
  noiseBarrier: false,
  // Amenities support CISA
  dellPro2X: false,
  networkTypeA: false,
  networkTypeB: false,
  networkTypeC: false,
  networkTypeTEN: false,
  hpUltraSlim: false, 
  hpUSBG5: false, 
  networkTypeCAL: false, 
  networkTypeM: false, 
  networkTypeTM: false, 
  universalDockingStations: false,
  vtc: false, 
  hdmi: false, 
  smartWhiteboard: false, 
  pivEnrollmentStation: false,
  dellK09A: false,
  dellOPS395: false,
  dellWYSE: false,
  dellWYSE3040: false,
  dellWYSE5070: false,
  networkTypeCOOL: false,
  networkTypeF: false,
  networkTypeG: false,
  networkTypeMOE: false,
  networkTypeN: false,
  msTeams: false,
  surfaceHub: false,

};
export const SHOW_COLLATERAL_TYPE_ROOMS = { id: 'collateral-na', text: 'Non-Collateral' }; // Collateral types CISA
export const SHOW_UNAVAILABLE_ROOMS = false;
export const SHOW_FAVORITES_ONLY = false;
export const SHOW_REQUESTABLE_ROOMS = true;
export const SHOW_PRIVATE_ROOMS = false;
export const CATERING_DATE_FORMAT = "MM/DD/YYYY";
export const RESERVATION_INIT_ISO_TIME = "08:00";
export const withoutDSTDate = "01/01/2021";
export const DATE_TIME_DIFFERENT_TIMEZONE_FORMAT = "MM/DD/yyyy, hh:mm A";
export const DATE_READABLE_FORMAT = "LL";
export const UPCOMING_RESERVATION_COUNT = 20;
export const UPCOMING_RESERVATION_COUNT_LS = 40;