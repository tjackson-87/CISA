export const NONE = "none";
export const OPEN = "open";
export const CLOSED = "closed";
export const EXPIRED = "expired";
export const EARLY_END = "early end";
