/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/

export const AvailableLocation = `
  <svg viewBox="0 0 32 32" version="1.1" xmlns="http://www.w3.org/2000/svg">
    <path id="location" d="M16,30,7.5645,20.0513c-.0479-.0571-.3482-.4515-.3482-.4515A10.8888,10.8888,0,0,1,5,13a11,11,0,0,1,22,0,10.8844,10.8844,0,0,1-2.2148,6.5973l-.0015.0025s-.3.3944-.3447.4474Z"></path>
    <circle id="status" cx="16" cy="13" r="4"></circle>
  </svg>`;

export const SelectedLocation = `
  <svg viewBox="0 0 32 32" version="1.1" xmlns="http://www.w3.org/2000/svg">
    <path id="location" d="M16,30,7.5645,20.0513c-.0479-.0571-.3482-.4515-.3482-.4515A10.8888,10.8888,0,0,1,5,13a11,11,0,0,1,22,0,10.8844,10.8844,0,0,1-2.2148,6.5973l-.0015.0025s-.3.3944-.3447.4474Z"></path>
    <polygon id="status" transform="translate(8.000000, 5.000000)" points="14 4.7 13.3 4 6.5 10.8 3.7 8 3 8.7 6.5 12.2"></polygon>
  </svg>`;

export const UnavailableLocation = `
  <svg viewBox="0 0 32 32" version="1.1" xmlns="http://www.w3.org/2000/svg">
    <path id="location" d="M16,30,7.5645,20.0513c-.0479-.0571-.3482-.4515-.3482-.4515A10.8888,10.8888,0,0,1,5,13a11,11,0,0,1,22,0,10.8844,10.8844,0,0,1-2.2148,6.5973l-.0015.0025s-.3.3944-.3447.4474Z"></path>
    <path id="status" transform="translate(8.000000, 5.000000)" d="M1,8 C1,11.8659932 4.13400675,15 8,15 C11.8659932,15 15,11.8659932 15,8 C15,4.13400675 11.8659932,1 8,1 C4.13400675,1 1,4.13400675 1,8 Z M12.575,11.875 L4.125,3.425 C6.50908162,1.44053979 10.0127591,1.60045901 12.2061501,3.79384993 C14.399541,5.98724086 14.5594602,9.49091838 12.575,11.875 Z M4.12,12.58 C1.59892273,10.439094 1.2858236,6.66177665 3.42,4.135 L11.865,12.58 C9.62900734,14.4693545 6.35599266,14.4693545 4.12,12.58 L4.12,12.58 Z"></path>
  </svg>`;

export const ColleagueLocation = `<svg id="Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32">
  <defs>
    <style>
      .cls-1 {
        fill: none;
      }
    </style>
  </defs>
  <path id="_inner-path_" data-name="&lt;inner-path&gt;" class="cls-1" d="M20,19H18V17H14v2H12V17a2.0021,2.0021,0,0,1,2-2h4a2.0021,2.0021,0,0,1,2,2Zm-1-8a3,3,0,1,0-3,3A3.0033,3.0033,0,0,0,19,11Zm-2,0a1,1,0,1,1-1-1A1.0011,1.0011,0,0,1,17,11Z" transform="translate(0 0)"/>
  <circle cx="16" cy="11" r="1"/>
  <path d="M16,2A11.0134,11.0134,0,0,0,5,13a10.8885,10.8885,0,0,0,2.2163,6.6s.3.3945.3482.4517L16,30l8.439-9.9526c.0444-.0533.3447-.4478.3447-.4478l.0015-.0024A10.8846,10.8846,0,0,0,27,13,11.0134,11.0134,0,0,0,16,2Zm0,6a3,3,0,1,1-3,3A3.0033,3.0033,0,0,1,16,8Zm4,11H18V17H14v2H12V17a2.0023,2.0023,0,0,1,2-2h4a2.0023,2.0023,0,0,1,2,2Z" transform="translate(0 0)"/>
  <rect id="_Transparent_Rectangle_" data-name="&lt;Transparent Rectangle&gt;" class="cls-1" width="32" height="32"/>
</svg>`;
