/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import moment from "moment-timezone";
import { TriDateTimeUtils } from "@tririga/tririga-react-components";
import {
  AppMsg,
  RecurrenceConstants,
  DateTimeConstants,
  TimezoneUtils,
} from ".";
import { isEmpty, isNil } from "lodash";
import styles from "../app/TririgaRoomReservationApp.scss";
import * as Routes from "./constants/Routes";
import * as ReservationTypes from "./constants/ReservationTypes";

const MIN_LAYOUT_HEIGHT = parseInt(
  styles["min-layout-height"].replace("px", "")
);
const {
  TIME_FORMAT,
  AM_PM_FORMAT,
  AM,
  PM,
  WORKSPACE_DAY,
  WORKSPACE_TIME,
  WORKSPACE_ALL_DAY_START,
  WORKSPACE_ALL_DAY_MID,
  WORKSPACE_ALL_DAY_END,
} = DateTimeConstants;

export const MAIN_APP_CONTAINER_CLASSNAME = "tririgaRoomReservationApp";

let mainAppContainer = null;

function getMainAppContainer() {
  if (mainAppContainer == null) {
    mainAppContainer = document.querySelector(
      `.${MAIN_APP_CONTAINER_CLASSNAME}`
    );
  }
  return mainAppContainer;
}

export function isSmallLayoutHeight() {
  return getMainAppContainer().offsetHeight <= MIN_LAYOUT_HEIGHT;
}

export const REQUEST_DISCARDED = "REQUEST_DISCARDED";

export const getCurrentDateTime = (timezone) => {
  return moment().tz(timezone);
};

export const isNow = (start, end) => {
  return start && end && isBetween(null, start, end);
};

export const isPast = (end) => {
  return end && new Date(end).getTime() <= new Date().getTime();
};

const HOUR_IN_MILLISECONDS = 60 * 60 * 1000;
export function isWithinAnHourFromNow(time) {
  const now = new Date();
  const anHourFromNow = now.getTime() + HOUR_IN_MILLISECONDS;
  const result = time && isBetween(time, now, anHourFromNow);
  return result;
}

export const isBetween = (time, start, end) => {
  const timeDT = !time ? new Date() : new Date(time);
  return (
    start &&
    end &&
    new Date(start).getTime() <= timeDT.getTime() &&
    timeDT.getTime() <= new Date(end).getTime()
  );
};

export const getDatesBetween = (start, events, end, timezone) => {
  if (start && events && end && timezone) {
    const datesBetween = [];

    const blockedOffdates = events.map((event) =>
      moment.tz(event.start, timezone)
    );

    let dateAfter = moment.tz(start, timezone);
    const endMo = moment.tz(end, timezone);

    while (dateAfter.isSameOrBefore(endMo, "day")) {
      const mo = moment.tz(dateAfter, timezone);

      const isSameDayAsBlockedDate = blockedOffdates.find((date) => {
        const isSame = mo.isSame(date, "day");
        return isSame;
      });
      if (!isSameDayAsBlockedDate) {
        datesBetween.push(mo.toDate());
      }
      dateAfter = moment.tz(dateAfter, timezone).add(1, "days");
    }
    return datesBetween;
  }
};

export const getNextMinuteInterval = (momentDateTime, interval = 15) => {
  const remainder = interval - (momentDateTime.minute() % interval);
  return moment(momentDateTime).add(remainder, "minutes");
};

export function computeMomentStartAndEndDates({
  allDayEvent,
  startDate,
  startTime,
  startTimePeriod,
  endDate,
  endTime,
  endTimePeriod,
  timezone,
}) {
  if (allDayEvent) {
    startTime = "00:00";
    startTimePeriod = "AM";
    endTime = "11:59:59";
    endTimePeriod = "PM";
  }
  const startDateTime = getMomentFrom(
    startDate,
    startTime,
    startTimePeriod,
    timezone
  );
  const endDateTime = getEndDateTime(endDate, endTime, endTimePeriod, timezone);
  return { startDateTime, endDateTime };
}

export function computeEndDateFromStartChange(
  {
    allDayEvent,
    startDate,
    startTime,
    startTimePeriod,
    endDate,
    endTime,
    endTimePeriod,
    timezone,
  },
  changedKey,
  changedValue
) {
  const { startDateTime, endDateTime } = computeMomentStartAndEndDates({
    allDayEvent,
    startDate,
    startTime,
    startTimePeriod,
    endDate,
    endTime,
    endTimePeriod,
    timezone,
  });
  const originalDuration = moment.duration(endDateTime.diff(startDateTime));
  const changedState = {
    startDate,
    startTime,
    startTimePeriod,
    timezone,
    [changedKey]: changedValue,
  };
  const changedEndDateTime = getMomentFrom(
    changedState.startDate,
    changedState.startTime,
    changedState.startTimePeriod,
    changedState.timezone
  ).add(originalDuration);

  return {
    endDate: moment(changedEndDateTime.format().slice(0, 10)).toDate(),
    endTime: changedEndDateTime.format(TIME_FORMAT),
    endTimePeriod: changedEndDateTime.format(AM_PM_FORMAT),
  };
}

export function getMomentFrom(date, time, timePeriod, timezone) {
  return moment.tz(
    `${moment(date).format("YYYY-MM-DD")} ${time} ${timePeriod.toLowerCase()}`,
    "YYYY-MM-DD HH:mm A",
    timezone
  );
}

const INVALID_DATE = "Invalid date";

export function isValidDate(date) {
  return date !== INVALID_DATE;
}

export function getEndDateTime(date, time, timePeriod, timezone) {
  return moment.tz(
    `${moment(date).format("YYYY-MM-DD")} ${time} ${timePeriod.toLowerCase()}`,
    "YYYY-MM-DD HH:mm:ss A",
    timezone
  );
}

export function formatTime(dateTime, locale) {
  const parsedDate = moment.parseZone(dateTime);
  if (locale != null) parsedDate.locale(locale);
  return parsedDate.format("hh:mm A");
}

export function getEventEndDate(isAllDay, end, timezone) {
  if (isAllDay) {
    return moment.tz(end, timezone).subtract(1, "seconds").toISOString(true);
  } else return moment.tz(end, timezone).toISOString(true);
}

export function setEventEndDate(isAllDay, end, timezone) {
  if (isAllDay) {
    return moment.tz(end, timezone).add(1, "seconds").toISOString(true);
  } else return end;
}

export function formatStartEndDates(
  startDateTime,
  endDateTime,
  allDay,
  dateFormat,
  locale,
  timezone,
  timezones,
  reservationType,
  recurrence
) {
  if (startDateTime == null || endDateTime == null) return null;

  const momentEndDate = moment(endDateTime).tz(timezone);

  const isSameDay = moment(startDateTime)
    .tz(timezone)
    .isSame(momentEndDate, "days");

  const startDateStr = TriDateTimeUtils.formatDate(
    startDateTime,
    dateFormat,
    locale
  );

  const endDateStr = TriDateTimeUtils.formatDate(
    momentEndDate.toISOString(true),
    dateFormat,
    locale
  );

  const startDateMoment = moment(startDateTime);
  const endDateMoment = moment(endDateTime);
  const dateAndTime = getDateAndTimeObject(
    startDateMoment,
    endDateMoment,
    timezone,
    recurrence
  );

  if (
    reservationType === ReservationTypes.MEETING ||
    needAdvancedView(dateAndTime)
  ) {
    if (allDay) {
      return `${startDateStr}${
        isSameDay ? " - " : " to " + endDateStr + " - "
      }${AppMsg.getMessage(AppMsg.RESERVATION_MESSAGE.STEP_TIME_ALL_DAY)}`;
    } else {
      return formattedDates(
        startDateTime,
        endDateTime,
        startDateStr,
        endDateStr,
        isSameDay,
        locale,
        timezone,
        timezones
      );
    }
  } else {
    if (isMorning(timezone, startDateMoment, endDateMoment) && isSameDay) {
      return formattedMorningDate(
        startDateStr,
        endDateStr,
        isSameDay,
        startDateMoment,
        endDateMoment,
        locale
      );
    } else if (
      isAfternoon(timezone, startDateMoment, endDateMoment) &&
      isSameDay
    ) {
      return formattedAfternoonDate(
        startDateStr,
        endDateStr,
        isSameDay,
        startDateMoment,
        endDateMoment,
        locale
      );
    } else if (
      isAllDay(timezone, startDateMoment, endDateMoment) &&
      isSameDay
    ) {
      return formattedAllDayDate(
        startDateStr,
        endDateStr,
        isSameDay,
        startDateMoment,
        endDateMoment,
        locale
      );
    } else {
      return formattedDates(
        startDateTime,
        endDateTime,
        startDateStr,
        endDateStr,
        isSameDay,
        locale,
        timezone,
        timezones
      );
    }
  }
}

function getDateAndTimeObject(startDate, endDate, timezone, recurrence) {
  const startDateNew = moment(
    moment(startDate.tz(timezone)).format().slice(0, 10)
  ).toDate();
  const endDateNew = moment(
    moment(endDate.tz(timezone)).format().slice(0, 10)
  ).toDate();
  const startTimePeriod = startDate.format("A");
  const endTimePeriod = endDate.format("A");
  const startTime = startDate.tz(timezone).format("HH:mm");
  const endTime = endDate.tz(timezone).format("HH:mm");
  return {
    startDateNew,
    endDateNew,
    startTimePeriod,
    endTimePeriod,
    startTime,
    endTime,
    timezone,
    recurrence,
  };
}

function formattedAllDayDate(
  startDateStr,
  endDateStr,
  isSameDay,
  startDateMoment,
  endDateMoment,
  locale
) {
  return `${startDateStr}${
    isSameDay ? " - " : " to " + endDateStr + " - "
  }${AppMsg.getMessage(
    AppMsg.RESERVATION_MESSAGE.STEP_TIME_ALLDAY
  )} (${formatTime(startDateMoment, locale)} - ${formatTime(
    endDateMoment,
    locale
  )})`;
}

function formattedMorningDate(
  startDateStr,
  endDateStr,
  isSameDay,
  startDateMoment,
  endDateMoment,
  locale
) {
  return `${startDateStr}${
    isSameDay ? " - " : " to " + endDateStr + " - "
  }${AppMsg.getMessage(
    AppMsg.RESERVATION_MESSAGE.STEP_TIME_MORNING
  )} (${formatTime(startDateMoment, locale)} - ${formatTime(
    endDateMoment,
    locale
  )})`;
}

function formattedAfternoonDate(
  startDateStr,
  endDateStr,
  isSameDay,
  startDateMoment,
  endDateMoment,
  locale
) {
  return `${startDateStr}${
    isSameDay ? " - " : " to " + endDateStr + " - "
  }${AppMsg.getMessage(
    AppMsg.RESERVATION_MESSAGE.STEP_TIME_AFTERNOON
  )} (${formatTime(startDateMoment, locale)} - ${formatTime(
    endDateMoment,
    locale
  )})`;
}

export function isAllDay(timezone, startDateMoment, endDateMoment) {
  return (
    checkStartEndTime(timezone, startDateMoment, WORKSPACE_ALL_DAY_START, AM) &&
    checkStartEndTime(timezone, endDateMoment, WORKSPACE_ALL_DAY_END, PM)
  );
}

export function isMorning(timezone, startDateMoment, endDateMoment) {
  return (
    checkStartEndTime(timezone, startDateMoment, WORKSPACE_ALL_DAY_START, AM) &&
    checkStartEndTime(timezone, endDateMoment, WORKSPACE_ALL_DAY_MID, PM)
  );
}

export function isAfternoon(timezone, startDateMoment, endDateMoment) {
  return (
    checkStartEndTime(timezone, startDateMoment, WORKSPACE_ALL_DAY_MID, PM) &&
    checkStartEndTime(timezone, endDateMoment, WORKSPACE_ALL_DAY_END, PM)
  );
}

function checkStartEndTime(timezone, DateTime, time, timePeriod) {
  return DateTime.tz(timezone)?.isSame(
    getMomentFrom(DateTime, time, timePeriod, timezone),
    "minute"
  );
}

function formattedDates(
  startDateTime,
  endDateTime,
  startDateStr,
  endDateStr,
  isSameDay,
  locale,
  timezone,
  timezones
) {
  const startTimeStr = formatTime(startDateTime, locale);
  const endTimeStr = formatTime(endDateTime, locale);
  const timezoneStr = TimezoneUtils.getTimezoneAbbr(timezone, timezones);
  return `${startDateStr}, ${startTimeStr}${
    isSameDay ? " - " : " to " + endDateStr + ", "
  }${endTimeStr} ${timezoneStr}`;
}

export function isStartAndEndWithinOneDayAndValid(
  startMoment,
  endMoment,
  allDayEvent
) {
  if (allDayEvent) {
    return startMoment.startOf("day").isSame(endMoment.startOf("day"));
  }

  const nextDayMidnightMoment = startMoment
    .clone()
    .add(1, "day")
    .startOf("day");

  return (
    endMoment.isAfter(startMoment) &&
    endMoment.isSameOrBefore(nextDayMidnightMoment)
  );
}

export const lastRequestDebouncer = (fn) => {
  let requestCounter = 0;
  let lastRequestUsedNumber = 0;

  return async function (...args) {
    const myRequestNumber = ++requestCounter;
    const result = await fn.apply(null, args);
    if (myRequestNumber > lastRequestUsedNumber) {
      lastRequestUsedNumber = myRequestNumber;
      return result;
    } else {
      return REQUEST_DISCARDED;
    }
  };
};

export const getTimezoneCode = (timezone) => {
  const index1 = timezone.indexOf("[");
  const index2 = timezone.indexOf("]");
  return timezone.substring(index1 + 1, index2);
};

export function isPopupBlocked(popup) {
  return (
    popup == null ||
    popup.closed ||
    popup.closed === undefined ||
    popup.innerWidth === 0 ||
    popup.document === undefined ||
    popup.document.documentElement === undefined ||
    popup.document.documentElement.clientWidth === 0
  );
}

export const isIOS =
  /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;

export const getRecurPropName = (type) => {
  return `${type.toLowerCase()}Properties`;
};

export const getRecurrenceInitial = (dateAndTime) => {
  let dayOfMonth = RecurrenceConstants.MONTH_DAYS[0];
  const weeklyDays = new Array(7).fill(false);
  let monthOfYear = RecurrenceConstants.MONTHS.JANUARY;
  if (
    (dateAndTime.startDate !== null || dateAndTime.startDateTime != null) &&
    dateAndTime.timezone !== null
  ) {
    const startDateTime =
      dateAndTime.startDateTime != null
        ? dateAndTime.startDateTime
        : computeMomentStartAndEndDates(dateAndTime).startDateTime;
    dayOfMonth = moment(startDateTime).tz(dateAndTime.timezone).format("D");
    const weekDay = moment(startDateTime).tz(dateAndTime.timezone).format("d");
    monthOfYear = moment(startDateTime).tz(dateAndTime.timezone).format("MMMM");
    weeklyDays[weekDay] = true;
  }
  return {
    type: RecurrenceConstants.RECUR_TYPE_VALUES.NONE,
    dailyProperties: {
      type: RecurrenceConstants.RECUR_DAILY_VALUES.DAY,
      interval: RecurrenceConstants.RECUR_OCCURRENCES_DEFAULT,
    },
    weeklyProperties: {
      weeklyDays: weeklyDays,
      interval: RecurrenceConstants.RECUR_OCCURRENCES_DEFAULT,
    },
    monthlyProperties: {
      type: RecurrenceConstants.RECUR_MONTH_VALUES.DAY_OF_EVERY_MONTH,
      dayOfMonth: dayOfMonth,
      dayOfWeek: RecurrenceConstants.RECUR_DAY_OF_WEEK_VALUES.DAY,
      weekOfMonth: RecurrenceConstants.RECUR_WEEK_OF_VALUES.DAY,
      interval: RecurrenceConstants.RECUR_OCCURRENCES_DEFAULT,
    },
    yearlyProperties: {
      type: RecurrenceConstants.RECUR_YEAR_VALUES.DAY_OF_MONTH,
      dayOfMonth: dayOfMonth,
      dayOfWeek: RecurrenceConstants.RECUR_DAY_OF_WEEK_VALUES.DAY,
      weekOfMonth: RecurrenceConstants.RECUR_WEEK_OF_VALUES.DAY,
      month: monthOfYear,
    },
    end: {
      type: RecurrenceConstants.RECUR_END_VALUES.END_AFTER,
      numberOfOccurrencesBeforeEnd:
        RecurrenceConstants.RECUR_OCCURRENCES_DEFAULT,
    },
  };
};

export const addDay = (date, days) => {
  const newDate = new Date(date);
  newDate.setDate(newDate.getDate() + days);
  return newDate;
};

export function getReservationRoute(reservationType) {
  return reservationType === ReservationTypes.MEETING ? Routes.MEETING
  : reservationType === ReservationTypes.WORKSPACE ? Routes.WORKSPACE
  : Routes.OFFICE; // Office support CISA
}

export function getTimeType(timezone, startDateTime, endDateTime) {
  if (isMorning(timezone, startDateTime, endDateTime)) {
    return WORKSPACE_TIME.MORNING;
  } else if (isAfternoon(timezone, startDateTime, endDateTime)) {
    return WORKSPACE_TIME.AFTERNOON;
  } else if (isAllDay(timezone, startDateTime, endDateTime)) {
    return WORKSPACE_TIME.ALLDAY;
  } else return null;
}

export function getDayType(timezone, startDateTime) {
  const { TODAY, TOMORROW } = WORKSPACE_DAY;
  const today = isToday(startDateTime, timezone);
  const tomorrow = isTomorrow(startDateTime, timezone);
  return today ? TODAY : tomorrow ? TOMORROW : null;
}

export function isToday(startDateMoment, timezone) {
  return startDateMoment?.isSame(moment().tz(timezone), "days");
}

export function isTomorrow(startDateMoment, timezone) {
  return startDateMoment?.isSame(addDay(moment().tz(timezone), 1), "days");
}

export function getTimeAsAllDay() {
  return {
    startTime: WORKSPACE_ALL_DAY_START,
    startTimePeriod: AM,
    endTime: WORKSPACE_ALL_DAY_END,
    endTimePeriod: PM,
  };
}

export function needAdvancedView(dateAndTime) {
  const { startDateTime, endDateTime } = computeMomentStartAndEndDates(
    dateAndTime
  );
  const { timezone, recurrence } = dateAndTime;
  const isSameDay = startDateTime?.isSame(endDateTime, "days");
  return (
    (!(isSameDay && isTomorrow(startDateTime, timezone)) &&
      !(isSameDay && isToday(startDateTime, timezone))) ||
    (!isAllDay(timezone, startDateTime, endDateTime) &&
      !isMorning(timezone, startDateTime, endDateTime) &&
      !isAfternoon(timezone, startDateTime, endDateTime)) ||
    recurrence
  );
}

export function computeAddress(room) {
  const { floor, building, city, state, country } = room;
  const addressArr = [floor, building, city, state, country];
  return addressArr.filter((e) => e !== null).join(", ");
}

export function getLocationInfo(data, addPrefix) {
  return isEmpty(data) ? "" : (!addPrefix ? "" : " | ") + data;
}

export function getScrollParent(node, root) {
  if (node == null || node === root) {
    return null;
  }

  if (
    node.scrollHeight > node.clientHeight &&
    node.style.overflowY === "auto"
  ) {
    return node;
  } else {
    return getScrollParent(node.parentNode);
  }
}

export function getResourceTimezones(resources, timezones) {
  const roomsTimezones = resources.map((resource) => {
    return JSON.stringify({
      resourceBuildingName: resource.room.building,
      resourceTimezone: timezones.find(
        (zone) => zone.englishName === resource.room.timezone
      ).name,
    });
  });
  const uniqueTimezones = new Set(roomsTimezones);
  const result = [];
  uniqueTimezones.forEach((value) => {
    result.push(JSON.parse(value));
  });
  return result;
}

const WORKPLACE_SERVICES_STORAGE_KEY = "workplaceServicesAppLabel";
const WORKPLACE_SERVICES_STORAGE_VALUE = "Workplace Services";

export function isWorkplaceServicesAppHome() {
  const appLabel = sessionStorage.getItem(WORKPLACE_SERVICES_STORAGE_KEY);
  return appLabel === WORKPLACE_SERVICES_STORAGE_VALUE;
}

export function getRecurrenceDetails(recurrence) {
  return (
    recurrence &&
    recurrence.details &&
    delete recurrence.details._id &&
    delete recurrence.details.success &&
    recurrence.details
  );
}

export function trapFocus(element) {
  // For future enhancement
  // Example --- element.querySelectorAll('a[href]:not([disabled]), button:not([disabled]), textarea:not([disabled]), input[type="text"]:not([disabled]), input[type="radio"]:not([disabled]), input[type="checkbox"]:not([disabled]), select:not([disabled])');
  const focusableEls = element.querySelectorAll('[role="button"]');
  const firstFocusableEl = focusableEls[0];
  const lastFocusableEl = focusableEls[focusableEls.length - 1];
  const KEYCODE_TAB = 9;

  element.addEventListener("keydown", function (e) {
    const isTabPressed = e.key === "Tab" || e.keyCode === KEYCODE_TAB;

    if (!isTabPressed) {
      return;
    }

    if (e.shiftKey) {
      /* shift + tab */ if (document.activeElement === firstFocusableEl) {
        lastFocusableEl.focus();
        e.preventDefault();
      }
    } /* tab */ else {
      if (document.activeElement === lastFocusableEl) {
        firstFocusableEl.focus();
        e.preventDefault();
      }
    }
  });
}

export function closeAllDatepickerPopups() {
  if (document.getElementsByClassName("flatpickr-calendar") !== null) {
    const ele = document.getElementsByClassName("flatpickr-calendar");
    if (!isNil(ele)) {
      ele.forEach((e) => {
        e.classList.remove("open");
        e.classList.remove("close");
      });
    }
  }
}

export function getColleagueReservationDateTime(
  { start, end, reservationTimezone, isAllDay },
  defaultTimezone
) {
  const timezone = defaultTimezone;
  const startDateMoment = moment(start);
  const endDateMoment = moment(end);
  const startDate = moment(
    moment(startDateMoment.tz(timezone)).format().slice(0, 10)
  ).toDate();
  const endDate = moment(
    moment(endDateMoment.tz(timezone)).format().slice(0, 10)
  ).toDate();
  const startTimePeriod = startDateMoment.format("A");
  const endTimePeriod = endDateMoment.format("A");
  const startTime = startDateMoment.tz(timezone).format("HH:mm");
  const endTime = endDateMoment.tz(timezone).format("HH:mm");
  return {
    startDate,
    endDate,
    startTimePeriod,
    endTimePeriod,
    startTime,
    endTime,
    timezone,
    allDayEvent: isAllDay,
  };
}

const EventEmitter = {
  _events: {},
  dispatch: function (event, data) {
    if (!this._events[event]) return;
    this._events[event].forEach((callback) => callback(data));
  },
  subscribe: function (event, callback) {
    if (!this._events[event]) this._events[event] = [];
    this._events[event].push(callback);
  },
  unsubscribe(event) {
    if (!this._events[event]) return;
    delete this._events[event];
  },
};
export { EventEmitter };
