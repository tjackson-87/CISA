/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import isEmpty from "lodash/isEmpty";

export function isAllSelectedEquipmentAvailable(resources) {
  return resources.every((resource) =>
    isResourceSelectedEquipmentAvailable(resource)
  );
}

export function isResourceSelectedEquipmentAvailable(resource) {
  if (isEmpty(resource.selectedEquipment)) return true;
  if (isEmpty(resource.availableEquipment)) return false;
  return resource.selectedEquipment.every((equipment) =>
    resource.availableEquipment.some(
      (available) => available._id === equipment._id
    )
  );
}

export function computeEquipmentTotalCost(selectedEquipments) {
  return selectedEquipments.reduce(
    (count, { totalCost, quantity }) => count + totalCost.value * quantity,
    0
  );
}

export function computeEquipmentUsageCost(selectedEquipments) {
  return selectedEquipments.reduce(
    (count, { usageCost, quantity }) => count + usageCost.value * quantity,
    0
  );
}
