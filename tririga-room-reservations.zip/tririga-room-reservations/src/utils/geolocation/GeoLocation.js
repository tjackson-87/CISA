/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import findNearest from "geolib/es/findNearest";
import getDistance from "geolib/es/getDistance";
import isEmpty from "lodash/isEmpty";
import { timeout } from "promise-timeout";

const GEO_TIMEOUT = 10000;
const PERMISSION_TIMEOUT = 20000;
const GEO_MAX_AGE = 600000;
const MAX_DISTANCE = 100;

export async function findNearestBuilding(buildings) {
  if (isEmpty(buildings)) return null;
  const currentPosition = await getCurrentPosition();
  if (currentPosition == null) return null;
  const nearestBuilding = findNearest(currentPosition, buildings);
  const nearestBuildingDistance = getDistance(currentPosition, nearestBuilding);
  return nearestBuildingDistance <= MAX_DISTANCE ? nearestBuilding : null;
}

let currentPosition = null;
let ongoingGetCurrentPosition = null;

export async function getCurrentPosition() {
  if (currentPosition != null) return currentPosition;
  if (ongoingGetCurrentPosition) return ongoingGetCurrentPosition;
  ongoingGetCurrentPosition = getCurrentPositionWithTimeout();
  currentPosition = await ongoingGetCurrentPosition;
  ongoingGetCurrentPosition = null;
  return currentPosition;
}

const getCurrentPositionWithTimeout = () =>
  timeout(
    new Promise((resolve) =>
      navigator.geolocation.getCurrentPosition(
        ({ coords }) =>
          resolve({ latitude: coords.latitude, longitude: coords.longitude }),
        (e) => resolve(null),
        {
          maximumAge: GEO_MAX_AGE,
          timeout: GEO_TIMEOUT,
          enableHighAccuracy: true,
        }
      )
    ),
    PERMISSION_TIMEOUT
  ).catch((e) => null);
