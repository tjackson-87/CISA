/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/
import { isEmpty } from "lodash";
import moment from "moment-timezone";

export function getItemsOrderCount(selectedMenuItems) {
  return selectedMenuItems.reduce((count, { qty }) => count + qty, 0);
}

export function getItemsOrderTotal(selectedMenuItems) {
  return selectedMenuItems.reduce(
    (count, { costPerItem, qty }) => count + costPerItem.value * qty,
    0
  );
}

export function getCurrency(currencies, menu) {
  if (isEmpty(currencies) || isEmpty(menu)) return null;
  return currencies.find(
    (currency) =>
      currency._UOM_Display_Value === menu.currency ||
      currency._UOM_Value === menu.currency
  )._UOM_Abbreviation;
}

export function getFoodCost(currentUserLocale, currency, number) {
  if (isEmpty(currency)) return "0.00";
  return new Intl.NumberFormat(currentUserLocale, {
    style: "currency",
    currency: currency,
  }).format(number);
}

export function getCateringForOccurrence(
  foodOrderItems,
  resources,
  purchaseOrders,
  start,
  end,
  isAllDay
) {
  const foodOrdersForOccurrence = foodOrderItems?.filter((item) =>
    resources.some((resource) => resource._id === item.resourceId)
  );
  if (
    !isEmpty(foodOrdersForOccurrence) &&
    !isEmpty(purchaseOrders) &&
    start &&
    end
  ) {
    const foodOrdersWithPurchaseOrdersForOccurrence = [];
    if (isAllDay) {
      end = moment(end).add(1, "seconds");
    }
    foodOrdersForOccurrence.forEach((catering) => {
      const poForCatering = purchaseOrders?.find(
        (order) =>
          catering.orderId === order.foodOrderRecordId &&
          moment(order.plannedStart).isSame(start) &&
          moment(order.plannedEnd).isSame(end)
      );
      foodOrdersWithPurchaseOrdersForOccurrence.push(
        poForCatering
          ? {
              ...catering,
              purchaseOrderId: poForCatering.id,
              purchaseOrderStatus: poForCatering.status,
            }
          : catering
      );
    });
    return foodOrdersWithPurchaseOrdersForOccurrence;
  } else {
    return foodOrdersForOccurrence;
  }
}
