/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import { createBrowserHistory } from "history";
import { getTriAppConfig } from "@tririga/tririga-react-components";

let appHistory = null;

export function getAppHistory() {
  if (appHistory == null) {
    appHistory = createBrowserHistory({
      basename: getTriAppConfig().appPath,
    });
  }
  return appHistory;
}
