/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2023 The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/

import moment from "moment-timezone";
import * as Status from "../constants/Status";

export async function upcomingReservationList(events) {
  if (!events || (events && !events.length)) return [];
  const sortEvents = [];
  events.forEach((evt) => {
    if (evt.rooms?.length > 1) {
      evt.rooms.forEach((room) => {
        if (
          room.statusENUS === Status.ACCEPTED ||
          room.statusENUS === Status.ACTIVE ||
          room.statusENUS === Status.TENTATIVE
        ) {
          sortEvents.push({
            ...evt,
            rooms: [room],
          });
          return true;
        }
      });
    } else {
      if (
        evt.rooms[0].statusENUS === Status.ACCEPTED ||
        evt.rooms[0].statusENUS === Status.ACTIVE ||
        evt.rooms[0].statusENUS === Status.TENTATIVE
      ) {
        sortEvents.push(evt);
      }
    }
    return true;
  });
  return sortEvents;
}

export function getTimeRange(evt, timezone) {
  return `${moment.tz(evt.start, timezone).format("h:mm A ")} - ${moment
    .tz(evt.end, timezone)
    .format("h:mm A ")} ${moment.tz(evt.start, timezone).format("zz")}`;
}
