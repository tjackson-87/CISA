/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2022 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/

import moment from "moment-timezone";
import isEmpty from "lodash/isEmpty";
import {
  DateTimeConstants,
  DefaultValues,
  getCurrentDateTime,
  getNextMinuteInterval,
  ReservationTypes,
  Status,
  EquipmentUtils,
  RecurrenceConstants,
  getRecurPropName,
  ExchangeConstants,
  AppMsg,
  computeMomentStartAndEndDates,
} from "..";

const {
  MINUTE_INTERVAL,
  TIME_FORMAT,
  AM_PM_FORMAT,
  DEFAULT_DURATION_MINUTES,
  WORKSPACE_ALL_DAY_START,
  WORKSPACE_ALL_DAY_END,
  PM,
} = DateTimeConstants;

export function computeReservationInitialTime(
  reservationType,
  timezone,
  start,
  end,
  isDateOnly
) {
  let startWithTZ;
  let endWithTZ;
  if (start != null && end != null) {
    startWithTZ = start.tz(timezone);
    endWithTZ = end.tz(timezone);
  } else if (reservationType === ReservationTypes.MEETING) {
    const startMo = moment.tz(start, timezone);
    const nowMo = getCurrentDateTime(timezone);
    const isToday = startMo.isSame(nowMo, "day");
    if (start && isDateOnly && !isToday) {
      const initISOTimeStringSplit = DefaultValues.RESERVATION_INIT_ISO_TIME.split(
        ":"
      );
      startWithTZ = startMo
        .clone()
        .hour(initISOTimeStringSplit[0])
        .minute(initISOTimeStringSplit[1]);
    } else if (start && !isDateOnly) {
      startWithTZ = startMo;
    } else {
      startWithTZ = getNextMinuteInterval(nowMo, MINUTE_INTERVAL);
    }
    endWithTZ = startWithTZ.clone().add(DEFAULT_DURATION_MINUTES, "minutes");
  } else if (reservationType === ReservationTypes.WORKSPACE || reservationType === ReservationTypes.OFFICE) { // Office type added CISA
    const date =
      start != null
        ? moment.tz(start, timezone).format("YYYY-MM-DD")
        : getCurrentDateTime(timezone).format("YYYY-MM-DD");
    startWithTZ = moment.tz(
      `${date} ${WORKSPACE_ALL_DAY_START}`,
      "YYYY-MM-DD hh:mm",
      timezone
    );
    endWithTZ = moment.tz(
      `${date} ${WORKSPACE_ALL_DAY_END} ${PM}`,
      "YYYY-MM-DD hh:mm A",
      timezone
    );
  }

  return {
    timezone,
    startDate: moment(startWithTZ.format("YYYY-MM-DD")).toDate(),
    startTime: startWithTZ.format(TIME_FORMAT),
    startTimePeriod: startWithTZ.format(AM_PM_FORMAT),
    endDate: moment(endWithTZ.format("YYYY-MM-DD")).toDate(),
    endTime: endWithTZ.format(TIME_FORMAT),
    endTimePeriod: endWithTZ.format(AM_PM_FORMAT),
  };
}

function hasDeclinedResources(resources) {
  if (isEmpty(resources)) return false;
  return resources.some((item) => !isAvailable(item.data.statusENUS));
}

export function hasPendingRooms(rooms) {
  if (isEmpty(rooms)) return false;
  return rooms.some((room) => room.statusENUS === Status.REVIEW_IN_PROGRESS);
}

export function hasDeclinedRooms(rooms) {
  if (isEmpty(rooms)) return false;
  return rooms.some((room) => room.statusENUS === Status.DECLINED);
}

export function isAvailable(status) {
  return (
    status === Status.ACCEPTED ||
    status === Status.TENTATIVE ||
    status === Status.REVIEW_IN_PROGRESS
  );
}

export function computeTimeDifferenceDuration(endTime) {
  if (endTime == null) return null;
  const diff = moment(endTime).diff(moment());
  return diff >= 0 ? diff : 0;
}

export function isReservationValid(
  subject,
  startDate,
  startTime,
  startTimePeriod,
  endDate,
  endTime,
  endTimePeriod,
  resources,
  holdTimeExpired,
  isExchangeIntegrated,
  reservationType
) {
  const isMeetingSpace = reservationType === ReservationTypes.MEETING;
  resources = getAvailableResources(resources);
  return (
    subject?.trim().length > 0 &&
    startDate != null &&
    !isEmpty(startTime) &&
    !isEmpty(startTimePeriod) &&
    endDate != null &&
    !isEmpty(endTime) &&
    !isEmpty(endTimePeriod) &&
    (!isEmpty(resources) || (isExchangeIntegrated && isMeetingSpace)) &&
    !hasDeclinedResources(resources) &&
    EquipmentUtils.isAllSelectedEquipmentAvailable(resources) &&
    !holdTimeExpired
  );
}

export function buildRecurrenceParams(
  startAndEndDate,
  reserveContextRecurrence
) {
  const recurrenceParamProps = buildRecurrenceProps(reserveContextRecurrence);
  return {
    start: startAndEndDate.startDate,
    end: startAndEndDate.endDate,
    timezone: {
      id: startAndEndDate.timezoneId,
    },
    ...recurrenceParamProps,
  };
}

function buildRecurrenceProps({ type, ...restArgs }) {
  let properties = {
    ...restArgs[getRecurPropName(type)],
  };

  const endProps = !isEmpty(properties.end)
    ? buildEndProps(properties.end)
    : buildEndProps(restArgs.end);

  switch (type) {
    case RecurrenceConstants.RECUR_TYPE_VALUES.DAILY: {
      properties = buildDailyProps(properties);
      break;
    }
    case RecurrenceConstants.RECUR_TYPE_VALUES.WEEKLY: {
      properties = buildWeeklyProps(properties);
      break;
    }
    case RecurrenceConstants.RECUR_TYPE_VALUES.MONTHLY: {
      properties = buildMonthlyProps(properties);
      break;
    }
    default:
      properties = buildYearlyProps(properties);
      break;
  }

  return {
    type,
    ...properties,
    ...endProps,
  };
}

function buildEndProps({ type, endDate, ...restArgs }) {
  const result = {
    endOption: type,
    noEndDate: type === RecurrenceConstants.RECUR_END_VALUES.NO_END_DATE,
    endDate: moment.isDate(endDate)
      ? moment(endDate)
          .endOf("day")
          .format("YYYY-MM-DDTHH:mm:ss.SSSZ")
          .toString()
      : endDate,
    ...restArgs,
    numberOfOccurrencesBeforeEnd: moment.isDate(endDate)
      ? 0
      : restArgs.numberOfOccurrencesBeforeEnd,
  };

  return result;
}

function buildDailyProps(properties) {
  return {
    dailyOption: properties.type,
    dailyRecurWeekDay:
      properties.type === RecurrenceConstants.RECUR_DAILY_VALUES.WEEKDAY,
    dailyRecurWeekEndDay:
      properties.type === RecurrenceConstants.RECUR_DAILY_VALUES.WEEKEND_DAY,
    dailyRecurrenceDays: properties.interval,
  };
}

function buildWeeklyProps(properties) {
  const result = {
    weeklySunday: false,
    weeklyMonday: false,
    weeklyTuesday: false,
    weeklyWednesday: false,
    weeklyThursday: false,
    weeklyFriday: false,
    weeklySaturday: false,
    weeklyRecurrenceWeeks: properties.interval,
  };

  if (properties.weeklyDays[0] === true || properties.weeklyDays[0] === false) {
    properties.weeklyDays = properties.weeklyDays
      .map((checked, idx) =>
        checked ? RecurrenceConstants.WEEK_DAYS[idx] : null
      )
      .filter((dayOfWeek) => dayOfWeek);
  }

  for (const day of properties.weeklyDays) {
    switch (day) {
      case RecurrenceConstants.WEEK_DAYS[0]:
        result.weeklySunday = true;
        break;
      case RecurrenceConstants.WEEK_DAYS[1]:
        result.weeklyMonday = true;
        break;
      case RecurrenceConstants.WEEK_DAYS[2]:
        result.weeklyTuesday = true;
        break;
      case RecurrenceConstants.WEEK_DAYS[3]:
        result.weeklyWednesday = true;
        break;
      case RecurrenceConstants.WEEK_DAYS[4]:
        result.weeklyThursday = true;
        break;
      case RecurrenceConstants.WEEK_DAYS[5]:
        result.weeklyFriday = true;
        break;
      case RecurrenceConstants.WEEK_DAYS[6]:
        result.weeklySaturday = true;
        break;
      default:
        break;
    }
  }
  return result;
}

function buildMonthlyProps(properties) {
  const result = {
    monthlyOption: properties.type,
    monthlyRecurrenceMonths: properties.interval,
  };
  if (
    properties.type ===
    RecurrenceConstants.RECUR_MONTH_VALUES.WEEK_OF_EVERY_MONTH
  ) {
    result.monthlyDayOfWeek = properties.dayOfWeek;
    result.monthlyWeekOfMonth = properties.weekOfMonth;
  }
  result.monthlyDayOfMonth = properties.dayOfMonth;
  return result;
}

function buildYearlyProps(properties) {
  const result = {
    yearlyOption: properties.type,
    yearlyMonth: properties.month,
  };

  if (properties.type === RecurrenceConstants.RECUR_YEAR_VALUES.WEEK_OF_MONTH) {
    result.yearlyDayOfWeek = properties.dayOfWeek;
    result.yearlyWeekOfMonth = properties.weekOfMonth;
  }
  result.yearlyDayOfMonth = properties.dayOfMonth;
  return result;
}
export function getInitialRecurrenceProperties() {
  const recurrenceProperties = {
    type: RecurrenceConstants.RECUR_TYPE_VALUES.DAILY,
    dailyProperties: {
      type: RecurrenceConstants.RECUR_DAILY_VALUES.DAY,
      interval: RecurrenceConstants.RECUR_OCCURRENCES_DEFAULT,
    },
    weeklyProperties: {
      weeklyDays: new Array(7).fill(false),
      interval: RecurrenceConstants.RECUR_OCCURRENCES_DEFAULT,
    },
    monthlyProperties: {
      type: RecurrenceConstants.RECUR_MONTH_VALUES.DAY_OF_EVERY_MONTH,
      dayOfMonth: RecurrenceConstants.MONTH_DAYS[0],
      dayOfWeek: RecurrenceConstants.RECUR_DAY_OF_WEEK_VALUES.DAY,
      weekOfMonth: RecurrenceConstants.RECUR_WEEK_OF_VALUES.DAY,
      interval: RecurrenceConstants.RECUR_OCCURRENCES_DEFAULT,
    },
    yearlyProperties: {
      type: RecurrenceConstants.RECUR_YEAR_VALUES.DAY_OF_MONTH,
      dayOfMonth: RecurrenceConstants.MONTH_DAYS[0],
      dayOfWeek: RecurrenceConstants.RECUR_DAY_OF_WEEK_VALUES.DAY,
      weekOfMonth: RecurrenceConstants.RECUR_WEEK_OF_VALUES.DAY,
      month: RecurrenceConstants.MONTHS.JANUARY,
    },
  };
  return recurrenceProperties;
}
export function getRecurrencePropertiesFromExchangeRecurrence(
  exchangeRecurrence
) {
  let recurrenceProperties = getInitialRecurrenceProperties();
  const { pattern, range } = exchangeRecurrence;

  switch (pattern.type) {
    case RecurrenceConstants.EXCHANGE_TYPE_VALUES.DAILY:
      recurrenceProperties.type = RecurrenceConstants.RECUR_TYPE_VALUES.DAILY;
      recurrenceProperties.dailyProperties = {
        type: RecurrenceConstants.RECUR_DAILY_VALUES.DAY,
        interval: pattern.interval.toString(),
      };
      break;
    case RecurrenceConstants.EXCHANGE_TYPE_VALUES.WEEKLY:
      recurrenceProperties.type = RecurrenceConstants.RECUR_TYPE_VALUES.WEEKLY;
      recurrenceProperties.weeklyProperties = {
        weeklyDays: getWeeklyDays(pattern.daysOfWeek),
        interval: pattern.interval.toString(),
      };
      break;
    case RecurrenceConstants.EXCHANGE_TYPE_VALUES.ABSOLUTE_MONTHLY:
      recurrenceProperties.type = RecurrenceConstants.RECUR_TYPE_VALUES.MONTHLY;
      recurrenceProperties.monthlyProperties = {
        type: RecurrenceConstants.RECUR_MONTH_VALUES.DAY_OF_EVERY_MONTH,
        dayOfMonth: pattern.dayOfMonth,
        interval: pattern.interval.toString(),
        weekOfMonth: RecurrenceConstants.RECUR_WEEK_OF_VALUES.DAY,
        dayOfWeek: RecurrenceConstants.RECUR_DAY_OF_WEEK_VALUES.DAY,
      };
      break;
    case RecurrenceConstants.EXCHANGE_TYPE_VALUES.RELATIVE_MONTHLY:
      recurrenceProperties.type = RecurrenceConstants.RECUR_TYPE_VALUES.MONTHLY;
      recurrenceProperties.monthlyProperties = {
        type: RecurrenceConstants.RECUR_MONTH_VALUES.WEEK_OF_EVERY_MONTH,
        interval: pattern.interval.toString(),
        weekOfMonth: getWeekOfMonth(pattern.index),
        dayOfWeek: getDayOfWeek(pattern.daysOfWeek),
        dayOfMonth: 0,
      };
      break;
    case RecurrenceConstants.EXCHANGE_TYPE_VALUES.ABSOLUTE_YEARLY:
      recurrenceProperties.type = RecurrenceConstants.RECUR_TYPE_VALUES.YEARLY;
      recurrenceProperties.yearlyProperties = {
        type: RecurrenceConstants.RECUR_YEAR_VALUES.DAY_OF_MONTH,
        dayOfMonth: pattern.dayOfMonth,
        dayOfWeek: RecurrenceConstants.RECUR_WEEK_OF_VALUES.DAY,
        weekOfMonth: RecurrenceConstants.RECUR_WEEK_OF_VALUES.DAY,
        month: RecurrenceConstants.MONTH_OPTIONS[pattern.month - 1].value,
      };
      break;
    case RecurrenceConstants.EXCHANGE_TYPE_VALUES.RELATIVE_YEARLY:
      recurrenceProperties.type = RecurrenceConstants.RECUR_TYPE_VALUES.YEARLY;
      recurrenceProperties.yearlyProperties = {
        type: RecurrenceConstants.RECUR_YEAR_VALUES.WEEK_OF_MONTH,
        dayOfMonth: 0,
        dayOfWeek: getDayOfWeek(pattern.daysOfWeek),
        weekOfMonth: getWeekOfMonth(pattern.index),
        month: RecurrenceConstants.MONTH_OPTIONS[pattern.month - 1].value,
      };
      break;
    default:
  }
  const end = buildReserveRecurrenceEnd(range);
  recurrenceProperties = { ...recurrenceProperties, end };
  return recurrenceProperties;
}

function getWeeklyDays(weeklyDays) {
  return RecurrenceConstants.EXCHANGE_DAYS_OF_WEEK.map(
    (day) => weeklyDays.indexOf(day) >= 0
  );
}

function getDayOfWeek(daysOfWeek) {
  let weeklyDays = getWeeklyDays(daysOfWeek);
  weeklyDays = weeklyDays
    .map((checked, idx) =>
      checked ? RecurrenceConstants.WEEK_DAYS[idx] : null
    )
    .filter((dayOfWeek) => dayOfWeek);
  return weeklyDays[0];
}

function getWeekOfMonth(weekOfMonth) {
  switch (weekOfMonth) {
    case RecurrenceConstants.EXCHANGE_WEEK_OF_MONTH_VALUES.FIRST_WEEK:
      return RecurrenceConstants.RECUR_WEEK_OF_VALUES.WEEK_OF_FIRST;
    case RecurrenceConstants.EXCHANGE_WEEK_OF_MONTH_VALUES.SECOND_WEEK:
      return RecurrenceConstants.RECUR_WEEK_OF_VALUES.WEEK_OF_SECOND;
    case RecurrenceConstants.EXCHANGE_WEEK_OF_MONTH_VALUES.THIRD_WEEK:
      return RecurrenceConstants.RECUR_WEEK_OF_VALUES.WEEK_OF_THIRD;
    case RecurrenceConstants.EXCHANGE_WEEK_OF_MONTH_VALUES.FOURTH_WEEK:
      return RecurrenceConstants.RECUR_WEEK_OF_VALUES.WEEK_OF_FOURTH;
    case RecurrenceConstants.EXCHANGE_WEEK_OF_MONTH_VALUES.LAST_WEEK:
      return RecurrenceConstants.RECUR_WEEK_OF_VALUES.WEEK_OF_LAST;
    default:
      return null;
  }
}

function buildReserveRecurrenceEnd(range) {
  switch (range.type) {
    case RecurrenceConstants.EXCHANGE_END_VALUES.END_AFTER:
      return {
        type: RecurrenceConstants.RECUR_END_VALUES.END_AFTER,
        numberOfOccurrencesBeforeEnd: range.numberOfOccurrences.toString(),
      };
    case RecurrenceConstants.EXCHANGE_END_VALUES.END_DATE:
      return {
        type: RecurrenceConstants.RECUR_END_VALUES.END_DATE,
        endDate: moment(range.endDate, "YYYY-MM-DD").toDate(),
      };
    default:
      return { type: RecurrenceConstants.RECUR_END_VALUES.NO_END_DATE };
  }
}

export function removeOnlineMeetingFromDescription(description) {
  return description.replace(
    new RegExp(
      `<div id=.*?${ExchangeConstants.ONLINE_MEETING_KEY_ON_EVENT_BODY}.*?</div>`,
      "gs"
    ),
    ""
  );
}

export function getAvailableResources(resources) {
  if (!resources) return null;
  return resources.filter(
    (resource) =>
      !(resource.reserved && resource.data?.statusENUS === Status.CANCELED)
  );
}

export function reservationDetailsLabel(reservation, timezone, locale) {
  return AppMsg.getMessage(
    AppMsg.RESERVATION_MESSAGE.RESERVATION_TIME_AND_SUBJECT_TEXT
  )
    .replace(
      "{1}",
      moment
        .tz(reservation.start, timezone)
        .locale(locale)
        .format(DateTimeConstants.TIME_FORMAT_12H_WITH_PERIOD)
    )
    .replace(
      "{2}",
      moment
        .tz(reservation.end, timezone)
        .locale(locale)
        .format(DateTimeConstants.TIME_FORMAT_12H_WITH_PERIOD)
    );
}

export function roomAndBuildingDetailsLabel(room) {
  return AppMsg.getMessage(AppMsg.RESERVATION_MESSAGE.ROOM_AND_BUILDING_TEXT)
    .replace("{1}", room.name)
    .replace("{2}", room.building);
}

export function calendarDetails(calendar) {
  return AppMsg.getMessage(AppMsg.RESERVATION_MESSAGE.DELEGATE_CALENDAR_LABEL)
    .replace("{1}", calendar.name)
    .replace("{2}", calendar.email);
}

export function isStartDateInvalid(dateAndTime) {
  const { startDateTime } = computeMomentStartAndEndDates(dateAndTime);
  if (startDateTime === null || dateAndTime.timezone === null) return false;
  const currentDate = moment.tz(moment(), dateAndTime.timezone);
  const startDate = moment(startDateTime).tz(dateAndTime.timezone);
  return moment(startDate).isBefore(
    currentDate,
    dateAndTime.allDayEvent ? "day" : "minutes"
  );
}
