/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/* 
  Reviewed for upgrade
  Name: Mike Tremblay
*/
import { isEmpty } from "lodash";
import moment from "moment-timezone";
import {
  TriDurationUtils,
  TriFloorPlanAPI,
} from "@tririga/tririga-react-components";
import {
  Restaurant16,
  Accessibility16,
  Run16,
  Rss16,
  Phone16,
  Video16,
  Screen16,
  Light16,
  VolumeMute16,
  BatteryCharging16,
} from "@carbon/icons-react";
import { AppMsg, ReservationTypes } from "..";
import { ReactComponent as ipPhone } from "../icons/ipPhone.svg";
import { ReactComponent as adjustableDesk } from "../icons/adjustableDesk.svg";

const AMENITY_MIN_WIDTH = 170;
const AMENITY_WIDTH = 30;

export function isStartDateBeforeAdvanceLimit(startDate, reserveAdvanceLimit) {
  if (reserveAdvanceLimit == null || reserveAdvanceLimit === 0) return false;
  const reserveAdvanceLimitMO = moment.duration(
    TriDurationUtils.convertTririgaDurationToIso(reserveAdvanceLimit)
  );
  const reserveAdvanceLimitDT = moment().add(reserveAdvanceLimitMO);
  return moment(startDate).isBefore(reserveAdvanceLimitDT, "second");
}

export function isEndDateAfterCutOffDuration(endDate, reserveCutOffDuration) {
  if (reserveCutOffDuration == null || reserveCutOffDuration === 0) {
    return false;
  }
  const reserveCutOffDurationMO = moment.duration(
    TriDurationUtils.convertTririgaDurationToIso(reserveCutOffDuration)
  );
  const reserveCutOffDurationDT = moment().add(reserveCutOffDurationMO);
  return moment(endDate).isAfter(reserveCutOffDurationDT, "second");
}

export async function getFloorplanId(selectedFloorId) {
  const floorPlanId = await TriFloorPlanAPI.getFloorplanId(selectedFloorId);
  return floorPlanId;
}

export function getFloorsOfBuildingSelected(floors, selectedBuildingId) {
  if (selectedBuildingId && !isEmpty(floors)) {
    const floorsForBuildingSelected = floors.filter(
      (floor) => floor.buildingSystemRecordID === selectedBuildingId
    );
    return floorsForBuildingSelected;
  }
  return floors;
}

export function getAmenitiesByRoom(room, currentReservationType) {
  const amenities = [
    {
      exist: room.adaAvailable,
      icon: Accessibility16,
      label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_ACCESSIBLE,
      reservationType: [ReservationTypes.MEETING, ReservationTypes.WORKSPACE, ReservationTypes.OFFICE], // Office reservation type added CISA
    },
    {
      exist: room.networkConnection,
      icon: Rss16,
      label:
        AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_NETWORK_CONNECTION,
      reservationType: [ReservationTypes.MEETING, ReservationTypes.WORKSPACE, ReservationTypes.OFFICE], // Office reservation type added CISA
    },
    {
      exist: room.inRoomProjector,
      icon: Run16,
      label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_PROJECTOR,
      reservationType: [ReservationTypes.MEETING],
    },
    {
      exist: room.telephoneConference,
      icon: Phone16,
      label:
        AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_TELEPHONE_CONFERENCE,
      reservationType: [ReservationTypes.MEETING],
    },
    {
      exist: room.whiteboard,
      icon: Screen16,
      label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_WHITEBOARD,
      reservationType: [ReservationTypes.MEETING],
    },
    {
      exist: room.videoConferenceRoom,
      icon: Video16,
      label:
        AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_VIDEO_CONFERENCE,
      reservationType: [ReservationTypes.MEETING],
    },
    {
      exist: room.cateringAvailable,
      icon: Restaurant16,
      label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_CATERING,
      reservationType: [ReservationTypes.MEETING],
    },
    {
      exist: room.ipPhone,
      icon: ipPhone,
      label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_IP_PHONE,
      reservationType: [ReservationTypes.WORKSPACE, ReservationTypes.OFFICE], // Office reservation type added CISA
    },
    {
      exist: room.noiseBarrier,
      icon: VolumeMute16,
      label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_NOISE_BARRIER,
      reservationType: [ReservationTypes.WORKSPACE, ReservationTypes.OFFICE], // Office reservation type added CISA
    },
    {
      exist: room.adjustableHeightDesk,
      icon: adjustableDesk,
      label:
        AppMsg.RESERVATION_MESSAGE
          .STEP_ROOM_SEARCH_FILTER_ADJUSTABLE_HEIGHT_DESK,
      reservationType: [ReservationTypes.WORKSPACE, ReservationTypes.OFFICE], // Office reservation type added CISA
    },
    {
      exist: room.naturalLight,
      icon: Light16,
      label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_NATURAL_LIGHT,
      reservationType: [ReservationTypes.MEETING, ReservationTypes.WORKSPACE, ReservationTypes.OFFICE], // Office reservation type added CISA
    },
    
    /*
      Amenities CISA
    */
    {
      exist: room.dellPro2X,
      icon: BatteryCharging16,
      label:
        AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_DELL_PRO_2X_DOCKING_STATION,
      reservationType: [ReservationTypes.WORKSPACE, ReservationTypes.OFFICE],
    },
    {
      exist: room.networkTypeA,
      icon: Rss16,
      label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_NETWORK_TYPE_A,
      reservationType: [ReservationTypes.WORKSPACE, ReservationTypes.OFFICE],
    },
    {
      exist: room.networkTypeB,
      icon: Rss16,
      label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_NETWORK_TYPE_B,
      reservationType: [ReservationTypes.WORKSPACE, ReservationTypes.OFFICE],
    },
    {
      exist: room.networkTypeC,
      icon: Rss16,
      label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_NETWORK_TYPE_C,
      reservationType: [ReservationTypes.WORKSPACE, ReservationTypes.OFFICE],
    },
    {
      exist: room.networkTypeCAL,
      icon: Rss16,
      label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_NETWORK_TYPE_CAL,
      reservationType: [ReservationTypes.WORKSPACE, ReservationTypes.OFFICE],
    },
    {
      exist: room.networkTypeM,
      icon: Rss16,
      label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_NETWORK_TYPE_M,
      reservationType: [ReservationTypes.WORKSPACE, ReservationTypes.OFFICE],
    },
    {
      exist: room.networkTypeTEN,
      icon: Rss16,
      label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_NETWORK_TYPE_TEN,
      reservationType: [ReservationTypes.WORKSPACE, ReservationTypes.OFFICE],
    },
    {
      exist: room.networkTypeTM,
      icon: Rss16,
      label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_NETWORK_TYPE_TM,
      reservationType: [ReservationTypes.WORKSPACE, ReservationTypes.OFFICE],
    },
    {
      exist: room.universalDockingStation,
      icon: BatteryCharging16,
      label:
        AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_UNIVERSAL_DOCKING_STATION,
      reservationType: [ReservationTypes.WORKSPACE, ReservationTypes.OFFICE],
    },
    {
      exist: room.hpUltraSlimDockingStation,
      icon: BatteryCharging16,
      label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_HP_ULTRASLIM,
      reservationType: [ReservationTypes.WORKSPACE, ReservationTypes.OFFICE],
    },
    {
      exist: room.dellK09A,
      icon: BatteryCharging16,
      label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_DELL_K09A,
      reservationType: [ReservationTypes.WORKSPACE, ReservationTypes.OFFICE],
    },
    {
      exist: room.dellOPW395,
      icon: BatteryCharging16,
      label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_DELL_OPW_395,
      reservationType: [ReservationTypes.WORKSPACE, ReservationTypes.OFFICE],
    },
    {
      exist: room.dellWYSE,
      icon: BatteryCharging16,
      label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_DELL_WYSE,
      reservationType: [ReservationTypes.WORKSPACE, ReservationTypes.OFFICE],
    },
    {
      exist: room.dellWYSE3040,
      icon: BatteryCharging16,
      label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_DELL_WYSE_3040,
      reservationType: [ReservationTypes.WORKSPACE, ReservationTypes.OFFICE],
    },
    {
      exist: room.dellWYSE5070,
      icon: BatteryCharging16,
      label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_DELL_WYSE_5070,
      reservationType: [ReservationTypes.WORKSPACE, ReservationTypes.OFFICE],
    },
    {
      exist: room.hpUSBG5,
      icon: BatteryCharging16,
      label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_HP_USB_G5,
      reservationType: [ReservationTypes.WORKSPACE, ReservationTypes.OFFICE],
    },
    {
      exist: room.vtc,
      icon: Video16,
      label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_VTC,
      reservationType: [ReservationTypes.MEETING],
    },
    {
      exist: room.hdmi,
      icon: Rss16,
      label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_HDMI,
      reservationType: [ReservationTypes.MEETING],
    },
    {
      exist: room.pivEnrollmentStation,
      icon: ipPhone,
      label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_PIV_ENROLLMENT,
      reservationType: [ReservationTypes.WORKSPACE, ReservationTypes.OFFICE],
    },
    {
      exist: room.smartWhiteboard,
      icon: Screen16,
      label:
        AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_SMART_WHITEBOARD,
      reservationType: [ReservationTypes.MEETING],
    },
    {
      exist: room.networkTypeCOOL,
      icon: Rss16,
      label:
        AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_NETWORK_TYPE_COOL,
      reservationType: [ReservationTypes.WORKSPACE, ReservationTypes.OFFICE],
    },
    {
      exist: room.networkTypeF,
      icon: Rss16,
      label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_NETWORK_TYPE_F,
      reservationType: [ReservationTypes.WORKSPACE, ReservationTypes.OFFICE],
    },
    {
      exist: room.networkTypeG,
      icon: Rss16,
      label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_NETWORK_TYPE_G,
      reservationType: [ReservationTypes.WORKSPACE, ReservationTypes.OFFICE],
    },
    {
      exist: room.networkTypeMOE,
      icon: Rss16,
      label:
        AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_NETWORK_TYPE_MOE,
      reservationType: [ReservationTypes.WORKSPACE, ReservationTypes.OFFICE],
    },
    {
      exist: room.networkTypeN,
      icon: Rss16,
      label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_NETWORK_TYPE_N,
      reservationType: [ReservationTypes.WORKSPACE, ReservationTypes.OFFICE],
    },
    {
      exist: room.msTeams,
      icon: Video16,
      label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_MS_TEAMS,
      reservationType: [ReservationTypes.MEETING],
    },

    {
      exist: room.surfaceHub,
      icon: Video16,
      label: AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_FILTER_SURFACE_HUB,
      reservationType: [ReservationTypes.MEETING],
    },

  ];

  return amenities.filter(
    (amenity) =>
      !!amenity.reservationType.includes(currentReservationType) &&
      amenity.exist === "Yes"
  );
}

export function computeOccurrencesLabel(availCount, maxCount) {
  return AppMsg.getMessage(
    AppMsg.RESERVATION_MESSAGE.STEP_ROOM_SEARCH_MEETS_OCCURRENCES
  )
    .replace("{1}", availCount)
    .replace("{2}", maxCount);
}

export function computeExceptionLabel(exceptions) {
  const total = exceptions.length;
  let resolved = 0;
  exceptions.map((exception) => {
    if (exception.room !== null) {
      resolved++;
    }
    return 0;
  });
  return AppMsg.getMessage(
    AppMsg.RESERVATION_MESSAGE.STEP_ROOM_EXCEPTIONS_DESCRIPTION
  )
    .replace("{0}", resolved)
    .replace("{1}", total);
}

export function computeMaxVisibleAmenities() {
  const width = Math.max(window.innerWidth - AMENITY_MIN_WIDTH, 0);
  return 1 + Math.trunc(width / AMENITY_WIDTH);
}

export function shiftReservedRoom(colleagueReservedRoom, rooms) {
  if (Object.keys(colleagueReservedRoom).length === 0) {
    const filterArr = [];
    rooms.map((room, index) => {
      if (!("reservedRoom" in room && room.reservedRoom)) {
        filterArr.push(room);
      }
      return true;
    });
    rooms = filterArr;
  } else {
    if (rooms[0] && rooms[0].name) {
      if (!rooms[0].reservedRoom) {
        rooms.unshift(colleagueReservedRoom);
      }
    }
    if (rooms.length === 0 && Object.keys(colleagueReservedRoom).length) {
      rooms.unshift(colleagueReservedRoom);
    }
    const filterArr = [];
    rooms.map((r) => {
      if (!(r.name === colleagueReservedRoom.name && r.reservedRoom !== true)) {
        filterArr.push(r);
      }
      return true;
    });
    rooms = filterArr;
  }
  return rooms;
}
