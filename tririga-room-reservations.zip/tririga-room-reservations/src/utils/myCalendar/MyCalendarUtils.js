/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

import styles from "../../app/TririgaRoomReservationApp.scss";

export const GROUP_HEADER_HEIGHT = parseInt(
  styles["group-header-height"].replace("px", "")
);

export const RESERVATION_LIST_TOP = 220;
export const RESERVATION_LIST_PAGE_HEIGHT_IN_PIXELS = 26 * 14;
export const RESERVATION_LIST_BUFFER_DAYS = 14;
export const RESERVATION_LIST_DATE_HEADER_FORMAT = "ddd MMM D";
export const RESERVATION_LIST_PAGINATION_THRESHOLD = 50;
