/*
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/

import { isEmpty, isEqual } from "lodash";
import moment from "moment-timezone";

export const areTimezonesDifferent = (buildingTimezone, defaultTimezone) => {
  if (!isEmpty(buildingTimezone) && !isEmpty(defaultTimezone)) {
    return !isEqual(
      moment.tz.zone(
        buildingTimezone.includes("[")
          ? getTimeZoneName(buildingTimezone)
          : buildingTimezone
      ).name,
      defaultTimezone
    );
  }
  return false;
};

export const getTimeZoneName = (timeZone) => {
  if (timeZone === null) return null;
  const regex = new RegExp("\\[(.*?)\\]").exec(timeZone);
  return regex && regex[1];
};

export const convertOffsetToMinutes = (timezone) => {
  const offset = timezone.split(":");
  const hour = Math.abs(parseInt(offset[0]));
  let min = 0;
  if (offset.length >= 2) {
    min = offset[1];
  }
  const time = hour * 60 + parseInt(min);
  return parseInt(timezone) < 0 ? -time : time;
};

export const getUtcOffset = (timezone, date = "") => {
  return !isEmpty(date) && timezone
    ? moment(date, "MM/DD/YYYY").tz(timezone).utcOffset()
    : moment.tz(timezone).utcOffset();
};

export const getTimezoneAbbr = (timezone, timezones) => {
  const momentAbbr = moment.tz(timezone).format("z");
  if (!isEmpty(timezone) || !isEmpty(timezones)) {
    if (!isNaN(momentAbbr)) {
      const zone = timezones.find(
        (tz) => getTimeZoneName(tz.englishName) === timezone
      );
      return moment().tz(getTimeZoneName(zone.englishName)).isDST()
        ? !isEmpty(zone.dstAbbr)
          ? zone.dstAbbr
          : zone.abbr
        : zone.abbr;
    }
  }
  return momentAbbr;
};

export const getTimeZoneDiff = (currentTz, otherTz) => {
  const selectedTz = moment.tz("1970-01-01T00:00:00", currentTz);
  const targetTz = moment.tz("1970-01-01T00:00:00", otherTz);
  return selectedTz.diff(targetTz, "minutes");
};
