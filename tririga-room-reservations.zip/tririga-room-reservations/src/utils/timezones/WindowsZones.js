/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */
/* Copyright © 2021-2023 Unicode, Inc. */

/* windowsZones.json converted from https://github.com/unicode-org/cldr/blob/master/common/supplemental/windowsZones.xml on  07/12/2020 */

/* 
  Reviewed for upgrade 7/29/2024
  Name: Mike Tremblay
*/

import windowsZones from "./windowsZones.json";
import { TimezoneUtils } from "..";
import { isEmpty } from "lodash";

const cachedTimezones = new Map();

export function ianaToWindows(ianaTimezone) {
  if (cachedTimezones.has(ianaTimezone)) {
    return cachedTimezones.get(ianaTimezone);
  }
  const timezone = windowsZones.mapTimezones.mapZone.find(
    (item) => item.type.indexOf(ianaTimezone) >= 0
  );
  let windowTimezone;
  if (timezone != null) {
    windowTimezone = timezone.other;
  } else {
    windowTimezone = null;
  }
  cachedTimezones.set(ianaTimezone, windowTimezone);
  return windowTimezone;
}

export function findTimezoneInWindowZones(timezone, timezones) {
  let mappedWindowsZone = "";
  const similarZones = windowsZones.mapTimezones.mapZone
    .filter((item) => item.type.includes(timezone))
    .map((item) => {
      if (isEmpty(mappedWindowsZone)) {
        mappedWindowsZone = item.other;
      }
      return item.type;
    });
  let similarZonesUnderMappedWindowsZone = [];
  if (!isEmpty(mappedWindowsZone)) {
    similarZonesUnderMappedWindowsZone = windowsZones.mapTimezones.mapZone
      .filter(
        (item) =>
          item.other === mappedWindowsZone && !item.type.includes(timezone)
      )
      .map((item) => item.type);
  }
  const allUniqueSimilarZones = [
    ...similarZones,
    ...similarZonesUnderMappedWindowsZone,
  ]
    .join(" ")
    .split(" ")
    .filter((item, index, self) => self.indexOf(item) === index);

  let timezonesNames = [];
  if (timezones) {
    timezonesNames = timezones.map((timezone) => {
      return TimezoneUtils.getTimeZoneName(timezone.englishName);
    });
  }
  return allUniqueSimilarZones.find(
    (zone) => timezonesNames.find((element) => zone === element) !== undefined
  );
}

export function windowsToIana(timezoneName) {
  const timezone = windowsZones.mapTimezones.mapZone
    .filter((item) => item.other.includes(timezoneName))
    .map((item) => {
      return item.type;
    });
  return `[${timezone[0]}]`;
}
