/* IBM Confidential‌ - OCO Source Materials‌ - (C) COPYRIGHT IBM CORP. 2021-2023 - The source code for this program is not published or otherwise‌ divested of its trade secrets, irrespective of what has been‌ deposited with the U.S. Copyright Office. */

// jest-dom adds custom jest matchers for asserting on DOM nodes.
// allows you to do things like:
// expect(element).toHaveTextContent(/react/i)
// learn more: https://github.com/testing-library/jest-dom

import "@testing-library/jest-dom";
import { initMessages } from "./utils/messages/ApplicationMessages";

jest.mock("./utils/history/AppHistory", () => ({
  getAppHistory: () => ({ location: "" }),
}));

jest.mock("@tririga/tririga-react-components", () => {
  const originalModule = jest.requireActual(
    "@tririga/tririga-react-components"
  );
  return {
    __esModule: true,
    ...originalModule,
    getTranslatedMessages: () => {
      throw new Error();
    },
  };
});

initMessages();
